import { BotApplication } from "./core/BotApplication";

const bootstrap = async () => {
  const app = new BotApplication();
  await app.start();
};

bootstrap().catch(error => {
  process.stderr.write(String(error));
  process.exitCode = 1;
});