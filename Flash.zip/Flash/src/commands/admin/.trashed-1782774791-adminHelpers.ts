import { DoubleUser, Limits } from "../../types/database";
import { VkMessageContext } from "../../core/mode/GameMode";
import crypto from "crypto";
import { TelegramService } from "../../services/TelegramService";

export const ADMIN_SESSION_LIFETIME_MS = 10 * 60 * 1000;
export const ADMIN_LOGIN_MAX_ATTEMPTS = 3;
export const ADMIN_LOGIN_BLOCK_MS = 5 * 60 * 1000;
export const ADMIN_LOGIN_CODE_LIFETIME_MS = 10 * 60 * 1000;

export const adminSessions = new Map<number, { expires: number }>();
export const adminLoginAttempts = new Map<number, { count: number; until: number }>();
export const adminLoginCodes = new Map<number, { hash: Buffer; expires: number }>();

export const getTgUserToken = (): string => {
  const token = process.env.TG_USER_TOKEN || process.env.VK_USER_TOKEN;
  if (!token) {
    throw new Error("VK_USER_TOKEN environment variable is not set");
  }
  return token;
};

export const getGiveawayVkGroupId = (): number => {
  const raw = process.env.GIVEAWAY_VK_GROUP_ID ?? "-212896919";
  const groupId = Number(raw);
  return Number.isFinite(groupId) && groupId !== 0 ? groupId : -212896919;
};

export const getGiveawayTgChannelId = (): string => {
  return process.env.GIVEAWAY_TG_CHANNEL_ID || "-1003635924096";
};

export const hasActiveAdminSession = (userId: number): boolean => {
  const session = adminSessions.get(userId);
  if (!session) return false;
  if (Date.now() > session.expires) {
    adminSessions.delete(userId);
    return false;
  }
  session.expires = Date.now() + ADMIN_SESSION_LIFETIME_MS;
  return true;
};

export const checkLoginBlocked = (userId: number): number => {
  const info = adminLoginAttempts.get(userId);
  if (!info) return 0;
  if (Date.now() > info.until) {
    adminLoginAttempts.delete(userId);
    return 0;
  }
  return info.until - Date.now();
};

export const registerLoginFail = (userId: number): void => {
  const info = adminLoginAttempts.get(userId) ?? { count: 0, until: 0 };
  info.count += 1;
  if (info.count >= ADMIN_LOGIN_MAX_ATTEMPTS) {
    info.until = Date.now() + ADMIN_LOGIN_BLOCK_MS;
    info.count = 0;
  }
  adminLoginAttempts.set(userId, info);
};

export const resetLoginAttempts = (userId: number): void => {
  adminLoginAttempts.delete(userId);
};

export const generateLoginCode = (): string => {
  return crypto.randomBytes(4).toString("hex").toUpperCase();
};

export const storeLoginCode = (userId: number, code: string): void => {
  const hash = crypto.createHash("sha256").update(code, "utf8").digest();
  adminLoginCodes.set(userId, { hash, expires: Date.now() + ADMIN_LOGIN_CODE_LIFETIME_MS });
};

export const verifyLoginCode = (userId: number, provided: string): boolean => {
  const info = adminLoginCodes.get(userId);
  if (!info) return false;
  if (Date.now() > info.expires) {
    adminLoginCodes.delete(userId);
    return false;
  }
  const providedHash = crypto.createHash("sha256").update(provided, "utf8").digest();
  const ok = crypto.timingSafeEqual(providedHash, info.hash);
  if (ok) {
    adminLoginCodes.delete(userId);
  }
  return ok;
};

export const randomPromoCode = (): string => {
  return crypto.randomBytes(4).toString("hex").toUpperCase();
};

export const safeEqualSha256 = (a: string, b: string): boolean => {
  const aHash = crypto.createHash("sha256").update(a, "utf8").digest();
  const bHash = crypto.createHash("sha256").update(b, "utf8").digest();
  return crypto.timingSafeEqual(aHash, bHash);
};

export const verifyAdminPassword = (provided: string): boolean => {
  const expectedHashHex = String(process.env.ADMIN_PASSWORD_SHA256 ?? "").trim().toLowerCase();
  if (expectedHashHex) {
    if (!/^[a-f0-9]{64}$/.test(expectedHashHex)) return false;
    const expectedHash = Buffer.from(expectedHashHex, "hex");
    const providedHash = crypto.createHash("sha256").update(provided, "utf8").digest();
    return crypto.timingSafeEqual(providedHash, expectedHash);
  }

  const expectedPlain = process.env.ADMIN_PASSWORD;
  if (expectedPlain) {
    return safeEqualSha256(provided, expectedPlain);
  }

  return false;
};

export const adminChatId = (): number => {
  const raw = 29 // process.env.ADMIN_CHAT_ID;
  const parsed = raw ? Number(raw) : 29;
  return Number.isFinite(parsed) ? parsed : 29;
};

export const adminTgChatId = (): number | null => {
  const raw = process.env.ADMIN_TG_CHAT_ID;
  if (!raw) return null;
  const parsed = Number(raw);
  return Number.isFinite(parsed) ? parsed : null;
};

export const auditChatId = (): number | null => {
  const raw = process.env.ADMIN_AUDIT_CHAT_ID;
  if (!raw) return 29;
  const parsed = Number(raw);
  return Number.isFinite(parsed) ? parsed : null;
};

export const canRunInAdminChat = (context: VkMessageContext): boolean => {
  if (!context.isChat) return false;
  if (context.platform === "tg") {
    const tgChatId = adminTgChatId();
    if (tgChatId === null) return true;
    return context.peerId === tgChatId;
  }
  return Boolean(context.chatId !== undefined && context.chatId === adminChatId());
};

export const hasFlag = (user: DoubleUser | undefined, flag: string): boolean => {
  return Boolean(user?.permiss && (user.permiss as any)[flag]);
};

export const isOwner = (user: DoubleUser | undefined): boolean => hasFlag(user, "owner");

export const isStaff = (user: DoubleUser | undefined): boolean =>
  hasFlag(user, "owner") ||
  hasFlag(user, "admin") ||
  hasFlag(user, "helper") ||
  hasFlag(user, "sponsor") ||
  hasFlag(user, "flash") ||
  hasFlag(user, "donate");

export const isCreator = (user: DoubleUser | undefined): boolean =>
  hasFlag(user, "owner") || hasFlag(user, "sponsor");

export const ensureCanUseAdminCommands = (user: DoubleUser | undefined): boolean => {
  if (!user) return false;
  if (user.ba?.bancmd) {
    return false;
  }
  return true;
};

export const resolveUserByUid = (users: DoubleUser[], uid: number): DoubleUser | undefined => {
  return users.find(u => u.uid === uid);
};

export const normalizeLimits = (value: unknown): Limits => {
  const v = (value ?? {}) as Partial<Limits>;
  const like = v.like ?? ({} as any);
  return {
    money: typeof v.money === "number" && Number.isFinite(v.money) ? v.money : 0,
    active_post: typeof v.active_post === "string" ? v.active_post : undefined,
    keyses: typeof v.keyses === "number" && Number.isFinite(v.keyses) ? v.keyses : 0,
    balance: typeof v.balance === "number" && Number.isFinite(v.balance) ? v.balance : 0,
    like: {
      give: typeof (like as any).give === "number" && Number.isFinite((like as any).give) ? (like as any).give : 0,
      active: Boolean((like as any).active)
    }
  };
};

export const formatBanDuration = (ms: number): string => {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (days > 0) {
    const remainingHours = hours % 24;
    return remainingHours > 0 ? `${days}д ${remainingHours}ч` : `${days}д`;
  }
  if (hours > 0) {
    const remainingMinutes = minutes % 60;
    return remainingMinutes > 0 ? `${hours}ч ${remainingMinutes}м` : `${hours}ч`;
  }
  if (minutes > 0) {
    const remainingSeconds = seconds % 60;
    return remainingSeconds > 0 ? `${minutes}м ${remainingSeconds}с` : `${minutes}м`;
  }
  return `${seconds}с`;
};

export const formatSessionTime = (ms: number): string => {
  const sec = Math.floor(ms / 1000);
  const min = Math.floor(sec / 60);
  return `${min}м ${sec % 60}с`;
};

export const sendUserNotification = async (
  user: DoubleUser,
  vkClient: any,
  message: string,
  telegramService?: TelegramService
): Promise<void> => {
  if (user.tgId && telegramService) {
    await telegramService
      .getTelegram()
      .api.sendMessage({
        chat_id: user.tgId,
        text: message
      })
      .catch(() => undefined);
  } else if (!user.tgId && vkClient) {
    await vkClient.api.messages
      .send({
        user_id: user.id,
        random_id: 0,
        message
      })
      .catch(() => undefined);
  }
};