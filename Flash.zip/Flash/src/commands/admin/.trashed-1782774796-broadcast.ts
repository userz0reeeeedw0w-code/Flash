import { CommandDefinition } from "../../core/command/Command";
import { botSend, VkMessageContext } from "../../core/mode/GameMode";
import { JsonDatabase } from "../../services/JsonDatabase";
import { AdminAuditService } from "../../services/AdminAuditService";
import { VkClients } from "../../services/VkClient";
import { DoubleChat, DoubleUser } from "../../types/database";
import { buildKeyboard } from "../../utils/keyboard";
import { normalizeTelegramText } from "../../utils/telegram";
import { TelegramClient } from "../../services/TelegramClient";

type BroadcastStats = {
  attempted: number;
  success: number;
  failed: number;
};

type BroadcastButton =
  | { kind: "text"; label: string; command: string }
  | { kind: "url"; label: string; url: string };

const sleep = (ms: number): Promise<void> => new Promise(resolve => setTimeout(resolve, ms));

const parseNumberEnv = (key: string, fallback: number): number => {
  const raw = process.env[key];
  const parsed = raw ? Number(raw) : fallback;
  return Number.isFinite(parsed) ? parsed : fallback;
};

const parseWallRef = (value: string): string | null => {
  const raw = String(value ?? "");
  const match = raw.match(/wall(-?\d+)_(\d+)/i);
  if (!match) return null;
  const ownerId = Number(match[1]);
  const itemId = Number(match[2]);
  if (!Number.isFinite(ownerId) || !Number.isFinite(itemId)) return null;
  return `wall${ownerId}_${itemId}`;
};

const extractWallRefsFromText = (text: string): string[] => {
  const refs: string[] = [];
  const seen = new Set<string>();
  const regex = /(?:https?:\/\/vk\.com\/)?(wall-?\d+_\d+)/gi;
  for (const match of text.matchAll(regex)) {
    const ref = parseWallRef(match[1] ?? "");
    if (ref && !seen.has(ref)) {
      seen.add(ref);
      refs.push(ref);
    }
  }
  return refs;
};

const parseButtonsFromText = (rawText: string): { cleanedText: string; buttons: BroadcastButton[] } => {
  const lines = String(rawText ?? "").split(/\r?\n/);
  const buttons: BroadcastButton[] = [];
  const kept: string[] = [];

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) {
      kept.push(line);
      continue;
    }

    const textBtn = trimmed.match(/^(?:кнопка|btn)\s*:\s*(.+?)\s*=\s*(.+)$/i);
    if (textBtn) {
      const label = String(textBtn[1] ?? "").trim();
      const command = String(textBtn[2] ?? "").trim();
      if (label && command) buttons.push({ kind: "text", label, command });
      continue;
    }

    const urlBtn = trimmed.match(/^(?:url)\s*:\s*(.+?)\s*=\s*(https?:\/\/\S+)$/i);
    if (urlBtn) {
      const label = String(urlBtn[1] ?? "").trim();
      const url = String(urlBtn[2] ?? "").trim();
      if (label && url) buttons.push({ kind: "url", label, url });
      continue;
    }

    kept.push(line);
  }

  return { cleanedText: kept.join("\n").trim(), buttons };
};

const chunk = <T>(items: T[], size: number): T[][] => {
  const out: T[][] = [];
  for (let i = 0; i < items.length; i += size) {
    out.push(items.slice(i, i + size));
  }
  return out;
};

const toVkAttachment = (att: any): string | null => {
  const type = typeof att?.type === "string" ? att.type : "";
  const ownerId = typeof att?.ownerId === "number" ? att.ownerId : Number(att?.owner_id ?? att?.ownerId ?? "");
  const id = typeof att?.id === "number" ? att.id : Number(att?.id ?? "");
  const accessKey = typeof att?.accessKey === "string" ? att.accessKey : typeof att?.access_key === "string" ? att.access_key : "";
  if (!Number.isFinite(ownerId) || !Number.isFinite(id)) return null;

  if (type === "photo") {
    return `photo${ownerId}_${id}${accessKey ? `_${accessKey}` : ""}`;
  }
  if (type === "wall") {
    return `wall${ownerId}_${id}`;
  }
  return null;
};

const extractMessageAttachments = (context: VkMessageContext): string[] => {
  const raw = (context.message as any)?.attachments;
  if (!Array.isArray(raw)) return [];
  const attachments: string[] = [];
  const seen = new Set<string>();
  for (const att of raw) {
    const encoded = toVkAttachment(att);
    if (encoded && !seen.has(encoded)) {
      seen.add(encoded);
      attachments.push(encoded);
    }
  }
  return attachments;
};

const withRetry = async <T>(fn: () => Promise<T>, retries: number, delayMs: number): Promise<T> => {
  let lastError: unknown;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error;
      if (attempt < retries && delayMs > 0) {
        await sleep(delayMs);
      }
    }
  }
  throw lastError;
};

const runPool = async <T>(
  items: T[],
  worker: (item: T) => Promise<void>,
  concurrency: number
): Promise<BroadcastStats> => {
  if (items.length === 0) return { attempted: 0, success: 0, failed: 0 };
  
  const stats: BroadcastStats = { attempted: items.length, success: 0, failed: 0 };
  let index = 0;
  
  const workers = Array.from({ length: Math.max(1, Math.min(concurrency, items.length)) }, async () => {
    while (index < items.length) {
      const current = items[index];
      index += 1;
      try {
        await worker(current);
        stats.success += 1;
      } catch {
        stats.failed += 1;
      }
    }
  });

  await Promise.all(workers);
  return stats;
};

const buildTelegramKeyboard = (buttons: BroadcastButton[]) => {
  if (buttons.length === 0) return undefined;
  
  const keyboardRows = chunk(buttons, 3);
  const inlineKeyboard = keyboardRows.map(row =>
    row.map(btn => {
      if (btn.kind === "url") {
        return { text: btn.label, url: btn.url };
      } else {
        return { text: btn.label, callback_data: btn.command };
      }
    })
  );
  
  return { inline_keyboard: inlineKeyboard };
};

export const createBroadcastCommand = (
  usersDb: JsonDatabase<DoubleUser[]>,
  chatsDb: JsonDatabase<DoubleChat[]>,
  clients: VkClients,
  telegramClient?: TelegramClient
): CommandDefinition<VkMessageContext> => {
  const auditService = new AdminAuditService(() => {
    const raw = process.env.ADMIN_AUDIT_CHAT_ID;
    if (!raw) return 5;
    const parsed = Number(raw);
    return Number.isFinite(parsed) ? parsed : null;
  });

  return {
    name: "admin.broadcast",
    pattern: /^(?:\/?рассылка)(?:\s+(--users|--chats|--all))?\s+([^]+)$/i,
    guard: context => Boolean(context.user && context.user.permiss && context.user.permiss.owner),
    handler: async context => {
      try {
        const rawFlag = String(context.match?.[1] ?? "").trim().toLowerCase();
        const rawText = String(context.match?.[2] ?? "").trim();
        if (!rawText) return;

        const audience = rawFlag === "--users" ? "users" : rawFlag === "--chats" ? "chats" : "all";

        const parsedButtons = parseButtonsFromText(rawText);
        const cleanedText = parsedButtons.cleanedText.length > 3500 ? parsedButtons.cleanedText.slice(0, 3500) : parsedButtons.cleanedText;
        const wallRefs = extractWallRefsFromText(rawText);
        const msgAttachments = extractMessageAttachments(context);
        const attachment = [...wallRefs, ...msgAttachments].slice(0, 10).join(",");
        const buttons = parsedButtons.buttons.slice(0, 10);

        const concurrency = parseNumberEnv("BROADCAST_CONCURRENCY", 5);
        const delayMs = parseNumberEnv("BROADCAST_DELAY_MS", 25);
        const retries = parseNumberEnv("BROADCAST_RETRIES", 1);

        const users = usersDb.load();
        const chats = chatsDb.load();

        const vkUsers: typeof users = [];
        const tgUsers: typeof users = [];
        const vkChats: typeof chats = [];
        const tgChats: typeof chats = [];
        
        if (audience !== "chats") {
          for (const u of users) {
            if (u.uvedu) {
              if (u.tgId) tgUsers.push(u);
              else vkUsers.push(u);
            }
          }
        }
        
        if (audience !== "users") {
          for (const c of chats) {
            if (c.uvedu) {
              if (c.id > 0) vkChats.push(c);
              else tgChats.push(c);
            }
          }
        }

        await botSend(context, 
          `📢 рассылка началась\n` +
            `👥 Получатели:\n` +
            `   📱 ВК пользователи: ${vkUsers.length}\n` +
            `   🤖 Telegram пользователи: ${tgUsers.length}\n` +
            `   💬 ВК чаты: ${vkChats.length}\n` +
            `   💬 Telegram чаты: ${tgChats.length}\n` +
            `⚙️ concurrency=${String(concurrency)} delayMs=${String(delayMs)} retries=${String(retries)}`
        );

        const extraKeyboardRows = chunk(
          buttons.map(b =>
            b.kind === "url" ? ({ label: b.label, url: b.url } as any) : ({ label: b.label, command: b.command } as any)
          ),
          3
        );

        const vkUserKeyboard = buildKeyboard({
          inline: true,
          buttons: [[{ label: "Уведы выкл", command: "Уведы выкл" }], ...extraKeyboardRows]
        });

        const vkChatKeyboard =
          extraKeyboardRows.length > 0
            ? buildKeyboard({
                inline: true,
                buttons: extraKeyboardRows
              })
            : undefined;

        const tgKeyboard = buildTelegramKeyboard(buttons);
        
        const tgUserMessageText = normalizeTelegramText(
          `✅ Уведомление: ${cleanedText}\n🌐 Уведомление пришло по подписке на уведомления. Чтобы выключить: /уведы_выкл`
        );
        const tgUserKeyboard = {
          inline_keyboard: [
            [{ text: "🔕 Уведы выкл", callback_data: "Уведы выкл" }],
            ...(tgKeyboard?.inline_keyboard || [])
          ]
        };

        const tgChatMessageText = normalizeTelegramText(
          `✅ Уведомление: @all ${cleanedText}\n🔍 Для отключения рассылки в чате: /увед_чата_выкл`
        );
        const tgChatKeyboard = tgKeyboard?.inline_keyboard?.length 
          ? { inline_keyboard: tgKeyboard.inline_keyboard }
          : undefined;

        const [vkUserStats, tgUserStats, vkChatStats, tgChatStats] = await Promise.all([
          runPool(
            vkUsers,
            async u => {
              await withRetry(
                async () => {
                  await clients.group.api.messages.send({
                    user_id: u.id,
                    random_id: 0,
                    message:
                      `✅ Уведомление: ${cleanedText}\n` +
                      `🌐 Уведомление пришло по подписке на уведомления. Чтобы выключить: "уведы выкл"`,
                    keyboard: vkUserKeyboard,
                    attachment: attachment || undefined
                  });
                },
                retries,
                delayMs
              );
            },
            concurrency
          ),
          (async () => {
            if (telegramClient && tgUsers.length > 0) {
              return await runPool(
                tgUsers,
                async u => {
                  await withRetry(
                    async () => {
                      await telegramClient.sendMessage(Number(u.tgId), tgUserMessageText, {
                        reply_markup: tgUserKeyboard
                      });
                    },
                    retries,
                    delayMs
                  );
                },
                concurrency
              );
            }
            if (tgUsers.length > 0 && !telegramClient) {
              console.warn("Telegram бот не инициализирован, пропускаем рассылку Telegram пользователям");
              return { attempted: tgUsers.length, success: 0, failed: tgUsers.length };
            }
            return { attempted: 0, success: 0, failed: 0 };
          })(),
          runPool(
            vkChats,
            async c => {
              await withRetry(
                async () => {
                  await clients.group.api.messages.send({
                    chat_id: c.id,
                    random_id: 0,
                    message: `✅ @all ${cleanedText}\n🔍 Для отключения рассылки в чате: "увед_чата_выкл"`,
                    attachment: attachment || undefined,
                    keyboard: vkChatKeyboard
                  });
                },
                retries,
                delayMs
              );
            },
            concurrency
          ),
          (async () => {
            if (telegramClient && tgChats.length > 0) {
              return await runPool(
                tgChats,
                async c => {
                  await withRetry(
                    async () => {
                      await telegramClient.sendMessage(Number(c.id), tgChatMessageText, {
                        reply_markup: tgChatKeyboard
                      });
                    },
                    retries,
                    delayMs
                  );
                },
                concurrency
              );
            }
            if (tgChats.length > 0 && !telegramClient) {
              console.warn("Telegram бот не инициализирован, пропускаем рассылку в Telegram чаты");
              return { attempted: tgChats.length, success: 0, failed: tgChats.length };
            }
            return { attempted: 0, success: 0, failed: 0 };
          })()
        ]);

        const totalSuccess = vkUserStats.success + tgUserStats.success + vkChatStats.success + tgChatStats.success;
        const totalFailed = vkUserStats.failed + tgUserStats.failed + vkChatStats.failed + tgChatStats.failed;
        const totalAttempted = vkUserStats.attempted + tgUserStats.attempted + vkChatStats.attempted + tgChatStats.attempted;

        let totalVkUsersCount = 0, totalTgUsersCount = 0;
        for (const u of users) {
          if (u.tgId) totalTgUsersCount++;
          else totalVkUsersCount++;
        }

        await botSend(context, 
          `🛑 рассылка завершена:\n\n` +
            `📊 Общая статистика:\n` +
            ` ✅ Успешно: ${totalSuccess}/${totalAttempted}\n` +
            ` 🚫 Ошибок: ${totalFailed}\n\n` +
            `👤 VK Users:\n` +
            ` ✅ Успешных: ${vkUserStats.success}\n` +
            ` 🚫 Ошибок: ${vkUserStats.failed}\n\n` +
            `🤖 Telegram Users:\n` +
            ` ✅ Успешных: ${tgUserStats.success}\n` +
            ` 🚫 Ошибок: ${tgUserStats.failed}\n\n` +
            `💬 VK Chats:\n` +
            ` ✅ Успешных: ${vkChatStats.success}\n` +
            ` 🚫 Ошибок: ${vkChatStats.failed}\n\n` +
            `💬 Telegram Chats:\n` +
            ` ✅ Успешных: ${tgChatStats.success}\n` +
            ` 🚫 Ошибок: ${tgChatStats.failed}\n\n` +
            `📈 Всего пользователей: ${users.length} (ВК: ${totalVkUsersCount}, TG: ${totalTgUsersCount})\n` +
            `🌐 Всего чатов: ${chats.length} (ВК: ${vkChats.length}, TG: ${tgChats.length})\n`

        );

        if (context.vk && context.user) {
          auditService.setVkClient(context.vk);
          await auditService.logAdminAction("Рассылка сообщений", context.user, {
            "Аудитория": audience,
            "VK Users успешно": vkUserStats.success,
            "Telegram Users успешно": tgUserStats.success,
            "VK Chats успешно": vkChatStats.success,
            "Telegram Chats успешно": tgChatStats.success,
            "Всего ошибок": totalFailed
          });
        }
      } catch (error) {
        console.error("admin.broadcast", error);
        await botSend(context, "Ошибка при выполнении рассылки.");
      }
    }
  };
};
