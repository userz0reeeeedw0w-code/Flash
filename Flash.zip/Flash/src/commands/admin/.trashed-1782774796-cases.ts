import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import * as adminHelpers from "./adminHelpers";

export const createCaseCommands = (): CommandDefinition<VkMessageContext>[] => {
  const commands: CommandDefinition<VkMessageContext>[] = [];

  commands.push({
    name: "admin.giveCase1",
    pattern: /^(?:выдатьк1)\s+(\d+)\s+(\d+)$/i,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const uid = Number(context.match?.[1]);
        const count = Number(context.match?.[2]);
        const target = context.state.users?.find(u => u.uid === uid || u.id === uid);
        if (!target) return botSend(context, "игрок не найден.");
        target.case1 = (target.case1 ?? 0) + count;
        await botSend(context, `вы выдали ${count} мини‑кейсов игроку ${target.tag}`);
      } catch (error) {
        console.error("admin.giveCase1", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.giveCase3",
    pattern: /^(?:выдатьк3)\s+(\d+)\s+(\d+)$/i,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const uid = Number(context.match?.[1]);
        const count = Number(context.match?.[2]);
        const target = context.state.users?.find(u => u.uid === uid || u.id === uid);
        if (!target) return botSend(context, "игрок не найден.");
        target.case3 = (target.case3 ?? 0) + count;
        await botSend(context, `вы выдали ${count} пиратских кейсов игроку ${target.tag}`);
      } catch (error) {
        console.error("admin.giveCase3", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  return commands;
};
