import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import * as adminHelpers from "./adminHelpers";

export const AdminHelp: CommandDefinition<VkMessageContext> = {
    name: "admin.help",
    pattern: /^админпомощь$/i,
    guard: context =>
        Boolean(
            context.user &&
            adminHelpers.isStaff(context.user) &&
            adminHelpers.canRunInAdminChat(context)
        ),
    handler: async context => {
        await botSend(context,
            "Админ‑панель:\n" +
            "• входадмин <пароль> — войти в админ‑панель\n" +
            "• выходадмин — выйти из админ‑панели\n" +
            "• админстатус — статус вашей сессии\n" +
            "• админы — список активных админов\n" +
            "• админпомощь+ — расширенная справка (нужна активная сессия)"
        );
    }
}

export const AdminHelpFull: CommandDefinition<VkMessageContext> = {
    name: "admin.helpExtended",
    pattern: /^админпомощь\+$/i,
    guard: context => Boolean(
        context.user &&
        adminHelpers.isStaff(context.user) &&
        adminHelpers.canRunInAdminChat(context) &&
        adminHelpers.hasActiveAdminSession(context.user.id)
    ), 
    handler: async context => {
        await botSend(context,
            "Расширенная админ‑справка:\n" +
            "Баны:\n" +
            "• бан <uid> <время?> <причина>\n" +
            "• разбан <uid>\n" +
            "• бантоп <uid> / разбантоп <uid>\n" +
            "• банбонус <uid> / разбанбонус <uid>\n\n" +
            "Финансы:\n" +
            "• выдатьфп <id|ссылка> <сумма>\n" +
            "• лнастр — лимиты\n" +
            "• лбал <число>\n" +
            "• лфп <число>\n" +
            "• лкейс <число>\n" +
            "• лнагр <число>\n" +
            "• лсост <вкл|выкл>\n\n" +
            "Права:\n" +
            "• датьпривилегию <id> <флаг>\n" +
            "• снятьпривилегию <id> <флаг>\n" +
            "• give <uid> — иммунитет\n" +
            "• отобрать <uid> — снять иммунитет\n\n" +
            "Прочее:\n" +
            "• логи <uid>\n" +
            "• гет <id|ссылка>\n" +
            "• создать промо <активаций> <сумма>\n" +
            "• создать персональное промо <uid> <сумма>\n" +
            "• обнулить промо <код>\n" +
            "• фейк <вкл|выкл>\n" +
            "• лимит <uid> <число>\n" +
            "• выдатьк1 <uid> <число>\n" +
            "• выдатьк3 <uid> <число>"
        );
    }
}
    