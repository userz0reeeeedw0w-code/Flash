import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext } from "../../core/mode/GameMode";
import { JsonDatabase } from "../../services/JsonDatabase";
import { DoubleUser, Limits } from "../../types/database";
import { TelegramService } from "../../services/TelegramService";
import { PasswordAdminCommand, LoginAdminCommand, LogoutAdminCommand } from "./panel";
import { AdminListCommand } from "./list";
import { ChatAdminCommands } from "./chatid";
import { AdminHelp, AdminHelpFull } from "./help";
import { createBanCommands } from "./ban";
import { createMoneyCommands } from "./money";
import { createPermissionCommands } from "./permissions";
import { createLimitCommands } from "./limits";
import { createLogCommands } from "./logs";
import { createProfileCommands } from "./profile";
import { createCaseCommands } from "./cases";
import { createPromoCommands } from "./promo";
import { createGiveawayCommands } from "./giveaway";

export const createAdminCommands = (
  limitsDb: JsonDatabase<Limits>,
  usersDb: JsonDatabase<DoubleUser[]>,
  telegramService?: TelegramService
): CommandDefinition<VkMessageContext>[] => {
  return [
    AdminHelp,
    AdminHelpFull,
    AdminListCommand,
    ChatAdminCommands,
    PasswordAdminCommand,
    LoginAdminCommand,
    LogoutAdminCommand,
    ...createBanCommands(usersDb, telegramService),
    ...createMoneyCommands(limitsDb, usersDb, telegramService),
    ...createPermissionCommands(telegramService),
    ...createLimitCommands(limitsDb),
    ...createLogCommands(),
    ...createProfileCommands(),
    ...createCaseCommands(),
    ...createPromoCommands(),
    ...createGiveawayCommands(usersDb)
  ];
};
