import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { JsonDatabase } from "../../services/JsonDatabase";
import { DoubleUser, Limits } from "../../types/database";
import * as adminHelpers from "./adminHelpers";

export const createLimitCommands = (
  limitsDb: JsonDatabase<Limits>
): CommandDefinition<VkMessageContext>[] => {
  const commands: CommandDefinition<VkMessageContext>[] = [];

  commands.push({
    name: "admin.limits",
    pattern: /^(?:лнастр)$/i,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isOwner(context.user) &&
      adminHelpers.canRunInAdminChat(context)
    ),
    handler: async context => {
      try {
        const limits = adminHelpers.normalizeLimits(limitsDb.load());
        const likeState = limits.like?.active ? "🟢 Включено" : "🔴 Выключено";
        const likeGive = limits.like?.give ?? 0;
        await botSend(
          context,
          `📊 Текущие лимиты:\n\n` +
          `Баланс: ${limits.balance ?? 0} FP\n` +
          `Выдача FP: ${limits.money ?? 0} FP\n` +
          `Кейсы: ${limits.keyses ?? 0}\n` +
          `Лайк награда: ${likeGive} FP (${likeState})`
        );
      } catch (error) {
        console.error("admin.limits", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.limitsBalance",
    pattern: /^(?:лбал)\s+(\d+)$/i,
    guard: context => Boolean(context.user && adminHelpers.isOwner(context.user) && adminHelpers.canRunInAdminChat(context)),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const amount = Number(context.match?.[1] ?? "");
        const limits = adminHelpers.normalizeLimits(limitsDb.load());
        limits.balance = amount;
        limitsDb.save(limits);
        await botSend(context, `лимит баланса изменён на ${amount} FP`);
      } catch (error) {
        console.error("admin.limitsBalance", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.limitsMoney",
    pattern: /^(?:лфп)\s+(\d+)$/i,
    guard: context => Boolean(context.user && adminHelpers.isOwner(context.user) && adminHelpers.canRunInAdminChat(context)),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const amount = Number(context.match?.[1] ?? "");
        const limits = adminHelpers.normalizeLimits(limitsDb.load());
        limits.money = amount;
        limitsDb.save(limits);
        await botSend(context, `лимит выдачи FP изменён на ${amount} FP`);
      } catch (error) {
        console.error("admin.limitsMoney", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.limitsKeys",
    pattern: /^(?:лкейс)\s+(\d+)$/i,
    guard: context => Boolean(context.user && adminHelpers.isOwner(context.user) && adminHelpers.canRunInAdminChat(context)),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const amount = Number(context.match?.[1] ?? "");
        const limits = adminHelpers.normalizeLimits(limitsDb.load());
        limits.keyses = amount;
        limitsDb.save(limits);
        await botSend(context, `лимит кейсов изменён на ${amount}`);
      } catch (error) {
        console.error("admin.limitsKeys", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.limitsLikeGive",
    pattern: /^(?:лнагр)\s+(\d+)$/i,
    guard: context => Boolean(context.user && adminHelpers.isOwner(context.user) && adminHelpers.canRunInAdminChat(context)),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const amount = Number(context.match?.[1] ?? "");
        const limits = adminHelpers.normalizeLimits(limitsDb.load());
        limits.like = limits.like ?? { give: 0, active: false };
        limits.like.give = amount;
        limitsDb.save(limits);
        await botSend(context, `награда за лайк изменена на ${amount} FP`);
      } catch (error) {
        console.error("admin.limitsLikeGive", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.limitsLikeState",
    pattern: /^(?:лсост)\s+(вкл|выкл)$/i,
    guard: context => Boolean(context.user && adminHelpers.isOwner(context.user) && adminHelpers.canRunInAdminChat(context)),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const enable = String(context.match?.[1] ?? "").toLowerCase() === "вкл";
        const limits = adminHelpers.normalizeLimits(limitsDb.load());
        limits.like = limits.like ?? { give: 0, active: false };
        limits.like.active = enable;
        limitsDb.save(limits);
        await botSend(context, `состояние настройки: ${enable ? "Включено" : "Выключено"}`);
      } catch (error) {
        console.error("admin.limitsLikeState", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.setLimit",
    pattern: /^(?:лимит)\s+(\d+)\s+(\d+)$/i,
    guard: context => Boolean(context.user && adminHelpers.isStaff(context.user) && adminHelpers.canRunInAdminChat(context) && adminHelpers.hasActiveAdminSession(context.user.id)),
    handler: async context => {
      try {
        const uid = Number(context.match?.[1]);
        const amount = Number(context.match?.[2]);

        if (amount < 1) {
          await botSend(context, "укажите корректный лимит.");
          return;
        }

        const target = context.state.users?.find(u => u.uid === uid || u.id === uid);
        if (!target) {
          await botSend(context, "игрок не найден.");
          return;
        }

        target.limit = amount;
        target.ba = target.ba ?? {};
        target.ba.limits_give = amount;

        await botSend(context, `лимит выдачи игрока ${target.tag} установлен на ${amount} FP`);
      } catch (error) {
        console.error("admin.setLimit", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "common.selfGive",
    pattern: /^(?:выдать)\s+(.+)$/i,
    guard: context => Boolean(context.user),
    handler: async context => {
      try {
        const user = context.user;
        if (!user) return;

        let raw = String(context.match?.[1] ?? "").trim();

        raw = raw.replace(/(\.|,)/g, "");
        raw = raw.replace(/(к|k)/gi, "000");
        raw = raw.replace(/(м|m)/gi, "000000");
        raw = raw.replace(/(b|б)/gi, "000000000");

        if (user.ba?.limits_give !== undefined) {
          raw = raw.replace(/(вабанк|вобанк|все|всё)/gi, String(user.ba.limits_give));
        }

        if (!Number(raw)) {
          await botSend(context, "укажите корректную сумму.");
          return;
        }

        const amount = Math.floor(Number(raw));

        if (!user.permiss.donate && !user.permiss.flash && !user.permiss.sponsor) {
          await botSend(context, "вам нельзя.");
          return;
        }

        if (amount < 1) {
          await botSend(context, "вы не можете выдавать ниже 1 FP");
          return;
        }

        user.ba = user.ba ?? {};
        user.ba.limits_give = user.ba.limits_give ?? user.limit ?? 0;
        user.ba.cooldown = user.ba.cooldown ?? 0;

        if (user.ba.cooldown > Date.now()) {
          const left = user.ba.cooldown - Date.now();
          await botSend(context, `следующая выдача будет доступна через ${Math.floor(left / 1000)} сек.`);
          return;
        }

        if (user.ba.limits_give === 0) {
          user.ba.limits_give = user.limit ?? 0;
          await botSend(context, "лимит обновлён, можно выдавать со следующей команды.");
          return;
        }

        if (amount > user.ba.limits_give) {
          await botSend(context, `введите сумму, меньше или равную ${user.ba.limits_give} FP`);
          return;
        }

        user.balance += amount;
        user.ba.limits_give -= amount;

        if (user.ba.limits_give === 0) {
          user.ba.cooldown = Date.now() + 4 * 60 * 60 * 1000;
          await botSend(context, `вы выдали себе ${amount} FP\nлимит достигнут, попробуйте позже.`);
          return;
        }

        await botSend(context, `вы выдали себе ${amount} FP\nостаток лимита: ${user.ba.limits_give} FP`);
      } catch (error) {
        console.error("common.selfGive", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  return commands;
};
