import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { formatTime } from "../../services/MessageLogService";
import { messageLogService } from "../../handlers/VkMessageHandler";
import * as adminHelpers from "./adminHelpers";

export const createLogCommands = (): CommandDefinition<VkMessageContext>[] => {
  const commands: CommandDefinition<VkMessageContext>[] = [];

  commands.push({
    name: "admin.logs",
    pattern: /^(?:логи)\s+(\d+)$/i,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const uid = Number(context.match?.[1] ?? "");
        if (!Number.isFinite(uid)) {
          await botSend(context, "Укажите ID игрока из его профиля.");
          return;
        }

        const users = context.state.users ?? [];
        const target = adminHelpers.resolveUserByUid(users, uid);
        if (!target) {
          await botSend(context, "Такого человека нет.");
          return;
        }

        const entries = messageLogService.list(target.id);
        if (entries.length === 0) {
          await botSend(context, "Человек не написал ни одного сообщения.");
          return;
        }

        const lines = entries.map(e => `⌛ » ${formatTime(e.time)} — ${e.text}`).join("\n");
        await botSend(context, `логи игрока «${target.tag}»:\n${lines}`);
      } catch (error) {
        console.error("admin.logs", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  return commands;
};
