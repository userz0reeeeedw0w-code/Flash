import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { JsonDatabase } from "../../services/JsonDatabase";
import { AdminAuditService } from "../../services/AdminAuditService";
import { TelegramService } from "../../services/TelegramService";
import { DoubleUser, Limits } from "../../types/database";
import { resolveResource } from "vk-io";
import * as adminHelpers from "./adminHelpers";
import { sendUserNotification } from "./adminHelpers";

export const createMoneyCommands = (
  limitsDb: JsonDatabase<Limits>,
  usersDb: JsonDatabase<DoubleUser[]>,
  telegramService?: TelegramService
): CommandDefinition<VkMessageContext>[] => {
  const auditService = new AdminAuditService(adminHelpers.auditChatId);
  const commands: CommandDefinition<VkMessageContext>[] = [];

  commands.push({
    name: "admin.giveMoney",
    pattern: /^(?:выдатьфп)(?:\s(?<id>\d+)?(?<link>(?:http?s:\/\/vk\.(?:ru|com)\/(?:id\d+|\w+))|(?:\[id\d+\|@?\w+\]))?)?(?:\s(?<amount>(?:[0-9\.]+[kкmм]*|вс[её]|all|в[ао]банк)))$/i,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }

        const { user, state, vk } = context;

        if (!user || !vk || !state || !state.users) {
          return;
        }

        const adminGiveMoneyCmd = commands.find(entry => entry.name === 'admin.giveMoney');
        if (!adminGiveMoneyCmd) return;

        const groups = (context.match ?? context.text.match(adminGiveMoneyCmd.pattern))?.groups as
              | { id?: string; link?: string; amount?: string }
              | undefined;
        
        if (!groups || !groups.amount) {
          await botSend(context, "укажите сумму, которую хотите выдать.");
          return;
        }

        let targetId: number | null = null;
        if (groups.id) {
          targetId = Number(groups.id);
        } else if (groups.link) {
          const match = groups.link.match(/https?:\/\/vk\.(?:ru|com)\/([a-zA-Z0-9_.-]+)/i);
          if (match) {
            const screenName = match[1];
            
            const explicitIdMatch = screenName.match(/^(?:id|club|public|event)(\d+)$/);
        
            if (explicitIdMatch) {
              targetId = Number(explicitIdMatch[1]);
            } else {
              try {
                const response = await resolveResource({
                  api: vk.api,
                  resource: screenName
                });
                
                targetId = response?.type == "user" ? response?.id : null;
              } catch (e) {
                console.error('Ошибка при резолве ссылки:', e);
                targetId = null;
              }
            }
          }
        } else if (!groups.id && !groups.link) {
          // Проверяем reply_to_message для Telegram
          if (context.platform === "tg" && (context.message as any).reply_to_message?.from?.id) {
            targetId = (context.message as any).reply_to_message.from.id;
          } else {
            targetId = context.message.hasReplyMessage
            ? context.message.replyMessage?.senderId ?? null
            : context.message.hasForwards
            ? context.message.forwards[0]?.senderId ?? null
            : null;
          }
        }
        if (!targetId) {
          await botSend(context, "вы указали неправильную ссылку.");
          return;
        }

        const allUsers = state.users;
        const targetUser = allUsers.find(entry => entry.id === targetId || entry.uid === targetId || entry.tgId === targetId);

        if (!targetUser) {
          await botSend(context, "этот игрок не играет в бота.");
          return;
        }

        let rawAmount = String(groups?.amount ?? "").toLowerCase();
        let formatAmountStr = rawAmount.replace(/[.,]/g, "");
        formatAmountStr = formatAmountStr.replace(/(к|k)/g, "000");
        formatAmountStr = formatAmountStr.replace(/(м|m)/g, "000000");
        if (/^(вс[её]|all)$/i.test(rawAmount)) {
          const limits = adminHelpers.normalizeLimits(limitsDb.load());
          formatAmountStr = String(limits.money ?? 0);
        }

        let amount = Math.floor(Number(formatAmountStr) || 0);
        if (!Number.isFinite(amount) || amount <= 0) {
          await botSend(context, "укажите сумму, которую хотите выдать.");
          return;
        }

        const limits = adminHelpers.normalizeLimits(limitsDb.load());
        if (amount > Number(limits.money)) {
          await botSend(context, `введите сумму, меньше или равную ${String(limits.money)} FP`);
          return;
        }

        targetUser.balance = (targetUser.balance ?? 0) + amount;

        if (context.vk) auditService.setVkClient(context.vk);
        await auditService.logTargetAction("Выдача FP", context.user, targetUser, { "Сумма (FP)": amount });

        try {
          await sendUserNotification(
            targetUser,
            context.vk,
            `▶ Админ ${context.user?.tag} выдал вам ${amount} FP`,
            telegramService
          );
        } catch (e) {}

        // Форматируем вывод в зависимости от платформы
        const targetDisplay = context.platform === "tg" ? `${targetUser.tag} (UID: ${targetUser.uid})` : targetUser.tag;
        await botSend(context, `вы выдали ${targetDisplay} ${String(amount)} FP`);
      } catch (err) {
        console.error(err);
      }
    }
  });

  return commands;
};
