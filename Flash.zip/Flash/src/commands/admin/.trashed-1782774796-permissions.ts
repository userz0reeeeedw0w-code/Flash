import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { AdminAuditService } from "../../services/AdminAuditService";
import { TelegramService } from "../../services/TelegramService";
import { DoubleUser } from "../../types/database";
import * as adminHelpers from "./adminHelpers";
import { sendUserNotification } from "./adminHelpers";

export const createPermissionCommands = (
  telegramService?: TelegramService
): CommandDefinition<VkMessageContext>[] => {
  const auditService = new AdminAuditService(adminHelpers.auditChatId);
  const commands: CommandDefinition<VkMessageContext>[] = [];

  commands.push({
    name: "admin.grantPermissionById",
    pattern: /^(?:датьпривилегию|датьправо)\s+(\d+)\s+(\w+)$/i,
    guard: context => Boolean(context.user && adminHelpers.isCreator(context.user) && adminHelpers.canRunInAdminChat(context)),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const vkId = Number(context.match?.[1] ?? "");
        const rawFlag = String(context.match?.[2] ?? "").toLowerCase();
        if (!vkId || !rawFlag) return await botSend(context, "Неверный синтаксис. Использование: датьпривилегию <uid> <флаг>");

        const users = context.state.users ?? [];
        const target = users.find(u => u.id === vkId || u.uid === vkId);
        if (!target) return await botSend(context, "Игрок с таким ID не найден.");

        const allowedFlags: Record<string, string> = {
          owner: "owner",
          admin: "admin",
          helper: "helper",
          sponsor: "sponsor",
          flash: "flash",
          donate: "donate",
          vip: "vip",
          premium: "premium",
          legend: "legend"
        };

        const flagKey = allowedFlags[rawFlag] ?? rawFlag;
        target.permiss = target.permiss ?? ({} as any);
        (target.permiss as any)[flagKey] = true;

        if (context.vk) auditService.setVkClient(context.vk);
        await auditService.logPermissionChange(flagKey, context.user, target, true);

        try {
          await sendUserNotification(
            target,
            context.vk,
            `Вам выдана привилегия: ${flagKey}`,
            telegramService
          );
        } catch {}

        await botSend(context, `привилегия ${flagKey} выдана игроку *id${target.id} (${target.tag})`);
      } catch (e) {
        console.error(e);
        await botSend(context, "Ошибка при выдаче привилегии.");
      }
    }
  });

  commands.push({
    name: "admin.revokePermissionById",
    pattern: /^(?:снятьпривилегию|отобратьправо)\s+(\d+)\s+(\w+)$/i,
    guard: context => Boolean(context.user && adminHelpers.isCreator(context.user) && adminHelpers.canRunInAdminChat(context)),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const vkId = Number(context.match?.[1] ?? "");
        const rawFlag = String(context.match?.[2] ?? "").toLowerCase();
        if (!vkId || !rawFlag) return await botSend(context, "Неверный синтаксис. Использование: снятьпривилегию <uid> <флаг>");

        const users = context.state.users ?? [];
        const target = users.find(u => u.id === vkId || u.uid === vkId);
        if (!target) return await botSend(context, "Игрок с таким ID не найден.");

        target.permiss = target.permiss ?? ({} as any);
        (target.permiss as any)[rawFlag] = false;

        if (context.vk) auditService.setVkClient(context.vk);
        await auditService.logPermissionChange(rawFlag, context.user, target, false);

        try {
          await sendUserNotification(
            target,
            context.vk,
            `У вас отозвана привилегия: ${rawFlag}`,
            telegramService
          );
        } catch {}

        await botSend(context, `привилегия ${rawFlag} снята у игрока id${target.id} (${target.tag})`);
      } catch (e) {
        console.error(e);
        await botSend(context, "Ошибка при снятии привилегии.");
      }
    }
  });

  commands.push({
    name: "admin.grantImmunity",
    pattern: /^(?:датьиммунитет)\s+(\d+)$/i,
    guard: context => Boolean(context.user && adminHelpers.isCreator(context.user) && adminHelpers.canRunInAdminChat(context)),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const uid = Number(context.match?.[1] ?? "");
        const users = context.state.users ?? [];
        const target = Number.isFinite(uid) ? adminHelpers.resolveUserByUid(users, uid) : undefined;
        if (!target) {
          await botSend(context, "Неверный ID игрока.");
          return;
        }
        target.ba = target.ba ?? {};
        target.ba.anti_ban = true;
        if (context.vk) auditService.setVkClient(context.vk);
        await auditService.logTargetAction("Выдача иммунитета", context.user, target);
        await botSend(context, `игроку *id${target.id} (${target.tag}) выдан иммунитет от админ команд`);
      } catch (error) {
        console.error("admin.grantImmunity", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.revokeImmunity",
    pattern: /^(?:снятьиммунитет)\s+(\d+)$/i,
    guard: context => Boolean(context.user && adminHelpers.isCreator(context.user) && adminHelpers.canRunInAdminChat(context)),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const uid = Number(context.match?.[1] ?? "");
        const users = context.state.users ?? [];
        const target = Number.isFinite(uid) ? adminHelpers.resolveUserByUid(users, uid) : undefined;
        if (!target) {
          await botSend(context, "Неверный ID игрока.");
          return;
        }
        target.ba = target.ba ?? {};
        target.ba.anti_ban = false;
        if (context.vk) auditService.setVkClient(context.vk);
        await auditService.logTargetAction("Снятие иммунитета", context.user, target);
        await botSend(context, `иммунитет снят у игрока *id${target.id} (${target.tag})`);
      } catch (error) {
        console.error("admin.revokeImmunity", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  return commands;
};
