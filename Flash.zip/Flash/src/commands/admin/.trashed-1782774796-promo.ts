import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import * as adminHelpers from "./adminHelpers";
import { readPromoStore, writePromoStore } from "../common/promo";

export const createPromoCommands = (): CommandDefinition<VkMessageContext>[] => {
  const commands: CommandDefinition<VkMessageContext>[] = [];

  commands.push({
    name: "admin.createPromo",
    pattern: /^(?:создать\s+промо)\s+(\d+)\s+(\d+)$/i,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }

        const activations = Number(context.match?.[1] ?? "");
        const amount = Number(context.match?.[2] ?? "");

        if (activations <= 0 || amount <= 0) {
          await botSend(context, "укажите корректные значения.");
          return;
        }

        const data = readPromoStore();
        let promo = adminHelpers.randomPromoCode();
        while (data[promo]) promo = adminHelpers.randomPromoCode();

        data[promo] = {
          code: promo,
          activations,
          amount,
          used: 0,
          created: Date.now(),
          personal: null,
          users: []
        };

        writePromoStore(data);

        await botSend(context, `промокод создан:\nКод: ${promo}\nАктиваций: ${activations}\nСумма: ${amount} FP`);
      } catch (e) {
        console.error("admin.createPromo", e);
        await botSend(context, "Ошибка при создании промокода.");
      }
    }
  });

  commands.push({
    name: "admin.resetPromo",
    pattern: /^(?:обнулить\s+промо)\s+([A-Z0-9]+)$/i,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }

        const code = String(context.match?.[1] ?? "").toUpperCase();

        const data = readPromoStore();
        if (Object.keys(data).length === 0) {
          await botSend(context, "база промокодов пуста.");
          return;
        }

        const promo = data[code];
        if (!promo) {
          await botSend(context, "такого промокода нет.");
          return;
        }

        promo.used = 0;
        promo.users = [];
        data[code] = promo;
        writePromoStore(data);

        const users = context.state.users ?? [];
        for (const user of users) {
          if (!Array.isArray(user.promo_used)) continue;
          user.promo_used = user.promo_used.filter(x => String(x).toUpperCase() !== code);
        }

        await botSend(context, `промокод ${code} успешно обнулён.`);
      } catch (e) {
        console.error("admin.resetPromo", e);
        await botSend(context, "Ошибка при обнулении промокода.");
      }
    }
  });

  commands.push({
    name: "admin.createPersonalPromo",
    pattern: /^(?:создать\s+персональное\s+промо)\s+(\d+)\s+(\d+)$/i,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }

        const uid = Number(context.match?.[1] ?? "");
        const amount = Number(context.match?.[2] ?? "");

        if (uid <= 0 || amount <= 0) {
          await botSend(context, "укажите корректные значения.");
          return;
        }

        const users = context.state.users ?? [];
        const target = users.find(u => u.uid === uid || u.id === uid);

        if (!target) {
          await botSend(context, "такого игрока нет.");
          return;
        }

        const data = readPromoStore();
        let promo = adminHelpers.randomPromoCode();
        while (data[promo]) promo = adminHelpers.randomPromoCode();

        data[promo] = {
          code: promo,
          activations: 1,
          amount,
          used: 0,
          created: Date.now(),
          personal: target.uid,
          users: []
        };

        writePromoStore(data);

        await botSend(context, `персональный промокод создан:\nКод: ${promo}\nИгрок: ${target.tag}\nСумма: ${amount} FP`);
      } catch (e) {
        console.error("admin.createPersonalPromo", e);
        await botSend(context, "Ошибка при создании персонального промокода.");
      }
    }
  });

  return commands;
};
