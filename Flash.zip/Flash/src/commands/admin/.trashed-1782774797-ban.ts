import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { JsonDatabase } from "../../services/JsonDatabase";
import { AdminAuditService } from "../../services/AdminAuditService";
import { TelegramService } from "../../services/TelegramService";
import { DoubleUser } from "../../types/database";
import * as adminHelpers from "./adminHelpers";
import { sendUserNotification } from "./adminHelpers";

export const createBanCommands = (
  usersDb: JsonDatabase<DoubleUser[]>,
  telegramService?: TelegramService
): CommandDefinition<VkMessageContext>[] => {
  const auditService = new AdminAuditService(adminHelpers.auditChatId);
  const commands: CommandDefinition<VkMessageContext>[] = [];

  commands.push({
    name: "admin.ban",
    pattern: /^(?:бан)\s+(\d+)(?:\s+(\d+[dhm]?))?\s*(.*)$/i,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const uid = Number(context.match?.[1] ?? "");
        const durationStr = String(context.match?.[2] ?? "").trim();
        const reason = String(context.match?.[3] ?? "").trim() || "Не указана";

        const users = context.state.users ?? [];
        const target = Number.isFinite(uid) ? adminHelpers.resolveUserByUid(users, uid) : undefined;
        if (!target) {
          // Попробуем найти по reply_to_message для Telegram
          if (context.platform === "tg" && (context.message as any).reply_to_message?.from?.id) {
            const tgId = (context.message as any).reply_to_message.from.id;
            const tgTarget = users.find(u => u.tgId === tgId);
            if (tgTarget) {
              // Используем найденного пользователя
              tgTarget.ba = tgTarget.ba ?? {};
              tgTarget.ba.value = true;
              tgTarget.ba.time = 0;
              tgTarget.ba.ban_top = true;
              if (context.vk) auditService.setVkClient(context.vk);
              await auditService.logTargetAction("Бан игрока (перманентный)", context.user, tgTarget, { "Причина": reason });
              await botSend(context, `вы забанили игрока ${tgTarget.tag} (UID: ${tgTarget.uid}).\nПричина: ${reason}`);
              return;
            }
          }
          await botSend(context, "Укажите UID игрока или ответьте на его сообщение (только для Telegram).");
          return;
        }

        if (target.ba?.anti_ban) {
          await botSend(context, "У игрока иммунитет от админ команд.");
          return;
        }

        let banDurationMs: number | null = null;
        if (durationStr) {
          const match = durationStr.match(/^(\d+)([dhm]?)$/);
          if (match) {
            const num = Number(match[1]);
            const unit = match[2] || "h";
            switch (unit) {
              case "d":
                banDurationMs = num * 86400000;
                break;
              case "h":
                banDurationMs = num * 3600000;
                break;
              case "m":
                banDurationMs = num * 60000;
                break;
            }
          }
        }

        target.ba = target.ba ?? {};
        target.ba.value = true;
        target.ba.time = banDurationMs ? Date.now() + banDurationMs : 0;
        target.ba.ban_top = true;

        const banType = banDurationMs ? "временный" : "перманентный";
        const durationText = banDurationMs ? ` на ${adminHelpers.formatBanDuration(banDurationMs)}` : "";

        if (context.vk) auditService.setVkClient(context.vk);
        await auditService.logTargetAction(
          `Бан игрока (${banType})`,
          context.user,
          target,
          {
            "Длительность": banDurationMs ? adminHelpers.formatBanDuration(banDurationMs) : "Перманент",
            "Причина": reason
          }
        );

        // Форматируем вывод в зависимости от платформы
        const targetDisplay = context.platform === "tg" ? `${target.tag} (UID: ${target.uid})` : `*id${target.id} (${target.tag})`;
        await botSend(
          context,
          `вы забанили игрока ${targetDisplay}${durationText}.\n` +
            `Причина: ${reason}`
        );

        try {
          await sendUserNotification(
            target,
            context.vk,
            `🚫 Вы были забанены${durationText}.\n` +
            `Причина: ${reason}\n` +
            `Свяжитесь с администрацией для обжалования.`,
            telegramService
          );
        } catch (e) {}
      } catch (error) {
        console.error("admin.ban", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.unban",
    pattern: /^(?:разбан)\s+(\d+)$/i,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const uid = Number(context.match?.[1] ?? "");
        const users = context.state.users ?? [];
        const target = Number.isFinite(uid) ? adminHelpers.resolveUserByUid(users, uid) : undefined;
        if (!target) {
          await botSend(context, "Укажите ID игрока из его профиля.");
          return;
        }
        if (target.ba?.anti_ban) {
          await botSend(context, "У игрока иммунитет от админ команд.");
          return;
        }
        target.ba = target.ba ?? {};
        target.ba.value = false;
        target.ba.time = 0;

        if (context.vk) auditService.setVkClient(context.vk);
        await auditService.logTargetAction("Разбан игрока", context.user, target);

        await botSend(context, `пользователь *id${target.id} (${target.tag}) был успешно разблокирован.`);
        await sendUserNotification(
          target,
          context.vk,
          "Ваш аккаунт был разблокирован.",
          telegramService
        );
      } catch (error) {
        console.error("admin.unban", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.banTop",
    pattern: /^(?:бантоп|бт)\s+(\d+)$/i,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const uid = Number(context.match?.[1] ?? "");
        const users = context.state.users ?? [];
        const target = Number.isFinite(uid) ? adminHelpers.resolveUserByUid(users, uid) : undefined;
        if (!target) {
          await botSend(context, "Неверный ID игрока.");
          return;
        }
        if (target.ba?.anti_ban) {
          await botSend(context, "У игрока иммунитет от админ команд.");
          return;
        }
        target.ba = target.ba ?? {};
        target.ba.ban_top = true;
        if (context.vk) auditService.setVkClient(context.vk);
        await auditService.logTargetAction("Бан из топа", context.user, target);
        await botSend(context, `вы забанили игроку id${target.id} (${target.tag}) появление в топе`);
      } catch (error) {
        console.error("admin.banTop", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.unbanTop",
    pattern: /^(?:разбантоп|рбт)\s+(\d+)$/i,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const uid = Number(context.match?.[1] ?? "");
        const users = context.state.users ?? [];
        const target = Number.isFinite(uid) ? adminHelpers.resolveUserByUid(users, uid) : undefined;
        if (!target) {
          await botSend(context, "Неверный ID игрока.");
          return;
        }
        target.ba = target.ba ?? {};
        target.ba.ban_top = false;
        if (context.vk) auditService.setVkClient(context.vk);
        await auditService.logTargetAction("Разбан из топа", context.user, target);
        await botSend(context, `игрок id${target.id} (${target.tag}) может снова появиться в топе`);
      } catch (error) {
        console.error("admin.unbanTop", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.banBonus",
    pattern: /^(?:банбонус)\s+(\d+)$/i,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const uid = Number(context.match?.[1] ?? "");
        const users = context.state.users ?? [];
        const target = Number.isFinite(uid) ? adminHelpers.resolveUserByUid(users, uid) : undefined;
        if (!target) {
          await botSend(context, "Неверный ID игрока.");
          return;
        }
        target.banbonus = true;
        if (context.vk) auditService.setVkClient(context.vk);
        await auditService.logTargetAction("Бан от бонуса", context.user, target);
        await botSend(context, `игроку id${target.id} (${target.tag}) заблокирован бонус`);
      } catch (error) {
        console.error("admin.banBonus", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.unbanBonus",
    pattern: /^(?:разбанбонус)\s+(\d+)$/i,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const uid = Number(context.match?.[1] ?? "");
        const users = context.state.users ?? [];
        const target = Number.isFinite(uid) ? adminHelpers.resolveUserByUid(users, uid) : undefined;
        if (!target) {
          await botSend(context, "Неверный ID игрока.");
          return;
        }
        target.banbonus = false;
        if (context.vk) auditService.setVkClient(context.vk);
        await auditService.logTargetAction("Разбан от бонуса", context.user, target);
        await botSend(context, `игроку id${target.id} (${target.tag}) разблокирован бонус`);
      } catch (error) {
        console.error("admin.unbanBonus", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.banTransfers",
    pattern: /^(?:банпереводов)\s+(\d+)$/i,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const uid = Number(context.match?.[1] ?? "");
        const users = context.state.users ?? [];
        const target = Number.isFinite(uid) ? adminHelpers.resolveUserByUid(users, uid) : undefined;
        if (!target) {
          await botSend(context, "Неверный ID игрока.");
          return;
        }
        target.banper = true;
        await botSend(context, `игроку *id${target.id} (${target.tag}) запрещены переводы.`);
      } catch (error) {
        console.error("admin.banTransfers", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.unbanTransfers",
    pattern: /^(?:разбанпереводов)\s+(\d+)$/i,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const uid = Number(context.match?.[1] ?? "");
        const users = context.state.users ?? [];
        const target = Number.isFinite(uid) ? adminHelpers.resolveUserByUid(users, uid) : undefined;
        if (!target) {
          await botSend(context, "Неверный ID игрока.");
          return;
        }
        target.banper = false;
        await botSend(context, `игроку *id${target.id} (${target.tag}) разрешены переводы.`);
      } catch (error) {
        console.error("admin.unbanTransfers", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  return commands;
};
