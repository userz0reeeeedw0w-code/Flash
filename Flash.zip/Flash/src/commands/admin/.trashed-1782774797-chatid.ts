import { CommandDefinition } from "../../core/command/Command";
import { botSend, VkMessageContext } from "../../core/mode/GameMode";

export const ChatAdminCommands: CommandDefinition<VkMessageContext> = {
    name: "admin.chatId",
    pattern: /^(?:чат)$/i,
    guard: context => Boolean(context.isChat),
    handler: async context => {
        await botSend(context, `Ид чата: ${String(context.chatId ?? "")}`);
    }
} 