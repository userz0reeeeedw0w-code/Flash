import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { JsonDatabase } from "../../services/JsonDatabase";
import { TelegramService } from "../../services/TelegramService";
import { DoubleUser } from "../../types/database";
import * as adminHelpers from "./adminHelpers";

const GIVEAWAY_DURATION_MS = 60 * 1000;
const DEFAULT_GIVEAWAY_PRIZE = 300;

type TgGiveaway = {
  id: string;
  chatId: number;
  channelId: number | string;
  messageId: number | null;
  adminId: number;
  prizeAmount: number;
  participants: Set<number>;
  endTime: number;
  callbackListener?: (data: any) => void;
  timeoutId?: NodeJS.Timeout;
  telegramApi?: any;
  callbackQueryId?: string;
  updateMessage?: () => Promise<void>;
  intervalId?: NodeJS.Timeout;
};

const tgGiveaways = new Map<string, TgGiveaway>();

export const createGiveawayCommands = (
  usersDb: JsonDatabase<DoubleUser[]>
): CommandDefinition<VkMessageContext>[] => {
  const commands: CommandDefinition<VkMessageContext>[] = [];

  commands.push({
    name: "admin.giveaway",
    pattern: /^(?:раздача)(?:\s+(\d+))?$/i,
    guard: (context) => 
      Boolean(
        context.user &&
        adminHelpers.isStaff(context.user) &&
        adminHelpers.canRunInAdminChat(context) &&
        adminHelpers.hasActiveAdminSession(context.user.id)
      ),
    handler: async (context: VkMessageContext) => {
      try {
        if (!context.user) {
          await botSend(context, "❌ Ошибка: пользователь не найден");
          return;
        }

        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "⛔ За плохое поведение вам заблокировали админ команды.");
          return;
        }

        const requestedPrize = Number(context.match?.[1] ?? "");
        const prizeAmount = Number.isFinite(requestedPrize) && requestedPrize > 0
          ? Math.floor(requestedPrize)
          : DEFAULT_GIVEAWAY_PRIZE;

        await createTgGiveaway(context, prizeAmount, usersDb);
        await createVkGiveaway(context, prizeAmount, usersDb);
        
        await botSend(context, `✅ Раздачи запущены!\n🏆 Приз: ${prizeAmount} Донат рублей`);
        
      } catch (error) {
        console.error("admin.giveaway error:", error);
        const errorMessage = error instanceof Error ? error.message : "Неизвестная ошибка";
        await botSend(context, `❌ Ошибка при создании раздачи: ${errorMessage}`);
      }
    }
  });

  commands.push({
    name: "admin.giveawayJoin",
    pattern: /^giveaway_join_([a-z0-9]+)$/i,
    guard: context => Boolean(context.platform === "tg" && context.user),
    handler: async context => {
      try {
        const giveawayId = String(context.match?.[1] ?? "").toLowerCase();
        const giveaway = tgGiveaways.get(giveawayId);
        
        if (!giveaway || !context.user) {
          return;
        }
        
        let isFirstTime = true;
        if (giveaway.participants.has(context.user.id)) {
          isFirstTime = false;
        } else {
          giveaway.participants.add(context.user.id);
        }
        
        const count = giveaway.participants.size;

        try {
          const api = giveaway.telegramApi;
          const callbackQueryId = context.payload?.callback_query_id;
          
          if (api && callbackQueryId) {
            const alertText = isFirstTime 
              ? `✅ Добавлены в раздачу!\n👥 Всего участников: ${count}`
              : `ℹ️ Вы уже участвуете!\n👥 Всего участников: ${count}`;
            
            await api.answerCallbackQuery({
              callback_query_id: callbackQueryId,
              text: alertText,
              show_alert: false
            });

            if (isFirstTime && giveaway.updateMessage) {
              await giveaway.updateMessage();
            }
          }
        } catch (error) {
          console.error("Failed to handle giveaway join:", error);
        }
      } catch (error) {
        console.error("admin.giveawayJoin error:", error);
      }
    }
  });

  return commands;
};

async function createTgGiveaway(context: VkMessageContext, prizeAmount: number, usersDb: JsonDatabase<DoubleUser[]>): Promise<void> {
  const tgApi = context.tgService?.getTelegram().api;
  if (!tgApi) throw new Error("Telegram API не доступен");
  
  const giveawayId = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
  const channelId = adminHelpers.getGiveawayTgChannelId();
  
  const giveaway: TgGiveaway = {
    id: giveawayId,
    chatId: 0,
    channelId,
    messageId: null,
    adminId: context.user!.id,
    prizeAmount,
    participants: new Set(),
    endTime: Date.now() + GIVEAWAY_DURATION_MS
  };
  
  const getMessageText = () => {
    const secondsLeft = Math.max(0, Math.round((giveaway.endTime - Date.now()) / 1000));
    return `🎁 РАЗДАЧА ${prizeAmount} ДОНАТ РУБЛЕЙ 🎁\n\n` +
      `👥 Участников: ${giveaway.participants.size}\n\n` +
      `Нажмите кнопку ниже чтобы принять участие!\n` +
      `⏱ Итоги через ${secondsLeft} сек`;
  };
  
  const getButtonText = () => {
    return `🎲 Участвовать (${giveaway.participants.size})`;
  };
  
  const channelMessage = await tgApi.sendMessage({
    chat_id: Number(channelId),
    text: getMessageText(),
    reply_markup: {
      inline_keyboard: [[
        {
          text: getButtonText(),
          callback_data: `giveaway_join_${giveawayId}`
        }
      ]]
    }
  });
  
  if (channelMessage.message_id) {
    giveaway.messageId = channelMessage.message_id;
  }
  
  giveaway.telegramApi = tgApi;
  tgGiveaways.set(giveawayId, giveaway);
  
  const updateMessage = async () => {
    if (!giveaway.messageId || !giveaway.telegramApi) return;
    
    try {
      await giveaway.telegramApi.editMessageText({
        chat_id: Number(channelId),
        message_id: giveaway.messageId,
        text: getMessageText(),
        reply_markup: {
          inline_keyboard: [[
            {
              text: getButtonText(),
              callback_data: `giveaway_join_${giveawayId}`
            }
          ]]
        }
      });
    } catch (error) {
      console.error("Failed to update message:", error);
    }
  };
  
  giveaway.updateMessage = updateMessage;
  
  const intervalId = setInterval(() => {
    if (!tgGiveaways.has(giveawayId)) {
      clearInterval(intervalId);
      return;
    }
    updateMessage();
  }, 1000);
  
  giveaway.intervalId = intervalId;
  
  const timeoutId = setTimeout(async () => {
    clearInterval(intervalId);
    const active = tgGiveaways.get(giveawayId);
    if (!active) return;
    
    tgGiveaways.delete(giveawayId);
    
    const users = usersDb.load();
    const participantIds = Array.from(active.participants);
    const participants = users.filter((u: any) => 
      participantIds.includes(u.id) || participantIds.includes(u.tgId)
    );
    
    let finalMessage = "";
    
    if (participants.length === 0) {
      finalMessage = `❌ РАЗДАЧА ОТМЕНЕНА ❌\n\n` +
        `🏆 Приз: ${active.prizeAmount} Донат рублей\n` +
        `😔 Нет участников`;
    } else {
      const winner = participants[Math.floor(Math.random() * participants.length)];
      winner.donate_rub = Number(winner.donate_rub ?? 0) + active.prizeAmount;
      usersDb.save(users);
      
      const winnerLabel = winner.tgUsername ? `@${winner.tgUsername}` : winner.tag;
      finalMessage = `🎉 РАЗДАЧА ЗАВЕРШЕНА 🎉\n\n` +
        `👥 Участников: ${participants.length}\n` +
        `🏆 Победитель: ${winnerLabel}\n` +
        `💰 Приз: ${active.prizeAmount} Донат рублей\n` +
        `💳 Новый баланс: ${winner.donate_rub} RUB`;
      
      if (winner.tgId) {
        await tgApi.sendMessage({
          chat_id: winner.tgId,
          text: `🎉 ПОБЕДА В РАЗДАЧЕ! 🎉\n\n` +
            `Вы выиграли ${active.prizeAmount} Донат рублей!\n` +
            `💳 Ваш баланс: ${winner.donate_rub} RUB\n\n` +
            `Спасибо за участие!`
        }).catch(() => undefined);
      }
    }
    
    if (active.messageId && active.channelId && active.telegramApi) {
      await active.telegramApi.editMessageText({
        chat_id: Number(active.channelId),
        message_id: active.messageId,
        text: finalMessage,
        reply_markup: { inline_keyboard: [] }
      }).catch(() => undefined);
    }
  }, GIVEAWAY_DURATION_MS);
  
  giveaway.timeoutId = timeoutId;
}

async function createVkGiveaway(context: VkMessageContext, prizeAmount: number, usersDb: JsonDatabase<DoubleUser[]>): Promise<void> {
  const userToken = process.env.VK_USER_TOKEN || "";
  
  if (!userToken) {
    const errorMsg = "VK User Token не найден. Нужен токен пользователя для создания постов в группе";
    console.error(`[VK Giveaway Error] ${errorMsg}`);
    throw new Error(errorMsg);
  }
  
  const { VK } = await import("vk-io");
  const userVk = new VK({ token: userToken });
  
  if (!context.vk) {
    const errorMsg = "VK instance not found in context";
    console.error(`[VK Giveaway Error] ${errorMsg}`);
    await botSend(context, `❌ ${errorMsg}`);
    throw new Error(errorMsg);
  }
  
  let vk = new VK({ token: `${process.env.VK_TOKEN}` });
  const groupId = adminHelpers.getGiveawayVkGroupId();
  
  try {
    console.log(`[VK Giveaway] Starting giveaway creation for ${prizeAmount} RUB`);
    
    const post = await vk.api.wall.post({
      owner_id: groupId,
      message:
        `🎁 РАЗДАЧА ${prizeAmount} ДОНАТ РУБЛЕЙ 🎁\n\n` +
        `Через ${Math.round(GIVEAWAY_DURATION_MS / 1000)} секунд будет выбран победитель среди лайкнувших.\n\n` +
        `Условия:\n` +
        `✅ Поставь лайк посту\n` +
        `✅ Будь подписан на сообщество\n` +
        `✅ Играй в бота`,
      from_group: 1
    });
    
    const postId = post.post_id;
    const postLink = `https://vk.com/wall${groupId}_${postId}`;
    
    console.log(`[VK Giveaway] Post created successfully: ${postLink}`);
    
    await botSend(context, `✅ VK-раздача запущена!\n🔗 Пост: ${postLink}\n🏆 Приз: ${prizeAmount} Донат рублей`);
    
    setTimeout(async () => {
      try {
        console.log(`[VK Giveaway] Finalizing giveaway for post ${postId}`);
        
        const likesResponse = await userVk.api.likes.getList({
          type: "post",
          owner_id: groupId,
          item_id: postId,
          filter: "likes",
          extended: 1,
          count: 1000
        });
        
        const items = likesResponse.items || [];
        const likeIds = items.map((item: any) => item.id || item.user_id).filter((id: number) => id);
        
        console.log(`[VK Giveaway] Found ${likeIds.length} likes`);
        
        const users = usersDb.load();
        const participants = users.filter((u: any) => likeIds.includes(u.id));
        
        console.log(`[VK Giveaway] Found ${participants.length} bot players among likes`);
        
        if (participants.length === 0) {
          console.log(`[VK Giveaway] No participants found, canceling giveaway`);
          if (vk) {
            await vk.api.wall.post({
              owner_id: groupId,
              message: `😔 Раздача не состоялась: среди лайков нет игроков бота.\n${postLink}`,
              from_group: 1
            }).catch((e) => console.error(`[VK Giveaway Error] Failed to post result: ${e.message}`));
          }
          return;
        }
        
        const winner = participants[Math.floor(Math.random() * participants.length)];
        const oldBalance = winner.donate_rub ?? 0;
        winner.donate_rub = Number(oldBalance) + prizeAmount;
        usersDb.save(users);
        
        console.log(`[VK Giveaway] Winner selected: ${winner.id} (${winner.tag}) won ${prizeAmount} RUB, new balance: ${winner.donate_rub}`);
        
        if (vk) {
          await vk.api.wall.post({
            owner_id: groupId,
            message:
              `🎊 ИТОГИ РАЗДАЧИ 🎊\n\n` +
              `👥 Участников (игроков бота): ${participants.length}\n` +
              `🏆 Победитель: @id${winner.id} (${winner.tag})\n` +
              `💰 Приз: ${prizeAmount} Донат рублей начислен\n` +
              `💳 Новый баланс: ${winner.donate_rub} RUB\n` +
              `🔗 Пост: ${postLink}`,
            from_group: 1
          }).catch((e) => console.error(`[VK Giveaway Error] Failed to post winner: ${e.message}`));
        }
        
        if (vk) {
          try {
            await vk.api.messages.send({
              user_id: winner.id,
              random_id: Math.floor(Math.random() * 1000000),
              message:
                `🎉 Вы победили в раздаче и получили ${prizeAmount} Донат рублей!\n` +
                `💳 Баланс: ${winner.donate_rub} RUB\n\n` +
                `Спасибо за участие!`
            });
            console.log(`[VK Giveaway] Personal message sent to winner ${winner.id}`);
          } catch (msgError: any) {
            console.error(`[VK Giveaway Error] Cannot send message to user ${winner.id}: ${msgError.message}`);
          }
        }
        
      } catch (error) {
        console.error(`[VK Giveaway Error] Finalization error:`, error);
        const errorMsg = error instanceof Error ? error.message : "Неизвестная ошибка";
        
        if (vk) {
          await vk.api.wall.post({
            owner_id: groupId,
            message: `❌ Ошибка при подведении итогов раздачи.\n❌ Ошибка: ${errorMsg}`,
            from_group: 1
          }).catch((e) => console.error(`[VK Giveaway Error] Failed to post error message: ${e.message}`));
        }
      }
    }, GIVEAWAY_DURATION_MS);
    
  } catch (error) {
    console.error(`[VK Giveaway Error] Creation error:`, error);
    const errorMsg = error instanceof Error ? error.message : "Неизвестная ошибка";
    
    await botSend(context, `❌ Ошибка при создании VK-поста: ${errorMsg}`);
    throw error;
  }
}
