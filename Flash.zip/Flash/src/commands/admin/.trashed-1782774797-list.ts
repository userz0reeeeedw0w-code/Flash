import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import * as adminHelpers from "./adminHelpers";

export const AdminListCommand: CommandDefinition<VkMessageContext> = {
    name: "admin.listActive",
    pattern: /^админы$/i,
    guard: context => Boolean(
        context.user &&
        adminHelpers.isStaff(context.user) &&
        adminHelpers.canRunInAdminChat(context)
    ),
    handler: async context => {
        const users = context.state.users ?? [];
    
        if (adminHelpers.adminSessions.size === 0) {
            await botSend(context, "нет активных админ‑сессий.");
            return;
        }
    
        const lines: string[] = [];
    
        for (const [id, session] of adminHelpers.adminSessions) {
            const u = users.find(x => x.id === id || x.uid === id);
            const name = u?.tag ?? `id${id}`;
            const remaining = session.expires - Date.now();
            const sec = Math.floor(remaining / 1000);
            const min = Math.floor(sec / 60);
            const left = `${min}м ${sec % 60}с`;
            lines.push(`• ${name} — ${left}`);
        }
    
        await botSend(context, `активные администраторы:\n${lines.join("\n")}`);
    }
}