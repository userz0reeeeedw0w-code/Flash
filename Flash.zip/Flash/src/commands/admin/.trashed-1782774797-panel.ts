import { botSend, CommandDefinition, VkMessageContext } from "../../core/mode/GameMode";
import * as adminHelpers from "./adminHelpers";
import { buildKeyboard } from "../../utils/keyboard";

export const PasswordAdminCommand: CommandDefinition<VkMessageContext> = {
    name: "admin.getLoginCode",
    pattern: /^(?:парольадмин|получитьадминпароль)$/i,
    guard: context => Boolean(context.user && adminHelpers.isStaff(context.user) && context.isChat),
    handler: async context => {
        const user = context.user;

        if (!user) return;
        const blocked = adminHelpers.checkLoginBlocked(user.id);
        
        if (blocked > 0) {
            const sec = Math.ceil(blocked / 1000);
            const min = Math.floor(sec / 60);
            const left = `${min}м ${sec % 60}с`;
            await botSend(context, `вы временно заблокированы для входа. осталось: ${left}`);
            
            return;
        }
        const code = adminHelpers.generateLoginCode();
        adminHelpers.storeLoginCode(user.id, code);
        
        const sec = Math.floor(adminHelpers.ADMIN_LOGIN_CODE_LIFETIME_MS / 1000);
        const min = Math.floor(sec / 60);
        const left = `${min}м ${sec % 60}с`;
        const message = `временный пароль для входа: ${code}\nсрок действия: ${left}`;
        
        const keyboard = buildKeyboard({
            inline: true,
            buttons: [
                [
                    {
                        label: "✅ Войти в админ‑панель",
                        color: "positive",
                        command: `входадмин ${code}`
                    }
                ]
            ]
        });
        
        await botSend(context, message, { keyboard });
    }
}

export const LoginAdminCommand: CommandDefinition<VkMessageContext> = {
    name: "admin.login",
    pattern: /^входадмин\s+([^]+)$/i,
    guard: context => Boolean(context.user && adminHelpers.isStaff(context.user) && context.isChat),
    handler: async context => {
        const user = context.user;    
        if (!user) return;
        
        const blocked = adminHelpers.checkLoginBlocked(user.id);
        if (blocked > 0) {
            const sec = Math.ceil(blocked / 1000);
            const min = Math.floor(sec / 60);
            const left = `${min}м ${sec % 60}с`;
            await botSend(context, `вы временно заблокированы для входа. осталось: ${left}`);
            return;
        }
        
        const pass = String(context.match?.[1] ?? "");
        const ok = Boolean(pass) && (adminHelpers.verifyAdminPassword(pass) || adminHelpers.verifyLoginCode(user.id, pass));
        
        if (!ok) {
            adminHelpers.registerLoginFail(user.id);
            await botSend(context, "неверный пароль");
            return;
        }
    
        adminHelpers.resetLoginAttempts(user.id);
    
        adminHelpers.adminSessions.set(user.id, {
            expires: Date.now() + adminHelpers.ADMIN_SESSION_LIFETIME_MS
        });
    
        await botSend(context, "вы вошли в админ‑панель. теперь используйте команды в админ‑чате.");
    }
}

export const LogoutAdminCommand: CommandDefinition<VkMessageContext> = {
    name: "admin.logout",
    pattern: /^выходадмин$/i,
    guard: context => Boolean(context.user && adminHelpers.isStaff(context.user)),
    handler: async context => {
        const user = context.user;    
        if (!user) return;
        
        adminHelpers.adminSessions.delete(user.id);
        await botSend(context, "вы вышли из админ‑панели");
    }
}

export const AdminStatusCommand: CommandDefinition<VkMessageContext> = {
    name: "admin.status",
    pattern: /^админстатус$/i,
    guard: context => Boolean(
        context.user &&
        adminHelpers.isStaff(context.user) &&
        adminHelpers.canRunInAdminChat(context)
    ),
    handler: async context => {
        const user = context.user;
        if (!user) return;
    
        const session = adminHelpers.adminSessions.get(user.id);
        if (!session) {
            await botSend(context, "у вас нет активной админ‑сессии.");
            return;
        }
    
        const remaining = session.expires - Date.now();
        if (remaining <= 0) {
            adminHelpers.adminSessions.delete(user.id);
            await botSend(context, "ваша админ‑сессия истекла.");
            return;
        }
    
        const sec = Math.floor(remaining / 1000);
        const min = Math.floor(sec / 60);
        const left = `${min}м ${sec % 60}с`;
    
        await botSend(context, `админ‑сессия активна. осталось: ${left}`);
    }
}
