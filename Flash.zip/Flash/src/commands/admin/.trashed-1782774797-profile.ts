import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { formatWithSpaces } from "../../utils/number";
import { resolveResource } from "vk-io";
import * as adminHelpers from "./adminHelpers";

export const createProfileCommands = (): CommandDefinition<VkMessageContext>[] => {
  const commands: CommandDefinition<VkMessageContext>[] = [];

  commands.push({
    name: "admin.userProfile",
    pattern: /^(?:профиль|проф|пр|гет)\s+(.+)$/i,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        const { vk, state, message } = context;
        if (!vk || !state || !state.users) return;

        let targetId: number | null = null;
        const arg = String(context.match?.[1] ?? "").trim();

        if (/^\d+$/.test(arg)) {
          targetId = Number(arg);
        }
        else if (context.platform === "tg") {
          // Для Telegram: check reply_to_message first
          if ((message as any).reply_to_message?.from?.id && !arg) {
            targetId = (message as any).reply_to_message.from.id;
          } else if (/vk\.(ru|com)\//.test(arg)) {
            const match = arg.match(/https?:\/\/vk\.(?:ru|com)\/([a-zA-Z0-9_.-]+)/i);
            if (match) {
              const screenName = match[1];
              const explicitIdMatch = screenName.match(/^(?:id|club|public|event)(\d+)$/);
              if (explicitIdMatch) {
                targetId = Number(explicitIdMatch[1]);
              }
            }
          }
        }
        else if (/vk\.(ru|com)\//.test(arg)) {
          const match = arg.match(/https?:\/\/vk\.(?:ru|com)\/([a-zA-Z0-9_.-]+)/i);
          if (match) {
            const screenName = match[1];
            const explicitIdMatch = screenName.match(/^(?:id|club|public|event)(\d+)$/);

            if (explicitIdMatch) {
              targetId = Number(explicitIdMatch[1]);
            } else {
              try {
                const response = await resolveResource({
                  api: vk.api,
                  resource: screenName
                });
                targetId = response?.type === "user" ? response?.id : null;
              } catch (e) {
                console.error("Ошибка при резолве ссылки:", e);
              }
            }
          }
        }
        else if (message.hasReplyMessage && !arg) {
          targetId = message.replyMessage?.senderId ?? null;
        }
        else if (message.hasForwards && !arg) {
          targetId = message.forwards[0]?.senderId ?? null;
        }

        if (!targetId) {
          await botSend(context, "Укажите ID, ссылку, ответ на сообщение или пересланное сообщение.");
          return;
        }

        const allUsers = state.users;
        const targetUser = allUsers.find(u => u.id === targetId || u.uid === targetId || u.tgId === targetId);

        if (!targetUser) {
          await botSend(context, "Этот пользователь не играет в бота.");
          return;
        }

        let profileText = `👤 Профиль ${targetUser.tag}\n`;
        if (context.platform === "tg") {
          // Для Telegram показываем TG ID если есть
          profileText += `(UID: ${targetUser.uid}`;
          if (targetUser.tgId) profileText += `, TG: ${targetUser.tgId}`;
          if (targetUser.id) profileText += `, VK: ${targetUser.id}`;
          profileText += `)\n`;
        } else {
          // Для VK показываем VK ID если есть
          profileText += `(ID: ${targetUser.id}, UID: ${targetUser.uid}`;
          if (targetUser.tgId) profileText += `, TG: ${targetUser.tgId}`;
          profileText += `)\n`;
        }

        if (targetUser.permiss?.vip) {
          const timeLeft = targetUser.vip_expires ? new Date(targetUser.vip_expires - Date.now()) : null;
          const vipDays = timeLeft ? timeLeft.getUTCDate() - 1 : 0;
          const vipHours = timeLeft ? timeLeft.getUTCHours() : 0;
          profileText += `\n[✨] Статус VIP (${vipDays} д, ${vipHours} ч)`;
        }

        if (targetUser.permiss?.premium) {
          const timeLeft = targetUser.premium_expires ? new Date(targetUser.premium_expires - Date.now()) : null;
          const premiumDays = timeLeft ? timeLeft.getUTCDate() - 1 : 0;
          const premiumHours = timeLeft ? timeLeft.getUTCHours() : 0;
          profileText += `\n[👑] Статус PREMIUM (${premiumDays} д, ${premiumHours} ч)`;
        }

        if (targetUser.permiss?.admin) {
          const timeLeft = targetUser.admin_expires ? new Date(targetUser.admin_expires - Date.now()) : null;
          const adminDays = timeLeft ? timeLeft.getUTCDate() - 1 : 0;
          const adminHours = timeLeft ? timeLeft.getUTCHours() : 0;
          profileText += `\n[🔑] ADMINISTRATOR (${adminDays} д, ${adminHours} ч)`;
        }

        if (targetUser.permiss?.legend) {
          const timeLeft = targetUser.legend_expires ? new Date(targetUser.legend_expires - Date.now()) : null;
          const legendDays = timeLeft ? timeLeft.getUTCDate() - 1 : 0;
          const legendHours = timeLeft ? timeLeft.getUTCHours() : 0;
          profileText += `\n[🌏] Статус LEGEND (${legendDays} д, ${legendHours} ч)`;
        }

        if (targetUser.permiss?.donate) {
          const timeLeft = targetUser.donate_expires ? new Date(targetUser.donate_expires - Date.now()) : null;
          const donateDays = timeLeft ? timeLeft.getUTCDate() - 1 : 0;
          const donateHours = timeLeft ? timeLeft.getUTCHours() : 0;
          profileText += `\n[💎] DONATE (${donateDays} д, ${donateHours} ч)`;
        }

        if (targetUser.permiss?.helper) {
          profileText += `\n[💛] HELPER`;
        }

        if (targetUser.permiss?.flash) {
          const timeLeft = targetUser.flash_expires ? new Date(targetUser.flash_expires - Date.now()) : null;
          const flashDays = timeLeft ? timeLeft.getUTCDate() - 1 : 0;
          const flashHours = timeLeft ? timeLeft.getUTCHours() : 0;
          profileText += `\n[⚡] Всемогущий (${flashDays} д, ${flashHours} ч)`;
        }

        if (targetUser.permiss?.sponsor) {
          const timeLeft = targetUser.sponsor_expires ? new Date(targetUser.sponsor_expires - Date.now()) : null;
          const sponsorDays = timeLeft ? timeLeft.getUTCDate() - 1 : 0;
          const sponsorHours = timeLeft ? timeLeft.getUTCHours() : 0;
          profileText += `\n[💝] Спонсор проекта (${sponsorDays} д, ${sponsorHours} ч)`;
        }

        if (targetUser.permiss?.owner) {
          profileText += `\n[🌹] OWNER`;
        }

        if (targetUser.ba?.value) {
          const banEndTime = targetUser.ba?.time ?? 0;
          if (banEndTime === 0) {
            profileText += `\n[🚫] ЗАБАНЕН (перманентно)`;
          } else if (banEndTime !== 0 && banEndTime > Date.now()) {
            const timeLeft = new Date(banEndTime - Date.now());
            const days = timeLeft.getUTCDate() - 1;
            const hours = timeLeft.getUTCHours();
            const mins = timeLeft.getUTCMinutes();
            profileText += `\n[🚫] ЗАБАНЕН (${days}д ${hours}ч ${mins}м)`;
          }
        }

        if (targetUser.ba?.ban_top) {
          profileText += `\n[📊] Забанен из топа`;
        }

        if (targetUser.banbonus) {
          profileText += `\n[🎁] Забанен от бонуса`;
        }

        if (targetUser.ba?.anti_ban) {
          profileText += `\n[🛡️] Иммунитет от админ команд`;
        }

        profileText += `\n[🪙] Баланс: ${formatWithSpaces(targetUser.balance)} FP`;
        profileText += `\n[🌐] Последняя ставка: ${formatWithSpaces(targetUser.lastbet)} FP`;
        profileText += `\n[💳] Донат баланс: ${formatWithSpaces(targetUser.donate_rub ?? 0)} RUB`;

        await botSend(context, profileText);
      } catch (error) {
        console.error("admin.userProfile", error);
        await botSend(context, "Ошибка при просмотре профиля.");
      }
    }
  });

  commands.push({
    name: "admin.fake",
    pattern: /^(?:фейк)\s+(вкл|выкл)$/i,
    guard: context => Boolean(context.user && adminHelpers.isStaff(context.user) && adminHelpers.canRunInAdminChat(context) && adminHelpers.hasActiveAdminSession(context.user.id)),
    handler: async context => {
      try {
        const user = context.user;
        if (!user) return;
        const mode = String(context.match?.[1]);
        user.fake = mode === "вкл";
        await botSend(context, `фейк профиль: ${mode}`);
      } catch (error) {
        console.error("admin.fake", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.incognitoToggle",
    pattern: /^(?:on|off)\s+(\d+)$/i,
    guard: context => Boolean(context.user && adminHelpers.isStaff(context.user) && adminHelpers.canRunInAdminChat(context) && adminHelpers.hasActiveAdminSession(context.user.id)),
    handler: async context => {
      try {
        const uid = Number(context.match?.[1]);
        const mode = context.text.toLowerCase().startsWith("on");

        const target = context.state.users?.find(u => u.uid === uid || u.id === uid);
        if (!target) {
          await botSend(context, "игрок не найден.");
          return;
        }

        target.fake = mode;

        await botSend(
          context,
          `инкогнито игрока ${target.tag}: ${mode ? "включено" : "выключено"}`
        );
      } catch (error) {
        console.error("admin.incognitoToggle", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  return commands;
};
