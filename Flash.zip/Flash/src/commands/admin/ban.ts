import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { JsonDatabase } from "../../services/JsonDatabase";
import { AdminAuditService } from "../../services/AdminAuditService";
import { TelegramService } from "../../services/TelegramService";
import { DoubleUser } from "../../types/database";
import * as adminHelpers from "./adminHelpers";
import { sendUserNotification } from "./adminHelpers";
import { resolveTargetId } from "../../utils/number";

export const createBanCommands = (
  usersDb: JsonDatabase<DoubleUser[]>,
  telegramService?: TelegramService
): CommandDefinition<VkMessageContext>[] => {
  const auditService = new AdminAuditService(adminHelpers.auditChatId);
  const commands: CommandDefinition<VkMessageContext>[] = [];

  const targetPattern = "(?<target>@[\\w.]+|id\\d+|\\[id\\d+\\|@?[\\w.]+\\]|https?://vk\\.(?:ru|com)/[a-zA-Z0-9_.-]+|\\d+)?";
  const banPattern = new RegExp(`^(?:бан)\\s+${targetPattern}(?:\\s+(?<duration>\\d+[dhm]?))?(?:\\s+(?<reason>.*))?$`, "i");
  const unbanPattern = new RegExp(`^(?:разбан)\\s+${targetPattern}$`, "i");
  const banTopPattern = new RegExp(`^(?:бантоп|бт)\\s+${targetPattern}$`, "i");
  const unbanTopPattern = new RegExp(`^(?:разбантоп|рбт)\\s+${targetPattern}$`, "i");
  const banBonusPattern = new RegExp(`^(?:банбонус)\\s+${targetPattern}$`, "i");
  const unbanBonusPattern = new RegExp(`^(?:разбанбонус)\\s+${targetPattern}$`, "i");
  const banTransfersPattern = new RegExp(`^(?:банпереводов)\\s+${targetPattern}$`, "i");
  const unbanTransfersPattern = new RegExp(`^(?:разбанпереводов)\\s+${targetPattern}$`, "i");

  commands.push({
    name: "admin.ban",
    pattern: banPattern,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const { vk, state } = context;
        if (!vk || !state || !state.users) return;

        const match = context.text.match(banPattern);
        const targetArg = match?.groups?.target || "";
        const durationStr = match?.groups?.duration || "";
        const reason = match?.groups?.reason || "Не указана";
        const targetId = await resolveTargetId({
          targetArg,
          allUsers: state.users,
          platform: context.platform,
          vkApi: vk.api,
          tgContext: (context as any).tgContext,
          message: context.message,
          tgUserId: (context as any).tgUserId
        });

        if (!targetId) {
          await botSend(context, "Укажите UID игрока, ссылку, @username или ответьте на его сообщение.");
          return;
        }

        const target = state.users.find(u => u.id === targetId || u.uid === targetId || (u as any).tgId === targetId);
        if (!target) {
          await botSend(context, "игрок не найден.");
          return;
        }

        if (target.ba?.anti_ban) {
          await botSend(context, "У игрока иммунитет от админ команд.");
          return;
        }

        let banDurationMs: number | null = null;
        if (durationStr) {
          const match = durationStr.match(/^(\d+)([dhm]?)$/);
          if (match) {
            const num = Number(match[1]);
            const unit = match[2] || "h";
            switch (unit) {
              case "d": banDurationMs = num * 86400000; break;
              case "h": banDurationMs = num * 3600000; break;
              case "m": banDurationMs = num * 60000; break;
            }
          }
        }

        target.ba = target.ba ?? {};
        target.ba.value = true;
        target.ba.time = banDurationMs ? Date.now() + banDurationMs : 0;
        target.ba.ban_top = true;

        const banType = banDurationMs ? "временный" : "перманентный";
        const durationText = banDurationMs ? ` на ${adminHelpers.formatBanDuration(banDurationMs)}` : "";

        if (context.vk) auditService.setVkClient(context.vk);
        await auditService.logTargetAction(          `Бан игрока (${banType})`,
          context.user,
          target,
          {
            "Длительность": banDurationMs ? adminHelpers.formatBanDuration(banDurationMs) : "Перманент",
            "Причина": reason
          }
        );

        const targetDisplay = context.platform === "tg" ? `${target.tag} (UID: ${target.uid})` : `*id${target.id} (${target.tag})`;
        await botSend(
          context,
          `вы забанили игрока ${targetDisplay}${durationText}.\nПричина: ${reason}`
        );

        try {
          await sendUserNotification(
            target,
            context.vk,
            `🚫 Вы были забанены${durationText}.\nПричина: ${reason}\nСвяжитесь с администрацией для обжалования.`,
            telegramService
          );
        } catch (e) {}
      } catch (error) {
        console.error("admin.ban", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.unban",
    pattern: unbanPattern,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const { vk, state } = context;
        if (!vk || !state || !state.users) return;

        const match = context.text.match(unbanPattern);
        const targetArg = match?.groups?.target || "";
        const targetId = await resolveTargetId({
          targetArg,
          allUsers: state.users,
          platform: context.platform,
          vkApi: vk.api,
          tgContext: (context as any).tgContext,
          message: context.message,
          tgUserId: (context as any).tgUserId
        });

        if (!targetId) {
          await botSend(context, "Укажите UID игрока, ссылку, @username или ответьте на его сообщение.");
          return;
        }

        const target = state.users.find(u => u.id === targetId || u.uid === targetId || (u as any).tgId === targetId);
        if (!target) {
          await botSend(context, "игрок не найден.");
          return;
        }

        if (target.ba?.anti_ban) {
          await botSend(context, "У игрока иммунитет от админ команд.");
          return;
        }

        target.ba = target.ba ?? {};
        target.ba.value = false;
        target.ba.time = 0;

        if (context.vk) auditService.setVkClient(context.vk);
        await auditService.logTargetAction("Разбан игрока", context.user, target);

        await botSend(context, `пользователь *id${target.id} (${target.tag}) был успешно разблокирован.`);
        await sendUserNotification(
          target,
          context.vk,
          "Ваш аккаунт был разблокирован.",
          telegramService
        );
      } catch (error) {
        console.error("admin.unban", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.banTop",    pattern: banTopPattern,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const { vk, state } = context;
        if (!vk || !state || !state.users) return;

        const match = context.text.match(banTopPattern);
        const targetArg = match?.groups?.target || "";

        const targetId = await resolveTargetId({
          targetArg,
          allUsers: state.users,
          platform: context.platform,
          vkApi: vk.api,
          tgContext: (context as any).tgContext,
          message: context.message,
          tgUserId: (context as any).tgUserId
        });

        if (!targetId) {
          await botSend(context, "Укажите UID игрока, ссылку, @username или ответьте на его сообщение.");
          return;
        }

        const target = state.users.find(u => u.id === targetId || u.uid === targetId || (u as any).tgId === targetId);
        if (!target) {
          await botSend(context, "игрок не найден.");
          return;
        }

        if (target.ba?.anti_ban) {
          await botSend(context, "У игрока иммунитет от админ команд.");
          return;
        }

        target.ba = target.ba ?? {};
        target.ba.ban_top = true;

        if (context.vk) auditService.setVkClient(context.vk);
        await auditService.logTargetAction("Бан из топа", context.user, target);        await botSend(context, `вы забанили игроку id${target.id} (${target.tag}) появление в топе`);
      } catch (error) {
        console.error("admin.banTop", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.unbanTop",
    pattern: unbanTopPattern,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const { vk, state } = context;
        if (!vk || !state || !state.users) return;

        const match = context.text.match(unbanTopPattern);
        const targetArg = match?.groups?.target || "";

        const targetId = await resolveTargetId({
          targetArg,
          allUsers: state.users,
          platform: context.platform,
          vkApi: vk.api,
          tgContext: (context as any).tgContext,
          message: context.message,
          tgUserId: (context as any).tgUserId
        });

        if (!targetId) {
          await botSend(context, "Укажите UID игрока, ссылку, @username или ответьте на его сообщение.");
          return;
        }

        const target = state.users.find(u => u.id === targetId || u.uid === targetId || (u as any).tgId === targetId);
        if (!target) {
          await botSend(context, "игрок не найден.");
          return;
        }
        target.ba = target.ba ?? {};
        target.ba.ban_top = false;

        if (context.vk) auditService.setVkClient(context.vk);
        await auditService.logTargetAction("Разбан из топа", context.user, target);
        await botSend(context, `игрок id${target.id} (${target.tag}) может снова появиться в топе`);
      } catch (error) {
        console.error("admin.unbanTop", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.banBonus",
    pattern: banBonusPattern,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const { vk, state } = context;
        if (!vk || !state || !state.users) return;

        const match = context.text.match(banBonusPattern);
        const targetArg = match?.groups?.target || "";

        const targetId = await resolveTargetId({
          targetArg,
          allUsers: state.users,
          platform: context.platform,
          vkApi: vk.api,
          tgContext: (context as any).tgContext,
          message: context.message,
          tgUserId: (context as any).tgUserId
        });

        if (!targetId) {
          await botSend(context, "Укажите UID игрока, ссылку, @username или ответьте на его сообщение.");
          return;
        }

        const target = state.users.find(u => u.id === targetId || u.uid === targetId || (u as any).tgId === targetId);        if (!target) {
          await botSend(context, "игрок не найден.");
          return;
        }

        target.banbonus = true;

        if (context.vk) auditService.setVkClient(context.vk);
        await auditService.logTargetAction("Бан от бонуса", context.user, target);
        await botSend(context, `игроку id${target.id} (${target.tag}) заблокирован бонус`);
      } catch (error) {
        console.error("admin.banBonus", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.unbanBonus",
    pattern: unbanBonusPattern,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const { vk, state } = context;
        if (!vk || !state || !state.users) return;

        const match = context.text.match(unbanBonusPattern);
        const targetArg = match?.groups?.target || "";

        const targetId = await resolveTargetId({
          targetArg,
          allUsers: state.users,
          platform: context.platform,
          vkApi: vk.api,
          tgContext: (context as any).tgContext,
          message: context.message,
          tgUserId: (context as any).tgUserId
        });

        if (!targetId) {
          await botSend(context, "Укажите UID игрока, ссылку, @username или ответьте на его сообщение.");          return;
        }

        const target = state.users.find(u => u.id === targetId || u.uid === targetId || (u as any).tgId === targetId);
        if (!target) {
          await botSend(context, "игрок не найден.");
          return;
        }

        target.banbonus = false;

        if (context.vk) auditService.setVkClient(context.vk);
        await auditService.logTargetAction("Разбан от бонуса", context.user, target);
        await botSend(context, `игроку id${target.id} (${target.tag}) разблокирован бонус`);
      } catch (error) {
        console.error("admin.unbanBonus", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.banTransfers",
    pattern: banTransfersPattern,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const { vk, state } = context;
        if (!vk || !state || !state.users) return;

        const match = context.text.match(banTransfersPattern);
        const targetArg = match?.groups?.target || "";

        const targetId = await resolveTargetId({
          targetArg,
          allUsers: state.users,
          platform: context.platform,
          vkApi: vk.api,
          tgContext: (context as any).tgContext,
          message: context.message,
          tgUserId: (context as any).tgUserId        });

        if (!targetId) {
          await botSend(context, "Укажите UID игрока, ссылку, @username или ответьте на его сообщение.");
          return;
        }

        const target = state.users.find(u => u.id === targetId || u.uid === targetId || (u as any).tgId === targetId);
        if (!target) {
          await botSend(context, "игрок не найден.");
          return;
        }

        target.banper = true;
        await botSend(context, `игроку *id${target.id} (${target.tag}) запрещены переводы.`);
      } catch (error) {
        console.error("admin.banTransfers", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.unbanTransfers",
    pattern: unbanTransfersPattern,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const { vk, state } = context;
        if (!vk || !state || !state.users) return;

        const match = context.text.match(unbanTransfersPattern);
        const targetArg = match?.groups?.target || "";

        const targetId = await resolveTargetId({
          targetArg,
          allUsers: state.users,
          platform: context.platform,
          vkApi: vk.api,
          tgContext: (context as any).tgContext,
          message: context.message,          tgUserId: (context as any).tgUserId
        });

        if (!targetId) {
          await botSend(context, "Укажите UID игрока, ссылку, @username или ответьте на его сообщение.");
          return;
        }

        const target = state.users.find(u => u.id === targetId || u.uid === targetId || (u as any).tgId === targetId);
        if (!target) {
          await botSend(context, "игрок не найден.");
          return;
        }

        target.banper = false;
        await botSend(context, `игроку *id${target.id} (${target.tag}) разрешены переводы.`);
      } catch (error) {
        console.error("admin.unbanTransfers", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  return commands;
};