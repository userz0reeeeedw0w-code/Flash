import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import * as adminHelpers from "./adminHelpers";
import { resolveTargetId } from "../../utils/number";

export const createCaseCommands = (): CommandDefinition<VkMessageContext>[] => {
  const commands: CommandDefinition<VkMessageContext>[] = [];

  const targetPattern = "(?<target>@[\\w.]+|id\\d+|\\[id\\d+\\|@?[\\w.]+\\]|https?://vk\\.(?:ru|com)/[a-zA-Z0-9_.-]+|\\d+)?";
  const giveCase1Pattern = new RegExp(`^(?:выдатьк1)\\s+${targetPattern}\\s+(?<count>\\d+)$`, "i");
  const giveCase3Pattern = new RegExp(`^(?:выдатьк3)\\s+${targetPattern}\\s+(?<count>\\d+)$`, "i");

  commands.push({
    name: "admin.giveCase1",
    pattern: giveCase1Pattern,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const { vk, state } = context;
        if (!vk || !state || !state.users) return;

        const match = context.text.match(giveCase1Pattern);
        const targetArg = match?.groups?.target || "";
        const count = Number(match?.groups?.count || 0);

        const targetId = await resolveTargetId({
          targetArg,
          allUsers: state.users,
          platform: context.platform,
          vkApi: vk.api,
          tgContext: (context as any).tgContext,
          message: context.message,
          tgUserId: (context as any).tgUserId
        });

        if (!targetId) {
          await botSend(context, "Укажите UID игрока, ссылку, @username или ответьте на его сообщение.");
          return;
        }

        const target = state.users.find(u => u.id === targetId || u.uid === targetId || (u as any).tgId === targetId);        if (!target) {
          await botSend(context, "игрок не найден.");
          return;
        }

        target.case1 = (target.case1 ?? 0) + count;
        await botSend(context, `вы выдали ${count} мини‑кейсов игроку ${target.tag}`);
      } catch (error) {
        console.error("admin.giveCase1", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  commands.push({
    name: "admin.giveCase3",
    pattern: giveCase3Pattern,
    guard: context => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user) &&
      adminHelpers.canRunInAdminChat(context) &&
      adminHelpers.hasActiveAdminSession(context.user.id)
    ),
    handler: async context => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }
        const { vk, state } = context;
        if (!vk || !state || !state.users) return;

        const match = context.text.match(giveCase3Pattern);
        const targetArg = match?.groups?.target || "";
        const count = Number(match?.groups?.count || 0);

        const targetId = await resolveTargetId({
          targetArg,
          allUsers: state.users,
          platform: context.platform,
          vkApi: vk.api,
          tgContext: (context as any).tgContext,
          message: context.message,
          tgUserId: (context as any).tgUserId
        });

        if (!targetId) {
          await botSend(context, "Укажите UID игрока, ссылку, @username или ответьте на его сообщение.");
          return;
        }
        const target = state.users.find(u => u.id === targetId || u.uid === targetId || (u as any).tgId === targetId);
        if (!target) {
          await botSend(context, "игрок не найден.");
          return;
        }

        target.case3 = (target.case3 ?? 0) + count;
        await botSend(context, `вы выдали ${count} пиратских кейсов игроку ${target.tag}`);
      } catch (error) {
        console.error("admin.giveCase3", error);
        await botSend(context, "Ошибка при выполнении команды.");
      }
    }
  });

  return commands;
};