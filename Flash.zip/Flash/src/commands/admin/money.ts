import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { JsonDatabase } from "../../services/JsonDatabase";
import { AdminAuditService } from "../../services/AdminAuditService";
import { TelegramService } from "../../services/TelegramService";
import { DoubleUser, Limits } from "../../types/database";
import { resolveResource } from "vk-io";
import * as adminHelpers from "./adminHelpers";
import { sendUserNotification } from "./adminHelpers";
import { resolveTargetId } from "../../utils/number";

export const createMoneyCommands = (
  limitsDb: JsonDatabase<Limits>,
  usersDb: JsonDatabase<DoubleUser[]>,
  telegramService?: TelegramService
): CommandDefinition<VkMessageContext>[] => {
  const auditService = new AdminAuditService(adminHelpers.auditChatId);
  const commands: CommandDefinition<VkMessageContext>[] = [];

  commands.push({
    name: "admin.giveMoney",
    pattern: /^выдатьфп(?:\s+(?:(?<target>@[\w.]+|id\d+|\[id\d+\|@?[\w.]+\]|https?:\/\/vk\.(?:ru|com)\/[a-zA-Z0-9_.-]+|\d+)\s+)?(?<amount>[0-9.]+[kкmм]*|вс[её]|all|в[ао]банк))?$/i,
    guard: (context) => Boolean(
      context.user &&
      adminHelpers.isStaff(context.user)
    ),
    handler: async (context) => {
      try {
        if (!adminHelpers.ensureCanUseAdminCommands(context.user)) {
          await botSend(context, "За плохое поведение вам заблокировали админ команды.");
          return;
        }

        const { user, state, vk } = context;
        if (!user || !vk || !state || !state.users) return;

        const match = context.text.match(/^выдатьфп(?:\s+(?:(?<target>@[\w.]+|id\d+|\[id\d+\|@?[\w.]+\]|https?:\/\/vk\.(?:ru|com)\/[a-zA-Z0-9_.-]+|\d+)\s+)?(?<amount>[0-9.]+[kкmм]*|вс[её]|all|в[ао]банк))?$/i);
        const targetArg = match?.groups?.target || "";
        const amountStr = match?.groups?.amount || "";

        if (!amountStr) {
          await botSend(context, "укажите сумму, которую хотите выдать.");
          return;
        }

        const allUsers = state.users;
        
        let targetId: string | number | null = null;
        let targetUser: DoubleUser | null = null;

        // ИСПРАВЛЕНО: поиск по тегу в Telegram
        if (context.platform === "tg") {
          // Если указан @username
          if (targetArg.startsWith('@')) {
            const username = targetArg.replace('@', '').toLowerCase();
            targetUser = allUsers.find(u => {
              const tgUser = u as any;
              return tgUser.tgUsername && tgUser.tgUsername.toLowerCase() === username;
            }) || null;
            if (targetUser) targetId = targetUser.id;
          }
          
          // Если указан ID пользователя (число)
          if (!targetId && /^\d+$/.test(targetArg)) {
            const numericId = Number(targetArg);
            targetUser = allUsers.find(u => {
              const tgUser = u as any;
              return tgUser.tgId === numericId || u.id === numericId || u.uid === numericId;
            }) || null;
            if (targetUser) targetId = targetUser.id;
          }
          
          // Если указан тег вида [id123|username] (VK формат)
          if (!targetId && /\[id\d+\|@?[\w.]+\]/.test(targetArg)) {
            const matchVk = targetArg.match(/\[id(\d+)\|/);
            if (matchVk) {
              const vkId = Number(matchVk[1]);
              targetUser = allUsers.find(u => u.id === vkId || u.uid === vkId) || null;
              if (targetUser) targetId = targetUser.id;
            }
          }
        }

        // Если не нашли через Telegram, пробуем стандартный resolveTargetId
        if (!targetId) {
          const resolvedId = await resolveTargetId({
            targetArg,
            allUsers,
            platform: context.platform,
            vkApi: vk?.api,
            tgContext: (context as any).tgContext,
            message: context.message,
            tgUserId: (context as any).tgUserId
          });
          
          if (resolvedId) {
            targetId = resolvedId;
            targetUser = allUsers.find(u => u.id === targetId || u.uid === targetId || (u as any).tgId === targetId) || null;
          }
        }

        if (!targetId || !targetUser) {
          const errorMsg = context.platform === "tg" 
            ? "пользователь не найден в базе бота. Убедитесь, что он зарегистрирован и у него есть @username."
            : "вы указали неправильную ссылку.";
          await botSend(context, errorMsg);
          return;
        }

        let formatAmountStr = amountStr.toLowerCase().replace(/[.,]/g, "");
        formatAmountStr = formatAmountStr.replace(/(к|k)/g, "000");
        formatAmountStr = formatAmountStr.replace(/(м|m)/g, "000000");
        
        if (/^(вс[её]|all)$/i.test(amountStr.toLowerCase())) {
          const limits = adminHelpers.normalizeLimits(limitsDb.load());
          formatAmountStr = String(limits.money ?? 0);
        }
        let amount = Math.floor(Number(formatAmountStr) || 0);
        if (!Number.isFinite(amount) || amount <= 0) {
          await botSend(context, "укажите сумму, которую хотите выдать.");
          return;
        }

        const limits = adminHelpers.normalizeLimits(limitsDb.load());
        if (amount > Number(limits.money)) {
          await botSend(context, `введите сумму, меньше или равную ${String(limits.money)} FP`);
          return;
        }

        targetUser.balance = (targetUser.balance ?? 0) + amount;

        if (context.vk) auditService.setVkClient(context.vk);
        await auditService.logTargetAction("Выдача FP", context.user!, targetUser, { "Сумма (FP)": amount });

        try {
          await sendUserNotification(
            targetUser,
            context.vk,
            `▶ Админ ${context.user?.tag} выдал вам ${amount} FP`,
            telegramService
          );
        } catch (e) {}

        const targetDisplay = context.platform === "tg" 
          ? `${targetUser.tag} (UID: ${targetUser.uid})` 
          : targetUser.tag;
        
        await botSend(context, `вы выдали ${targetDisplay} ${String(amount)} FP`);

      } catch (err) {
        console.error(err);
        await botSend(context, "произошла ошибка при выдаче FP.");
      }
    }
  });
  return commands;
};