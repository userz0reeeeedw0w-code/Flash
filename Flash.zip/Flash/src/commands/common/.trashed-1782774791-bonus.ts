import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { formatWithSpaces } from "../../utils/number";
import { secondsToHuman } from "../../utils/time";

export const bonusCommand: CommandDefinition<VkMessageContext> = {
  name: "common.bonus",
  pattern: /^(?:бонус)$/i,
  handler: async context => {
    const { user } = context;
    if (!user) return;

    if (user.banbonus) {
      await botSend(context, 'У вас стоит бан на команду "Бонус".');
      return;
    }

    if (user.bonustime > 0) {
      const streakTimeMin = user.lastBonusTime ? Math.ceil(user.lastBonusTime / 60) : 0;
      await botSend(context, `До получения бонуса ${secondsToHuman(user.bonustime)} ⏳\n🔥 Текущий стрик: ${user.bonusStreak || 0}/10 (Сброс через: ${streakTimeMin} мин)`);
      return;
    }

    let additionalTime = 600;
    if (user.refCount > 10) {
      additionalTime = Math.floor(user.refCount / 10) * 600;
    }

    const refBonus = typeof user.ref_bonus === "number" ? user.ref_bonus : 0;
    let baseBonus = 50000000 + refBonus;
    let roleText = "";

    if (user.permiss?.flash) { baseBonus = 120000000 + refBonus; roleText = "💸 Всемогущий, "; }
    else if (user.permiss?.donate) { baseBonus = 100000000 + refBonus; roleText = "💎 DONATE, "; }
    else if (user.permiss?.admin) { baseBonus = 750000000 + refBonus; roleText = "🌟 Администратор, "; }
    else if (user.permiss?.sponsor) { baseBonus = 777777777 + refBonus; roleText = "💰 Спонсор, "; }
    else if (user.permiss?.legend) { baseBonus = 500000000 + refBonus; roleText = "LEGEND, "; }
    else if (user.permiss?.premium) { baseBonus = 30000000 + refBonus; roleText = "PREMIUM, "; }
    else if (user.permiss?.vip) { baseBonus = 250000000 + refBonus; roleText = "VIP, "; }

    const currentStreak = user.bonusStreak || 0;
    let newStreak = currentStreak + 1;
    if (newStreak > 10) newStreak = 10;

    let streakFP = newStreak * 5000;
    let caseDropMsg = "";

    if (newStreak > currentStreak && Math.random() < 0.2) {
      streakFP = currentStreak * 5000;
      const caseId = Math.floor(Math.random() * 4) + 1;
      if (caseId === 1) user.case1 = (user.case1 || 0) + 1;
      else if (caseId === 2) user.case2 = (user.case2 || 0) + 1;
      else if (caseId === 3) user.case3 = (user.case3 || 0) + 1;
      else if (caseId === 4) user.case4 = (user.case4 || 0) + 1;
      const caseNames = ["", "Мини кейс", "Легендарный кейс", "Пиратский кейс", "Все или ничего"];
      caseDropMsg = `\n📦 Стрик вырос до ${newStreak}, но FP не увеличилось. Вместо этого вы получили: ${caseNames[caseId]} (+1)`;
    }

    const isFifthBonus = newStreak % 5 === 0 && newStreak > currentStreak;

    if (isFifthBonus) {
      const multipliers = [
        { value: 1, weight: 35 },
        { value: 2, weight: 30 },
        { value: 3, weight: 20 },
        { value: 5, weight: 10 },
        { value: 10, weight: 4 },
        { value: 100, weight: 1 }
      ];
      let random = Math.random() * 100;
      let cumulative = 0;
      let multiplier = 1;
      for (const m of multipliers) {
        cumulative += m.weight;
        if (random <= cumulative) { multiplier = m.value; break; }
      }
      const totalBeforeWheel = baseBonus + streakFP;
      const finalBonus = totalBeforeWheel * multiplier;
      user.bonusStreak = newStreak;
      user.balance += finalBonus;
      user.bonustime = additionalTime;
      user.lastBonusTime = 7200;
      await botSend(context, `🔥 СТРИК ${newStreak}! Сработало КОЛЕСО ФОРТУНЫ!\nМножитель: x${multiplier}\nВы получили ${formatWithSpaces(finalBonus)} FP 💰${newStreak === 10 ? "\n🏆 Максимальный стрик достигнут!" : ""}`);
    } else {
      const totalBonus = baseBonus + streakFP;
      user.bonusStreak = newStreak;
      user.balance += totalBonus;
      user.bonustime = additionalTime;
      user.lastBonusTime = 7200;
      let reply = `${roleText}вы получили бонус +${formatWithSpaces(totalBonus)} FP 💵\n🔥 Стрик: ${newStreak}/10`;
      if (newStreak === 10) reply += `\n🏆 Максимальный стрик достигнут!`;
      else reply += `\n➕ До макс. стрика осталось: ${10 - newStreak}`;
      reply += caseDropMsg;
      await botSend(context, reply);
    }
  }
};