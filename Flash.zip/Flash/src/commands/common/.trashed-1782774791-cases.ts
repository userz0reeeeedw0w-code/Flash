import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext } from "../../core/mode/GameMode";
import { formatWithSpaces, pick } from "../../utils/number";

type Currency = "FP" | "RUB";
type CaseKey = `case${number}`;
type RoleCode = "vip" | "premium" | "legend" | "admin" | "donate" | "flash";
type RoleName = "VIP" | "Premium" | "LEGEND" | "Administrator" | "DONATE" | "Всемогущий";

interface CaseConfig {
  readonly id: number;
  readonly name: string;
  readonly emoji: string;
  readonly description: string;
  readonly price: number;
  readonly currency: Currency;
}

const DONATE_PRICE = 50;
const DURATION_DAYS = 30;

const CASES: Record<number, CaseConfig> = {
  1: {
    id: 1,
    name: "Мини кейс",
    emoji: "1⃣",
    description: "Маленький кейс с шансом на FP",
    price: 15_500_000,
    currency: "FP"
  },
  2: {
    id: 2,
    name: "Легендарный кейс",
    emoji: "2⃣",
    description: "Шанс на LEGEND или FP",
    price: DONATE_PRICE,
    currency: "RUB"
  },
  3: {
    id: 3,
    name: "Пиратский кейс",
    emoji: "3⃣",
    description: "FP, рефералы или бонус",
    price: 150_000_000_000,
    currency: "FP"
  },
  4: {
    id: 4,
    name: "Все или ничего",
    emoji: "4⃣",
    description: "75% пусто, 25% ADMIN",
    price: DONATE_PRICE,
    currency: "RUB"
  },
  5: {
    id: 5,
    name: "Кейс Богача",
    emoji: "5⃣",
    description: "VIP / LEGEND / Premium / Admin / Donate",
    price: DONATE_PRICE,
    currency: "RUB"
  },
  6: {
    id: 6,
    name: "Ultra кейс",
    emoji: "6⃣",
    description: "FP, RUB, DONATE, Всемогущий",
    price: DONATE_PRICE,
    currency: "RUB"
  }
};

const ROLE_NAMES: Record<RoleCode, RoleName> = {
  vip: "VIP",
  premium: "Premium",
  legend: "LEGEND",
  admin: "Administrator",
  donate: "DONATE",
  flash: "Всемогущий"
};

const resolveCaseKey = (id: number): CaseKey => `case${id}` as CaseKey;

const randomInt = (min: number, max: number): number =>
  Math.floor(Math.random() * (max - min + 1)) + min;

const messageOrSend = (context: VkMessageContext, text: string): Promise<unknown> => {
  return "send" in context && typeof context.send === "function"
    ? context.send(text)
    : context.message.send(text, { disable_mentions: 1 });
};

const sendWithKeyboard = (
  context: VkMessageContext,
  text: string,
  keyboard: any
): Promise<unknown> => {
  return "send" in context && typeof context.send === "function"
    ? context.send(text, { keyboard: JSON.stringify(keyboard), disable_mentions: 1 })
    : context.message.send(text, { keyboard: JSON.stringify(keyboard), disable_mentions: 1 });
};

const openAgainKeyboard = (id: number) => ({
  inline: true,
  buttons: [
    [
      {
        action: {
          type: "text",
          label: `Открыть ${id}`
        }
      }
    ]
  ]
});

const grantRole = async (
  context: VkMessageContext,
  roleCode: RoleCode,
  durationDays: number = DURATION_DAYS,
  compRange: [number, number] = [50_000, 400_000]
): Promise<void> => {
  const user = context.user!;

  if (user.permiss?.[roleCode]) {
    const compensation = randomInt(compRange[0], compRange[1]);
    user.balance += compensation;
    user.winnings = (user.winnings || 0) + compensation;
    await messageOrSend(
      context,
      `⚠️ У вас уже есть статус ${ROLE_NAMES[roleCode]}\n💸 Компенсация: ${formatWithSpaces(compensation)} FP`
    );
    return;
  }

  user.permiss = { ...user.permiss, [roleCode]: true };
  (user as any)[`${roleCode}_expires`] = Date.now() + durationDays * 86_400_000;

  if (roleCode === "donate") user.limit = 5_000_000;
  if (roleCode === "flash") user.limit = 10_000_000;

  await messageOrSend(
    context,
    `🎁 Вам выпал статус ${ROLE_NAMES[roleCode]} на ${durationDays} дней!`
  );
};

const processBuy = async (
  context: VkMessageContext,
  id: number,
  amount: number
): Promise<void> => {
  if (!Number.isFinite(id) || !Number.isFinite(amount) || amount < 1) {
    await messageOrSend(context, "❌ Укажите корректный номер кейса и количество.");
    return;
  }

  const caseMeta = CASES[id];
  if (!caseMeta) {
    await messageOrSend(context, "❌ Кейс не найден.");
    return;
  }

  const user = context.user!;
  const totalCost = caseMeta.price * amount;

  if (caseMeta.currency === "RUB") {
    await messageOrSend(context, `💳 Данный кейс приобретается за донат (${caseMeta.price} RUB).`);
    return;
  }

  if (user.balance < totalCost) {
    await messageOrSend(
      context,
      `❌ Недостаточно средств. Требуется: ${formatWithSpaces(totalCost)} FP.`
    );
    return;
  }

  user.balance -= totalCost;
  const key = resolveCaseKey(id);
  (user as any)[key] = ((user as any)[key] || 0) + amount;

  await messageOrSend(
    context,
    `✅ Приобретено: ${caseMeta.name} (x${amount}) за ${formatWithSpaces(totalCost)} FP.`
  );
};

const processOpen = async (context: VkMessageContext, id: number): Promise<void> => {
  const caseMeta = CASES[id];
  if (!caseMeta) {
    await messageOrSend(context, "❌ Кейс не найден.");
    return;
  }

  const user = context.user!;
  const key = resolveCaseKey(id);

  if (!((user as any)[key] > 0)) {
    await messageOrSend(context, "📦 У вас отсутствует данный кейс.");
    return;
  }

  (user as any)[key]--;
  const header = `${caseMeta.emoji} ${caseMeta.name}\n`;

  const kb = openAgainKeyboard(id);

  switch (id) {
    case 1: {
      const reward = randomInt(5_000_000, 20_000_000);
      user.balance += reward;
      user.winnings = (user.winnings || 0) + reward;
      await sendWithKeyboard(
        context,
        `${header}💸 Выигрыш: ${formatWithSpaces(reward)} FP`,
        kb
      );
      break;
    }

    case 2: {
      const type = pick(["money", "money", "money", "money", "role"]);
      if (type === "money") {
        const reward = randomInt(150_000_000, 30_000_000);
        user.balance += reward;
        user.winnings = (user.winnings || 0) + reward;
        await sendWithKeyboard(
          context,
          `${header}💸 Выигрыш: ${formatWithSpaces(reward)} FP`,
          kb
        );
      } else {
        await grantRole(context, "legend");
        await sendWithKeyboard(context, header, kb);
      }
      break;
    }

    case 3: {
      const type = pick(["fp", "ref", "bonus"]);
      if (type === "fp") {
        const reward = randomInt(250_000_000, 2_000_000_000);
        user.balance += reward;
        user.winnings = (user.winnings || 0) + reward;
        await sendWithKeyboard(
          context,
          `${header}💸 Выигрыш: ${formatWithSpaces(reward)} FP`,
          kb
        );
      } else if (type === "ref") {
        const count = randomInt(1, 3);
        user.ref_bonus = (user.ref_bonus || 0) + count * 100;
        user.refCount = (user.refCount || 0) + count;
        await sendWithKeyboard(
          context,
          `${header}👥 Выигрыш: ${count} реф.`,
          kb
        );
      } else {
        user.ref_bonus = (user.ref_bonus || 0) + 25000;
        await sendWithKeyboard(
          context,
          `${header}🎁 Выигрыш: +2500 к бонусу`,
          kb
        );
      }
      break;
    }

    case 4: {
      if (Math.random() > 0.25) {
        await sendWithKeyboard(
          context,
          `${header}❌ Пусто. Повезет в следующий раз!`,
          kb
        );
      } else {
        await grantRole(context, "admin");
        await sendWithKeyboard(context, header, kb);
      }
      break;
    }

    case 5: {
      const role = pick<RoleCode>([
        "vip", "vip", "vip",
        "premium", "premium",
        "legend", "legend",
        "admin",
        "donate"
      ]);
      await grantRole(context, role);
      await sendWithKeyboard(context, header, kb);
      break;
    }

    case 6: {
      const outcome = pick([
        "money", "money",
        "rub_small", "rub_big",
        "donate",
        "flash_14", "flash_30"
      ]);

      if (outcome === "money") {
        const reward = randomInt(50_000_000, 100_000_000);
        user.balance += reward;
        user.winnings = (user.winnings || 0) + reward;
        await sendWithKeyboard(
          context,
          `${header}💸 Выигрыш: ${formatWithSpaces(reward)} FP`,
          kb
        );
      } else if (outcome === "rub_small") {
        user.donate_rub = (user.donate_rub || 0) + 25;
        await sendWithKeyboard(context, `${header}💳 Выигрыш: 25 RUB`, kb);
      } else if (outcome === "rub_big") {
        user.donate_rub = (user.donate_rub || 0) + 80;
        await sendWithKeyboard(context, `${header}💳 Выигрыш: 80 RUB`, kb);
      } else if (outcome === "donate") {
        await grantRole(context, "donate");
        await sendWithKeyboard(context, header, kb);
      } else {
        const days = outcome === "flash_14" ? 14 : 30;
        await grantRole(context, "flash", days);
        await sendWithKeyboard(context, header, kb);
      }
      break;
    }

    default:
      await messageOrSend(context, "❌ Ошибка конфигурации кейса.");
  }
};

export const casesCommand: CommandDefinition<VkMessageContext> = {
  name: "common.cases",
  pattern: /^кейсы?$/i,
  handler: async context => {
    const user = context.user!;

    const list = Object.values(CASES)
      .map(c => {
        const price = c.currency === "FP"
          ? `${formatWithSpaces(c.price)} FP`
          : `${c.price} RUB`;
        return `${c.emoji} ${c.name} — ${price}\n   ${c.description}`;
      })
      .join("\n\n");

    let inventory = "";
    for (const c of Object.values(CASES)) {
      const count = (user as any)[resolveCaseKey(c.id)] || 0;
      if (count > 0) {
        inventory += `▪️ ${c.name}: ${formatWithSpaces(count)} шт.\n`;
      }
    }

    await messageOrSend(
      context,
      `📦 Магазин кейсов:\n\n${list}\n\n🛒 Купить: кейс <ID> <Кол-во>\n🎁 Открыть: открыть <ID>\n\n🎒 Инвентарь:\n${inventory || "Пусто"}`
    );
  }
};

export const buyCaseCommand: CommandDefinition<VkMessageContext> = {
  name: "common.buycase",
  pattern: /^кейс\s+(\d+)\s+(\d+)$/i,
  handler: async context => {
    const id = Number(context.match?.[1] ?? 0);
    const amount = Number(context.match?.[2] ?? 0);
    await processBuy(context, id, amount);
  }
};

export const openCaseCommand: CommandDefinition<VkMessageContext> = {
  name: "common.opencase",
  pattern: /^открыть\s+(\d+)$/i,
  handler: async context => {
    const id = Number(context.match?.[1] ?? 0);
    await processOpen(context, id);
  }
};