import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { formatWithSpaces } from "../../utils/number";
import { DoubleUser } from "../../types/database";
 
const formatRemainingTime = (expiresTimestamp?: number): string => {
  if (!expiresTimestamp) return "неограниченно";
  const diff = expiresTimestamp - Date.now();
  if (diff <= 0) return "истек";
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  if (days === 0 && hours === 0) return "менее часа";
  return `${days} д, ${hours} ч`;
};

const buildStatusesString = (user: DoubleUser): string => {
  const statuses: string[] = [];
  if (user.permiss.owner) {
    statuses.push("[🌹] OWNER");
  }
  if (user.permiss?.admin) {
    const timeLeft = formatRemainingTime(user?.admin_expires!);
    statuses.push(`[🔑] ADMINISTRATOR (${timeLeft})`);
  }
  if (user.permiss?.premium) {
    const timeLeft = formatRemainingTime(user?.premium_expires!);
    statuses.push(`[👑] PREMIUM (${timeLeft})`);
  }
  if (user.permiss?.vip) {
    const timeLeft = formatRemainingTime(user?.vip_expires!);
    statuses.push(`[✨] VIP (${timeLeft})`);
  }
  if (user.permiss?.legend) {
    const timeLeft = formatRemainingTime(user?.legend_expires!);
    statuses.push(`[🌏] LEGEND (${timeLeft})`);
  }
  if (user.permiss?.donate) {
    const timeLeft = formatRemainingTime(user?.donate_expires!);
    statuses.push(`[💎] DONATE (${timeLeft})`);
  }
  if (user.permiss?.flash) {
    const timeLeft = formatRemainingTime(user?.flash_expires!);
    statuses.push(`[⚡] Всемогущий (${timeLeft})`);
  }
  if (user.permiss?.sponsor) {
    const timeLeft = formatRemainingTime(user?.sponsor_expires!);
    statuses.push(`[💝] Спонсор проекта (${timeLeft})`);
  }
  if (user.permiss?.helper) {
    statuses.push("[💛] HELPER");  }
  if (statuses.length === 0) {
    return "";
  }
  return `\n👑 Статусы:\n ${statuses.join("\n ")}`;
};

const buildGameStatsString = (user: DoubleUser): string => {
  const hasStats =
    user.totalGames !== undefined ||
    user.totalWins !== undefined ||
    user.totalLosses !== undefined;
  if (!hasStats) return "";
  const totalGames = user.totalGames ?? 0;
  const totalWins = user.totalWins ?? 0;
  const totalLosses = user.totalLosses ?? 0;
  const winRate = totalGames > 0 ? ((totalWins / totalGames) * 100).toFixed(1) : "0.0";
  const stats = [
    `🎮 Игр: ${formatWithSpaces(totalGames)}`,
    `✅ Побед: ${formatWithSpaces(totalWins)} (${winRate}%)`,
    `❌ Поражений: ${formatWithSpaces(totalLosses)}\n`,
  ];
  return `\n🎮 Статистика:\n${stats.join("\n")}`;
};

const buildConnectionsString = (user: DoubleUser): string => {
  const connections: string[] = [];
  if (user.tgId) {
    connections.push(`✅ Привязан к Telegram`);
  }
  if (connections.length === 0) return "";
  return `\n${connections.join("\n")}`;
};

export const profileCommand: CommandDefinition<VkMessageContext> = {
  name: "common.profile",
  pattern: /^(?:👤 Профиль|проф|профиль)$/i,
  handler: async (context) => {
    const { user } = context;
    if (!user) return;

    if (user.fake === true) {
      const fakeBalance = Math.floor(1000 + Math.random() * 9000);
      const fakeLastBet = Math.floor(10 + Math.random() * 500);
      const fakeId = Math.floor(100000 + Math.random() * 900000);
      const fakeRegDate = new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000);
      const fakeGames = Math.floor(10 + Math.random() * 200);
      const fakeWins = Math.floor(fakeGames * (0.3 + Math.random() * 0.5));
      const fakeWinRate = fakeGames > 0 ? ((fakeWins / fakeGames) * 100).toFixed(1) : "0.0";
      const text = `
🆔 ID: ${fakeId}
📅 Регистрация: ${fakeRegDate.toLocaleDateString("ru-RU")}
🎮 Статистика:
🎮 Игр: ${formatWithSpaces(fakeGames)}
✅ Побед: ${formatWithSpaces(fakeWins)} (${fakeWinRate}%)
❌ Поражений: ${formatWithSpaces(fakeGames - fakeWins)}
💰 Баланс: ${formatWithSpaces(fakeBalance)} FP
🎲 Последняя ставка: ${formatWithSpaces(fakeLastBet)} FP
`;
      await botSend(context, text);
      return;
    }

    const profileSections: string[] = [];

    profileSections.push(`🆔 ID: ${user.uid}`);

    if (user.regDate) {
      const regDate = new Date(user.regDate).toLocaleDateString("ru-RU");
      profileSections.push(`📅 Регистрация: ${regDate}`);
    }

    const connections = buildConnectionsString(user);
    if (connections) profileSections.push(connections);

    const gameStats = buildGameStatsString(user);
    if (gameStats) profileSections.push(gameStats);

    profileSections.push(`💰 Баланс: ${formatWithSpaces(user.balance)} FP`);
    profileSections.push(`🎲 Последняя ставка: ${formatWithSpaces(user.lastbet)} FP`);

    const statuses = buildStatusesString(user);
    if (statuses) profileSections.push(statuses);

    const text = profileSections.join("\n");
    await botSend(context, `твой профиль:\n${text}`);
  },
};