import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { formatWithSpaces } from "../../utils/number";

export const balanceCommand: CommandDefinition<VkMessageContext> = {
  name: "common.balance",
  pattern: /^(?:баланс)$/i,
  handler: async context => {
    const { user } = context;
    if (!user) {
      return;
    }

    const donateRub = typeof user.donate_rub === "number" ? user.donate_rub : 0;
    const formattedDonate = new Intl.NumberFormat("ru-RU", {
      style: "currency",
      currency: "RUB"
    }).format(donateRub);

    await botSend(context, `ваш баланс: ${formatWithSpaces(user.balance)} FP 💸\nДонат рублей: ${formattedDonate}.`);
  }
};

