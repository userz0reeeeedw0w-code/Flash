import { CommandDefinition } from "../../core/mode/GameMode";
import { VkMessageContext } from "../../core/mode/GameMode";
import { BlackjackGame, DoubleUser, DoubleChat, BlackjackCard } from "../../types/database";
import { botSend } from "../../core/mode/GameMode";
import { buildKeyboard } from "../../utils/keyboard";
import { formatWithSpaces } from "../../utils/number";
import { updateGameStats } from "../../utils/gameStats";
const SUITS = ["♠", "♥", "♦", "♣"] as const;
const RANKS = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"] as const;
const TENS = ["10", "J", "Q", "K"];


const parseBetAmount = (raw: unknown, balance: number): number | null => {
    let value = String(raw ?? "").trim().toLowerCase();
    if (!value) return null;
    
    value = value.replace(/[.,]/g, "");
    value = value.replace(/(к|k)/gi, "000");
    value = value.replace(/(м|m)/gi, "000000");
    
    if (value.match(/(вс[её]|all|в[ао][ -]?банк)/gi)) {
        return balance;
    }
    
    value = value.replace(/\s+/g, "");
    const amount = Number.parseInt(value, 10);
    return Number.isFinite(amount) && amount > 0 ? amount : null;
};

const createDeck = (): BlackjackCard[] => {
    const deck: BlackjackCard[] = [];
    for (const suit of SUITS) {
        for (const rank of RANKS) {
            deck.push({ rank, suit });
        }
    }
    return deck;
};

const shuffleInPlace = <T>(array: T[]): void => {
    for (let i = array.length - 1; i > 0; i -= 1) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
};

const ensureBettingGame = (user: DoubleUser): BlackjackGame => {
    const existing = user.blackjack;
    
    if (existing && existing.phase === "betting") {
        existing.updatedAt = Date.now();
        existing.bet = 0;
        existing.player = existing.player ?? [];
        existing.dealer = existing.dealer ?? [];
        existing.deck = existing.deck ?? [];
        existing.splitCards = null;
        existing.splitBet = 0;
        existing.activeHand = "main";
        existing.mainFinished = false;
        existing.splitFinished = false;
        existing.player.length = 0;
        existing.dealer.length = 0;
        return existing;
    }
    
    const now = Date.now();
    const created: BlackjackGame = {
        phase: "betting",
        bet: 0,
        deck: [],
        player: [],
        dealer: [],
        splitCards: null,
        splitBet: 0,
        activeHand: "main",
        mainFinished: false,
        splitFinished: false,
        updatedAt: now
    };
    
    user.blackjack = created;
    return created;
};

const ensureDeckReady = (game: BlackjackGame): void => {
    if (Array.isArray(game.deck) && game.deck.length > 0) return;
    const deck = createDeck();
    shuffleInPlace(deck);
    game.deck = deck;
};

const drawCard = (game: BlackjackGame): BlackjackCard => {
    if (!Array.isArray(game.deck) || game.deck.length === 0) {
        const deck = createDeck();
        shuffleInPlace(deck);
        game.deck = deck;
    }
    return game.deck.pop()!;
};

const cardText = (card: BlackjackCard): string => `${card.rank}${card.suit}`;

const handValue = (hand: BlackjackCard[]) => {
    let total = 0;
    let aces = 0;
    
    for (const card of hand) {
        const r = card.rank;
        if (r === "A") {
            total += 11;
            aces += 1;
        } else if (r === "K" || r === "Q" || r === "J") {
            total += 10;
        } else {
            total += Number.parseInt(r, 10);
        }
    }
    
    while (total > 21 && aces > 0) {
        total -= 10;
        aces -= 1;
    }
    
    return { total, soft: aces > 0 };
};

const isBlackjack = (hand: BlackjackCard[]): boolean => {
    return hand.length === 2 && handValue(hand).total === 21;
};

const canSplit = (hand: BlackjackCard[], balance: number, currentBet: number): boolean => {
    if (!hand || hand.length !== 2) return false;
    if (balance < currentBet) return false;
    
    const rank1 = hand[0].rank;
    const rank2 = hand[1].rank;
    
    if (TENS.includes(rank1) && TENS.includes(rank2)) {
        return true;
    }
    
    return rank1 === rank2;
};


const buildBetKeyboard = (userBalance: number, lastBet: number) => {
    const lb = lastBet > 0 ? String(lastBet) : "100";
    const keyboard = buildKeyboard({
        inline: true,
        buttons: [
            [
                { label: "50", color: "primary", command: "21 50" },
                { label: lb, color: "primary", command: `21 ${lb}` },
                { label: "500", color: "primary", command: "21 500" }
            ],
            [
                { label: "1к", color: "secondary", command: "21 1к" },
                { label: "5к", color: "secondary", command: "21 5к" },
                { label: "Ва-банк", color: "negative", command: `21 ${userBalance}` }
            ],
            [
                { label: "Баланс", color: "positive", command: "баланс" },
                { label: "Отмена", color: "default", command: "21 отмена" }
            ]
        ]
    });
    
    if (userBalance < 50) {
        return buildKeyboard({
            inline: true,
            buttons: [[{ label: "Баланс", color: "positive", command: "баланс" }]]
        });
    }
    
    return keyboard;
};

const buildActionKeyboard = (canSplit: boolean = false) => {
    const buttons: any[] = [
        [
            { label: "Взять 🃏", color: "positive", command: "21 взять" },
            { label: "Стоп ✋", color: "primary", command: "21 стоп" }
        ]
    ];
    
    if (canSplit) {
        buttons.unshift([
            { label: "Сплит ✂️", color: "secondary", command: "21 сплит" }
        ]);
    }
    
    buttons.push([{ label: "Отмена ❌", color: "default", command: "21 отмена" }]);
    
    return buildKeyboard({
        inline: true,
        buttons
    });
};

const buildFinishedKeyboard = (lastBet: number) => {
    return buildKeyboard({
        inline: true,
        buttons: [
            [
                { label: "Ещё раз 🔄", color: "positive", command: `21 ${lastBet}` },
                { label: "Новая ставка 💰", color: "primary", command: "21 ставка" }
            ],
            [{ label: "Баланс 📊", color: "secondary", command: "баланс" }]
        ]
    });
};


interface RenderOptions {
    revealDealer: boolean;
}

const renderTable = (game: BlackjackGame, options: RenderOptions): string => {
    const player = Array.isArray(game.player) ? game.player : [];
    const dealer = Array.isArray(game.dealer) ? game.dealer : [];
    
    const dealerCards = options.revealDealer
        ? dealer.map(cardText).join(" ")
        : dealer.length > 0
            ? `${cardText(dealer[0])} 🂠`
            : "🂠";
    
    if (game.splitCards) {
        return renderSplitTable(game, options);
    }
    
    const playerValue = handValue(player).total;
    const dealerTotalText = options.revealDealer ? String(handValue(dealer).total) : "?";
    
    return `🃏 21 очко\n\n` +
        `💰 Ставка: ${formatWithSpaces(game.bet)} FP\n\n` +
        `👤 Дилер: ${dealerCards} (${dealerTotalText})\n` +
        `👋 Ты: ${player.map(cardText).join(" ")} (${playerValue})`;
};

const renderSplitTable = (game: BlackjackGame, options: RenderOptions): string => {
    const mainHand = game.player;
    const splitHand = game.splitCards!;
    const dealer = game.dealer;
    
    const mainValue = handValue(mainHand).total;
    const splitValue = handValue(splitHand).total;
    
    const dealerCards = options.revealDealer
        ? dealer.map(cardText).join(" ")
        : dealer.length > 0
            ? `${cardText(dealer[0])} 🂠`
            : "🂠";
    const dealerTotalText = options.revealDealer ? String(handValue(dealer).total) : "?";
    
    let activeMarker1 = "";
    let activeMarker2 = "";
    if (!options.revealDealer && game.phase === "split") {
        if (game.activeHand === "main" && !game.mainFinished) activeMarker1 = "👉 ";
        if (game.activeHand === "split" && !game.splitFinished) activeMarker2 = "👉 ";
    }
    
    let result = `🃏 21 очко (Сплит)\n\n`;
    result += `💰 Ставка: ${formatWithSpaces(game.bet)} FP + ${formatWithSpaces(game.splitBet!)} FP\n\n`;
    result += `👤 Дилер: ${dealerCards} (${dealerTotalText})\n\n`;
    result += `${activeMarker1}Рука 1: ${mainHand.map(cardText).join(" ")} (${mainValue})\n`;
    result += `${activeMarker2}Рука 2: ${splitHand.map(cardText).join(" ")} (${splitValue})\n`;
    
    if (!options.revealDealer && game.phase === "split") {
        result += `\nСейчас ходит ${game.activeHand === "main" ? "Рука 1" : "Рука 2"}`;
    }
    
    return result;
};

const dealerPlay = (game: BlackjackGame): void => {
    while (true) {
        const { total, soft } = handValue(game.dealer);
        if (total > 21) return;
        if (total > 17) return;
        if (total === 17 && soft) return;
        if (total === 17 && !soft) return;
        game.dealer.push(drawCard(game));
    }
};

const outcomeLabel = (outcome?: string): string => {
    if (outcome === "blackjack") return "блэкджек 🎉";
    if (outcome === "win") return "победа 🏆";
    if (outcome === "push") return "ничья 🤝";
    return "поражение 😢";
};

const renderFinished = (game: BlackjackGame, lastBet: number): string => {
    const table = renderTable(game, { revealDealer: true });
    
    if (game.splitCards) {
        const totalBet = game.bet + game.splitBet!;
        const profit = game.payout! - totalBet;
        let profitText = "";
        if (profit === 0) profitText = "0";
        else if (profit > 0) profitText = `+${formatWithSpaces(profit)}`;
        else profitText = `-${formatWithSpaces(Math.abs(profit))}`;
        
        return `${table}\n\nИтог:\n💰 Выплата: ${formatWithSpaces(game.payout!)} FP (${profitText} FP)`;
    }
    
    const bet = Math.max(0, Math.floor(Number(game.bet || 0)));
    const delta = game.payout! - bet;
    let deltaText = "";
    if (delta === 0) deltaText = "0";
    else if (delta > 0) deltaText = `+${formatWithSpaces(delta)}`;
    else deltaText = `-${formatWithSpaces(Math.abs(delta))}`;
    
    return `${table}\n\nИтог: ${outcomeLabel(game.outcome)}\n💰 Выплата: ${formatWithSpaces(game.payout || 0)} FP (${deltaText} FP)`;
};

const settleSplit = (user: DoubleUser, game: BlackjackGame): void => {
    const dealerHand = game.dealer;
    const dealerTotal = handValue(dealerHand).total;
    
    const mainTotal = handValue(game.player).total;
    let mainPayout = 0;
    if (mainTotal > 21) {
        mainPayout = 0;
    } else if (dealerTotal > 21) {
        mainPayout = game.bet * 2;
    } else if (mainTotal > dealerTotal) {
        mainPayout = game.bet * 2;
    } else if (mainTotal < dealerTotal) {
        mainPayout = 0;
    } else {
        mainPayout = game.bet;
    }
    
    const splitTotal = handValue(game.splitCards!).total;
    let splitPayout = 0;
    if (splitTotal > 21) {
        splitPayout = 0;
    } else if (dealerTotal > 21) {
        splitPayout = game.splitBet! * 2;
    } else if (splitTotal > dealerTotal) {
        splitPayout = game.splitBet!! * 2;
    } else if (splitTotal < dealerTotal) {
        splitPayout = 0;
    } else {
        splitPayout = game.splitBet!;
    }
    
    const totalPayout = mainPayout + splitPayout;
    user.balance += totalPayout;
    user.winnings = (user.winnings || 0) + totalPayout;
    
    game.phase = "finished";
    game.payout = totalPayout;
    game.updatedAt = Date.now();
};

const normalizeArg = (raw: unknown): string => {
    return String(raw ?? "")
        .trim()
        .toLowerCase()
        .replace(/\s+/g, " ");
};

const isBetKeyword = (arg: string): boolean => {
    return arg === "ставка" || arg.startsWith("ставка ");
};

const isHitKeyword = (arg: string): boolean => {
    return arg === "взять" || arg === "еще" || arg === "ещё" || arg === "hit" || arg === "карту";
};

const isStandKeyword = (arg: string): boolean => {
    return arg === "стоп" || arg === "хватит" || arg === "stand" || arg === "enough";
};

const isSplitKeyword = (arg: string): boolean => {
    return arg === "сплит" || arg === "split" || arg === "разделить";
};

const isCancelKeyword = (arg: string): boolean => {
    return arg === "отмена" || arg === "выйти" || arg === "выход" || arg === "cancel";
};

// ==================== GAME HANDLERS ====================

const startWithBet = async (context: VkMessageContext, betRaw: string): Promise<void> => {
    const user = context?.user!;
    const game = ensureBettingGame(user);
    const amount = parseBetAmount(betRaw, user.balance);
    
    if (!amount || amount < 50) {
        await botSend(
            context,
            `❌ Ставка должна быть не менее 50 FP.\n💰 Твой баланс: ${formatWithSpaces(user.balance)} FP`,
            { keyboard: buildBetKeyboard(user.balance, user.lastbet) }
        );
        return;
    }
    
    const bet = Math.min(amount, user.balance);
    if (bet < 50) {
        await botSend(
            context,
            `❌ Недостаточно средств для ставки 50 FP.\n💰 Твой баланс: ${formatWithSpaces(user.balance)} FP`,
            { keyboard: buildBetKeyboard(user.balance, user.lastbet) }
        );
        return;
    }
    
    user.balance -= bet;
    user.lastbet = bet;
    
    ensureDeckReady(game);
    game.bet = bet;
    game.player = [];
    game.dealer = [];
    game.splitCards = null;
    game.splitBet = 0;
    game.phase = "player";
    game.mainFinished = false;
    game.splitFinished = false;
    game.outcome = undefined;
    game.payout = undefined;
    game.activeHand = "main";
    
    game.player.push(drawCard(game));
    game.dealer.push(drawCard(game));
    game.player.push(drawCard(game));
    game.dealer.push(drawCard(game));
    
    const playerBJ = isBlackjack(game.player);
    const dealerBJ = isBlackjack(game.dealer);
    
    if (playerBJ && dealerBJ) {
        user.balance += bet;
        user.winnings = (user.winnings || 0) + bet;
        game.phase = "finished";
        game.outcome = "push";
        updateGameStats(user, "push");
        game.payout = bet;
        await botSend(context, renderFinished(game, user.lastbet),
            { keyboard: buildFinishedKeyboard(user.lastbet) }
        );
        return;
    }
    
    if (playerBJ) {
        const payout = Math.floor(bet * 2.5);
        user.balance += payout;
        user.winnings = (user.winnings || 0) + payout;
        game.phase = "finished";
        game.outcome = "blackjack";
        updateGameStats(user, "blackjack");
        game.payout = payout;
        await botSend(context, renderFinished(game, user.lastbet),
            { keyboard: buildFinishedKeyboard(user.lastbet) }
        );
        return;
    }
    
    if (dealerBJ) {
        game.phase = "finished";
        game.outcome = "lose";
        updateGameStats(user, "lose");
        game.payout = 0;
        await botSend(context, renderFinished(game, user.lastbet),
            { keyboard: buildFinishedKeyboard(user.lastbet) }
        );
        return;
    }
    
    const canSplitHand = canSplit(game.player, user.balance, game.bet);
    await botSend(context, renderTable(game, { revealDealer: false }),
        { keyboard: buildActionKeyboard(canSplitHand) }
    );
};

const handleSplit = async (context: VkMessageContext): Promise<void> => {
    const user = context?.user!;
    const game = user?.blackjack as BlackjackGame;
    
    if (!game || game.phase !== "player" || game.bet <= 0) {
        await botSend(context, "❌ Сейчас нет активной игры. Напиши: 21 ставка");
        return;
    }
    
    if (!canSplit(game.player, user.balance, game.bet)) {
        await botSend(context, "❌ Нельзя сделать сплит", {
            keyboard: buildActionKeyboard(false)
        });
        return;
    }
    
    user.balance -= game.bet;
    
    const secondCard = game.player.pop()!;
    game.splitCards = [secondCard];
    game.splitBet = game.bet;
    
    ensureDeckReady(game);
    game.player.push(drawCard(game));
    game.splitCards.push(drawCard(game));
    
    game.phase = "split";
    game.activeHand = "main";
    game.mainFinished = false;
    game.splitFinished = false;
    
    const message = renderTable(game, { revealDealer: false });
    await botSend(context, message, {
        keyboard: buildActionKeyboard(false)
    });
};

const handleHit = async (context: VkMessageContext): Promise<void> => {
    const user = context?.user!;
    const game = user?.blackjack as BlackjackGame;
    
    if (!game || (game.phase !== "player" && game.phase !== "split") || game.bet <= 0) {
        await botSend(context, "❌ Сейчас нет активной игры. Напиши: 21 ставка");
        return;
    }
    
    ensureDeckReady(game);
    
    if (game.phase === "split") {
        let activeHand: BlackjackCard[];
        if (game.activeHand === "main") {
            activeHand = game.player;
        } else {
            activeHand = game.splitCards!;
        }
        
        activeHand.push(drawCard(game));
        
        const { total } = handValue(activeHand);
        
        if (total > 21) {
            if (game.activeHand === "main") {
                game.mainFinished = true;
                if (!game.splitFinished) {
                    game.activeHand = "split";
                } else {
                    dealerPlay(game);
                    settleSplit(user, game);
                    await botSend(context, renderFinished(game, user.lastbet),
                        { keyboard: buildFinishedKeyboard(user.lastbet) }
                    );
                    return;
                }
            } else {
                game.splitFinished = true;
                if (!game.mainFinished) {
                    game.activeHand = "main";
                } else {
                    dealerPlay(game);
                    settleSplit(user, game);
                    await botSend(context, renderFinished(game, user.lastbet),
                        { keyboard: buildFinishedKeyboard(user.lastbet) }
                    );
                    return;
                }
            }
        } else if (total === 21) {
            if (game.activeHand === "main") {
                game.mainFinished = true;
                if (!game.splitFinished) {
                    game.activeHand = "split";
                } else {
                    dealerPlay(game);
                    settleSplit(user, game);
                    await botSend(context, renderFinished(game, user.lastbet),
                        { keyboard: buildFinishedKeyboard(user.lastbet) }
                    );
                    return;
                }
            } else {
                game.splitFinished = true;
                if (!game.mainFinished) {
                    game.activeHand = "main";
                } else {
                    dealerPlay(game);
                    settleSplit(user, game);
                    await botSend(context, renderFinished(game, user.lastbet),
                        { keyboard: buildFinishedKeyboard(user.lastbet) }
                    );
                    return;
                }
            }
        }
        
        const message = renderTable(game, { revealDealer: false });
        await botSend(context, message, {
            keyboard: buildActionKeyboard(false)
        });
        return;
    }
    
    game.player.push(drawCard(game));
    game.updatedAt = Date.now();
    
    const { total } = handValue(game.player);
    
    if (total > 21) {
        game.phase = "finished";
        game.outcome = "lose";
        updateGameStats(user, "lose");
        game.payout = 0;
        await botSend(context, renderFinished(game, user.lastbet),
            { keyboard: buildFinishedKeyboard(user.lastbet) }
        );
        return;
    }
    
    if (total === 21) {
        await handleStand(context);
        return;
    }
    
    await botSend(context, renderTable(game, { revealDealer: false }),
        { keyboard: buildActionKeyboard(canSplit(game.player, user.balance, game.bet)) }
    );
};

const handleStand = async (context: VkMessageContext): Promise<void> => {
    const user = context?.user!;
    const game = user?.blackjack as BlackjackGame;
    
    if (!game || (game.phase !== "player" && game.phase !== "split") || game.bet <= 0) {
        await botSend(context, "❌ Сейчас нет активной игры. Напиши: 21 ставка");
        return;
    }
    
    if (game.phase === "split") {
        if (game.activeHand === "main") {
            game.mainFinished = true;
            if (!game.splitFinished) {
                game.activeHand = "split";
                const message = renderTable(game, { revealDealer: false });
                await botSend(context, message, {
                    keyboard: buildActionKeyboard(false)
                });
                return;
            }
        } else {
            game.splitFinished = true;
            if (!game.mainFinished) {
                game.activeHand = "main";
                const message = renderTable(game, { revealDealer: false });
                await botSend(context, message, {
                    keyboard: buildActionKeyboard(false)
                });
                return;
            }
        }
        
        dealerPlay(game);
        settleSplit(user, game);
        await botSend(context, renderFinished(game, user.lastbet),
            { keyboard: buildFinishedKeyboard(user.lastbet) }
        );
        return;
    }
    
    ensureDeckReady(game);
    dealerPlay(game);
    
    const playerTotal = handValue(game.player).total;
    const dealerTotal = handValue(game.dealer).total;
    
    if (dealerTotal > 21) {
        game.outcome = "win";
        updateGameStats(user, "win");
        game.payout = game.bet * 2;
        user.balance += game.payout;
        user.winnings = (user.winnings || 0) + game.payout;
    } else if (playerTotal > dealerTotal) {
        game.outcome = "win";
        updateGameStats(user, "win");
        game.payout = game.bet * 2;
        user.balance += game.payout;
        user.winnings = (user.winnings || 0) + game.payout;
    } else if (playerTotal < dealerTotal) {
        game.outcome = "lose";
        updateGameStats(user, "lose");
        game.payout = 0;
    } else {
        game.outcome = "push";
        updateGameStats(user, "push");
        game.payout = game.bet;
        user.balance += game.payout;
        user.winnings = (user.winnings || 0) + game.payout;
    }
    
    game.phase = "finished";
    game.updatedAt = Date.now();
    
    await botSend(context, renderFinished(game, user.lastbet),
        { keyboard: buildFinishedKeyboard(user.lastbet) }
    );
};

const handleCancel = async (context: VkMessageContext): Promise<void> => {
    const user = context?.user!;
    const game = user?.blackjack as BlackjackGame;
    
    if (game) {
        if (game.phase !== "finished" && Number(game.bet) > 0) {
            user.balance += game.bet;
            user.winnings = (user.winnings || 0) + game.bet;
            if (game.splitBet! > 0) {
                user.balance += game.splitBet!;
                user.winnings = (user.winnings || 0) + game.splitBet!;
            }
        }
    }
    
    user.blackjack = undefined;
    await botSend(context, "🃏 Игра закрыта. Возвращайся ещё!",
        { keyboard: buildFinishedKeyboard(user.lastbet) }
    );
};

export const blackjackCommand: CommandDefinition<VkMessageContext> = {
    name: "common.blackjack",
    pattern: /^(?:21|бл(?:э|е)кджек|blackjack)(?:\s+(.*))?$/i,
    guard: (context: VkMessageContext) => Boolean(context.user && !context.isChat),
    handler: async (context) => {
        const user = context?.user!;
        const arg = normalizeArg(context.match?.[1] ?? "");
        
        if (isCancelKeyword(arg)) {
            await handleCancel(context);
            return;
        }
        
        if (isHitKeyword(arg)) {
            await handleHit(context);
            return;
        }
        
        if (isStandKeyword(arg)) {
            await handleStand(context);
            return;
        }
        
        if (isSplitKeyword(arg)) {
            await handleSplit(context);
            return;
        }
        
        if (isBetKeyword(arg)) {
            const betRaw = arg === "ставка" ? "" : arg.replace(/^ставка\s+/i, "");
            if (!betRaw) {
                ensureBettingGame(user);
                await botSend(
                    context,
                    `🃏 Мини-игра «21 очко»\n\n` +
                    `💰 Твой баланс: ${formatWithSpaces(user.balance)} FP\n\n` +
                    `Выбери ставку:`,
                    { keyboard: buildBetKeyboard(user.balance, user.lastbet) }
                );
                return;
            }
            await startWithBet(context, betRaw);
            return;
        }
        
        if (arg) {
            await startWithBet(context, arg);
            return;
        }
        
        const game = user?.blackjack as BlackjackGame;
        
        if (game?.phase === "player" || game?.phase === "split") {
            const canSplitHand = game.phase === "player" ? canSplit(game.player, user.balance, game.bet) : false;
            await botSend(context, renderTable(game, { revealDealer: false }),
                { keyboard: buildActionKeyboard(canSplitHand) }
            );
            return;
        }
        
        if (game?.phase === "finished") {
            await botSend(context, renderFinished(game, user.lastbet),
                { keyboard: buildFinishedKeyboard(user.lastbet) }
            );
            return;
        }
        
        ensureBettingGame(user);
        await botSend(
            context,
            `🃏 Мини-игра «21 очко»\n\n` +
            `Правила:\n` +
            `• Ставка от 50 FP\n` +
            `• Блэкджек платит 3:2\n` +
            `• Можно сплитовать:\n` +
            `  - одинаковые карты (A-A, K-K, 10-10, 9-9 и т.д.)\n` +
            `  - 10 с J/Q/K\n\n` +
            `💰 Твой баланс: ${formatWithSpaces(user.balance)} FP\n\n` +
            `Выбери ставку:`,
            { keyboard: buildBetKeyboard(user.balance, user.lastbet) }
        );
    }
};