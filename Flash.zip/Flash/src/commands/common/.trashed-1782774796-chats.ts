import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";

export const chatsCommand: CommandDefinition<VkMessageContext> = {
  name: "common.chats",
  pattern: /^(?:💬 Беседы|Беседы)$/i,
  handler: async context => {
    const getKeyboard = () => {
      const baseButtons = [
        { label: "💬 Crash" },
        { label: "💬 Double" },
        { label: "💬 Кости" },
        { label: "💬 Под 7 Над" }
      ];

      if (context.platform === "vk") {
        const vkLinks = [
          "https://vk.me/join/2VGzrCX6bd16SJAfvUgoZlCUU/Siy3XopV8=",
          "https://vk.me/join/Tf/lURsnrwCZPt7ltEW6CqMBUYH9e7hh3O4=",
          "https://vk.me/join/CyeuDayEL0dyqWO/WknqNqSph6nG6ScaFvA=",
          "https://vk.me/join/GaBrkRNw8HJ1rLiU/f04a0boCPhHHiLBa6M="
        ];

        return {
          inline: true,
          buttons: baseButtons.map((btn, idx) => [
            {
              action: {
                type: "open_link",
                link: vkLinks[idx],
                label: btn.label
              }
            }
          ])
        };
      } else {
        const telegramLinks = [
          "https://t.me/+6PlRaelP3DxjYzZi",
          "https://t.me/+1ArDV_WPofkxOWJi",
          "https://t.me/",
          "https://t.me/+Q2wBDlhLqNxkMzE6"
        ];

        return {
          inline: true,
          buttons: baseButtons.map((btn, idx) => [
            {
              action: {
                type: "open_link",
                link: telegramLinks[idx],
                label: btn.label
              }
            }
          ])
        };
      }
    };

    await botSend(context, "💬 Вот ваши беседы", {
      keyboard: JSON.stringify(getKeyboard())
    });
  }
};