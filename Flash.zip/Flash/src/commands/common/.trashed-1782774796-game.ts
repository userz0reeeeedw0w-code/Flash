import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { buildKeyboard } from "../../utils/keyboard";

type ModeId = "double" | "crash" | "seven" | "dice";

const modeToType: Record<ModeId, number> = {
  double: 1,
  crash: 2,
  seven: 3,
  dice: 4
};

const modeLabel: Record<ModeId, string> = {
  double: "Дабл",
  crash: "Краш",
  seven: "Под7Над",
  dice: "Кости"
};

const modeCost: Record<ModeId, number> = {
  double: 150000,
  crash: 150000,
  seven: 150000,
  dice: 150000
};

const isChatAdmin = async (context: VkMessageContext): Promise<boolean> => {
  if (context.platform === "tg") {
    const tg = context.tg;
    const tgUserId = context.tgUserId;
    if (!tg || !tgUserId) return false;
    const member = await tg.getChatMember(context.peerId, tgUserId);
    if (!member) return false;
    return member.status === "creator" || member.status === "administrator";
  }

  const { vk, peerId, senderId } = context;
  if (!vk) {
    return false;
  }

  const members = await vk.api.messages.getConversationMembers({
    peer_id: peerId
  });

  const entry = members.items.find(m => Number(m.member_id) === senderId);
  if (!entry) {
    return false;
  }

  return Boolean((entry as any).is_admin || (entry as any).is_owner);
};

export const gameCreateCommand: CommandDefinition<VkMessageContext> = {
  name: "common.gameCreate",
  pattern: /^(?:игра создать)$/i,
  guard: context => Boolean(context.chat && context.user && context.isChat),
  handler: async context => {
    const { chat } = context;
    if (!chat || !context.user || !context.isChat) {
      return;
    }

    const admin = await isChatAdmin(context).catch(() => false);
    if (!admin) {
      await botSend(context, "Вы не админ этой беседы!");
      return;
    }

    const keyboard = buildKeyboard({
      inline: true,
      buttons: [
        [
          { label: "Дабл", color: "positive", command: "игра выбрать double" },
          { label: "Краш", color: "positive", command: "игра выбрать crash" }
        ],
        [
          { label: "Под7Над", color: "positive", command: "игра выбрать seven" },
          { label: "Кости", color: "positive", command: "игра выбрать dice" }
        ],
        [{ label: "Отмена", color: "negative", command: "игра отмена" }]
      ]
    });

    await botSend(context, "Выберите режим игры:", { keyboard });
  }
};

export const gameSelectCommand: CommandDefinition<VkMessageContext> = {
  name: "common.gameSelect",
  pattern: /^(?:игра выбрать)\s+(double|crash|seven|dice)$/i,
  guard: context => Boolean(context.chat && context.user && context.isChat),
  handler: async context => {
    const { chat } = context;
    if (!chat || !context.user || !context.isChat) {
      return;
    }

    const admin = await isChatAdmin(context).catch(() => false);
    if (!admin) {
      await botSend(context, "Вы не админ этой беседы!");
      return;
    }

    const mode = (context.match?.[1] ?? "").toLowerCase() as ModeId;
    if (!modeToType[mode]) {
      await botSend(context, "Неизвестный режим.");
      return;
    }

    chat.pendingGameType = modeToType[mode];
    chat.pendingGameAt = Date.now();

    const keyboard = buildKeyboard({
      inline: true,
      buttons: [
        [
          { label: "Уверен", color: "positive", command: "игра.уверен" },
          { label: "Отмена", color: "negative", command: "игра отмена" }
        ]
      ]
    });

    await botSend(
      context,
      `Вы уверены, что хотите перевести эту беседу в режим "${modeLabel[mode]}"?\nСтоимость: ${modeCost[mode].toLocaleString("ru-RU")} FP`,
      { keyboard }
    );
  }
};

export const gameConfirmCommand: CommandDefinition<VkMessageContext> = {
  name: "common.gameConfirm",
  pattern: /^(?:игра\.уверен)$/i,
  guard: context => Boolean(context.chat && context.user && context.isChat),
  handler: async context => {
    const { chat, user } = context;
    if (!chat || !user || !context.isChat) {
      return;
    }

    const admin = await isChatAdmin(context).catch(() => false);
    if (!admin) {
      await botSend(context, "Вы не админ этой беседы!");
      return;
    }

    const pendingType = chat.pendingGameType;
    const pendingAt = chat.pendingGameAt;
    if (!pendingType || !pendingAt) {
      await botSend(context, 'Сначала выберите режим командой "игра создать".');
      return;
    }

    if (Date.now() - pendingAt > 2 * 60 * 1000) {
      chat.pendingGameType = undefined;
      chat.pendingGameAt = undefined;
      await botSend(context, 'Подтверждение устарело. Введите "игра создать" ещё раз.');
      return;
    }

    const mode = (Object.keys(modeToType) as ModeId[]).find(m => modeToType[m] === pendingType);
    if (!mode) {
      chat.pendingGameType = undefined;
      chat.pendingGameAt = undefined;
      await botSend(context, "Невозможно подтвердить: неизвестный режим.");
      return;
    }

    const cost = modeCost[mode];
    if (user.balance < cost) {
      await botSend(context, `Недостаточно средств! (Нужно ${cost.toLocaleString("ru-RU")} FP)`);
      return;
    }

    user.balance -= cost;

    chat.type = pendingType;
    chat.games = [];
    chat.gametime = mode === "crash" ? 30 : 60;
    chat.game = false;
    chat.start = false;
    chat.firstbet = false;
    chat.pendingGameType = undefined;
    chat.pendingGameAt = undefined;

    await botSend(context, `Чат был переведён в режим "${modeLabel[mode]}"!\nИгра будет запущена после следующего сообщения.`);
  }
};

export const gameCancelCommand: CommandDefinition<VkMessageContext> = {
  name: "common.gameCancel",
  pattern: /^(?:игра отмена)$/i,
  guard: context => Boolean(context.chat && context.isChat),
  handler: async context => {
    const { chat } = context;
    if (!chat || !context.isChat) {
      return;
    }
    chat.pendingGameType = undefined;
    chat.pendingGameAt = undefined;
    await botSend(context, "Отменено.");
  }
};
