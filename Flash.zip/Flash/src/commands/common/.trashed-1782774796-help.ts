import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { buildKeyboard } from "../../utils/keyboard";

const buildDmKeyboard = (): string => {
  return buildKeyboard({
    oneTime: false,
    buttons: [
      [
        { label: "👤 Профиль", color: "primary", command: "профиль" },
        { label: "💰 Баланс", color: "positive", command: "баланс" }
      ],
      [
        { label: "🏆 Рейтинг", color: "negative", command: "рейтинг" },
        { label: "🎁 Бонус", color: "positive", command: "бонус" }
      ],
      [
        { label: "🃏 21 очко", color: "primary", command: "21" },
        { label: "💳 Донат", color: "default", command: "донат" }
      ],
      [
        { label: "❤️ Лайк", color: "default", command: "лайк" }
      ],
      [{ label: "ℹ️ Помощь", color: "secondary", command: "помощь" }]
    ]
  });
};

export const helpCommand: CommandDefinition<VkMessageContext> = {
  name: "common.help",
  pattern: /^(?:помощь|help|команды|меню)$/i,
  handler: async context => {
    const { chat, isChat } = context;

    const common =
      `📌 Основные команды:\n` +
      `- профиль\n` +
      `- баланс\n` +
      `- бонус\n` +
      `- рейтинг\n` +
      `- донат\n` +
      `- перевод [id] [сумма]\n` +
      `- 21 [ставка] (ЛС)\n` +
      `- лайк\n` +
      `- уведы вкл/выкл\n` +
      `- кнопки / кнопки выкл\n` +
      `- ник <новый ник>\n` +
      `- тег вкл/выкл\n`;

    let mode = "";
    if (isChat && chat && chat.type !== 0) {
      if (chat.type === 1) {
        mode =
          `\n🎮 Режим «Дабл»:\n` +
          `- x2 / x3 / x5 / x50 [сумма]\n` +
          `- банк\n` +
          `- обновить кнопки\n`;
      } else if (chat.type === 2) {
        mode =
          `\n🎮 Режим «Краш»:\n` +
          `- ставка [сумма]\n` +
          `- ставка [сумма] [множитель] (авто-вывод)\n` +
          `- забрать\n` +
          `- банк\n` +
          `- обновить кнопки\n`;
      } else if (chat.type === 3) {
        mode =
          `\n🎮 Режим «Под7Над»:\n` +
          `- >7 / <7 / =7 [сумма]\n` +
          `- банк\n` +
          `- обновить кнопки\n`;
      } else if (chat.type === 4) {
        mode =
          `\n🎮 Режим «Кости»:\n` +
          `- кости [сумма]\n` +
          `- принять [uid]\n` +
          `- отменить ставку\n` +
          `- обновить кнопки\n`;
      }
    } else if (isChat && chat && chat.type === 0) {
      mode =
        `\n🛠 Управление беседой:\n` +
        `- игра создать\n` +
        `- игра выбрать double|crash|seven|dice\n` +
        `- игра.уверен / игра отмена\n`;
    }

    const text = `${common}${mode}`.trim();

    if (!isChat) {
      await botSend(context, text, { keyboard: buildDmKeyboard() });
      return;
    }

    await botSend(context, text);
  }
};
