import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { buildKeyboard } from "../../utils/keyboard";
import { formatWithSpaces } from "../../utils/number";

const RANKS = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"] as const;
type HighLowRank = typeof RANKS[number];

type HighLowSuit = "♠" | "♥" | "♦" | "♣";
type HighLowCard = {
  rank: HighLowRank;
  suit: HighLowSuit;
};

type HighLowPhase = "betting" | "game" | "finished";
type HighLowGame = {
  phase: HighLowPhase;
  bet: number;
  deck: HighLowCard[];
  currentCard: HighLowCard | null;
  streak: number;
  multiplierHigher: number;
  multiplierLower: number;
  potentialPayoutHigher: number;
  potentialPayoutLower: number;
  payout: number;
  totalWon: number;
  maxStreak: number;
  updatedAt: number;
};

type UserWithHighlow = NonNullable<VkMessageContext["user"]> & { highlow?: HighLowGame };

const SUITS: HighLowSuit[] = ["♠", "♥", "♦", "♣"];
const RANK_VALUES: Record<HighLowRank, number> = {
  A: 1, "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9,
  "10": 10, J: 11, Q: 12, K: 13
};

const GAME_CONFIG = {
  MIN_BET: 50,
  STREAK_BONUS: 0.05,
  MAX_MULTIPLIER: 50,
  BASE_MULTIPLIER_HIGHER: 1.0,
  BASE_MULTIPLIER_LOWER: 1.2
};

const parseBetAmount = (raw: string, balance: number): number | null => {
  let value = String(raw ?? "").trim().toLowerCase();
  if (!value) return null;
  value = value.replace(/[.,]/g, "");
  value = value.replace(/(к|k)/gi, "000");
  value = value.replace(/(м|m)/gi, "000000");
  value = value.replace(/(вс[её]|all)/gi, String(balance));
  value = value.replace(/(в[ао][ -]?банк|вабанк|vabank)/gi, String(balance)); // 🔥 Добавлена поддержка "вабанк"
  value = value.replace(/\s+/g, "");
  const amount = Number.parseInt(value, 10);
  return Number.isFinite(amount) && amount > 0 ? amount : null;
};

const createDeck = (): HighLowCard[] => {
  const deck: HighLowCard[] = [];
  for (const suit of SUITS) {
    for (const rank of RANKS) {
      deck.push({ rank, suit });
    }
  }
  return deck;
};

const removeEqualCards = (deck: HighLowCard[], currentCard: HighLowCard): HighLowCard[] => {
  return deck.filter(card => card.rank !== currentCard.rank);
};

const shuffleInPlace = <T>(array: T[]): void => {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
};

const cardText = (card: HighLowCard): string => `${card.rank}${card.suit}`;
const getCardValue = (card: HighLowCard): number => RANK_VALUES[card.rank];

const normalizeArg = (raw: string): string => {
  return String(raw ?? "").trim().toLowerCase().replace(/\s+/g, " ");
};

const isBetKeyword = (arg: string): boolean => arg === "ставка" || arg.startsWith("ставка ");
const isHigherKeyword = (arg: string): boolean => ["выше", "больше", "high"].includes(arg);
const isLowerKeyword = (arg: string): boolean => ["ниже", "меньше", "low"].includes(arg);
const isTakeKeyword = (arg: string): boolean => ["забрать", "выход", "стоп", "stop"].includes(arg);
const isAgainKeyword = (arg: string): boolean => ["ещё", "еще", "again", "repeat"].includes(arg);
const isCancelKeyword = (arg: string): boolean => ["отмена", "выйти", "cancel", "exit"].includes(arg);

const ensureBettingGame = (user: UserWithHighlow): HighLowGame => {
  if (user.highlow?.phase === "betting") {
    const game = user.highlow;
    game.bet = 0;
    game.streak = 0;
    game.maxStreak = 0;
    game.totalWon = 0;
    game.payout = 0;
    game.deck = [];
    game.currentCard = null;
    game.updatedAt = Date.now();
    return game;
  }

  const game: HighLowGame = {
    phase: "betting",
    bet: 0,
    deck: [],
    currentCard: null,
    streak: 0,
    maxStreak: 0,
    totalWon: 0,
    multiplierHigher: 1,
    multiplierLower: 1,
    potentialPayoutHigher: 0,
    potentialPayoutLower: 0,
    payout: 0,
    updatedAt: Date.now(),
  };
  
  user.highlow = game;
  return game;
};

const ensureDeckReady = (game: HighLowGame): void => {
  if (game.deck.length > 0) return;
  const deck = createDeck();
  shuffleInPlace(deck);
  game.deck = deck;
};

const drawCard = (game: HighLowGame): HighLowCard => {
  ensureDeckReady(game);
  return game.deck.pop()!;
};

const prepareDeckForNextRound = (game: HighLowGame): void => {
  if (!game.currentCard) return;
  game.deck = removeEqualCards(game.deck, game.currentCard);
};

const calculateProbabilities = (currentCard: HighLowCard | null, deck: HighLowCard[]) => {
  if (!currentCard || deck.length === 0) {
    return { higher: 0, lower: 0 };
  }

  const currentValue = getCardValue(currentCard);
  let higher = 0, lower = 0;

  for (const card of deck) {
    const value = getCardValue(card);
    if (value > currentValue) higher++;
    else if (value < currentValue) lower++;
  }

  const total = deck.length;

  if (currentValue === 1) {
    return {
      higher: 100,
      lower: 0
    };
  }

  if (currentValue === 13) {
    return {
      higher: 0,
      lower: 100
    };
  }
  
  return {
    higher: Number(((higher / total) * 100).toFixed(1)),
    lower: Number(((lower / total) * 100).toFixed(1))
  };
};

const calculateMultiplierByDifficulty = (probability: number, baseMultiplier: number, streak: number): number => {
  if (probability === 0) {
    return Number((baseMultiplier * 5 * (1 + streak * 0.2)).toFixed(2));
  }

  const difficultyFactor = 100 / probability;

  const streakFactor = 1 + (streak * 0.1);
  
  const multiplier = baseMultiplier * difficultyFactor * streakFactor;
  
  return Math.min(GAME_CONFIG.MAX_MULTIPLIER, Number(multiplier.toFixed(2)));
};

const calculatePayout = (bet: number, multiplier: number, probability: number, streak: number): number => {
  if (bet <= 0) return 0;

  if (probability === 0) {
    return Math.floor(bet * multiplier * 2);
  }

  const basePayout = Math.floor(bet * multiplier);

  const streakBonus = 1 + (streak * 0.05);
  
  return Math.floor(basePayout * streakBonus);
};

const updateGameState = (game: HighLowGame): void => {
  if (!game.currentCard) return;
  
  const probs = calculateProbabilities(game.currentCard, game.deck);
  
  game.multiplierHigher = calculateMultiplierByDifficulty(
    probs.higher, 
    GAME_CONFIG.BASE_MULTIPLIER_HIGHER, 
    game.streak
  );
  
  game.multiplierLower = calculateMultiplierByDifficulty(
    probs.lower, 
    GAME_CONFIG.BASE_MULTIPLIER_LOWER, 
    game.streak
  );
  
  game.potentialPayoutHigher = calculatePayout(
    game.bet, 
    game.multiplierHigher, 
    probs.higher, 
    game.streak
  );
  
  game.potentialPayoutLower = calculatePayout(
    game.bet, 
    game.multiplierLower, 
    probs.lower, 
    game.streak
  );
};

const buildBetKeyboard = (balance: number, lastBet: number): string => {
  if (balance < GAME_CONFIG.MIN_BET) {
    return buildKeyboard({
      inline: true,
      buttons: [[{ label: "Баланс", color: "positive", command: "баланс" }]]
    });
  }

  const lb = lastBet > 0 ? String(lastBet) : "100";

  const vabankCommand = `hl ${balance}`;
  
  return buildKeyboard({
    inline: true,
    buttons: [
      [
        { label: "50", color: "primary", command: "hl 50" },
        { label: lb, color: "primary", command: `hl ${lb}` },
        { label: "500", color: "primary", command: "hl 500" }
      ],
      [
        { label: "1к", color: "secondary", command: "hl 1к" },
        { label: "5к", color: "secondary", command: "hl 5к" },
        { label: "Ва-банк", color: "negative", command: vabankCommand }
      ],
      [
        { label: "Баланс", color: "positive", command: "баланс" },
        { label: "Отмена", color: "default", command: "hl отмена" }
      ]
    ]
  });
};

const buildGameKeyboard = (game: HighLowGame): string => {
  const probs = calculateProbabilities(game.currentCard, game.deck);
  
  return buildKeyboard({
    inline: true,
    buttons: [
      [
        { 
          label: `👆 Выше ${probs.higher}% x${game.multiplierHigher.toFixed(2)}`, 
          color: probs.higher > 0 ? "positive" : "secondary", 
          command: "hl выше" 
        }
      ],
      [
        { 
          label: `👇 Ниже ${probs.lower}% x${game.multiplierLower.toFixed(2)}`, 
          color: probs.lower > 0 ? "negative" : "secondary", 
          command: "hl ниже" 
        }
      ],
      [
        { label: "💰 Забрать", color: "primary", command: "hl забрать" },
        { label: "❌ Отмена", color: "default", command: "hl отмена" }
      ]
    ]
  });
};

const buildContinueKeyboard = (): string => {
  return buildKeyboard({
    inline: true,
    buttons: [
      [
        { label: "🔄 Ещё", color: "positive", command: "hl ещё" },
        { label: "💰 Ставка", color: "primary", command: "hl ставка" }
      ],
      [{ label: "Баланс", color: "secondary", command: "баланс" }]
    ]
  });
};

const renderGame = (game: HighLowGame): string => {
  const probs = calculateProbabilities(game.currentCard, game.deck);
  const current = game.currentCard ? cardText(game.currentCard) : "—";
  
  const streakInfo = game.streak > 0 
    ? `🔥 Серия: ${game.streak} (рекорд: ${game.maxStreak})` 
    : '';

  const warnings = [];
  if (probs.higher === 0) warnings.push("⚠️ Нет карт ВЫШЕ, только НИЖЕ!");
  if (probs.lower === 0) warnings.push("⚠️ Нет карт НИЖЕ, только ВЫШЕ!");
  
  const warningText = warnings.length > 0 ? `\n${warnings.join('\n')}\n` : '';

  return [
    `🎰 БОЛЬШЕ-МЕНЬШЕ`,
    `━━━━━━━━━━━━━━`,
    `💰 Ставка: ${formatWithSpaces(game.bet)} FP`,
    streakInfo,
    `💎 Забрать: ${formatWithSpaces(game.payout)} FP`,
    `━━━━━━━━━━━━━━`,
    `🃏 Карта: ${current}`,
    warningText,
    `━━━━━━━━━━━━━━`,
    `👆 Выше ${probs.higher}% | x${game.multiplierHigher.toFixed(2)} → ${formatWithSpaces(game.potentialPayoutHigher)} FP`,
    `👇 Ниже ${probs.lower}% | x${game.multiplierLower.toFixed(2)} → ${formatWithSpaces(game.potentialPayoutLower)} FP`,
    `━━━━━━━━━━━━━━`,
    `💰 Всего: ${formatWithSpaces(game.totalWon)} FP`,
  ].filter(Boolean).join('\n');
};

const renderStepResult = (
  user: UserWithHighlow,
  game: HighLowGame,
  result: { won: boolean; prevCard: HighLowCard; nextCard: HighLowCard; choice: string }
): string => {
  const cashout = Math.max(0, Math.floor(game.payout));
  
  if (result.won) {
    game.maxStreak = Math.max(game.maxStreak, game.streak);
    const stepProfit = cashout - (game.totalWon - cashout);

    prepareDeckForNextRound(game);
    
    const probs = calculateProbabilities(game.currentCard!, game.deck);
    
    const choiceEmoji = result.choice === "higher" ? "👆" : "👇";
    const choiceText = result.choice === "higher" ? "ВЫШЕ" : "НИЖЕ";

    return [
      `🎰 БОЛЬШЕ-МЕНЬШЕ`,
      `━━━━━━━━━━━━━━`,
      `✅ ПОБЕДА! ${choiceEmoji} ${choiceText}`,
      `💰 +${formatWithSpaces(stepProfit)} FP`,
      `🔥 Серия: ${game.streak} (рекорд: ${game.maxStreak})`,
      `━━━━━━━━━━━━━━`,
      `🃏 Было: ${cardText(result.prevCard)}`,
      `🃏 Стало: ${cardText(result.nextCard)}`,
      `━━━━━━━━━━━━━━`,
      `🎯 Следующий ход:`,
      `👆 ${probs.higher}% x${game.multiplierHigher.toFixed(2)} → ${formatWithSpaces(game.potentialPayoutHigher)} FP`,
      `👇 ${probs.lower}% x${game.multiplierLower.toFixed(2)} → ${formatWithSpaces(game.potentialPayoutLower)} FP`,
      `━━━━━━━━━━━━━━`,
      `💳 Баланс: ${formatWithSpaces(user.balance)} FP`,
    ].join('\n');
  }

  const nextValue = getCardValue(result.nextCard);
  const prevValue = getCardValue(result.prevCard);
  
  let resultType = '';
  if (nextValue > prevValue) resultType = '👆 Выпала карта ВЫШЕ';
  else resultType = '👇 Выпала карта НИЖЕ';

  return [
    `🎰 БОЛЬШЕ-МЕНЬШЕ`,
    `━━━━━━━━━━━━━━`,
    `❌ ПРОИГРЫШ`,
    resultType,
    `💸 Потеряно: ${formatWithSpaces(game.bet)} FP`,
    `🔥 Серия прервана на ${game.streak}`,
    `━━━━━━━━━━━━━━`,
    `🃏 Было: ${cardText(result.prevCard)}`,
    `🃏 Стало: ${cardText(result.nextCard)}`,
    `━━━━━━━━━━━━━━`,
    `💳 Баланс: ${formatWithSpaces(user.balance)} FP`,
  ].join('\n');
};

const renderFinish = (user: UserWithHighlow, game: HighLowGame): string => {
  const payout = Math.max(0, Math.floor(game.payout));
  const profit = payout - game.bet;
  const profitText = profit >= 0 ? `+${formatWithSpaces(profit)}` : `-${formatWithSpaces(Math.abs(profit))}`;
  
  return [
    `🎰 БОЛЬШЕ-МЕНЬШЕ`,
    `━━━━━━━━━━━━━━`,
    `🏆 ИГРА ЗАВЕРШЕНА`,
    `💰 Выигрыш: ${formatWithSpaces(payout)} FP (${profitText} FP)`,
    `🔥 Макс. серия: ${game.maxStreak}`,
    `━━━━━━━━━━━━━━`,
    `💳 Баланс: ${formatWithSpaces(user.balance)} FP`,
  ].join('\n');
};

const startWithBet = async (context: VkMessageContext, betRaw: string): Promise<void> => {
  const user = context.user as UserWithHighlow;
  if (!user) return;

  const game = ensureBettingGame(user);
  const amount = parseBetAmount(betRaw, user.balance);

  if (!amount || amount < GAME_CONFIG.MIN_BET) {
    await botSend(
      context,
      `❌ Минимальная ставка: ${GAME_CONFIG.MIN_BET} FP\n💰 Баланс: ${formatWithSpaces(user.balance)} FP`,
      { keyboard: buildBetKeyboard(user.balance, user.lastbet) }
    );
    return;
  }

  const bet = Math.min(amount, user.balance);
  if (bet < GAME_CONFIG.MIN_BET) {
    await botSend(context, 
      `❌ Недостаточно средств\n💰 Баланс: ${formatWithSpaces(user.balance)} FP`, {
      keyboard: buildBetKeyboard(user.balance, user.lastbet)
    });
    return;
  }

  user.balance -= bet;
  user.lastbet = bet;

  game.deck = [];
  ensureDeckReady(game);
  game.bet = bet;
  game.currentCard = drawCard(game);

  prepareDeckForNextRound(game);
  
  game.streak = 0;
  game.maxStreak = 0;
  game.totalWon = 0;
  game.payout = 0;
  game.phase = "game";
  game.updatedAt = Date.now();
  
  updateGameState(game);

  await botSend(context, renderGame(game), { keyboard: buildGameKeyboard(game) });
};

const ensureActiveGame = async (context: VkMessageContext): Promise<{ user: UserWithHighlow; game: HighLowGame } | null> => {
  const user = context.user as UserWithHighlow;
  if (!user) return null;

  const game = user.highlow;
  if (!game || game.phase !== "game" || game.bet <= 0) {
    await botSend(context, "❌ Сейчас нет активной игры.", 
      { keyboard: buildBetKeyboard(user.balance, user.lastbet) });
    return null;
  }

  if (!game.currentCard) {
    game.phase = "finished";
    game.payout = 0;
    await botSend(context, "❌ Игра повреждена.", { keyboard: buildContinueKeyboard() });
    return null;
  }

  return { user, game };
};

const handleHigher = async (context: VkMessageContext): Promise<void> => {
  const active = await ensureActiveGame(context);
  if (!active) return;
  const { user, game } = active;

  ensureDeckReady(game);
  const prevCard = game.currentCard!;
  const probs = calculateProbabilities(prevCard, game.deck);
  const nextCard = drawCard(game);

  const won = getCardValue(nextCard) > getCardValue(prevCard);
  
  if (won) {
    const payout = calculatePayout(game.bet, game.multiplierHigher, probs.higher, game.streak);
    game.payout += payout;
    game.totalWon += payout;
    game.streak++;
    game.maxStreak = Math.max(game.maxStreak, game.streak);
    game.currentCard = nextCard;

    prepareDeckForNextRound(game);
    
    game.updatedAt = Date.now();
    updateGameState(game);

    await botSend(context, renderStepResult(user, game, { won: true, prevCard, nextCard, choice: "higher" }), {
      keyboard: buildGameKeyboard(game)
    });
    return;
  }

  game.phase = "finished";
  game.updatedAt = Date.now();

  await botSend(context, renderStepResult(user, game, { won: false, prevCard, nextCard, choice: "higher" }), {
    keyboard: buildContinueKeyboard()
  });
};

const handleLower = async (context: VkMessageContext): Promise<void> => {
  const active = await ensureActiveGame(context);
  if (!active) return;
  const { user, game } = active;

  ensureDeckReady(game);
  const prevCard = game.currentCard!;
  const probs = calculateProbabilities(prevCard, game.deck);
  const nextCard = drawCard(game);

  const won = getCardValue(nextCard) < getCardValue(prevCard);
  
  if (won) {
    const payout = calculatePayout(game.bet, game.multiplierLower, probs.lower, game.streak);
    game.payout += payout;
    game.totalWon += payout;
    game.streak++;
    game.maxStreak = Math.max(game.maxStreak, game.streak);
    game.currentCard = nextCard;

    prepareDeckForNextRound(game);
    
    game.updatedAt = Date.now();
    updateGameState(game);

    await botSend(context, renderStepResult(user, game, { won: true, prevCard, nextCard, choice: "lower" }), {
      keyboard: buildGameKeyboard(game)
    });
    return;
  }

  game.phase = "finished";
  game.updatedAt = Date.now();

  await botSend(context, renderStepResult(user, game, { won: false, prevCard, nextCard, choice: "lower" }), {
    keyboard: buildContinueKeyboard()
  });
};

const handleTake = async (context: VkMessageContext): Promise<void> => {
  const user = context.user as UserWithHighlow;
  if (!user) return;

  const game = user.highlow;
  if (!game || game.phase !== "game") {
    await botSend(context, "❌ Нет активной игры.");
    return;
  }

  const payout = Math.max(0, Math.floor(game.payout));
  if (payout <= 0) {
    await botSend(context, "💰 Нечего забирать.", { keyboard: buildGameKeyboard(game) });
    return;
  }

  user.balance += payout;
  user.winnings = (user.winnings || 0) + payout;
  game.phase = "finished";
  game.updatedAt = Date.now();

  await botSend(context, renderFinish(user, game), { keyboard: buildContinueKeyboard() });
};

const handleAgain = async (context: VkMessageContext): Promise<void> => {
  const user = context.user as UserWithHighlow;
  if (!user) return;

  const game = user.highlow;
  if (!game || game.phase !== "finished" || game.bet <= 0) {
    await botSend(context, "❌ Нет завершённой игры.", 
      { keyboard: buildBetKeyboard(user.balance, user.lastbet) });
    return;
  }

  if (user.balance < game.bet) {
    await botSend(context, "❌ Недостаточно средств", 
      { keyboard: buildBetKeyboard(user.balance, user.lastbet) });
    return;
  }

  user.balance -= game.bet;

  game.deck = [];
  ensureDeckReady(game);
  game.currentCard = drawCard(game);
  
  prepareDeckForNextRound(game);
  
  game.streak = 0;
  game.maxStreak = 0;
  game.totalWon = 0;
  game.payout = 0;
  game.phase = "game";
  game.updatedAt = Date.now();
  
  updateGameState(game);

  await botSend(context, renderGame(game), { keyboard: buildGameKeyboard(game) });
};

const handleCancel = async (context: VkMessageContext): Promise<void> => {
  const user = context.user as UserWithHighlow;
  if (!user) return;

  const game = user.highlow;
  if (game?.phase !== "finished" && game?.bet && game.streak === 0 && !game.payout) {
    user.balance += game.bet;
    user.winnings = (user.winnings || 0) + game.bet;
  }

  user.highlow = undefined;
  await botSend(context, "🃏 Игра закрыта.", { keyboard: buildBetKeyboard(user.balance, user.lastbet) });
};

export const hlCommand: CommandDefinition<VkMessageContext> = {
  name: "common.hl",
  pattern: /^(?:hl|highlow|большеменьше)(?:\s+(.*))?$/i,
  guard: context => Boolean(context.user && !context.isChat),
  handler: async context => {
    const user = context.user as UserWithHighlow;
    if (!user) return;

    const arg = normalizeArg(context.match?.[1] ?? "");

    if (isCancelKeyword(arg)) {
      await handleCancel(context);
      return;
    }

    if (isHigherKeyword(arg)) {
      await handleHigher(context);
      return;
    }

    if (isLowerKeyword(arg)) {
      await handleLower(context);
      return;
    }

    if (isTakeKeyword(arg)) {
      await handleTake(context);
      return;
    }

    if (isAgainKeyword(arg)) {
      await handleAgain(context);
      return;
    }

    if (isBetKeyword(arg)) {
      const betRaw = arg === "ставка" ? "" : arg.replace(/^ставка\s+/i, "");
      if (!betRaw) {
        ensureBettingGame(user);
        await botSend(context, `🎰 БОЛЬШЕ-МЕНЬШЕ\n💰 Баланс: ${formatWithSpaces(user.balance)} FP`, {
          keyboard: buildBetKeyboard(user.balance, user.lastbet)
        });
        return;
      }

      await startWithBet(context, betRaw);
      return;
    }

    if (arg) {
      await startWithBet(context, arg);
      return;
    }

    const game = user.highlow;
    if (game?.phase === "game") {
      updateGameState(game);
      await botSend(context, renderGame(game), { keyboard: buildGameKeyboard(game) });
      return;
    }

    if (game?.phase === "finished") {
      await botSend(context, renderFinish(user, game), { keyboard: buildContinueKeyboard() });
      return;
    }

    ensureBettingGame(user);
    await botSend(context, `🎰 БОЛЬШЕ-МЕНЬШЕ\n💰 Баланс: ${formatWithSpaces(user.balance)} FP`, {
      keyboard: buildBetKeyboard(user.balance, user.lastbet)
    });
  }
};