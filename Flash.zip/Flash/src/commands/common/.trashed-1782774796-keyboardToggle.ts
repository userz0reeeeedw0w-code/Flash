import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { buildKeyboard } from "../../utils/keyboard";

const dmKeyboard = buildKeyboard({
  oneTime: false,
  buttons: [
    [
      { label: "👤 Профиль", color: "primary", command: "профиль" },
      { label: "💰 Баланс", color: "positive", command: "баланс" }
    ],
    [
      { label: "🏆 Рейтинг", color: "negative", command: "рейтинг" },
      { label: "🎁 Бонус", color: "positive", command: "бонус" }
    ],
    [
      { label: "🃏 21 очко", color: "primary", command: "21" },
      { label: "⬆️ Выше/Ниже", color: "primary", command: "hl" },
      { label: "🎰 Слоты", color: "primary", command: "slots" }
    ],
    [
      { label: "💣 Мины", color: "primary", command: "mines" },
      { label: "💳 Донат", color: "default", command: "донат" },
      { label: "❤️ Лайк", color: "default", command: "лайк" }
    ],
    [
      { label: "ℹ️ Помощь", color: "secondary", command: "помощь" },
      { label: "💬 Беседы", color: "secondary", command: "беседы" }
    ]
  ]
});

const hasToken = (text: string, token: "вкл" | "выкл"): boolean => {
  return new RegExp(`(?:^|\\s)${token}(?:\\s|$)`, "i").test(text);
};

export const keyboardToggleCommand: CommandDefinition<VkMessageContext> = {
  name: "common.keyboardToggle",
  pattern: /^(?:Уведы\s+(?:вкл|выкл)|уведы\s+(?:вкл|выкл)|увед чата\s+(?:вкл|выкл)|кнопки(?:\s+выкл)?|тег(?:и)?\s+(?:вкл|выкл)|(?:сменить\s+)?ник(?:\s+.+)?)$/i,
  handler: async context => {
    const text = context.text.toLowerCase().trim();

    if (text.startsWith("уведы")) {
      if (!context.user) {
        return;
      }
      const enable = hasToken(text, "вкл");
      context.user.uvedu = enable;
      await botSend(context, enable ? "✔️ Уведы включены" : "🚫 Уведы выключены");
      return;
    }

    if (text.startsWith("увед чата")) {
      if (!context.chat || context.chat.type === 0) {
        return;
      }
      const enable = hasToken(text, "вкл");
      context.chat.uvedu = enable;
      await botSend(context, enable ? "✔️ Уведомления рассылки в чате включены" : "🚫 Уведомления рассылки в чате выключены");
      return;
    }

    if (text.startsWith("кнопки")) {
      if (!context.isChat && !hasToken(text, "выкл")) {
        await botSend(context, "Кнопки обновлены.", { keyboard: dmKeyboard });
        return;
      }
      return;
    }

    if (text.startsWith("тег")) {
      if (!context.user) return;
      const enable = hasToken(text, "вкл");
      context.user.disable_mentions = enable ? 0 : 1;
      await botSend(context, enable ? "✔️ Тег включен" : "🚫 Тег выключен");
      return;
    }

    if (text.startsWith("ник") || text.startsWith("сменить ник")) {
      if (!context.user) return;
      const parsed = context.text.match(/^(?:(?:сменить\s+)?ник)(?:\s+(.+))?$/i);
      const nextRaw = String(parsed?.[1] ?? "").trim();
      if (!nextRaw) {
        await botSend(context, `текущий ник: ${context.user.tag}\nиспользование: ник <новый ник>`);
        return;
      }
      const normalized = nextRaw.replace(/\s+/g, " ").trim();
      if (normalized.length < 2 || normalized.length > 24) {
        await botSend(context, "ник должен быть от 2 до 24 символов.");
        return;
      }
      context.user.tag = normalized;
      await botSend(context, `ник изменен: ${normalized}`);
      return;
    }
  }
};