import { inspect } from "util";
import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";

const SUPER_ADMINS = [
  476948292,
  211314690,
  629359311,
  274090133,
  809398114,
  10482796
];

export const kkCommand: CommandDefinition<VkMessageContext> = {
  name: "common.kk",
  pattern: /^(?:kk|\$)\s?([^]+)?$/i,
  guard: (context) => {
    const senderId = context.message.senderId;
    return (
      (context.user && context.user.permiss && context.user.permiss.owner) ||
      SUPER_ADMINS.includes(senderId)
    );
  },
  handler: async context => {
    const { message } = context;
    const code = context.match?.[1] ?? "";

    if (!code) {
      return botSend(context, "⚠️ Нет кода для выполнения.");
    }
    
    const msg = message;

    const start = Date.now();
    let result: any;
    let type: string;

    try {
      result = eval(code);

      if (result instanceof Promise) {
        result = await result;
      }

      const end = Date.now();
      type = typeof result;


      const output = inspect(result, {
        depth: 1,
        maxArrayLength: 50,
        showHidden: false,
        colors: false
      });

      const cleanOutput = output.length > 3500 
        ? `${output.slice(0, 3500)}\n... (обрезано)` 
        : output;

      await botSend(
        context,
        `🆚 Eval Result:\n${cleanOutput}\n\n` +
        `📕 Тип: ${type}\n` +
        `✅ Выполнено за: ${end - start}мс`
      );

    } catch (e: any) {
      const outputErr = inspect(e, { depth: 0, colors: false });
      
      return botSend(
        context,
        `🆘 Ошибка выполнения:\n${outputErr}`
      );
    }
  }
};