import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { DoubleGame, SevenGame } from "../../types/database";

export const lastGamesCommand: CommandDefinition<VkMessageContext> = {
  name: "common.lastGames",
  pattern: /^(?:Последние игры|последние игры)$/i,
  handler: async context => {
    const { chat } = context;
    if (!chat || chat.type === 0) {
      return;
    }

    if (chat.type !== 1 && chat.type !== 3) {
      await botSend(context, "последние игры доступны только для Дабл и Под7Над.");
      return;
    }

    const finished = chat.games.filter((g: any) => g && g.stavka === false);
    if (finished.length === 0) {
      await botSend(context, "пока нет завершённых игр.");
      return;
    }

    let text = "";
    let i = 1;
    for (const game of finished) {
      if (chat.type === 1) {
        const info = game as DoubleGame;
        text += `${i}) Выпал коэффициент: x${info.result}\nХеш игры: ${info.hash}\nПроверка честности: ${info.proverka}\n\n`;
      } else {
        const info = game as SevenGame;
        text += `${i}) Выпало число: ${info.result}\nХеш игры: ${info.hash}\nПроверка честности: ${info.proverka}\n\n`;
      }
      i++;
    }

    await botSend(context, `последние игры:\n${text}`);
  }
};
