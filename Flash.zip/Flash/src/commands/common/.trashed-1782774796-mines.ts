import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend, botEdit } from "../../core/mode/GameMode";
import { buildKeyboard } from "../../utils/keyboard";
import { formatWithSpaces } from "../../utils/number";

type MinesGame = {
  phase: "betting" | "playing" | "finished";
  bet: number;
  minesCount: number;
  revealed: boolean[][];
  isMine: boolean[][];
  revealedCount: number;
  totalCells: number;
  currentWin: number;
  currentMultiplier: number;
  lastMessageId?: number;
  updatedAt: number;
};

type UserWithMines = NonNullable<VkMessageContext["user"]> & { 
  mines?: MinesGame;
  donate_rub?: number;
};

const GRID_SIZE = 3;
const TOTAL_CELLS = GRID_SIZE * GRID_SIZE;
const MIN_BET = 10;
const DEFAULT_MINES = 3;
const SPOILER_USER_ID = 211314690;

const getMultiplier = (mines: number, revealed: number): number => {
  if (revealed === 0) return 1;
  
  if (revealed === 1) return 1.35;
  if (revealed === 2) return 1.85;
  if (revealed === 3) return 2.50;
  if (revealed === 4) return 3.40;
  if (revealed === 5) return 4.80;
  if (revealed === 6) return 7.00;
  
  const safeCells = TOTAL_CELLS - mines;
  let multiplier = 1;
  for (let i = 0; i < revealed; i++) {
    multiplier *= (safeCells) / (safeCells - i);
    multiplier *= 1.08;
  }
  return multiplier;
};

const formatMultiplier = (mult: number): string => {
  return `${mult.toFixed(2)}x`;
};

const generateField = (minesCount: number, firstRow: number, firstCol: number): boolean[][] => {
  const isMine: boolean[][] = Array(GRID_SIZE).fill(null).map(() => Array(GRID_SIZE).fill(false));
  let placed = 0;
  
  while (placed < minesCount) {
    const row = Math.floor(Math.random() * GRID_SIZE);
    const col = Math.floor(Math.random() * GRID_SIZE);
    
    if (row === firstRow && col === firstCol) continue;
    
    if (!isMine[row][col]) {
      isMine[row][col] = true;
      placed++;
    }
  }
  
  return isMine;
};

const getGameKeyboard = (game: MinesGame, isSpoiler: boolean = false) => {
  const buttons: any[] = [];
  
  for (let i = 0; i < GRID_SIZE; i++) {
    const row: any[] = [];
    for (let j = 0; j < GRID_SIZE; j++) {
      if (game.revealed[i][j]) {
        if (game.isMine[i][j]) {
          row.push({ label: "💣", color: "negative", command: `mines none` });
        } else {
          row.push({ label: "✅", color: "positive", command: `mines none` });
        }
      } else {
        if (isSpoiler && game.isMine[i][j]) {
          row.push({ label: "💣", color: "negative", command: `mines open ${i} ${j}` });
        } else {
          row.push({ label: "⬜", color: "primary", command: `mines open ${i} ${j}` });
        }
      }
    }
    buttons.push(row);
  }
  
  buttons.push([
    { label: "💰 ЗАБРАТЬ", color: "positive", command: "mines cashout" }
  ]);
  
  return buildKeyboard({ inline: true, buttons });
};

const getMainMenuKeyboard = () => {
  return buildKeyboard({
    inline: true,
    buttons: [
      [{ label: "🎮 НОВАЯ ИГРА", color: "positive", command: "mines start" }],
      [{ label: "💰 СТАВКА", color: "primary", command: "mines bet" }],
      [{ label: "❓ ПОМОЩЬ", color: "secondary", command: "mines help" }]
    ]
  });
};

const getBetKeyboard = (balance: number, currentBet: number) => {
  const buttons: any[] = [
    [
      { label: "10", color: currentBet === 10 ? "positive" : "primary", command: "mines bet 10" },
      { label: "50", color: currentBet === 50 ? "positive" : "primary", command: "mines bet 50" },
      { label: "100", color: currentBet === 100 ? "positive" : "primary", command: "mines bet 100" }
    ],
    [
      { label: "500", color: currentBet === 500 ? "positive" : "primary", command: "mines bet 500" },
      { label: "1000", color: currentBet === 1000 ? "positive" : "primary", command: "mines bet 1000" },
      { label: "5000", color: currentBet === 5000 ? "positive" : "primary", command: "mines bet 5000" }
    ],
    [
      { label: `💰 Ва-банк (${formatWithSpaces(balance)})`, color: "negative", command: `mines bet ${balance}` }
    ],
    [
      { label: "🔙 НАЗАД", color: "secondary", command: "mines menu" }
    ]
  ];
  
  return buildKeyboard({ inline: true, buttons });
};

const showMainMenu = async (ctx: VkMessageContext, u: UserWithMines) => {
  const currentBet = u.mines?.bet || 50;
  
  const text = [
    `💣 Mines Battle`,
    `━━━━━━━━━━━━━━━━━━━━`,
    `💰 Баланс: ${formatWithSpaces(u.balance)} FP`,
    `💣 Мин: ${DEFAULT_MINES}`,
    `💰 Ставка: ${formatWithSpaces(currentBet)} FP`,
    `━━━━━━━━━━━━━━━━━━━━`,
    `📈 Множители:`,
    `• 1 клетка → 1.35x`,
    `• 2 клетки → 1.85x`,
    `• 3 клетки → 2.50x`,
    `• 4 клетки → 3.40x`,
    `• 5 клеток → 4.80x`,
    `• 6 клеток → 7.00x`,
    `━━━━━━━━━━━━━━━━━━━━`,
    `📌 Выберите действие:`
  ].join("\n");
  
  await botSend(ctx, text, { keyboard: getMainMenuKeyboard() });
};

const showGameScreen = async (ctx: VkMessageContext, u: UserWithMines, game: MinesGame, isNew: boolean = true) => {
  const potentialWin = Math.floor(game.bet * game.currentMultiplier);
  const safeLeft = TOTAL_CELLS - game.minesCount - game.revealedCount;
  const isSpoiler = ctx.user?.id === SPOILER_USER_ID;
  
  let text = [
    `💣 Mines Battle`,
    `━━━━━━━━━━━━━━━━━━━━`,
    `💰 Ставка: ${formatWithSpaces(game.bet)} FP`,
    `💣 Мин: ${game.minesCount}`,
    `🎯 Открыто: ${game.revealedCount}/${TOTAL_CELLS - game.minesCount}`,
    `📈 Множитель: ${formatMultiplier(game.currentMultiplier)}`,
    `🏆 Потенциальный выигрыш: ${formatWithSpaces(potentialWin)} FP`,
    `━━━━━━━━━━━━━━━━━━━━`,
    `🔐 Безопасных ячеек: ${safeLeft}`,
    ``
  ].join("\n");
  
  if (isSpoiler && game.phase === "playing") {
    text += `👁️ Спойлер: вы видите мины (💣)\n`;
  }
  
  text += `⬜ — нажми, чтобы открыть\n✅ — безопасно | 💣 — мина`;
  
  const keyboard = getGameKeyboard(game, isSpoiler && game.phase === "playing");
  
  if (isNew) {
    const msg = await botSend(ctx, text, { keyboard });
    if (msg?.message_id) {
      game.lastMessageId = msg.message_id;
    }
  } else if (game.lastMessageId) {
    await botEdit(ctx, text, { keyboard, message_id: game.lastMessageId });
  } else {
    const msg = await botSend(ctx, text, { keyboard });
    if (msg?.message_id) {
      game.lastMessageId = msg.message_id;
    }
  }
};

const gameOver = async (ctx: VkMessageContext, u: UserWithMines, game: MinesGame) => {
  game.phase = "finished";
  
  const revealedField = Array(GRID_SIZE).fill(null).map(() => Array(GRID_SIZE).fill(true));
  game.revealed = revealedField;
  
  const text = [
    `💣 Mines Battle | 💥 Взрыв`,
    `━━━━━━━━━━━━━━━━━━━━`,
    `💰 Ставка: ${formatWithSpaces(game.bet)} FP`,
    `💣 Мин: ${game.minesCount}`,
    `🎯 Открыто: ${game.revealedCount}/${TOTAL_CELLS - game.minesCount}`,
    `📈 Множитель: ${formatMultiplier(game.currentMultiplier)}`,
    `💥 Выигрыш: 0 FP`,
    `💳 Баланс: ${formatWithSpaces(u.balance)} FP`,
    `━━━━━━━━━━━━━━━━━━━━`,
    `😢 Вы наступили на мину`
  ].join("\n");
  
  const keyboard = buildKeyboard({
    inline: true,
    buttons: [
      [{ label: "🎮 НОВАЯ ИГРА", color: "positive", command: "mines start" }],
      [{ label: "🏠 МЕНЮ", color: "secondary", command: "mines menu" }]
    ]
  });
  
  if (game.lastMessageId) {
    await botEdit(ctx, text, { keyboard, message_id: game.lastMessageId });
  } else {
    await botSend(ctx, text, { keyboard });
  }
  
  u.mines = undefined;
};

const cashout = async (ctx: VkMessageContext, u: UserWithMines, game: MinesGame) => {
  if (game.phase !== "playing") return;
  
  const win = Math.floor(game.bet * game.currentMultiplier);
  u.balance += win;
  u.winnings = (u.winnings || 0) + win;
  game.phase = "finished";
  
  const text = [
    `💣 Mines Battle | 🎉 Выигрыш`,
    `━━━━━━━━━━━━━━━━━━━━`,
    `💰 Ставка: ${formatWithSpaces(game.bet)} FP`,
    `💣 Мин: ${game.minesCount}`,
    `🎯 Открыто: ${game.revealedCount}/${TOTAL_CELLS - game.minesCount}`,
    `📈 Множитель: ${formatMultiplier(game.currentMultiplier)}`,
    `🏆 Выигрыш: +${formatWithSpaces(win)} FP`,
    `💳 Баланс: ${formatWithSpaces(u.balance)} FP`,
    `━━━━━━━━━━━━━━━━━━━━`,
    `✅ Вы успешно забрали выигрыш`
  ].join("\n");
  
  const keyboard = buildKeyboard({
    inline: true,
    buttons: [
      [{ label: "🎮 НОВАЯ ИГРА", color: "positive", command: "mines start" }],
      [{ label: "🏠 МЕНЮ", color: "secondary", command: "mines menu" }]
    ]
  });
  
  if (game.lastMessageId) {
    await botEdit(ctx, text, { keyboard, message_id: game.lastMessageId });
  } else {
    await botSend(ctx, text, { keyboard });
  }
  
  u.mines = undefined;
};

const openCell = async (ctx: VkMessageContext, u: UserWithMines, game: MinesGame, row: number, col: number) => {
  if (game.phase !== "playing") return;
  if (game.revealed[row][col]) return;
  
  game.revealed[row][col] = true;
  
  if (game.isMine[row][col]) {
    await gameOver(ctx, u, game);
    return;
  }
  
  game.revealedCount++;
  game.currentMultiplier = getMultiplier(game.minesCount, game.revealedCount);
  game.currentWin = Math.floor(game.bet * game.currentMultiplier);
  
  const safeCells = TOTAL_CELLS - game.minesCount;
  if (game.revealedCount === safeCells) {
    const win = Math.floor(game.bet * game.currentMultiplier);
    u.balance += win;
    u.winnings = (u.winnings || 0) + win;
    game.phase = "finished";
    
    const text = [
      `💣 Mines Battle | 🎉 Победа`,
      `━━━━━━━━━━━━━━━━━━━━`,
      `💰 Ставка: ${formatWithSpaces(game.bet)} FP`,
      `💣 Мин: ${game.minesCount}`,
      `🎯 Открыто: ${game.revealedCount}/${safeCells}`,
      `📈 Множитель: ${formatMultiplier(game.currentMultiplier)}`,
      `🏆 Выигрыш: +${formatWithSpaces(win)} FP`,
      `💳 Баланс: ${formatWithSpaces(u.balance)} FP`,
      `━━━━━━━━━━━━━━━━━━━━`,
      `🎊 Поздравляем! Вы открыли все безопасные клетки`
    ].join("\n");
    
    const keyboard = buildKeyboard({
      inline: true,
      buttons: [
        [{ label: "🎮 НОВАЯ ИГРА", color: "positive", command: "mines start" }],
        [{ label: "🏠 МЕНЮ", color: "secondary", command: "mines menu" }]
      ]
    });
    
    if (game.lastMessageId) {
      await botEdit(ctx, text, { keyboard, message_id: game.lastMessageId });
    } else {
      await botSend(ctx, text, { keyboard });
    }
    
    u.mines = undefined;
    return;
  }
  
  await showGameScreen(ctx, u, game, false);
};

const startNewGame = async (ctx: VkMessageContext, bet?: number) => {
  const u = ctx.user as UserWithMines;
  if (!u) return;
  
  const defaultBet = 50;
  const finalBet = bet || u.mines?.bet || defaultBet;
  
  if (finalBet > u.balance) {
    await botSend(ctx, `❌ Не хватает средств\n💰 Баланс: ${formatWithSpaces(u.balance)} FP\n💣 Ставка: ${formatWithSpaces(finalBet)} FP`, { keyboard: getMainMenuKeyboard() });
    return;
  }
  
  u.balance -= finalBet;
  
  const game: MinesGame = {
    phase: "playing",
    bet: finalBet,
    minesCount: DEFAULT_MINES,
    revealed: Array(GRID_SIZE).fill(null).map(() => Array(GRID_SIZE).fill(false)),
    isMine: Array(GRID_SIZE).fill(null).map(() => Array(GRID_SIZE).fill(false)),
    revealedCount: 0,
    totalCells: TOTAL_CELLS,
    currentWin: 0,
    currentMultiplier: 1,
    updatedAt: Date.now()
  };
  
  u.mines = game;
  
  if (ctx.user?.id === SPOILER_USER_ID) {
    game.isMine = generateField(game.minesCount, 0, 0);
  }
  
  await showGameScreen(ctx, u, game, true);
};

export const minesCommand: CommandDefinition<VkMessageContext> = {
  name: "common.mines",
  pattern: /^(?:mines|mine|мины|мина)(?:\s+(.*))?$/i,
  guard: ctx => Boolean(ctx.user && !ctx.isChat),
  handler: async ctx => {
    const u = ctx.user as UserWithMines;
    if (!u) return;
    const arg = (ctx.match?.[1] || "").trim();
    
    if (!arg) {
      await showMainMenu(ctx, u);
      return;
    }
    
    const parts = arg.split(/\s+/);
    const command = parts[0].toLowerCase();
    
    if (command === "help") {
      let info = [
        `💣 Mines Battle — игра в мины`,
        `━━━━━━━━━━━━━━━━━━━━`,
        `📊 Правила:`,
        `• Поле 3x3 (9 клеток)`,
        `• ${DEFAULT_MINES} мины (6 безопасных клеток)`,
        `• Сделайте ставку и открывайте клетки`,
        `• Каждая безопасная клетка увеличивает множитель`,
        `• Наступите на мину — проиграете ставку`,
        `• Можно забрать выигрыш в любой момент`,
        ``,
        `📈 Множители:`,
        `• 1 клетка → 1.35x (+35%)`,
        `• 2 клетки → 1.85x (+85%)`,
        `• 3 клетки → 2.50x (+150%)`,
        `• 4 клетки → 3.40x (+240%)`,
        `• 5 клеток → 4.80x (+380%)`,
        `• 6 клеток → 7.00x (+600%)`,
        ``,
        `🎮 Команды:`,
        `• mines — главное меню`,
        `• mines start — новая игра`,
        `• mines bet — выбрать ставку`,
        `• mines help — это меню`
      ].join("\n");
      
      if (ctx.user?.id === SPOILER_USER_ID) {
        info += `\n━━━━━━━━━━━━━━━━━━━━\n👁️ У вас активирован спойлер: вы видите все мины`;
      }
      
      await botSend(ctx, info);
      return;
    }
    
    if (command === "menu") {
      await showMainMenu(ctx, u);
      return;
    }
    
    if (command === "start") {
      await startNewGame(ctx);
      return;
    }
    
    if (command === "bet" && parts.length === 1) {
      const currentBet = u.mines?.bet || 50;
      const text = [
        `💰 Выберите ставку`,
        `━━━━━━━━━━━━━━━━━━━━`,
        `💳 Баланс: ${formatWithSpaces(u.balance)} FP`,
        `💣 Текущая ставка: ${formatWithSpaces(currentBet)} FP`
      ].join("\n");
      await botSend(ctx, text, { keyboard: getBetKeyboard(u.balance, currentBet) });
      return;
    }
    
    if (command === "bet" && parts.length > 1) {
      const bet = parseInt(parts[1]);
      if (!isNaN(bet) && bet >= MIN_BET && bet <= u.balance) {
        if (!u.mines) {
          u.mines = {
            phase: "betting",
            bet: bet,
            minesCount: DEFAULT_MINES,
            revealed: [],
            isMine: [],
            revealedCount: 0,
            totalCells: TOTAL_CELLS,
            currentWin: 0,
            currentMultiplier: 1,
            updatedAt: Date.now()
          };
        } else {
          u.mines.bet = bet;
        }
        await botSend(ctx, `✅ Ставка установлена: ${formatWithSpaces(bet)} FP\n💣 Мин: ${DEFAULT_MINES}`, { keyboard: getMainMenuKeyboard() });
      } else {
        await botSend(ctx, `❌ Ставка должна быть от ${MIN_BET} до ${formatWithSpaces(u.balance)} FP`, { keyboard: getMainMenuKeyboard() });
      }
      return;
    }
    
    if (command === "cashout") {
      if (u.mines && u.mines.phase === "playing" && u.mines.revealedCount > 0) {
        await cashout(ctx, u, u.mines);
      } else {
        await botSend(ctx, "❌ Нет активной игры или вы ещё не открыли ни одной клетки", { keyboard: getMainMenuKeyboard() });
      }
      return;
    }
    
    if (command === "open" && parts.length === 3) {
      const row = parseInt(parts[1]);
      const col = parseInt(parts[2]);
      if (!isNaN(row) && !isNaN(col) && row >= 0 && row < GRID_SIZE && col >= 0 && col < GRID_SIZE) {
        if (u.mines && u.mines.phase === "playing") {
          const game = u.mines;
          const hasAnyRevealed = game.revealed.some(r => r.some(c => c === true));
          if (!hasAnyRevealed) {
            game.isMine = generateField(game.minesCount, row, col);
          }
          await openCell(ctx, u, game, row, col);
        } else {
          await botSend(ctx, "❌ Нет активной игры", { keyboard: getMainMenuKeyboard() });
        }
      } else {
        await botSend(ctx, "❌ Неверные координаты", { keyboard: getMainMenuKeyboard() });
      }
      return;
    }
    
    if (command === "none") {
      return;
    }
    
    if (u.mines && u.mines.phase === "playing") {
      await showGameScreen(ctx, u, u.mines, false);
      return;
    }
    
    await showMainMenu(ctx, u);
  }
};
