import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { buildKeyboard } from "../../utils/keyboard";

const resolveMiniAppUrl = (): string => {
  const raw = String(process.env.MINI_APP_URL ?? "").trim();
  if (raw) return raw;
  return "http://localhost:8787";
};

export const miniAppCommand: CommandDefinition<VkMessageContext> = {
  name: "common.miniapp",
  pattern: /^(?:миниапп|миниап|miniapp|webapp)(?:\s+(тест|test))?$/i,
  guard: context => Boolean(!context.isChat && context.user),
  handler: async context => {
    const base = resolveMiniAppUrl();
    const user = context.user!;
    const testMode = /^(?:тест|test)$/i.test(String(context.match?.[1] ?? "").trim());
    const params = new URLSearchParams({
      userId: String(user.id),
      uid: String(user.uid),
      tag: user.tag
    });
    if (testMode) {
      params.set("test", "1");
    }
    const url = `${base}?${params.toString()}`;
    const keyboard = buildKeyboard({
      inline: true,
      buttons: [
        [{ label: "Открыть мини-апп", url }],
        [{ label: "Открыть тест-профиль", url: `${base}?test=1` }],
        [{ label: "Баланс", color: "positive", command: "баланс" }]
      ]
    });

    await botSend(
      context,
      `Запускай мини‑апп:\n${url}\n\nДоступны режимы: Классика, Спидран, Хайроллер, Стратег, Хаос, Марафон, Lucky7, Dealer Doom.`,
      { keyboard }
    );
  }
};
