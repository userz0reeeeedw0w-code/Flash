import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import fs from "fs";
import path from "path";

export type PromoEntry = {
  code: string;
  activations: number;
  used: number;
  amount: number;
  created: number;
  personal: number | null;
  users: number[];
};

const getDatabaseRootPath = (): string => {
  return process.env.DATABASE_ROOT_PATH ?? path.join(process.cwd(), "database");
};

export const getPromoDbPath = (): string => {
  return path.join(getDatabaseRootPath(), "promo.json");
};

export const normalizePromoEntry = (value: any): PromoEntry | null => {
  const code = String(value?.code ?? value?.name ?? "").toUpperCase().trim();
  if (!code) return null;

  const amount = Number(value?.amount ?? 0);
  if (!Number.isFinite(amount) || amount <= 0) return null;

  const users = Array.isArray(value?.users) ? value.users.map((x: any) => Number(x)).filter((x: any) => Number.isFinite(x)) : [];
  const used =
    typeof value?.used === "number" && Number.isFinite(value.used) && value.used >= 0 ? value.used : users.length;
  const activationsRaw =
    typeof value?.activations === "number" && Number.isFinite(value.activations)
      ? value.activations
      : typeof value?.activation === "number" && Number.isFinite(value.activation)
        ? value.activation + users.length
        : used;

  const activations = Math.max(0, Math.floor(activationsRaw));
  const created =
    typeof value?.created === "number" && Number.isFinite(value.created) && value.created > 0 ? value.created : Date.now();
  const personal = typeof value?.personal === "number" && Number.isFinite(value.personal) ? value.personal : null;

  return { code, activations, used: Math.max(0, Math.floor(used)), amount, created, personal, users };
};

export const readPromoStore = (): Record<string, PromoEntry> => {
  const filePath = getPromoDbPath();
  if (!fs.existsSync(filePath)) return {};

  const raw = fs.readFileSync(filePath, { encoding: "utf8" });
  const parsed = JSON.parse(raw || "{}");

  const out: Record<string, PromoEntry> = {};

  if (Array.isArray(parsed)) {
    for (const item of parsed) {
      const entry = normalizePromoEntry(item);
      if (!entry) continue;
      out[entry.code] = entry;
    }
    return out;
  }

  if (parsed && typeof parsed === "object") {
    for (const [key, value] of Object.entries(parsed as Record<string, any>)) {
      const entry = normalizePromoEntry({ ...(value as any), code: (value as any)?.code ?? key });
      if (!entry) continue;
      out[entry.code] = entry;
    }
  }

  return out;
};

export const writePromoStore = (data: Record<string, PromoEntry>): void => {
  const filePath = getPromoDbPath();
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
};

export const promoListCommand: CommandDefinition<VkMessageContext> = {
  name: "common.promolist",
  pattern: /^(?:промо\s*список)$/i,
  guard: ctx => Boolean(ctx.user && ctx.user.permiss && (ctx.user.permiss.admin || ctx.user.permiss.owner)),
  handler: async ctx => {
    try {
      const data = readPromoStore();
      const codes = Object.values(data);

      if (codes.length === 0) {
        await botSend(ctx, "промокодов нет.");
        return;
      }

      let text = "📦 Список промокодов:\n\n";

      for (const p of codes.sort((a, b) => (b.created ?? 0) - (a.created ?? 0))) {
        const date = new Date(p.created).toLocaleString("ru-RU");
        text += `🔹 ${p.code}\n`;
        text += `   ${p.used}/${p.activations} активаций\n`;
        text += `   Сумма: ${p.amount} FP\n`;
        text += `   Тип: ${p.personal ? `персональный (UID ${p.personal})` : "общий"}\n`;
        text += `   Создан: ${date}\n\n`;
      }

      await botSend(ctx, text);
    } catch {
      await botSend(ctx, "Ошибка при выводе списка промокодов.");
    }
  }
};

export const promoActivateCommand: CommandDefinition<VkMessageContext> = {
  name: "common.promoactivate",
  pattern: /^(?:промо)\s+([A-Z0-9]+)$/i,
  handler: async ctx => {
    try {
      const code = String(ctx.match?.[1] ?? "").toUpperCase();
      const user = ctx.user;

      if (!user) {
        await botSend(ctx, "ошибка данных.");
        return;
      }

      const data = readPromoStore();
      const promo = data[code];

      if (!promo) {
        await botSend(ctx, "такого промокода нет.");
        return;
      }

      if (promo.personal && promo.personal !== user.uid) {
        await botSend(ctx, "этот промокод не для вас.");
        return;
      }

      promo.users = promo.users ?? [];
      promo.used = promo.users.length;

      if (promo.used >= promo.activations) {
        await botSend(ctx, "лимит активаций промокода исчерпан.");
        return;
      }

      user.promo_used = user.promo_used ?? [];
      if (user.promo_used.includes(code) || promo.users.includes(user.id)) {
        await botSend(ctx, "вы уже активировали этот промокод.");
        return;
      }

      user.balance = (user.balance ?? 0) + promo.amount;

      promo.users.push(user.id);
      promo.used = promo.users.length;
      data[code] = promo;
      writePromoStore(data);

      user.promo_used.push(code);

      await botSend(ctx, `🎉 Вы активировали промокод ${code} и получили ${promo.amount} FP!`);
    } catch {
      await botSend(ctx, "Ошибка при активации промокода.");
    }
  }
};
