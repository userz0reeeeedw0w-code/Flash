import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend, formatUserLabel } from "../../core/mode/GameMode";
import { formatWithSpaces } from "../../utils/number";

export const myRefCommand: CommandDefinition<VkMessageContext> = {
  name: "common.myref",
  pattern: /^(?:мой\s*реф|мойреф|реф\s*инфо|рефинфо)$/i,
  handler: async context => {
    const user = context.user;
    if (!user) return;

    const confirmed = user.referrals?.filter(r => r.confirmed).length || 0;
    const pending = user.referrals?.filter(r => !r.confirmed).length || 0;
    const total = (user.referrals?.length || 0);

    let text = `👥 Ваши рефералы:\n`;
    text += `✅ Подтверждено: ${confirmed}\n`;
    text += `⏳ В ожидании: ${pending}\n`;
    text += `📊 Всего приглашено: ${total}\n\n`;
    text += `💰 Бонус от подтвержденных: ${formatWithSpaces(user.ref_bonus || 0)} FP\n`;
    text += `💎 Подтвержденных рефералов: ${user.refCount || 0}\n`;
    
    if (pending > 0) {
      text += `\n⏱️ Рефералы подтверждаются через 1 час активности`;
    }

    await botSend(context, text);
  }
};

export const referralLinkCommand: CommandDefinition<VkMessageContext> = {
  name: "common.reflink",
  pattern: /^(?:реф\s*ссылка|рефссылка|наш\s*лидер|пригласить)$/i,
  handler: async context => {
    const user = context.user;
    if (!user) return;

    const platform = context.platform || "vk";
    let refLink = "";

    if (platform === "tg") {
      refLink = `https://t.me/realflashgame_bot?start=ref_${user.uid}`;
    } else {
      const groupId = Math.abs(context.vkContext?.$groupId || 237124814);
      refLink = `https://vk.com/write-${groupId}?ref=${user.uid}`;
    }

    const text = `🎁 Ваша реферальная ссылка:\n\n${refLink}\n\n` +
      `Приглашайте друзей и получайте:\n` +
      `💰 +5000 FP за каждого друга\n` +
      `🏆 Специальные награды\n` +
      `📈 Увеличение дохода`;

    await botSend(context, text);
  }
};

export const topReferrersCommand: CommandDefinition<VkMessageContext> = {
  name: "common.topreferrers",
  pattern: /^(?:топ\s*рефы|топрефы|топ\s*рефер|топрефер)$/i,
  handler: async context => {
    const users = context.state.users;

    if (!users?.length) {
      await botSend(context, "Нет данных по рефералам.");
      return;
    }

    const filtered = users
      .filter(u => (u.refCount || 0) > 0 && !u.ba?.ban_top)
      .sort((a, b) => (b.refCount || 0) - (a.refCount || 0))
      .slice(0, 10);

    if (filtered.length === 0) {
      await botSend(context, "Нет данных по рефералам.");
      return;
    }

    const placeEmojis = ["1⃣", "2⃣", "3⃣", "4⃣", "5⃣", "6⃣", "7⃣", "8⃣", "9⃣", "🔟"];
    let text = "";

    for (let i = 0; i < filtered.length; i++) {
      const user = filtered[i];
      text += `${placeEmojis[i]} ${user.tag || "Игрок"} - ${user.refCount || 0} реф.\n`;
    }

    const myIndex = users.findIndex(u => u.id === (context.user?.id ?? context.senderId));
    if (myIndex >= 10 && myIndex !== -1) {
      const sorted = users
        .filter(u => (u.refCount || 0) > 0 && !u.ba?.ban_top)
        .sort((a, b) => (b.refCount || 0) - (a.refCount || 0));
      const myRank = sorted.findIndex(u => u.id === (context.user?.id ?? context.senderId)) + 1;

      if (myRank > 10) {
        const myUser = users[myIndex];
        text += `—————————————————\n${myRank} ${myUser.tag || "Игрок"} - ${myUser.refCount || 0} реф.\n`;
      }
    }

    await botSend(context, `👥 Топ рефереров:\n\n${text}`);
  }
};
