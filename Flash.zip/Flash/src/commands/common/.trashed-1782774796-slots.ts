import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { buildKeyboard } from "../../utils/keyboard";
import { formatWithSpaces } from "../../utils/number";

type SlotGame = {
  phase: "betting" | "spinning" | "free_spins" | "finished" | "auto_spins";
  bet: number;
  totalBet: number;
  reels: string[][];
  freeSpins: number;
  freeSpinsTotalWin: number;
  freeSpinsOriginal: number;
  lastWin: number;
  maxWin: number;
  globalMultiplier: number;
  isSuperBonus: boolean;
  anteEnabled: boolean;
  updatedAt: number;
  autoSpinsLeft?: number;
  stopAuto?: boolean;
  autoSpinsTotal?: number;
  autoSpinsWin?: number;
};

type UserWithSlots = NonNullable<VkMessageContext["user"]> & { 
  slots?: SlotGame;
  donate_rub?: number;
};

const SYMBOLS = [
  { n: "FLASH", e: "⚡", m: 10, p: 0.008 },
  { n: "WAVE", e: "🌊", m: 5, p: 0.018 },
  { n: "FIRE", e: "🔥", m: 3, p: 0.03 },
  { n: "OWL", e: "🦉", m: 2.4, p: 0.05 },
  { n: "SUN", e: "☀️", m: 2, p: 0.07 },
  { n: "BOW", e: "🏹", m: 1.6, p: 0.09 },
  { n: "WING", e: "👟", m: 1, p: 0.11 },
  { n: "GRAPE", e: "🍇", m: 0.8, p: 0.13 },
  { n: "HAMMER", e: "🔨", m: 0.4, p: 0.15 },
  { n: "WHEAT", e: "🌾", m: 0.3, p: 0.17 },
  { n: "SWORD", e: "⚔️", m: 0.2, p: 0.19 }
];

const SCATTER = { n: "SCATTER", e: "💲", payouts: { 4: 20, 5: 100, 6: 500 } };
const WILD = { n: "WILD", e: "💎" };
const MULT = "MULTIPLIER";

const ROWS = 6;
const REELS = 5;
const MIN_BET = 10;
const FREE_SPINS = 10;
const NORM_BONUS_MULT = 2;
const SUPER_BONUS_MULT = 10;
const NORM_BONUS_PRICE = 100;
const SUPER_BONUS_PRICE = 500;
const ANTE_COST = 1.25;
const ANTE_SCATTER_MULT = 1.5;

const MULT_EMOJI: Record<number, string> = {
  2: "2️⃣", 3: "3️⃣", 4: "4️⃣", 5: "5️⃣", 6: "6️⃣", 7: "7️⃣", 8: "8️⃣", 9: "9️⃣",
  10: "🔟", 12: "1️⃣2️⃣", 15: "1️⃣5️⃣", 20: "2️⃣0️⃣", 25: "2️⃣5️⃣", 30: "3️⃣0️⃣", 50: "5️⃣0️⃣", 100: "💯"
};

const parseBet = (raw: string, balance: number): number | null => {
  if (!raw) return null;
  let val = raw.trim().toLowerCase().replace(/[.,]/g, "");
  val = val.replace(/(к|k)/gi, "000").replace(/(м|m)/gi, "000000");
  val = val.replace(/(вс[её]|all|в[ао][ -]?банк|вабанк|vabank)/gi, String(balance));
  const amount = Number.parseInt(val.replace(/\s+/g, ""));
  return amount > 0 && amount <= balance ? amount : null;
};

const getMultEmoji = (v: number): string => {
  return MULT_EMOJI[v] || `${v}✖️`;
};

const getMultValue = (isSuper: boolean): number => {
  const r = Math.random();
  if (isSuper) {
    if (r < 0.45) return 10;
    if (r < 0.65) return 12;
    if (r < 0.8) return 15;
    if (r < 0.9) return 20;
    if (r < 0.96) return 25;
    if (r < 0.99) return 30;
    return 50;
  }
  if (r < 0.6) return 2;
  if (r < 0.78) return 3;
  if (r < 0.88) return 4;
  if (r < 0.94) return 5;
  if (r < 0.975) return 6;
  if (r < 0.99) return 7;
  if (r < 0.996) return 8;
  return 9;
};

const getPayout = (sym: string, cnt: number, bet: number): number => {
  const mult = (c: number): number => {
    if (c >= 12) return 5;
    if (c >= 10) return 2.5;
    return 1;
  };
  
  if (sym === WILD.n) {
    const flash = SYMBOLS.find(s => s.n === "FLASH");
    return Math.floor(bet * flash!.m * mult(cnt));
  }
  const s = SYMBOLS.find(s => s.n === sym);
  return s ? Math.floor(bet * s.m * mult(cnt)) : 0;
};

const getScatterPayout = (cnt: number, bet: number): number => {
  if (cnt >= 6) return Math.floor(bet * SCATTER.payouts[6]);
  if (cnt >= 5) return Math.floor(bet * SCATTER.payouts[5]);
  if (cnt >= 4) return Math.floor(bet * SCATTER.payouts[4]);
  return 0;
};

const getSymEmoji = (sym: string): string => {
  if (sym === WILD.n) return WILD.e;
  if (sym === SCATTER.n) return SCATTER.e;
  if (sym.startsWith(MULT)) {
    const multValue = parseInt(sym.split('_')[1]);
    return getMultEmoji(multValue);
  }
  const symbol = SYMBOLS.find(s => s.n === sym);
  return symbol?.e || "❓";
};

const getRandSym = (isFree: boolean, isSuper: boolean, ante: boolean): string => {
  const r = Math.random();
  let multCh = 0.0025;
  let scatCh = 0.007;
  const wildCh = 0.018;
  
  if (isFree) { 
    multCh *= 1.2; 
    scatCh *= 1.2; 
  }
  if (isSuper) multCh *= 1.5;
  if (ante && !isFree) scatCh *= ANTE_SCATTER_MULT;
  
  if (r < multCh) return `${MULT}_${getMultValue(isSuper)}`;
  if (r < multCh + scatCh) return SCATTER.n;
  if (r < multCh + scatCh + wildCh) return WILD.n;
  
  let cum = multCh + scatCh + wildCh;
  for (const s of SYMBOLS) {
    cum += s.p;
    if (r <= cum) return s.n;
  }
  return SYMBOLS[0].n;
};

const genReels = (isFree: boolean, isSuper: boolean, ante: boolean): string[][] => {
  const reels: string[][] = [];
  for (let i = 0; i < REELS; i++) {
    const column: string[] = [];
    for (let j = 0; j < ROWS; j++) {
      column.push(getRandSym(isFree, isSuper, ante));
    }
    reels.push(column);
  }
  return reels;
};

const countSyms = (reels: string[][]): Map<string, number> => {
  const counts = new Map<string, number>();
  for (let i = 0; i < REELS; i++) {
    for (let j = 0; j < ROWS; j++) {
      const s = reels[i][j];
      if (s !== MULT && !s.startsWith(MULT)) {
        counts.set(s, (counts.get(s) || 0) + 1);
      }
    }
  }
  return counts;
};

const findMults = (reels: string[][]) => {
  let total = 0;
  let cnt = 0;
  for (let i = 0; i < REELS; i++) {
    for (let j = 0; j < ROWS; j++) {
      const s = reels[i][j];
      if (s.startsWith(MULT)) {
        total += parseInt(s.split('_')[1]);
        cnt++;
      }
    }
  }
  return { cnt, total };
};

const renderReels = (reels: string[][]): string => {
  const rows: string[] = [];
  for (let i = 0; i < ROWS; i++) {
    const rowSymbols: string[] = [];
    for (let j = 0; j < REELS; j++) {
      rowSymbols.push(getSymEmoji(reels[j][i]));
    }
    rows.push(rowSymbols.join(" "));
  }
  return rows.join("\n");
};

const mainKb = (bet: number, ante: boolean) => buildKeyboard({
  inline: true,
  buttons: [
    [{ label: `💎 Ставка: ${formatWithSpaces(bet)} FP`, color: "secondary", command: "slot ставка" }],
    [{ label: "⚡ КРУТИТЬ", color: "positive", command: "slot" }],
    [{ label: "🔄 АВТОСПИНЫ", color: "primary", command: "slot авто" }],
    [
      { label: `💲 БОНУС (${NORM_BONUS_PRICE}₽)`, color: "negative", command: "slot купить бонус" },
      { label: `🔟 СУПЕР (${SUPER_BONUS_PRICE}₽)`, color: "negative", command: "slot купить супер бонус" }
    ],
    [
      { label: ante ? "✅ АНТЕ ВКЛ" : "🎲 АНТЕ ВЫКЛ", color: ante ? "positive" : "secondary", command: "slot анте" },
      { label: "❓ Помощь", color: "secondary", command: "slot инфо" }
    ]
  ]
});

const autoSpinKb = () => buildKeyboard({
  inline: true,
  buttons: [
    [
      { label: "5 спинов", color: "primary", command: "slot авто 5" },
      { label: "10 спинов", color: "primary", command: "slot авто 10" }
    ],
    [
      { label: "25 спинов", color: "primary", command: "slot авто 25" },
      { label: "50 спинов", color: "primary", command: "slot авто 50" }
    ],
    [{ label: "🔙 Назад", color: "secondary", command: "slot" }]
  ]
});

const autoSpinActiveKb = () => buildKeyboard({
  inline: true,
  buttons: [
    [{ label: "⏹️ ОСТАНОВИТЬ", color: "negative", command: "slot стоп авто" }]
  ]
});

const betKb = (balance: number, curBet: number, ante: boolean) => buildKeyboard({
  inline: true,
  buttons: [
    [
      { label: "10", color: curBet === 10 ? "positive" : "primary", command: "slot 10" },
      { label: "50", color: curBet === 50 ? "positive" : "primary", command: "slot 50" },
      { label: "100", color: curBet === 100 ? "positive" : "primary", command: "slot 100" }
    ],
    [
      { label: "500", color: curBet === 500 ? "positive" : "primary", command: "slot 500" },
      { label: "1000", color: curBet === 1000 ? "positive" : "primary", command: "slot 1000" },
      { label: "5000", color: curBet === 5000 ? "positive" : "primary", command: "slot 5000" }
    ],
    [{ label: `💰 Ва-банк (${formatWithSpaces(balance)} FP)`, color: "negative", command: `slot ${balance}` }],
    [
      { label: ante ? "✅ АНТЕ ВКЛ" : "🎲 АНТЕ ВЫКЛ", color: ante ? "positive" : "secondary", command: "slot анте" },
      { label: "🔙 Назад", color: "secondary", command: "slot" }
    ]
  ]
});

// Выполнение одного спина с каскадами (каждый каскад - новое сообщение)
const executeSpinWithCascades = async (
  ctx: VkMessageContext,
  u: UserWithSlots,
  bet: number,
  isFree: boolean,
  isSuper: boolean,
  ante: boolean,
  currentMultiplier: number,
  spinTitle: string
): Promise<{ totalWin: number; freeEarned: number; finalMultiplier: number; cascadesCount: number }> => {
  let reels = genReels(isFree, isSuper, ante);
  let totalWin = 0;
  let freeEarned = 0;
  let cascade = true;
  let cascadesCount = 0;
  let multiplier = currentMultiplier;
  
  while (cascade && cascadesCount < 10) {
    cascadesCount++;
    const counts = countSyms(reels);
    const multipliers = findMults(reels);
    
    let cascadeWin = 0;
    const wins: string[] = [];
    
    for (const [sym, cnt] of counts) {
      if (cnt >= 8 && sym !== SCATTER.n) {
        const payout = getPayout(sym, cnt, bet);
        if (payout > 0) {
          cascadeWin += payout;
          wins.push(`🎯 ${getSymEmoji(sym)} x${cnt} → ${formatWithSpaces(payout)} FP`);
        }
      }
    }
    
    const sc = counts.get(SCATTER.n) || 0;
    if (sc >= 4) {
      const scatterWin = getScatterPayout(sc, bet);
      cascadeWin += scatterWin;
      if (!isFree) freeEarned = FREE_SPINS;
      wins.push(`💲 SCATTER x${sc} → ${formatWithSpaces(scatterWin)} FP`);
    }
    
    // Применяем текущий множитель
    if (cascadeWin > 0) {
      const winBeforeMult = cascadeWin;
      cascadeWin *= multiplier;
      wins.push(`${getMultEmoji(multiplier)} МНОЖИТЕЛЬ x${multiplier}: ${formatWithSpaces(winBeforeMult)} → ${formatWithSpaces(cascadeWin)} FP`);
    }
    
    // Добавляем новые множители
    if (multipliers.total > 0) {
      multiplier += multipliers.total;
      wins.push(`✨ ВЫПАЛ МНОЖИТЕЛЬ +${multipliers.total}! Новый множитель: x${multiplier}`);
    }
    
    totalWin += cascadeWin;
    
    // Отправляем сообщение для этого каскада
    const cascadeLines = [
      spinTitle,
      `━━━━━━━━━━━━━━━━━━━━`,
      renderReels(reels),
      ``,
      `🌀 КАСКАД #${cascadesCount}`,
    ];
    
    if (wins.length > 0) {
      cascadeLines.push(``);
      cascadeLines.push(...wins);
    }
    
    cascadeLines.push(``);
    cascadeLines.push(`💰 ВЫИГРЫШ КАСКАДА: ${cascadeWin > 0 ? '+' + formatWithSpaces(cascadeWin) : '0'} FP`);
    cascadeLines.push(`${getMultEmoji(multiplier)} ТЕКУЩИЙ МНОЖИТЕЛЬ: x${multiplier}`);
    cascadeLines.push(`━━━━━━━━━━━━━━━━━━━━`);
    
    await botSend(ctx, cascadeLines.join('\n'));
    await new Promise(r => setTimeout(r, 1200));
    
    // Подготовка к следующему каскаду
    const toRemove = new Set<string>();
    for (const [sym, cnt] of counts) {
      if (cnt >= 8 && sym !== SCATTER.n && sym !== MULT && !sym.startsWith(MULT)) {
        toRemove.add(sym);
      }
    }
    
    if (toRemove.size > 0) {
      const newReels = JSON.parse(JSON.stringify(reels));
      for (let i = 0; i < REELS; i++) {
        for (let j = 0; j < ROWS; j++) {
          if (toRemove.has(newReels[i][j])) {
            newReels[i][j] = null;
          }
        }
      }
      
      for (let c = 0; c < REELS; c++) {
        const col = [];
        for (let r = 0; r < ROWS; r++) {
          if (newReels[c][r] !== null) {
            col.push(newReels[c][r]);
          }
        }
        while (col.length < ROWS) {
          col.unshift(getRandSym(isFree, isSuper, ante));
        }
        for (let r = 0; r < ROWS; r++) {
          newReels[c][r] = col[r];
        }
      }
      reels = newReels;
      cascade = true;
    } else {
      cascade = false;
    }
  }
  
  return { totalWin, freeEarned, finalMultiplier: multiplier, cascadesCount };
};

// Функция для выполнения одного обычного спина (для автоспинов)
const executeNormalSpinForAuto = async (
  ctx: VkMessageContext,
  u: UserWithSlots,
  bet: number,
  ante: boolean,
  spinNum: number,
  totalSpins: number
): Promise<{ totalWin: number; freeEarned: number }> => {
  const totalBet = ante ? Math.floor(bet * ANTE_COST) : bet;
  
  if (totalBet > u.balance) {
    return { totalWin: 0, freeEarned: -1 };
  }
  
  u.balance -= totalBet;
  
  const result = await executeSpinWithCascades(
    ctx, u, bet, false, false, ante, 1,
    `🔄 АВТОСПИН ${spinNum}/${totalSpins}`
  );
  
  if (result.totalWin > 0) {
    u.balance += result.totalWin;
    if (u.winnings !== undefined) {
      u.winnings += result.totalWin;
    } else {
      u.winnings = result.totalWin;
    }
  }
  
  return { totalWin: result.totalWin, freeEarned: result.freeEarned };
};

// Автоспины с показом каждого спина
const performAutoSpins = async (ctx: VkMessageContext, u: UserWithSlots, spinsCount: number) => {
  const bet = u.slots?.bet || 50;
  const ante = u.slots?.anteEnabled || false;
  const totalBet = ante ? Math.floor(bet * ANTE_COST) : bet;
  
  if (totalBet * spinsCount > u.balance) {
    await botSend(ctx,
      `❌ Недостаточно средств для ${spinsCount} автоспинов!\n` +
      `💰 Нужно: ${formatWithSpaces(totalBet * spinsCount)} FP\n` +
      `💳 Баланс: ${formatWithSpaces(u.balance)} FP`,
      { keyboard: mainKb(bet, ante) }
    );
    return;
  }
  
  const game: SlotGame = {
    phase: "auto_spins",
    bet: bet,
    totalBet: totalBet,
    reels: [],
    freeSpins: 0,
    freeSpinsTotalWin: 0,
    freeSpinsOriginal: 0,
    lastWin: 0,
    maxWin: 0,
    globalMultiplier: 1,
    isSuperBonus: false,
    anteEnabled: ante,
    updatedAt: Date.now(),
    autoSpinsLeft: spinsCount,
    autoSpinsTotal: spinsCount,
    autoSpinsWin: 0,
    stopAuto: false
  };
  u.slots = game;
  
  await botSend(ctx,
    `🔄 ЗАПУСК АВТОСПИНОВ\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `🎰 Количество: ${spinsCount}\n` +
    `💰 Ставка: ${formatWithSpaces(totalBet)} FP\n` +
    `💳 Баланс: ${formatWithSpaces(u.balance)} FP`,
    { keyboard: autoSpinActiveKb() }
  );
  
  let spinsDone = 0;
  let totalWin = 0;
  
  for (let i = 0; i < spinsCount; i++) {
    if (game.stopAuto) {
      await botSend(ctx,
        `⏹️ АВТОСПИНЫ ОСТАНОВЛЕНЫ\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `🎰 Выполнено: ${spinsDone}/${spinsCount}\n` +
        `💰 Выиграно: ${formatWithSpaces(totalWin)} FP\n` +
        `💳 Баланс: ${formatWithSpaces(u.balance)} FP`,
        { keyboard: mainKb(bet, ante) }
      );
      u.slots = undefined;
      return;
    }
    
    const result = await executeNormalSpinForAuto(ctx, u, bet, ante, i + 1, spinsCount);
    
    if (result.freeEarned === -1) {
      await botSend(ctx,
        `❌ Недостаточно средств!\n💳 Баланс: ${formatWithSpaces(u.balance)} FP`,
        { keyboard: mainKb(bet, ante) }
      );
      u.slots = undefined;
      return;
    }
    
    totalWin += result.totalWin;
    spinsDone++;
    game.autoSpinsWin = totalWin;
    game.autoSpinsLeft = spinsCount - spinsDone;
    
    // Итог спина
    await botSend(ctx,
      `✅ СПИН ${i + 1}/${spinsCount} ЗАВЕРШЁН\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `💰 Выигрыш спина: ${result.totalWin > 0 ? '+' + formatWithSpaces(result.totalWin) : '0'} FP\n` +
      `💎 Всего выиграно: ${formatWithSpaces(totalWin)} FP\n` +
      `💳 Баланс: ${formatWithSpaces(u.balance)} FP`,
      { keyboard: autoSpinActiveKb() }
    );
    
    if (result.freeEarned > 0) {
      await botSend(ctx,
        `🎁 ВЫПАЛИ ФРИСПИНЫ!\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `🔄 Автоспины остановлены\n` +
        `🎰 Выполнено: ${spinsDone}/${spinsCount}\n` +
        `💰 Выиграно: ${formatWithSpaces(totalWin)} FP`,
        { keyboard: mainKb(bet, ante) }
      );
      
      const bonusGame: SlotGame = {
        phase: "free_spins",
        bet: bet,
        totalBet,
        reels: [],
        freeSpins: result.freeEarned,
        freeSpinsTotalWin: 0,
        freeSpinsOriginal: result.freeEarned,
        lastWin: 0,
        maxWin: 0,
        globalMultiplier: 1,
        isSuperBonus: false,
        anteEnabled: false,
        updatedAt: Date.now()
      };
      
      u.slots = bonusGame;
      await performAllFreeSpins(ctx, u, bonusGame);
      return;
    }
    
    await new Promise(r => setTimeout(r, 1000));
  }
  
  await botSend(ctx,
    `✅ АВТОСПИНЫ ЗАВЕРШЕНЫ\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `🎰 Выполнено: ${spinsDone}/${spinsCount}\n` +
    `💰 Всего выиграно: ${formatWithSpaces(totalWin)} FP\n` +
    `💳 Баланс: ${formatWithSpaces(u.balance)} FP`,
    { keyboard: mainKb(bet, ante) }
  );
  
  u.slots = {
    phase: "betting",
    bet: bet,
    totalBet: 0,
    reels: [],
    freeSpins: 0,
    freeSpinsTotalWin: 0,
    freeSpinsOriginal: 0,
    lastWin: 0,
    maxWin: 0,
    globalMultiplier: 1,
    isSuperBonus: false,
    anteEnabled: ante,
    updatedAt: Date.now()
  };
};

// Бонусная игра (каскады новыми сообщениями, спин только после всех каскадов)
const performAllFreeSpins = async (ctx: VkMessageContext, u: UserWithSlots, game: SlotGame) => {
  let spinCount = 0;
  const totalSpins = game.freeSpins;
  
  await botSend(ctx,
    `🎰 ЗАПУСК БОНУСНОЙ ИГРЫ\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `💰 СТАВКА: ${formatWithSpaces(game.bet)} FP\n` +
    `🎰 ФРИСПИНОВ: ${totalSpins}\n` +
    `${getMultEmoji(game.globalMultiplier)} СТАРТОВЫЙ МНОЖИТЕЛЬ: x${game.globalMultiplier}`
  );
  
  await new Promise(r => setTimeout(r, 1500));
  
  while (game.freeSpins > 0) {
    spinCount++;
    
    const isSuper = game.isSuperBonus;
    const ante = false;
    
    const result = await executeSpinWithCascades(
      ctx, u, game.bet, true, isSuper, ante, game.globalMultiplier,
      `🎰 БОНУС - СПИН ${spinCount}`
    );
    
    // Спин завершён, уменьшаем счётчик
    game.freeSpins--;
    game.globalMultiplier = result.finalMultiplier;
    game.freeSpinsTotalWin += result.totalWin;
    
    if (result.freeEarned > 0) {
      game.freeSpins += result.freeEarned;
      game.freeSpinsOriginal += result.freeEarned;
    }
    
    // Итог спина
    const spinSummary = [
      `✅ БОНУС - СПИН ${spinCount} ЗАВЕРШЁН`,
      `━━━━━━━━━━━━━━━━━━━━`,
      `🌀 Всего каскадов: ${result.cascadesCount}`,
      `💰 Выигрыш спина: ${result.totalWin > 0 ? '+' + formatWithSpaces(result.totalWin) : '0'} FP`,
      `${getMultEmoji(game.globalMultiplier)} МНОЖИТЕЛЬ: x${game.globalMultiplier}`,
      `💎 ВСЕГО ВЫИГРАНО: ${formatWithSpaces(game.freeSpinsTotalWin)} FP`,
    ];
    
    if (result.freeEarned > 0) {
      spinSummary.push(`🎁 +${result.freeEarned} ФРИСПИНОВ!`);
    }
    
    spinSummary.push(``);
    spinSummary.push(`🎰 ОСТАЛОСЬ: ${game.freeSpins} фриспинов`);
    spinSummary.push(`━━━━━━━━━━━━━━━━━━━━`);
    
    await botSend(ctx, spinSummary.join('\n'));
    await new Promise(r => setTimeout(r, 1500));
  }
  
  u.balance += game.freeSpinsTotalWin;
  if (u.winnings !== undefined) {
    u.winnings += game.freeSpinsTotalWin;
  } else {
    u.winnings = game.freeSpinsTotalWin;
  }
  
  const startMult = game.isSuperBonus ? SUPER_BONUS_MULT : NORM_BONUS_MULT;
  const finalText = 
    `🎉 БОНУС ЗАВЕРШЁН!\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `🎰 ВСЕГО ВРАЩЕНИЙ: ${game.freeSpinsOriginal}\n` +
    `${getMultEmoji(startMult)} СТАРТОВЫЙ МНОЖИТЕЛЬ: x${startMult}\n` +
    `${getMultEmoji(game.globalMultiplier)} ФИНАЛЬНЫЙ МНОЖИТЕЛЬ: x${game.globalMultiplier}\n` +
    `💰 ОБЩИЙ ВЫИГРЫШ: ${formatWithSpaces(game.freeSpinsTotalWin)} FP\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `💳 БАЛАНС: ${formatWithSpaces(u.balance)} FP`;
  
  await botSend(ctx, finalText, { keyboard: mainKb(game.bet, false) });
  
  const savedBet = game.bet;
  u.slots = {
    phase: "betting",
    bet: savedBet,
    totalBet: 0,
    reels: [],
    freeSpins: 0,
    freeSpinsTotalWin: 0,
    freeSpinsOriginal: 0,
    lastWin: 0,
    maxWin: 0,
    globalMultiplier: 1,
    isSuperBonus: false,
    anteEnabled: false,
    updatedAt: Date.now()
  };
};

const buyBonus = async (ctx: VkMessageContext, isSuper: boolean) => {
  const u = ctx.user as UserWithSlots;
  if (!u) return;
  
  const price = isSuper ? SUPER_BONUS_PRICE : NORM_BONUS_PRICE;
  if ((u.donate_rub || 0) < price) {
    await botSend(ctx, 
      `❌ Недостаточно донатных рублей!\n` +
      `💰 Нужно: ${price}₽\n` +
      `💳 Ваш баланс: ${u.donate_rub || 0}₽`
    );
    return;
  }
  
  u.donate_rub = (u.donate_rub || 0) - price;
  const bet = u.slots?.bet || 50;
  const startMult = isSuper ? SUPER_BONUS_MULT : NORM_BONUS_MULT;
  
  const game: SlotGame = {
    phase: "free_spins", 
    bet: bet, 
    totalBet: bet, 
    reels: [],
    freeSpins: FREE_SPINS, 
    freeSpinsTotalWin: 0, 
    freeSpinsOriginal: FREE_SPINS,
    lastWin: 0, 
    maxWin: 0, 
    globalMultiplier: startMult,
    isSuperBonus: isSuper, 
    anteEnabled: false, 
    updatedAt: Date.now()
  };
  u.slots = game;
  
  await performAllFreeSpins(ctx, u, game);
};

const toggleAnte = async (ctx: VkMessageContext) => {
  const u = ctx.user as UserWithSlots;
  if (!u) return;
  
  if (!u.slots) {
    u.slots = { 
      phase: "betting", 
      bet: 50, 
      totalBet: 0, 
      reels: [], 
      freeSpins: 0, 
      freeSpinsTotalWin: 0, 
      freeSpinsOriginal: 0, 
      lastWin: 0, 
      maxWin: 0, 
      globalMultiplier: 1, 
      isSuperBonus: false, 
      anteEnabled: false, 
      updatedAt: Date.now() 
    };
  }
  
  u.slots.anteEnabled = !u.slots.anteEnabled;
  const anteStatus = u.slots.anteEnabled;
  const newTotalBet = Math.floor(u.slots.bet * (anteStatus ? ANTE_COST : 1));
  
  await botSend(ctx, 
    `🎲 АНТЕ ${anteStatus ? "ВКЛЮЧЕНА" : "ВЫКЛЮЧЕНА"}\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `${anteStatus ? 
      `💰 Ставка: ${formatWithSpaces(u.slots.bet)} → ${formatWithSpaces(newTotalBet)} FP (×${ANTE_COST})\n` +
      `🎯 Шанс SCATTER увеличен на +50%` : 
      `💰 Ставка: ${formatWithSpaces(u.slots.bet)} FP`
    }`, 
    { keyboard: mainKb(u.slots.bet, anteStatus) }
  );
};

const changeBet = async (ctx: VkMessageContext, newBet: number) => {
  const u = ctx.user as UserWithSlots;
  if (!u) return;
  
  if (!u.slots) {
    u.slots = { 
      phase: "betting", 
      bet: newBet, 
      totalBet: 0, 
      reels: [], 
      freeSpins: 0, 
      freeSpinsTotalWin: 0, 
      freeSpinsOriginal: 0, 
      lastWin: 0, 
      maxWin: 0, 
      globalMultiplier: 1, 
      isSuperBonus: false, 
      anteEnabled: false, 
      updatedAt: Date.now() 
    };
  } else {
    u.slots.bet = newBet;
  }
  
  const ante = u.slots.anteEnabled;
  const totalBet = ante ? Math.floor(newBet * ANTE_COST) : newBet;
  
  await botSend(ctx,
    `💎 СТАВКА ИЗМЕНЕНА\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `💰 Новая ставка: ${formatWithSpaces(newBet)} FP\n` +
    `${ante ? `🎲 С анте: ${formatWithSpaces(totalBet)} FP (×${ANTE_COST})` : ''}`,
    { keyboard: mainKb(newBet, ante) }
  );
};

const startGame = async (ctx: VkMessageContext, betRaw?: string) => {
  const u = ctx.user as UserWithSlots;
  if (!u) return;
  
  let bet = u.slots?.bet || 50;
  
  if (betRaw) {
    const parsed = parseBet(betRaw, u.balance);
    if (parsed && parsed >= MIN_BET) {
      bet = parsed;
      if (!u.slots) {
        u.slots = { 
          phase: "betting", 
          bet: bet, 
          totalBet: 0, 
          reels: [], 
          freeSpins: 0, 
          freeSpinsTotalWin: 0, 
          freeSpinsOriginal: 0, 
          lastWin: 0, 
          maxWin: 0, 
          globalMultiplier: 1, 
          isSuperBonus: false, 
          anteEnabled: false, 
          updatedAt: Date.now() 
        };
      } else {
        u.slots.bet = bet;
      }
    }
  }
  
  const ante = u.slots?.anteEnabled || false;
  let totalBet = bet;
  if (ante) {
    totalBet = Math.floor(bet * ANTE_COST);
  }
  
  if (totalBet > u.balance) {
    await botSend(ctx, 
      `❌ Недостаточно средств!\n💰 Нужно: ${formatWithSpaces(totalBet)} FP`, 
      { keyboard: mainKb(bet, ante) }
    );
    return;
  }
  
  u.balance -= totalBet;
  
  const result = await executeSpinWithCascades(
    ctx, u, bet, false, false, ante, 1,
    `⚡ FLASH SUPER SCATTER`
  );
  
  if (result.totalWin > 0) {
    u.balance += result.totalWin;
    if (u.winnings !== undefined) {
      u.winnings += result.totalWin;
    } else {
      u.winnings = result.totalWin;
    }
  }
  
  // Итог спина
  const summaryLines = [
    `✅ СПИН ЗАВЕРШЁН`,
    `━━━━━━━━━━━━━━━━━━━━`,
    `🌀 Всего каскадов: ${result.cascadesCount}`,
    `💰 ВЫИГРЫШ: ${result.totalWin > 0 ? '+' + formatWithSpaces(result.totalWin) : '0'} FP`,
  ];
  
  if (result.freeEarned > 0) {
    summaryLines.push(`🎁 +${result.freeEarned} ФРИСПИНОВ!`);
  }
  
  summaryLines.push(`━━━━━━━━━━━━━━━━━━━━`);
  summaryLines.push(`💳 БАЛАНС: ${formatWithSpaces(u.balance)} FP`);
  
  await botSend(ctx, summaryLines.join('\n'), { 
    keyboard: mainKb(bet, ante)
  });
  
  if (result.freeEarned > 0) {
    const game: SlotGame = {
      phase: "free_spins",
      bet: bet,
      totalBet,
      reels: [],
      freeSpins: result.freeEarned,
      freeSpinsTotalWin: 0,
      freeSpinsOriginal: result.freeEarned,
      lastWin: 0,
      maxWin: 0,
      globalMultiplier: 1,
      isSuperBonus: false,
      anteEnabled: false,
      updatedAt: Date.now()
    };
    
    u.slots = game;
    await performAllFreeSpins(ctx, u, game);
  } else {
    if (!u.slots) {
      u.slots = { 
        phase: "betting", 
        bet: bet, 
        totalBet: 0, 
        reels: [], 
        freeSpins: 0, 
        freeSpinsTotalWin: 0, 
        freeSpinsOriginal: 0, 
        lastWin: 0, 
        maxWin: 0, 
        globalMultiplier: 1, 
        isSuperBonus: false, 
        anteEnabled: ante, 
        updatedAt: Date.now() 
      };
    } else {
      u.slots.bet = bet;
      u.slots.phase = "betting";
    }
  }
};

export const slotsCommand: CommandDefinition<VkMessageContext> = {
  name: "common.slots",
  pattern: /^(?:slot|slots|слот)(?:\s+(.*))?$/i,
  guard: ctx => Boolean(ctx.user && !ctx.isChat),
  handler: async ctx => {
    const u = ctx.user as UserWithSlots;
    if (!u) return;
    
    const arg = (ctx.match?.[1] || "").trim().toLowerCase();
    
    if (["инфо", "info", "help", "?"].includes(arg)) {
      const info = 
        `⚡ FLASH SUPER SCATTER - СЛОТ-ИГРА\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `📊 ИГРОВОЕ ПОЛЕ: ${REELS}x${ROWS}\n` +
        `💰 МИНИМАЛЬНАЯ СТАВКА: ${MIN_BET} FP\n` +
        `💎 ТЕКУЩАЯ СТАВКА: ${formatWithSpaces(u.slots?.bet || 50)} FP\n` +
        `🎯 СИМВОЛЫ ПЛАТЯТ В ЛЮБОМ МЕСТЕ (ОТ 8 ШТУК)\n\n` +
        `💡 КОМАНДЫ:\n` +
        `  slot - играть\n` +
        `  slot 100 - ставка 100 FP\n` +
        `  slot ставка - меню ставки\n` +
        `  slot авто - меню автоспинов\n` +
        `  slot авто 10 - 10 автоспинов\n` +
        `  slot стоп авто - остановить\n` +
        `  slot анте - вкл/выкл Анте\n` +
        `  slot купить бонус - купить бонус`;
        
      await botSend(ctx, info);
      return;
    }
    
    if (arg === "ставка" || arg === "bet") {
      const bet = u.slots?.bet || 50;
      await botSend(ctx, 
        `💎 ВЫБЕРИТЕ СТАВКУ\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `💰 Текущая: ${formatWithSpaces(bet)} FP\n` +
        `💳 Баланс: ${formatWithSpaces(u.balance)} FP`,
        { keyboard: betKb(u.balance, bet, u.slots?.anteEnabled || false) }
      );
      return;
    }
    
    if (arg === "авто" || arg === "auto") {
      await botSend(ctx,
        `🔄 ВЫБЕРИТЕ КОЛИЧЕСТВО АВТОСПИНОВ`,
        { keyboard: autoSpinKb() }
      );
      return;
    }
    
    if (arg === "стоп авто" || arg === "stop auto") {
      if (u.slots && u.slots.phase === "auto_spins") {
        u.slots.stopAuto = true;
        await botSend(ctx, "⏹️ Останавливаем...");
      } else {
        await botSend(ctx, "❌ Нет активных автоспинов!");
      }
      return;
    }
    
    const autoMatch = arg.match(/^(?:авто|auto)\s+(\d+)$/);
    if (autoMatch) {
      const count = parseInt(autoMatch[1]);
      if ([5, 10, 25, 50].includes(count)) {
        await performAutoSpins(ctx, u, count);
      } else {
        await botSend(ctx, "❌ Доступно: 5, 10, 25, 50");
      }
      return;
    }
    
    if (arg === "анте" || arg === "ante") { 
      await toggleAnte(ctx); 
      return; 
    }
    
    if (arg === "купить бонус" || arg === "buy bonus") { 
      await buyBonus(ctx, false); 
      return; 
    }
    
    if (arg === "купить супер бонус" || arg === "buy super bonus") { 
      await buyBonus(ctx, true); 
      return; 
    }
    
    const betAmount = parseInt(arg);
    if (!isNaN(betAmount) && betAmount >= MIN_BET) {
      await changeBet(ctx, betAmount);
      await startGame(ctx);
      return;
    }
    
    await startGame(ctx, arg);
  }
};