import crypto from "crypto";
import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";

const LINK_TTL_MS = 10 * 60 * 1000;

const generateCode = (): string => crypto.randomBytes(4).toString("hex").toUpperCase();

export const tgLinkCommand: CommandDefinition<VkMessageContext> = {
  name: "common.tgLink",
  pattern: /^(?:tg|тг|link|bind|start|\/start)(?:\s+([A-Za-z0-9]+))?$/i,
  handler: async context => {
    const user = context.user;
    const state = context.state;
    if (!user || !state || !state.users) return;

    const codeArg = String(context.match?.[1] ?? "").trim();
    const platform = context.platform ?? "vk";

    if (platform === "tg") {
      if (!codeArg) {
        if (user.id > 0 && user.tgId) {
          await botSend(context, "Telegram уже привязан.");
          return;
        }
        await botSend(context, "Сначала получите код в VK командой tg, затем отправьте /start КОД сюда.");
        return;
      }

      const normalized = codeArg.toUpperCase();
      const now = Date.now();
      const target = state.users.find(
        entry =>
          typeof entry.tgLinkCode === "string" &&
          entry.tgLinkCode.toUpperCase() === normalized &&
          typeof entry.tgLinkExpires === "number" &&
          entry.tgLinkExpires > now
      );

      if (!target) {
        await botSend(context, "Неверный или просроченный код.");
        return;
      }

      const tgUserId = context.tgUserId;
      if (!tgUserId) {
        await botSend(context, "Не удалось определить пользователя Telegram.");
        return;
      }

      if (target.tgId && target.tgId !== tgUserId) {
        await botSend(context, "Этот код уже привязан.");
        return;
      }

      const existing = state.users.find(entry => entry.tgId === tgUserId && entry.id !== target.id);
      if (existing) {
        existing.tgId = undefined;
        existing.tgUsername = undefined;
      }

      target.tgId = tgUserId;
      if (context.tgUsername) target.tgUsername = context.tgUsername;
      target.tgLinkCode = undefined;
      target.tgLinkExpires = undefined;

      await botSend(context, "Аккаунт привязан.");
      return;
    }

    const code = generateCode();
    user.tgLinkCode = code;
    user.tgLinkExpires = Date.now() + LINK_TTL_MS;
    await botSend(context, `Код для привязки Telegram: ${code}\nОтправьте /start ${code} в Telegram-боте.`);
  }
};
