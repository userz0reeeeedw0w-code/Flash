import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend, formatUserLabel } from "../../core/mode/GameMode";
import { formatWithSpaces } from "../../utils/number";
import { resolveResource } from "vk-io";

const parseAmount = (raw: string, balance: number): number => {
  let value = raw.replace(/(\.|,)/gi, "");
  value = value.replace(/(к|k)/gi, "000");
  value = value.replace(/(м|m)/gi, "000000");
  value = value.replace(/(вс[её]|all)/gi, String(balance));
  value = value.replace(/(в[ао]банк)/gi, "999999999999");
  return Math.floor(Number(value));
};

export const transferCommand: CommandDefinition<VkMessageContext> = {
  name: "common.transfer",
  pattern:
    /^(?:передать|дать|перевести|пиревести|пиредать|перидать)(?:\s(?<id>\d+)?(?<link>(?:http?s:\/\/vk\.(?:ru|com)\/(?:id\d+|\w+))|(?:\[id\d+\|@?\w+\]))?)?(?:\s(?<amount>(?:[0-9\.]+[kкmм]*|вс[её]|all|в[ао]банк)))$/i,
  handler: async context => {
    const { user, state, vk } = context;
    if (!user || !state || !state.users) {
      return;
    }

    if (user.banper) {
      await botSend(context, "У вас бан переводов");
      return;
    }

    const groups = (context.match ?? context.text.match(transferCommand.pattern))?.groups as
      | { id?: string; link?: string; amount?: string }
      | undefined;
    if (!groups || !groups.amount) {
      await botSend(context, "укажите сумму, которую хотите отправить.");
      return;
    }

    const amount = parseAmount(groups.amount, user.balance);
    if (!Number.isFinite(amount) || amount <= 0) {
      await botSend(context, "укажите сумму, которую хотите отправить.");
      return;
    }

    if (amount > user.balance) {
      await botSend(context, "у Вас нет столько FP коинов.");
      return;
    }

    const platform = context.platform ?? "vk";
    let targetId: number | null = null;

    if (groups.id) {
      targetId = Number(groups.id);
    } else if (groups.link) {
      if (platform === "tg" || !vk) {
        targetId = null;
      } else {
      const match = groups.link.match(/https?:\/\/vk\.(?:ru|com)\/([a-zA-Z0-9_.-]+)/i);
      if (match) {
        const screenName = match[1];

        const explicitIdMatch = screenName.match(/^(?:id|club|public|event)(\d+)$/);

        if (explicitIdMatch) {
            targetId = Number(explicitIdMatch[1]);
        } else {
          try {
            const response = await resolveResource({
              api: vk.api,
              resource: screenName
            });

            targetId = response?.type == "user" ? response?.id : null;
          } catch (e) {
            console.error('Ошибка при резолве ссылки:', e);
            targetId = null;
          }
        }
      }
      }
    } else if (!groups.id && !groups.link) {
      if (platform === "vk") {
        targetId = context.message.hasReplyMessage
          ? context.message.replyMessage?.senderId ?? null
          : context.message.hasForwards
            ? context.message.forwards[0]?.senderId ?? null
            : null;
      } else {
        targetId = null;
      }
    }

    if (!targetId) {
      await botSend(context, platform === "tg" ? "укажите UID игрока для перевода." : "вы указали неправильную ссылку.");
      return;
    }

    const allUsers = state.users;
    const targetUser =
      platform === "tg"
        ? allUsers.find(entry => entry.uid === targetId)
        : allUsers.find(entry => entry.id === targetId || entry.uid === targetId);
    if (!targetUser) {
      await botSend(context, "этот игрок не играет в бота.");
      return;
    }

    if (targetUser.id === user.id) {
      await botSend(context, "нельзя перевести самому себе.");
      return;
    }

    const transferAmount = Math.min(amount, user.balance);

    let feePercentage = 25;

    if (user.permiss.sponsor) {
      feePercentage = 3;
    } else if (user.permiss.flash) {
      feePercentage = 5;
    } else if (user.permiss.donate) {
      feePercentage = 10;
    } else if (user.permiss.admin) {
      feePercentage = 15;
    } else if (user.permiss.legend) {
      feePercentage = 18;
    } else if (user.permiss.premium) {
      feePercentage = 20;
    } else if (user.permiss.vip) {
      feePercentage = 23;
    }

    const fee = Math.floor(transferAmount * (feePercentage / 100));
    const transferTotal = transferAmount - fee;

    if (transferTotal <= 0) {
      await botSend(context, "у вас недостаточно FP коинов для осуществления перевода");
      return;
    }

    user.balance -= transferAmount;
    targetUser.balance += transferTotal;

    if (platform === "vk" && vk) {
      await vk.api.messages.send({
        chat_id: 5,
        message: `[ЛОГ ДЕЙСТВИЙ]\nПользователь *id${user.id} (${user.tag}) совершил перевод ${formatWithSpaces(
          transferTotal
        )} FP для пользователя *id${targetUser.id} (${targetUser.tag})`,
        random_id: 0
      });

      await vk.api.messages.send({
        user_id: targetUser.id,
        message: `Игрок ${formatUserLabel(user, false)} перевел вам ${formatWithSpaces(transferTotal)} FP 💳`,
        random_id: 0
      });
    } else if (platform === "tg") {
      const tg = context.tg;
      const tgId = typeof targetUser.tgId === "number" ? targetUser.tgId : null;
      if (tg && tgId) {
        const senderLabel = typeof user.tgUsername === "string" && user.tgUsername ? `@${user.tgUsername}` : user.tag;
        await tg.sendMessage(tgId, `Игрок ${senderLabel} перевел вам ${formatWithSpaces(transferTotal)} FP 💳`).catch(() => undefined);
      }
    }

    const targetLabel =
      platform === "tg"
        ? (typeof targetUser.tgUsername === "string" && targetUser.tgUsername ? `@${targetUser.tgUsername}` : targetUser.tag)
        : formatUserLabel(targetUser, Boolean(context.isChat && !targetUser.disable_mentions));
    await botSend(
      context,
      `вы перевели ${targetLabel} ${formatWithSpaces(transferTotal)} FP 💳\n` +
        `Сумма комиссии ${feePercentage}%\n` +
        `⚙️Ваша комиссия составила ${formatWithSpaces(fee)} FP`
    );
  }
};
