import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { formatWithSpaces } from "../../utils/number";

const placeEmojis = ["1⃣", "2⃣", "3⃣", "4⃣", "5⃣", "6⃣", "7⃣", "8⃣", "9⃣", "🔟"];

export const winningsTopCommand: CommandDefinition<VkMessageContext> = {
  name: "common.winningstop",
  pattern: /^(?:топ\s*выигрыш|топвыигрыш|выигрыш\s*топ)$/i,
  handler: async context => {
    
    const users = context.state.users;

    if (!users?.length) {
      await botSend(context, "Нет данных по выигрышам.");
      return;
    }

    const filtered = users.filter(u => (u.winnings || 0) > 0 && !u.ba?.ban_top);
    const sorted = filtered.sort((a, b) => (b.winnings || 0) - (a.winnings || 0));

    if (sorted.length === 0) {
      await botSend(context, "Нет данных по выигрышам.");
      return;
    }

    const top10 = sorted.slice(0, 10);
    let text = "";

    for (let i = 0; i < top10.length; i++) {
      const label = top10[i].tag || "Игрок";
      text += `${placeEmojis[i]} ${label} - ${formatWithSpaces(top10[i].winnings || 0)} FP\n`;
    }

    const meId = context.user?.id ?? context.senderId;
    const myIndex = sorted.findIndex(u => u.id === meId);

    if (myIndex >= 10 && myIndex !== -1) {
      const user = sorted[myIndex];
      const label = user.tag || "Игрок";
      text += `—————————————————\n${myIndex + 1} ${label} - ${formatWithSpaces(user.winnings || 0)} FP\n`;
    }

    await botSend(context, `💰 Топ по выигрышам за день:\n\n${text}`);
  }
};
