import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { JsonDatabase } from "../../services/JsonDatabase";
import { DoubleUser } from "../../types/database";
import { formatWithSpaces } from "../../utils/number";

type DonateProduct = {
    key?: string;
    label: string;
    priceRub: number; // Новая цена (со скидкой)
    oldPriceRub?: number; // Старая цена
    fp?: number;
    info?: string;
    apply: (user: NonNullable<VkMessageContext["user"]>) => void;
};

const monthMs = 30 * 24 * 60 * 60 * 1000;

const formatRub = (value: number): string =>
    new Intl.NumberFormat("ru-RU", { style: "currency", currency: "RUB" }).format(value);

const emojiNumber = (n: number) => {
    const map: Record<string, string> = {
        "0": "0️⃣", "1": "1️⃣", "2": "2️⃣", "3": "3️⃣", "4": "4⃣",
        "5": "5⃣", "6": "6️⃣", "7": "7️⃣", "8": "8️⃣", "9": "9️⃣"
    };
    return String(n).split("").map(d => map[d]).join("");
};

const kb = (label: string) => ({
    inline: true,
    buttons: [[{ action: { type: "text", label, payload: "{}" } }]]
});

// Функция для расчета старой цены на основе новой и процента скидки
const calculateOldPrice = (newPrice: number, discountPercent: number = 75): number => {
    return Math.round(newPrice / ((100 - discountPercent) / 100));
};

const products: Record<number, DonateProduct> = {
    1: { key: "vip", label: "VIP", priceRub: 20, oldPriceRub: 80, info: "Статус VIP на 30 дней", apply: u => { u.permiss.vip = true; u.vip_expires = Date.now() + monthMs; } },
    2: { key: "premium", label: "PREMIUM", priceRub: 30, oldPriceRub: 120, info: "Статус PREMIUM на 30 дней", apply: u => { u.permiss.premium = true; u.premium_expires = Date.now() + monthMs; } },
    3: { key: "legend", label: "LEGEND", priceRub: 40, oldPriceRub: 160, info: "Статус LEGEND на 30 дней", apply: u => { u.permiss.legend = true; u.legend_expires = Date.now() + monthMs; } },
    4: { key: "admin", label: "ADMINISTRATOR", priceRub: 45, oldPriceRub: 180, info: "Статус ADMIN на 30 дней", apply: u => { u.permiss.admin = true; u.admin_expires = Date.now() + monthMs; } },
    5: { key: "donate", label: "DONATE", priceRub: 62, oldPriceRub: 250, info: "Статус DONATE на 30 дней", apply: u => { u.permiss.donate = true; u.donate_expires = Date.now() + monthMs; } },
    6: { key: "flash", label: "Всемогущий", priceRub: 150, oldPriceRub: 600, info: "Статус Всемогущий на 30 дней", apply: u => { u.permiss.flash = true; u.flash_expires = Date.now() + monthMs; } },
    7: { key: "sponsor", label: "Спонсор", priceRub: 375, oldPriceRub: 1500, info: "Статус Спонсор на 30 дней", apply: u => { u.permiss.sponsor = true; u.sponsor_expires = Date.now() + monthMs; } }
};

const currencyProducts: Record<number, DonateProduct> = {    8: { label: "2.000.000.000 FP", priceRub: 22, oldPriceRub: 90, fp: 2_000_000_000, info: "2.000.000.000 FP", apply: u => { u.balance += 2_000_000_000; } },
    9: { label: "6.000.000.000 FP", priceRub: 45, oldPriceRub: 180, fp: 6_000_000_000, info: "6.000.000.000 FP", apply: u => { u.balance += 6_000_000_000; } },
    10: { label: "15.000.000.000 FP", priceRub: 80, oldPriceRub: 320, fp: 15_000_000_000, info: "15.000.000.000 FP", apply: u => { u.balance += 15_000_000_000; } }
};

const extraProducts: Record<number, DonateProduct> = {
    11: { label: "Легендарный кейс", priceRub: 12, oldPriceRub: 50, info: "1 Легендарный кейс", apply: u => { u.case2 = u.case2 ?? 0; u.case2 += 1; } },
    12: { label: "Все или ничего", priceRub: 12, oldPriceRub: 50, info: "1 кейс Все или ничего", apply: u => { u.case4 = u.case4 ?? 0; u.case4 += 1; } },
    13: { label: "Кейс богача", priceRub: 12, oldPriceRub: 50, info: "1 кейс Богача", apply: u => { u.case5 = u.case5 ?? 0; u.case5 += 1; } },
    14: { label: "Ultra кейс", priceRub: 12, oldPriceRub: 50, info: "1 Ultra кейс", apply: u => { u.case6 = u.case6 ?? 0; u.case6 += 1; } },
    15: { label: "100 рефералов", priceRub: 12, oldPriceRub: 50, info: "+100 рефералов", apply: u => { u.refCount += 100; u.ref_bonus += 10_000; } },
    16: { label: "Иммунитет", priceRub: 25, oldPriceRub: 100, info: "Иммунитет от бана/кика", apply: u => { u.ba = u.ba ?? {}; u.ba.anti_ban = true; } },
    17: { label: "10 кейсов Богача", priceRub: 37, oldPriceRub: 150, info: "10 кейсов Богача", apply: u => { u.case5 = u.case5 ?? 0; u.case5 += 10; } },
    18: { label: "+100.000.000 лимита", priceRub: 37, oldPriceRub: 150, info: "+100.000.000 лимита", apply: u => { u.ba = u.ba ?? {}; u.ba.limits_give = u.ba.limits_give ?? 0; u.limit += 100_000_000; u.ba.limits_give += 100_000_000; } },
    19: { label: "Доступ «выдать»", priceRub: 30, oldPriceRub: 120, info: "Доступ +150.000 FP", apply: u => { u.ba = u.ba ?? {}; u.ba.limits_give = u.ba.limits_give ?? 0; u.limit += 150_000; u.ba.limits_give += 150_000; u.dostupe = true; } },
    20: { label: "Сброс времени «выдать»", priceRub: 5, oldPriceRub: 20, info: "Сброс таймера выдачи", apply: u => { u.ba = u.ba ?? {}; u.ba.reset_give = true; } },
    21: {
        label: "Эконом набор",
        priceRub: 20,
        oldPriceRub: 80,
        info: "🎁 Эконом набор:\n• 1️⃣ Легендарный кейс\n• 5.000.000 FP\n• +10 рефералов",
        apply: u => {
            u.case2 = u.case2 ?? 0; u.case2 += 1;
            u.balance += 5_000_000;
            u.refCount += 10; u.ref_bonus += 1000;
        }
    },
    22: {
        label: "Специальный набор",
        priceRub: 35,
        oldPriceRub: 140,
        info: "🎁 Специальный набор:\n• 1️⃣ Легендарный кейс\n• 1️⃣ Все или ничего\n• 10.000.000 FP\n• +25 рефералов",
        apply: u => {
            u.case2 = u.case2 ?? 0; u.case4 = u.case4 ?? 0;
            u.case2 += 1; u.case4 += 1;
            u.balance += 10_000_000;
            u.refCount += 25; u.ref_bonus += 2500;
        }
    },
    23: {
        label: "Легендарный набор",
        priceRub: 60,
        oldPriceRub: 240,
        info: "🎁 Легендарный набор:\n• 1️⃣ Легендарный кейс\n• 1️⃣ Ultra кейс\n• 20.000.000 FP\n• +50 рефералов\n• +500.000 лимита",
        apply: u => {
            u.ba = u.ba ?? {}; u.ba.limits_give = u.ba.limits_give ?? 0;
            u.case2 = u.case2 ?? 0; u.case6 = u.case6 ?? 0;
            u.case2 += 1; u.case6 += 1;
            u.balance += 20_000_000;
            u.refCount += 50; u.ref_bonus += 5000;            u.limit += 500_000; u.ba.limits_give += 500_000;
        }
    },
    24: {
        label: "Хакерский набор",
        priceRub: 135,
        oldPriceRub: 540,
        info: "🎁 Хакерский набор:\n• 1️⃣ Легендарный кейс\n• 1️⃣ Все или ничего\n• 1️⃣ Кейс богача\n• 1️⃣ Ultra кейс\n• 50.000.000 FP\n• +100 рефералов\n• +1.000.000 лимита",
        apply: u => {
            u.ba = u.ba ?? {}; u.ba.limits_give = u.ba.limits_give ?? 0;
            u.case2 = u.case2 ?? 0; u.case4 = u.case4 ?? 0;
            u.case5 = u.case5 ?? 0; u.case6 = u.case6 ?? 0;
            u.case2 += 1; u.case4 += 1; u.case5 += 1; u.case6 += 1;
            u.balance += 50_000_000;
            u.refCount += 100; u.ref_bonus += 10_000;
            u.limit += 1_000_000; u.ba.limits_give += 1_000_000;
        }
    }
};

export const donateCommand: CommandDefinition<VkMessageContext> = {
    name: "common.donate",
    pattern: /^(?:донат|донаты)(?:\s+([^]+))?$/i,
    handler: async context => {
        const { user } = context;
        if (!user) return;
        const arg = (context.match?.[1] ?? "").trim().toLowerCase();

        if (!arg) {
            await botSend(
                context,
                ` РАСПРОДАЖА! СКИДКИ 75% 🔥\n\n` +
                `список донатов:\n` +
                `✨ Привилегии\n` +
                ` Валюта\n` +
                ` Кейсы\n` +
                ` Остальное\n` +
                `🗃 Наборы\n\n` +
                `💰 У вас ${formatRub(user.donate_rub ?? 0)}.\n` +
                `ℹ️ Донат привилегии / Донат валюта / Донат кейсы / Донат остальное / Донат наборы\n` +
                `ℹ️ Донат инфо [номер]\n` +
                `ℹ️ Донат [номер]`,
                kb("Донат привилегии")
            );
            return;
        }

        if (arg.startsWith("инфо")) {
            const id = Number(arg.split(" ")[1]);
            const item = products[id] || currencyProducts[id] || extraProducts[id];            if (!item) {
                await botSend(context, "Такого товара нет.");
                return;
            }
            
            let priceDisplay = `${formatRub(item.priceRub)}`;
            if (item.oldPriceRub) {
                priceDisplay = `${formatRub(item.oldPriceRub)} -> ${formatRub(item.priceRub)}`;
            }

            await botSend(
                context,
                `ℹ️ Донат инфо:\n` +
                `${emojiNumber(id)} ${item.label}\n` +
                `Цена: ${priceDisplay}\n` +
                `${item.info ?? "Описание отсутствует"}`, 
                kb(`Донат ${id}`)
            );
            return;
        }

        // Helper to format list with strikethrough prices
        const formatList = (items: Record<number, DonateProduct>) => {
            return Object.entries(items)
                .map(([n, p]) => {
                    let priceStr = `${formatRub(p.priceRub)}`;
                    if (p.oldPriceRub) {
                        priceStr = `${formatRub(p.oldPriceRub)}->${formatRub(p.priceRub)}`;
                    }
                    return `${emojiNumber(Number(n))} ${p.label} - ${priceStr}`;
                })
                .join("\n");
        };

        if (arg === "привилегии") {
            await botSend(context, `✨ Привилегии (-75%):\n\n${formatList(products)}`, kb("Донат валюта"));
            return;
        }

        if (arg === "валюта") {
            await botSend(context, ` Валюта (-75%):\n\n${formatList(currencyProducts)}`, kb("Донат кейсы"));
            return;
        }

        if (arg === "кейсы") {
            const list = Object.entries(extraProducts)
                .filter(([n]) => Number(n) >= 11 && Number(n) <= 14)
                .map(([n, p]) => {
                    let priceStr = `${formatRub(p.priceRub)}`;
                    if (p.oldPriceRub) priceStr = `${formatRub(p.oldPriceRub)}->${formatRub(p.priceRub)}`;                    return `${emojiNumber(Number(n))} ${p.label} - ${priceStr}`;
                })
                .join("\n");
            await botSend(context, ` Кейсы (-75%):\n\n${list}`, kb("Донат остальное"));
            return;
        }

        if (arg === "остальное") {
            const list = Object.entries(extraProducts)
                .filter(([n]) => Number(n) >= 15 && Number(n) <= 20)
                .map(([n, p]) => {
                    let priceStr = `${formatRub(p.priceRub)}`;
                    if (p.oldPriceRub) priceStr = `${formatRub(p.oldPriceRub)}-> ${formatRub(p.priceRub)}`;
                    return `${emojiNumber(Number(n))} ${p.label} - ${priceStr}`;
                })
                .join("\n");
            await botSend(context, `🧊 Остальное (-75%):\n\n${list}`, kb("Донат наборы"));
            return;
        }

        if (arg === "наборы") {
            const list = Object.entries(extraProducts)
                .filter(([n]) => Number(n) >= 21 && Number(n) <= 24)
                .map(([n, p]) => {
                    let priceStr = `${formatRub(p.priceRub)}`;
                    if (p.oldPriceRub) priceStr = `${formatRub(p.oldPriceRub)}-> ${formatRub(p.priceRub)}`;
                    return `${emojiNumber(Number(n))} ${p.label} - ${priceStr}`;
                })
                .join("\n");
            await botSend(context, `🗃 Наборы (-75%):\n\n${list}`, kb("Донат"));
            return;
        }

        const n = Number(arg);
        if (!Number.isFinite(n)) {
            await botSend(context, "Не понял запрос.");
            return;
        }

        const item = products[n] || currencyProducts[n] || extraProducts[n];
        if (!item) {
            await botSend(context, "Такого номера нет.");
            return;
        }

        const balanceRub = user.donate_rub ?? 0;
        if (balanceRub < item.priceRub) {
            await botSend(context, `Недостаточно RUB. Нужно ${formatRub(item.priceRub)}.`, kb(`Пополнить ${item.priceRub}`));
            return;
        }
        user.donate_rub = balanceRub - item.priceRub;
        item.apply(user);

        if (item.info?.startsWith("🎁")) {
            await botSend(
                context,
                `Покупка успешна: ${item.label}\n\n${item.info}`,
                kb("Донат")
            );
            return;
        }

        await botSend(
            context,
            `Покупка успешна:\n` +
            `${emojiNumber(n)} ${item.label}\n` +
            `Цена: ${formatRub(item.priceRub)}\n` +
            `Остаток: ${formatRub(user.donate_rub ?? 0)}`,
            kb("Донат")
        );
    }
};

const STAR_TO_RUB_RATE = 5;
const MIN_STARS = 10;
const MAX_STARS = 10000;
const pendingPayments = new Map<string, {
    userId: number;
    tgId: number;
    stars: number;
    rubAmount: number;
    createdAt: number;
}>();

export const topUpCommand: CommandDefinition<VkMessageContext> = {
    name: "common.topUp",
    pattern: /^(?:пополнить)(?:\s+(\d+(?:[.,]\d+)?))?$/i,
    guard: context => Boolean(context.user && !context.isChat),
    handler: async context => {
        const { user, platform, peerId, tg } = context;
        if (!user) return;
        const arg = context.match?.[1] ?? "";
        const amount = parseFloat(arg.replace(",", "."));

        if (!arg || isNaN(amount)) {
            if (platform === "tg") {
                await botSend(
                    context,
                    `💎 ПОПОЛНЕНИЕ БАЛАНСА 💎\n\n` +                    `💰 Ваш баланс: ${(user.donate_rub ?? 0).toFixed(2)} RUB\n\n` +
                    `⭐️ 1 Star = ${STAR_TO_RUB_RATE} RUB\n\n` +
                    `Введите сумму в Stars: /пополнить [число]\n` +
                    `Минимум: ${MIN_STARS} Stars (${MIN_STARS * STAR_TO_RUB_RATE} RUB)\n` +
                    `Максимум: ${MAX_STARS} Stars (${MAX_STARS * STAR_TO_RUB_RATE} RUB)`,
                    {
                        keyboard: JSON.stringify({
                            inline: true,
                            buttons: [
                                [
                                    { action: { type: "text", label: "⭐️ 50 Stars", payload: JSON.stringify({ amount: 50 }) } },
                                    { action: { type: "text", label: "⭐️ 100 Stars", payload: JSON.stringify({ amount: 100 }) } }
                                ],
                                [
                                    { action: { type: "text", label: "⭐️ 500 Stars", payload: JSON.stringify({ amount: 500 }) } },
                                    { action: { type: "text", label: "⭐️ 1000 Stars", payload: JSON.stringify({ amount: 1000 }) } }
                                ]
                            ]
                        })
                    }
                );
            } else {
                await botSend(context, "❌ Пополнение доступно только в Telegram");
            }
            return;
        }

        const stars = Math.floor(amount);
        if (stars < MIN_STARS) {
            await botSend(context, `❌ Минимум: ${MIN_STARS} Stars (${MIN_STARS * STAR_TO_RUB_RATE} RUB)`);
            return;
        }

        if (stars > MAX_STARS) {
            await botSend(context, `❌ Максимум: ${MAX_STARS} Stars (${MAX_STARS * STAR_TO_RUB_RATE} RUB)`);
            return;
        }

        const rubAmount = stars * STAR_TO_RUB_RATE;
        const paymentId = `${user.id}_${Date.now()}`;

        pendingPayments.set(paymentId, {
            userId: user.id,
            tgId: user.tgId || peerId,
            stars: stars,
            rubAmount: rubAmount,
            createdAt: Date.now()
        });

        setTimeout(() => {            pendingPayments.delete(paymentId);
        }, 30 * 60 * 1000);

        if (platform === "tg" && tg) {
            try {
                const invoiceUrl = `https://t.me/${process.env.BOT_USERNAME || "realflashgame_bot"}?start=pay_${paymentId}_${stars}`;
                
                await botSend(
                    context,
                    `💳 ОПЛАТА ЧЕРЕЗ TELEGRAM STARS\n\n` +
                    `⭐️ Сумма: ${stars} Stars\n` +
                    `💰 Получите: ${rubAmount} RUB\n` +
                    `🆔 ID платежа: ${paymentId}\n\n` +
                    `Для оплаты перейдите по ссылке и подтвердите платеж:\n${invoiceUrl}\n\n` +
                    `После оплаты баланс пополнится автоматически.`,
                    {
                        keyboard: JSON.stringify({
                            inline: true,
                            buttons: [[
                                {
                                    action: {
                                        type: "open_link",
                                        link: invoiceUrl,
                                        label: "💎 Оплатить Stars"
                                    }
                                }
                            ]]
                        })
                    }
                );
            } catch (error) {
                console.error("Failed to create payment:", error);
                await botSend(context, `❌ Ошибка: ${error}`);
                pendingPayments.delete(paymentId);
            }
        }
    }
};

let lastCheckedPaymentId = "";
let checkInterval: NodeJS.Timeout | null = null;

export function startPaymentChecker(bot: any, usersDb: JsonDatabase<DoubleUser[]>) {
    if (checkInterval) return;
    checkInterval = setInterval(async () => {
        try {
            const updates = await bot.getUpdates();
            for (const update of updates) {
                if (update.message?.successful_payment) {
                    const payment = update.message.successful_payment;                    const payload = JSON.parse(payment.invoice_payload);
                    
                    if (payment.telegram_payment_charge_id === lastCheckedPaymentId) continue;
                    
                    const pending = pendingPayments.get(payload.paymentId);
                    if (!pending) continue;
                    
                    if (pending.userId !== payload.userId) continue;
                    
                    const users = usersDb.load();
                    const user = users.find((u: any) => u.id === payload.userId);
                    
                    if (user) {
                        user.donate_rub = (user.donate_rub ?? 0) + payload.rubAmount;
                        usersDb.save(users);
                        
                        lastCheckedPaymentId = payment.telegram_payment_charge_id;
                        pendingPayments.delete(payload.paymentId);
                        
                        try {
                            await bot.sendMessage(
                                update.message.chat.id,
                                `✅ Пополнение успешно!\n⭐️ ${payload.stars} Stars → +${payload.rubAmount} RUB\n Новый баланс: ${user.donate_rub} RUB`
                            );
                        } catch (e) {}
                    }
                }
            }
        } catch (error) {
            console.error("Payment checker error:", error);
        }
    }, 10000);
}