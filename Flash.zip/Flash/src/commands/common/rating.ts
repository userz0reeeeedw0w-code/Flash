import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { formatWithSpaces } from "../../utils/number";
import { DoubleUser } from "../../types/database";

const placeEmojis = ["1⃣  ", "2⃣  ", "3⃣  ", "4⃣  ", "5⃣  ", "6⃣  ", "7⃣  ", "8⃣  ", "9⃣  ", "🔟  "];
const SEPARATOR = "—————————————————  ";

function makeLabel(context: VkMessageContext, u: DoubleUser): string {
    if (!u) return "Удаленный пользователь";

    const tag = String(u.tag ?? "Игрок");
    const vkId = u.id;
    const tgId = (u as any).tgId;
    const isVkBlocked = (u as any).isVkBlocked || false;

    const isTg = context.platform === "tg";

    if (isTg) {
        if (tgId) {
            return `<a href="tg://user?id=${tgId}">${tag}</a>`;
        }
        if (vkId && !isVkBlocked) {
            return `<a href="https://vk.com/id${vkId}">${tag}</a>`;
        }
        return tag;
    }

    if (vkId && !isVkBlocked) {
        return `[id${vkId}|${tag}]`;
    }
    
    return tag;
}

interface TopOptions {
    minRequired?: number;
    getValue: (user: DoubleUser) => number;
    formatValue: (value: number) => string;
    emptyMessage: string;
}

async function buildAndSendTop(
    context: VkMessageContext,
    title: string,
    options: TopOptions,
    keyboard?: any
) {
    const users = context.state.users;
    const { minRequired = 10, getValue, formatValue, emptyMessage } = options;

    if (!users?.length) {
        await botSend(context, emptyMessage);
        return;
    }

    const filtered = users.filter(u => !(u.ba?.ban_top));
    const sorted = filtered.sort((a, b) => getValue(b) - getValue(a));
    const topValid = sorted.filter(u => getValue(u) > 0);

    if (topValid.length === 0) {
        await botSend(context, emptyMessage);
        return;
    }

    const top10 = topValid.slice(0, 10);
    const isTg = context.platform === "tg";

    let text = "";
    for (let i = 0; i < top10.length; i++) {
        const label = makeLabel(context, top10[i]);
        text += `${placeEmojis[i]} ${label} -- ${formatValue(getValue(top10[i]))}\n`;
    }

    const meId = (context as any).user?.id ?? (context as any).senderId;
    const myIndex = sorted.findIndex(u => u.id === meId);

    let myPosition = "";
    if (myIndex >= 10 && myIndex !== -1 && getValue(sorted[myIndex]) > 0) {
        const label = makeLabel(context, sorted[myIndex]);
        myPosition = `${SEPARATOR}\n${myIndex + 1} ${label} — ${formatValue(getValue(sorted[myIndex]))}\n\n`;
    }

    const sendOptions: any = keyboard ? { keyboard: JSON.stringify(keyboard) } : {};

    if (isTg) {
        sendOptions.parse_mode = "HTML";
    }

    await botSend(context, `${title}\n\n${text}${myPosition}`, sendOptions);
}

export const ratingCommand: CommandDefinition<VkMessageContext> = {
    name: "common.rating",
    pattern: /^(?:рейтинг)$/i,
    handler: async context => {
        const keyboard = {
            inline: true,
            buttons: [
                [
                    {
                        action: {
                            type: "text",
                            payload: JSON.stringify({ command: "Топ реф" }),
                            label: "Топ реф"
                        }
                    },
                    {
                        action: {
                            type: "text",
                            payload: JSON.stringify({ command: "Топ выигрыш" }),
                            label: "Топ выигрыш"
                        }
                    }
                ]
            ]
        };
        await buildAndSendTop(context, "Список Forbes на данный момент:", {
            getValue: (u: any) => u.balance ?? 0,
            formatValue: (v: number) => `${formatWithSpaces(v)} FP`,
            emptyMessage: "пока низя, меньше 10 игроков."
        }, keyboard);
    }
};

export const topRefCommand: CommandDefinition<VkMessageContext> = {
    name: "common.topref",
    pattern: /^(?:топ\s*реф|топреф)$/i,
    handler: async context => {
        const keyboard = {
            inline: true,
            buttons: [
                [
                    {
                        action: {
                            type: "text",
                            payload: JSON.stringify({ command: "рейтинг" }),
                            label: "Топ баланс"
                        }
                    },
                    {
                        action: {
                            type: "text",
                            payload: JSON.stringify({ command: "Топ выигрыш" }),
                            label: "Топ выигрыш"
                        }
                    }
                ]
            ]
        };
        await buildAndSendTop(context, "Топ по рефералам:", {
            getValue: (u: any) => (u as any).refCount ?? 0,
            formatValue: (v: number) => `${v} реф.`,
            emptyMessage: "нет данных по рефералам."
        }, keyboard);
    }
};

export const topWinCommand: CommandDefinition<VkMessageContext> = {
    name: "common.topwin",
    pattern: /^(?:топ\s*выигрыш|топвыигрыш)$/i,
    handler: async context => {
        const keyboard = {
            inline: true,
            buttons: [
                [
                    {
                        action: {
                            type: "text",
                            payload: JSON.stringify({ command: "рейтинг" }),
                            label: "Топ баланс"
                        }
                    },
                    {
                        action: {
                            type: "text",
                            payload: JSON.stringify({ command: "Топ реф" }),
                            label: "Топ реф"
                        }
                    }
                ]
            ]
        };
        await buildAndSendTop(context, "Топ по выигрышам:", {
            getValue: (u: any) => (u as any).winnings ?? 0,
            formatValue: (v: number) => `${formatWithSpaces(v)} FP`,
            emptyMessage: "нет данных по выигрышам."
        }, keyboard);
    }
};