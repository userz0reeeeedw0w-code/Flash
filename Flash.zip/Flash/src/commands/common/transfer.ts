import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend, formatUserLabel } from "../../core/mode/GameMode";
import { formatWithSpaces, resolveTargetId } from "../../utils/number";

const parseAmount = (raw: string, balance: number): number => {
  let value = raw.replace(/[.,]/gi, "");
  value = value.replace(/(к|k)/gi, "000");
  value = value.replace(/(м|m)/gi, "000000");
  value = value.replace(/(вс[её]|all)/gi, String(balance));
  value = value.replace(/(в[ао]банк)/gi, "999999999999");
  return Math.floor(Number(value));
};

const transferPattern = /^(?:передать|дать|перевести|пиревести|пиредать|перидать)(?:\s(?<target>@[\w.]+|id\d+|\[id\d+\|@?[\w.]+\]|https?:\/\/vk\.(?:ru|com)\/[a-zA-Z0-9_.-]+|\d+))?\s(?<amount>[0-9.]+[kкmм]*|вс[её]|all|в[ао]банк)$/i;

export const transferCommand: CommandDefinition<VkMessageContext> = {
  name: "common.transfer",
  pattern: transferPattern,
  handler: async context => {
    const { user, state, vk } = context;
    if (!user || !state || !state.users) {
      return;
    }
    if (user.banper) {
      await botSend(context, "У вас бан переводов");
      return;
    }

    const match = context.text.match(transferPattern);
    const targetArg = match?.groups?.target || "";
    const amountStr = match?.groups?.amount || "";

    if (!amountStr) {
      await botSend(context, "укажите сумму, которую хотите отправить.");
      return;
    }

    const amount = parseAmount(amountStr, user.balance);
    if (!Number.isFinite(amount) || amount <= 0) {
      await botSend(context, "укажите сумму, которую хотите отправить.");
      return;
    }

    if (amount > user.balance) {
      await botSend(context, "у Вас нет столько FP коинов.");
      return;
    }

    const platform = context.platform ?? "vk";
    const targetId = await resolveTargetId({      targetArg,
      allUsers: state.users,
      platform,
      vkApi: vk?.api,
      tgContext: (context as any).tgContext,
      message: context.message,
      tgUserId: (context as any).tgUserId
    });

    if (!targetId) {
      await botSend(context, "укажите получателя: ответьте на сообщение, укажите UID, @username или ссылку VK.");
      return;
    }

    const allUsers = state.users;
    const targetUser = allUsers.find(entry =>
      entry.id === targetId || entry.uid === targetId || (entry as any).tgId === targetId
    );

    if (!targetUser) {
      await botSend(context, "этот игрок не играет в бота.");
      return;
    }

    if (
      targetUser.id === user.id ||
      targetUser.uid === user.uid ||
      (targetUser as any).tgId === (user as any).tgId
    ) {
      await botSend(context, "нельзя перевести самому себе.");
      return;
    }

    const transferAmount = Math.min(amount, user.balance);

    let feePercentage = 25;

    if (user.permiss?.sponsor) {
      feePercentage = 3;
    } else if (user.permiss?.flash) {
      feePercentage = 5;
    } else if (user.permiss?.donate) {
      feePercentage = 10;
    } else if (user.permiss?.admin) {
      feePercentage = 15;
    } else if (user.permiss?.legend) {
      feePercentage = 18;
    } else if (user.permiss?.premium) {
      feePercentage = 20;
    } else if (user.permiss?.vip) {      feePercentage = 23;
    }

    const fee = Math.floor(transferAmount * (feePercentage / 100));
    const transferTotal = transferAmount - fee;

    if (transferTotal <= 0) {
      await botSend(context, "у вас недостаточно FP коинов для осуществления перевода");
      return;
    }

    user.balance -= transferAmount;
    targetUser.balance += transferTotal;

    if (platform === "vk" && vk) {
      await vk.api.messages.send({
        chat_id: 5,
        message: `[ЛОГ ДЕЙСТВИЙ]\nПользователь *id${user.id} (${user.tag}) совершил перевод ${formatWithSpaces(transferTotal)} FP для пользователя *id${targetUser.id} (${targetUser.tag})`,
        random_id: 0
      });

      await vk.api.messages.send({
        user_id: targetUser.id,
        message: `Игрок ${formatUserLabel(user, false)} перевел вам ${formatWithSpaces(transferTotal)} FP 💳`,
        random_id: 0
      });
    } else if (platform === "tg") {
      const tg = (context as any).tg;
      const tgId = typeof (targetUser as any).tgId === "number" ? (targetUser as any).tgId : null;
      if (tg && tgId) {
        const senderLabel = typeof (user as any).tgUsername === "string" && (user as any).tgUsername ? `@${(user as any).tgUsername}` : user.tag;
        await tg.sendMessage(tgId, `Игрок ${senderLabel} перевел вам ${formatWithSpaces(transferTotal)} FP 💳`).catch(() => undefined);
      }
    }

    const targetLabel =
      platform === "tg"
        ? (typeof (targetUser as any).tgUsername === "string" && (targetUser as any).tgUsername ? `@${(targetUser as any).tgUsername}` : targetUser.tag)
        : formatUserLabel(targetUser, Boolean((context as any).isChat && !targetUser.disable_mentions));
    await botSend(
      context,
      `вы перевели ${targetLabel} ${formatWithSpaces(transferTotal)} FP 💳\n` +
        `Сумма комиссии ${feePercentage}%\n` +
        `⚙️Ваша комиссия составила ${formatWithSpaces(fee)} FP`
    );
  }
};