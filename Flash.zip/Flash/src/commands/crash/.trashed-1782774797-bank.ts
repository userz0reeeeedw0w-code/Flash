import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend, formatUserLabel } from "../../core/mode/GameMode";
import { formatWithSpaces } from "../../utils/number";

export const crashBankCommand: CommandDefinition<VkMessageContext> = {
  name: "crash.bank",
  pattern: /^(?:банк)$/i,
  guard: context => Boolean(context.chat && context.chat.type === 2),
  handler: async context => {
    const { chat } = context;
    if (!chat) return;

    const currentGame = chat.games[chat.games.length - 1];
    if (!currentGame || currentGame.stavki.length === 0) {
      return botSend(context, "в этом раунде ещё никто не поставил.");
    }

    const users = context.state.users ?? [];
    const stakes = currentGame.stavki as any[];
    const totalAmount = stakes.reduce((sum, s) => sum + Number(s.amount || 0), 0);
    const cashedOut = stakes.filter(s => Boolean(s.mnoj)).length;
    const active = stakes.length - cashedOut;
    const phase = chat.gametime > 0 ? `⏳ До старта: ${chat.gametime} сек.` : `📈 Множитель: x${Number((currentGame as any).result || 0).toFixed(2)}`;

    const lines = [...stakes]
      .sort((a, b) => Number(b.amount || 0) - Number(a.amount || 0))
      .map((stake, i) => {
        const user = users.find(u => u.id === stake.id);
        const label = user ? formatUserLabel(user, Boolean(context.isChat && !user.disable_mentions)) : `[id${stake.id}|User]`;
        const amountText = `${formatWithSpaces(Number(stake.amount || 0))} FP`;
        const target = typeof stake.target === "number" ? stake.target : null;
        const cashoutMult = typeof stake.mnoj === "number" ? stake.mnoj : null;
        const cashoutAmount =
          typeof stake.cashout === "number"
            ? stake.cashout
            : cashoutMult
              ? Math.floor(Number(stake.amount || 0) * cashoutMult)
              : null;

        if (cashoutMult) {
          return `${i + 1}) ✅ ${label} — ставка ${amountText} • забрал x${cashoutMult.toFixed(2)} (+${formatWithSpaces(
            Number(cashoutAmount || 0)
          )} FP)`;
        }

        if (target) {
          return `${i + 1}) 🎯 ${label} — ставка ${amountText} • авто x${target.toFixed(2)}`;
        }

        return `${i + 1}) ⏳ ${label} — ставка ${amountText}`;
      });

    return botSend(
      context,
      `💰 Банк раунда: ${formatWithSpaces(totalAmount)} FP\n` +
        `👥 Ставок: ${stakes.length} • в игре: ${active} • забрали: ${cashedOut}\n` +
        `${phase}\n\n` +
        `📋 Ставки:\n${lines.join("\n")}`
    );
  }
};
