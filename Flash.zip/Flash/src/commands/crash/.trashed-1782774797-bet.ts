import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { formatWithSpaces } from "../../utils/number";
import { CrashGame } from "../../types/database";
import { buildKeyboard } from "../../utils/keyboard";

const parseAmount = (raw: string): number | null => {
  let value = String(raw ?? "").trim();
  if (!value) return null;
  value = value.replace(/[.,]/g, "").replace(/[кk]/gi, "000").replace(/[мm]/gi, "000000").replace(/\s+/g, "");
  const amount = Number.parseInt(value, 10);
  return Number.isFinite(amount) && amount > 0 ? amount : null;
};

const parseMultiplier = (raw: string): number | null => {
  const normalized = String(raw ?? "")
    .trim()
    .replace(/^[xх]\s*/i, "")
    .replace(",", ".");
  if (!normalized) return null;
  const value = Number.parseFloat(normalized);
  if (!Number.isFinite(value)) return null;
  const rounded = Math.round(value * 100) / 100;
  if (rounded < 1.01 || rounded > 100) return null;
  return rounded;
};

const parseStakeInput = (raw: string): { amount: number; target?: number } | null => {
  const text = String(raw ?? "").trim();
  if (!text) return null;

  const match = text.match(/^(.+?)(?:\s+(?:x|х)?\s*([0-9]+(?:[.,][0-9]+)?))?$/i);
  if (!match) return null;

  const amount = parseAmount(match[1] ?? "");
  if (!amount) return null;

  const multRaw = match[2];
  if (!multRaw) return { amount };
  const target = parseMultiplier(multRaw);
  if (!target) return null;
  return { amount, target };
};

export const crashBetCommand: CommandDefinition<VkMessageContext> = {
  name: "crash.bet",
  pattern: /^(?:ставка)(?:\s+(.+))?$/i,
  guard: context => Boolean(context.chat && context.chat.type === 2 && context.user),
  handler: async context => {
    const { chat, user } = context;
    if (!chat || !user) return;

    if (!Array.isArray(chat.games) || chat.games.length === 0) {
      chat.games = [
        {
          id: 0,
          result: 1.0,
          stavka: true,
          end: false,
          stavki: []
        } as CrashGame
      ];
      chat.game = true;
      chat.gametime = 30;
      chat.firstbet = false;
    }

    if (!context.match![1]) {
      const keyboard = buildKeyboard({
        inline: true,
        buttons: [
          [
            { label: `ставка ${formatWithSpaces(user.lastbet || 0)}`, color: "default", command: `ставка ${formatWithSpaces(user.lastbet || 0)}` },
            { label: `ставка ${formatWithSpaces((user.lastbet || 0) * 2)}`, color: "default", command: `ставка ${formatWithSpaces((user.lastbet || 0) * 2)}` },
            { label: `ставка ${formatWithSpaces(user.balance)}`, color: "default", command: `ставка ${formatWithSpaces(user.balance)}` }
          ],
          [
            { label: `авто x2`, color: "primary", command: `ставка ${formatWithSpaces(user.lastbet || 0)} 2` },
            { label: `авто x3`, color: "primary", command: `ставка ${formatWithSpaces(user.lastbet || 0)} 3` }
          ]
        ]
      });

      return botSend(
        context,
        `введи команду:\n` +
          `«ставка [сумма]» — обычная ставка\n` +
          `«ставка [сумма] [множитель]» — авто-вывод по множителю\n\n` +
          `примеры: «ставка 1000 2.5», «ставка 1000 x2.5»`,
        {
          keyboard
        }
      );
    }

    if (chat.gametime <= 0) return botSend(context, "игра уже началась!");

    const parsed = parseStakeInput(context.match![1]);
    if (!parsed) {
      const keyboard = buildKeyboard({
        inline: true,
        buttons: [
          [
            { label: `ставка ${formatWithSpaces(user.lastbet || 0)}`, color: "default", command: `ставка ${formatWithSpaces(user.lastbet || 0)}` },
            { label: `ставка ${formatWithSpaces((user.lastbet || 0) * 2)}`, color: "default", command: `ставка ${formatWithSpaces((user.lastbet || 0) * 2)}` },
            { label: `ставка ${formatWithSpaces(user.balance)}`, color: "default", command: `ставка ${formatWithSpaces(user.balance)}` }
          ],
          [
            { label: `авто x2`, color: "primary", command: `ставка ${formatWithSpaces(user.lastbet || 0)} 2` },
            { label: `авто x3`, color: "primary", command: `ставка ${formatWithSpaces(user.lastbet || 0)} 3` }
          ]
        ]
      });

      return botSend(
        context,
        `неверный формат.\n` +
          `используй:\n` +
          `«ставка [сумма]» или «ставка [сумма] [множитель]»\n` +
          `примеры: «ставка 1000 2.5», «ставка 1000 x2.5»`,
        {
          keyboard
        }
      );
    }
    const amount = parsed.amount;
    const target = parsed.target;

    if (amount > user.balance) {
      return botSend(context, `на твоем балансе нет столько коинов...`);
    }

    user.balance -= amount;
    user.lastbet = amount;

    const currentGame = chat.games[chat.games.length - 1] as CrashGame;

    const existingStake = currentGame.stavki.find(s => 
      s.id === user.id && 
      ((target && s.target) || (!target && !s.target))
    );

    if (existingStake) {
      existingStake.amount += amount;
      if (typeof target === "number") {
        existingStake.target = target;
      }
    } else {
      currentGame.stavki.push({
        uid: user.uid,
        id: user.id,
        amount,
        target
      });
    }

    chat.firstbet = true;

    const targetText = typeof target === "number" ? `\n🎯 авто-вывод: x${String(target)}` : "";
    return botSend(
      context,
      `успешная ставка ${formatWithSpaces(amount)} FP${targetText}\n\nДо начала игры: ${chat.gametime} сек.`
    );
  }
};