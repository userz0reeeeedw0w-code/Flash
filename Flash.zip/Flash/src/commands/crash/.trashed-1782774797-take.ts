import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { formatWithSpaces } from "../../utils/number";
import { CrashGame } from "../../types/database";
import { buildKeyboard } from "../../utils/keyboard";
import { updateGameStats } from "../../utils/gameStats";

export const crashTakeCommand: CommandDefinition<VkMessageContext> = {
  name: "crash.take",
  pattern: /^(?:Забрать!|забрать)$/i,
  guard: context => Boolean(context.chat && context.chat.type === 2 && context.user),
  handler: async context => {
    const { chat, user } = context;
    if (!chat || !user) return;

    if (!Array.isArray(chat.games) || chat.games.length === 0) {
      return botSend(context, "игра ещё не запущена.");
    }

    if (chat.gametime > 0) {
      return botSend(context, `игра начнётся через ${chat.gametime} сек.`);
    }

    const currentGame = chat.games[chat.games.length - 1] as CrashGame;
    const stake = currentGame.stavki.find(s => s.id === user.id);

    if (!stake) {
      const keyboard = buildKeyboard({
        inline: true,
        buttons: [[
          {
            label: `Ставка ${formatWithSpaces(user.lastbet || 0)}`,
            color: "default",
            command: `ставка ${formatWithSpaces(user.lastbet || 0)}`
          },
          {
            label: `Ставка ${formatWithSpaces((user.lastbet || 0) * 2)}`,
            color: "default",
            command: `ставка ${formatWithSpaces((user.lastbet || 0) * 2)}`
          },
          {
            label: `Ставка ${formatWithSpaces(user.balance)}`,
            color: "default",
            command: `ставка ${formatWithSpaces(user.balance)}`
          }
        ]]
      });

      return botSend(context, "в этой игре вы ещё ничего не ставили :(", {
        keyboard
      });
    }

    if (stake.mnoj) {
      return botSend(context, "вы уже забрали свой выигрыш!");
    }

    const winAmount = Math.floor(stake.amount * currentGame.result);
    user.balance += winAmount;
    user.winnings = (user.winnings || 0) + winAmount;
    updateGameStats(user, "win");
    stake.mnoj = currentGame.result;
    stake.cashout = winAmount;

    return botSend(context, `вы выиграли ${formatWithSpaces(winAmount)} FP (x${currentGame.result.toFixed(2)})`);
  }
};
