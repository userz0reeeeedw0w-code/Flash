import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { buildKeyboard } from "../../utils/keyboard";

const crashKeyboard = buildKeyboard({
  buttons: [
    [
      {
        label: "Забрать!",
        color: "default",
        command: "Забрать!"
      },
      {
        label: "Банк",
        color: "positive",
        command: "банк"
      }
    ],
    [
      {
        label: "Ставка",
        color: "primary",
        command: "ставка"
      },
      {
        label: "Рейтинг",
        color: "negative",
        command: "рейтинг"
      },
      {
        label: "Баланс",
        color: "positive",
        command: "баланс"
      }
    ],
    [
      {
        label: "Донат",
        color: "default",
        command: "донат"
      },
      {
        label: "Бонус",
        color: "positive",
        command: "бонус"
      }
    ]
  ]
});

export const crashUpdateKeyboardCommand: CommandDefinition<VkMessageContext> = {
  name: "crash.updateKeyboard",
  pattern: /^(?:обновить кнопки)$/i,
  guard: context => Boolean(context.chat && context.chat.type === 2),
  handler: async context => {
    const { chat } = context;
    if (!chat) {
      return;
    }

    await botSend(context, "Обновляю...", {
      keyboard: crashKeyboard
    });
  }
};

