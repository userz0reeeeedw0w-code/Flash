import { CommandDefinition } from "../../core/command/Command";
import { botSend, VkMessageContext } from "../../core/mode/GameMode";
import { formatWithSpaces, randomInt } from "../../utils/number";
import { DoubleUser, DiceGame } from "../../types/database";
import { updateGameStats } from "../../utils/gameStats";

const diceEmoji = (value: number): string => {
  const map: Record<number, string> = {
    1: "⚀",
    2: "⚁",
    3: "⚂",
    4: "⚃",
    5: "⚄",
    6: "⚅"
  };
  return map[value] ?? "🎲";
};

const resolveUser = (users: DoubleUser[], id: number): DoubleUser | undefined => {
  return users.find(entry => entry.id === id);
};

export const diceAcceptCommand = (allUsers: () => DoubleUser[]): CommandDefinition<VkMessageContext> => ({
  name: "dice.accept",
  pattern: /^(?:принять)\s([^]+)$/i,
  guard: context => Boolean(context.chat && context.chat.type === 4 && context.user),
  handler: async context => {
    if (!context.chat || !context.user) {
      return;
    }
    if (context.chat.type !== 4) {
      return;
    }
    const activeGame: DiceGame | undefined =
      context.chat.games.length > 0
        ? (context.chat.games[context.chat.games.length - 1] as DiceGame)
        : undefined;
    if (!activeGame || activeGame.stavki.length !== 1 || activeGame.status !== "waiting") {
      await botSend(context, "Нет активной ставки для принятия.");
      return;
    }
    const uidText = context.match?.[1] ?? context.text.match(/^(?:принять)\s([^]+)$/i)?.[1] ?? "";
    const expectedUid = activeGame.stavki[0].uid;
    const parsedUid = Number(uidText);
    if (parsedUid !== expectedUid) {
      await botSend(context, "Неверный UID игрока в кнопке. Возможно, ставка уже устарела. Создайте новую.");
      return;
    }
    const player1Stake = activeGame.stavki[0];
    if (player1Stake.id === context.user.id) {
      await botSend(context, "Вы не можете принять свою собственную ставку.");
      return;
    }
    const betAmount = player1Stake.amount;
    if (context.user.balance < betAmount) {
      await botSend(context, 
        `У вас нет достаточно средств (${formatWithSpaces(betAmount)} FP) для принятия этой ставки!`
      );
      return;
    }
    activeGame.status = "playing";
    activeGame.stavki.push({
      uid: context.user.uid,
      id: context.user.id,
      number: 0,
      amount: betAmount
    });
    context.user.balance -= betAmount;
    context.user.lastbet = betAmount;

    await botSend(context, 
      "Ставки приняты. Ожидайте начала игры! [WARN] Больше ставки не принимаются",
      {
        keyboard: JSON.stringify({
          inline: true,
          buttons: []
        })
      }
    );

    await new Promise(resolve => setTimeout(resolve, 10000));
    await botSend(context, "До броска кубиков 5 секунд!");

    await new Promise(resolve => setTimeout(resolve, 5000));

    player1Stake.number = randomInt(1, 6);
    const player2Stake = activeGame.stavki[1];
    player2Stake.number = randomInt(1, 6);

    const users = allUsers();
    const player1 = resolveUser(users, player1Stake.id);
    const player2 = resolveUser(users, player2Stake.id);

    if (!player1 || !player2) {
      context.chat.games.pop();
      return;
    }

    let winner: DoubleUser | undefined;
    let loser: DoubleUser | undefined;

    if (player1Stake.number > player2Stake.number) {
      winner = player1;
      loser = player2;
    } else if (player2Stake.number > player1Stake.number) {
      winner = player2;
      loser = player1;
    }

    let resultMessage: string;
    if (winner && loser) {
      const winAmount = betAmount * 2;
      winner.balance += winAmount;
      winner.winnings = (winner.winnings || 0) + winAmount;
      updateGameStats(winner, "win");
      updateGameStats(loser, "lose");
      resultMessage = `⚔️ Игра Кости завершена! 🎲 Кубики упали!
        
        👤 @id${player1.id} (${player1.tag}):  ${diceEmoji(player1Stake.number)} ${player1Stake.number}
        👤 @id${player2.id} (${player2.tag}):  ${diceEmoji(player2Stake.number)} ${player2Stake.number}

        🎉 Победитель: @id${winner.id} (${winner.tag}), 
        🔥 Выигрыш: ${formatWithSpaces(winAmount)} FP!`;
    } else {
      player1.balance += betAmount;
      player2.balance += betAmount;
      updateGameStats(player1, "push");
      updateGameStats(player2, "push");
      resultMessage = `🤝 Ничья!
        
        👤 @id${player1.id} (${player1.tag}): ${diceEmoji(player1Stake.number)} ${player1Stake.number}
        👤 @id${player2.id} (${player2.tag}): ${diceEmoji(player2Stake.number)} ${player2Stake.number}

        Суммы ставок (${formatWithSpaces(betAmount)} FP) возвращены обоим игрокам.`;
    }

    context.chat.games.pop();

    await botSend(context, resultMessage);
  }
});
