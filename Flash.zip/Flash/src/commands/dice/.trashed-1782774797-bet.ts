import { CommandDefinition } from "../../core/command/Command";
import { botSend, VkMessageContext } from "../../core/mode/GameMode";
import { formatWithSpaces } from "../../utils/number";
import { DoubleChat, DoubleUser, DiceGame } from "../../types/database";

const maxBet = 200000000000;

const parseBet = (value: string): number => {
  let normalized = value.replace(/(\.|,)/gi, "");
  normalized = normalized.replace(/(к|k)/gi, "000");
  normalized = normalized.replace(/(м|m)/gi, "000000");
  return Number(normalized);
};

const findOrCreateGame = (chat: DoubleChat): DiceGame => {
  const lastRaw = chat.games[chat.games.length - 1];
  const last = lastRaw as DiceGame | undefined;
  if (!last || !Array.isArray((last as DiceGame).stavki) || (last as DiceGame).stavki.length === 0) {
    const game: DiceGame = {
      stavki: [],
      status: "waiting"
    };
    chat.games.push(game);
    return game;
  }
  return last;
};

const createStake = (user: DoubleUser, amount: number, platform?: string, peerId?: number) => {
  return {
    uid: user.uid,
    id: user.id,
    number: 0,
    amount,
    platform: platform as "vk" | "tg" | undefined,
    peerId
  };
};

export const diceBetCommand: CommandDefinition<VkMessageContext> = {
  name: "dice.bet",
  pattern: /^(?:кости)\s(.*)$/i,
  guard: context => Boolean(context.chat && context.chat.type === 4 && context.user),
  handler: async context => {
    if (!context.chat || !context.user) {
      return;
    }
    if (context.chat.type !== 4) {
      return;
    }
    const betText = context.match?.[1] ?? context.text.match(diceBetCommand.pattern)?.[1] ?? "";
    const betAmount = parseBet(betText);

    if (!Number.isFinite(betAmount) || betAmount < 50) {
      await botSend(context, `[ERROR] Ставка должна быть числом и быть не менее 50 FP.`);
      return;
    }

    if (betAmount > maxBet) {
      await botSend(context, `[ERROR] Вы не можете поставить больше ${formatWithSpaces(maxBet)} FP`);
      return;
    }

    if (betAmount > context.user.balance) {
      await botSend(context, `[ERROR] На твоем балансе нет столько коинов...`);
      return;
    }

    const lastGame: DiceGame | undefined =
      context.chat.games.length > 0
        ? (context.chat.games[context.chat.games.length - 1] as DiceGame)
        : undefined;
    if (lastGame && lastGame.stavki.length === 1 && lastGame.status === "waiting") {
      await botSend(context, 
        `[WARN] В чате уже активна ставка! Вы можете принять ее, а не создавать новую.`
      );
      return;
    }

    const game = findOrCreateGame(context.chat);
    const stake = createStake(context.user, betAmount, context.platform, context.peerId);

    game.stavki.push(stake);
    context.user.lastbet = betAmount;
    context.user.balance -= betAmount;

    const keyboard = {
      inline: true,
      one_time: false,
      buttons: [
        [
          {
            action: {
              type: "text",
              payload: "{}",
              label: `Принять ${context.user.uid}`
            },
            color: "default"
          },
          {
            action: {
              type: "text",
              payload: "{}",
              label: "Отменить ставку"
            },
            color: "negative"
          }
        ]
      ]
    };

    const message = `@id${context.user.id} (${context.user.tag}), сделал ставку!
    
    💰 Сумма ставки: ${formatWithSpaces(betAmount)} FP
    
    @online кто примет вызов нажав на кнопку? (сумма вашей ставки автоматически равна изначальной ставке)
    [WARN] Если ставку никто не примет в течение 5 минут, она будет отменена и деньги вернутся.`;

    await botSend(context, message, {
      keyboard: JSON.stringify(keyboard)
    });
  }
};
