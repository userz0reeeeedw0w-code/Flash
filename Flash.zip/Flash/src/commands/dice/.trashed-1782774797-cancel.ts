import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { formatWithSpaces } from "../../utils/number";
import { DiceGame } from "../../types/database";

export const diceCancelCommand: CommandDefinition<VkMessageContext> = {
  name: "dice.cancel",
  pattern: /^(?:отменить ставку)$/i,
  guard: context => Boolean(context.chat && context.chat.type === 4 && context.user),
  handler: async context => {
    if (!context.chat || !context.user) {
      return;
    }
    if (context.chat.type !== 4) {
      return;
    }
    const activeGame: DiceGame | undefined =
      context.chat.games.length > 0
        ? (context.chat.games[context.chat.games.length - 1] as DiceGame)
        : undefined;
    if (!activeGame || activeGame.stavki.length !== 1 || activeGame.status !== "waiting") {
      await botSend(context, "В этом чате нет активной ставки, ожидающей оппонента.");
      return;
    }
    const stake = activeGame.stavki[0];
    if (stake.id !== context.senderId) {
      await botSend(context, "Вы можете отменить только свою ставку.");
      return;
    }
    context.user.balance += stake.amount;
    context.chat.games.pop();
    await botSend(context, `Ставка на сумму ${formatWithSpaces(stake.amount)} FP была успешно отменена и возвращена на ваш баланс.`);
  }
};
