import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { buildKeyboard } from "../../utils/keyboard";

export const diceCreateCommand: CommandDefinition<VkMessageContext> = {
  name: "dice.create",
  pattern: /^(?:Кости создать)$/i,
  guard: context => Boolean(context.chat && context.user && context.isChat && context.chat.type !== 4),
  handler: async context => {
    const keyboard = buildKeyboard({
      inline: true,
      buttons: [
        [
          {
            label: "Игра создать",
            color: "positive",
            command: "игра создать"
          }
        ]
      ]
    });

    await botSend(context, 'Используйте команду "игра создать".', { keyboard });
  }
};

export const diceConfirmCreateCommand: CommandDefinition<VkMessageContext> = {
  name: "dice.confirmCreate",
  pattern: /^(?:кости\.уверен)$/i,
  guard: context => Boolean(context.chat && context.user && context.isChat && context.chat.type !== 4),
  handler: async context => {
    const keyboard = buildKeyboard({
      inline: true,
      buttons: [[{ label: "Игра создать", color: "positive", command: "игра создать" }]]
    });
    await botSend(context, 'Используйте команду "игра создать".', { keyboard });
  }
};
