import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { formatWithSpaces } from "../../utils/number";
import { buildKeyboard } from "../../utils/keyboard";

export const diceStakePromptCommand: CommandDefinition<VkMessageContext> = {
  name: "dice.stakePrompt",
  pattern: /^(?:ставка)$/i,
  guard: context => Boolean(context.chat && context.chat.type === 4 && context.user),
  handler: async context => {
    if (!context.chat || !context.user) {
      return;
    }
    if (context.chat.type !== 4) {
      return;
    }
    const lastBet = context.user.lastbet > 0 ? formatWithSpaces(context.user.lastbet) : "50";
    const keyboard = buildKeyboard({
      inline: true,
      buttons: [
        [
          {
            label: `Кости ${lastBet}`,
            color: "default",
            command: `кости ${lastBet}`
          }
        ]
      ]
    });

    const text = `введи команду «кости [сумма ставки]»

        💰 Ваш последний размер ставки: ${lastBet} FP
        [WARN] Ставка не должна превышать ваш баланс!
        [WARN] Для отмены ставки, введи команду "отменить ставку"`;

    await botSend(context, text, { keyboard });
  }
};
