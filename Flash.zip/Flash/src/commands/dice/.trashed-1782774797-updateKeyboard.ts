import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { buildKeyboard } from "../../utils/keyboard";

const mainKeyboard = buildKeyboard({
  oneTime: false,
  buttons: [
    [
      {
        label: "Ставка",
        color: "default",
        command: "ставка"
      }
    ],
    [
      {
        label: "Профиль",
        color: "primary",
        command: "профиль"
      },
      {
        label: "Рейтинг",
        color: "negative",
        command: "рейтинг"
      },
      {
        label: "Баланс",
        color: "positive",
        command: "баланс"
      }
    ],
    [
      {
        label: "Бонус",
        color: "positive",
        command: "бонус"
      },
      {
        label: "Донат",
        color: "default",
        command: "донат"
      }
    ]
  ]
});

export const diceUpdateKeyboardCommand: CommandDefinition<VkMessageContext> = {
  name: "dice.updateKeyboard",
  pattern: /^(?:обновить кнопки)$/i,
  guard: context => Boolean(context.chat && context.chat.type === 4),
  handler: async context => {
    if (!context.chat) {
      return;
    }
    if (context.chat.type !== 4) {
      return;
    }
    await botSend(context, "Обновляю...", {
      keyboard: mainKeyboard
    });
  }
};
