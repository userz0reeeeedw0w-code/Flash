import { CommandDefinition } from "../../core/command/Command";
import { botSend, VkMessageContext } from "../../core/mode/GameMode";
import { DoubleGame, DoubleGameStake } from "../../types/database";
import { formatWithSpaces } from "../../utils/number";
import { buildKeyboard } from "../../utils/keyboard";

export const doubleBankCommand: CommandDefinition<VkMessageContext> = {
  name: "double.bank",
  pattern: /^(?:банк)$/i,
  guard: context => Boolean(context.chat && context.chat.type === 1),
  handler: async context => {
    const { chat } = context;
    if (!chat || chat.type !== 1) return;

    const currentGame = chat.games[chat.games.length - 1] as DoubleGame | undefined;
    if (!currentGame) return;

    if (currentGame.stavki.length === 0) {
      const keyboard = buildKeyboard({
        inline: true,
        buttons: [[{ label: "Последние игры", color: "positive", command: "Последние игры" }]]
      });

      await botSend(context, 
        `в этом раунде еще никто не поставил.\n\nХеш игры: ${currentGame.hash}\nДо конца раунда: ${chat.gametime} сек.`,
        { keyboard }
      );
      return;
    }

    const users = context.state.users ?? [];
    let totalAmount = 0;

    let x2 = "\nCтавки на x2:\n";
    let x3 = "\nСтавки на x3:\n";
    let x5 = "\nСтавки на x5:\n";
    let x50 = "\nСтавки на x50:\n";

    for (const stake of currentGame.stavki as DoubleGameStake[]) {
      totalAmount += stake.amount;
      const user = users.find(u => u.id === stake.id);
      const tag = user?.tag ?? "User";
      const line = `[id${stake.id}|${tag}] - ${formatWithSpaces(stake.amount)} FP\n`;
      if (stake.type === 2) x2 += line;
      if (stake.type === 3) x3 += line;
      if (stake.type === 5) x5 += line;
      if (stake.type === 50) x50 += line;
    }

    let stakesText = "";
    if (x2.length !== "\nCтавки на x2:\n".length) stakesText += x2;
    if (x3.length !== "\nСтавки на x3:\n".length) stakesText += x3;
    if (x5.length !== "\nСтавки на x5:\n".length) stakesText += x5;
    if (x50.length !== "\nСтавки на x50:\n".length) stakesText += x50;

    const keyboard = buildKeyboard({
      inline: true,
      buttons: [[{ label: "Последние игры", color: "positive", command: "Последние игры" }]]
    });

    await botSend(context, 
      `всего поставлено: ${formatWithSpaces(totalAmount)} FP\n\n${stakesText}\n\nХеш игры: ${currentGame.hash}\nДо конца раунда: ${chat.gametime} сек.`,
      { keyboard }
    );
  }
};
