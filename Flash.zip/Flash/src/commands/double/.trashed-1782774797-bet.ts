import { CommandDefinition } from "../../core/command/Command";
import { botSend, VkMessageContext } from "../../core/mode/GameMode";
import { DoubleGame, DoubleGameMultiplier } from "../../types/database";
import { formatWithSpaces } from "../../utils/number";
import { buildKeyboard } from "../../utils/keyboard";

const parseAmount = (value: string): number => {
  let normalized = value.replace(/[.,]/g, "");
  normalized = normalized.replace(/[кk]/gi, "000");
  normalized = normalized.replace(/[мm]/gi, "000000");
  return Number(normalized);
};

const getMultiplierFromText = (text: string): DoubleGameMultiplier | null => {
  const normalized = text.toLowerCase().trim();
  if (normalized.startsWith("x50") || normalized.startsWith("50")) return 50;
  if (normalized.startsWith("x5") || normalized.startsWith("5")) return 5;
  if (normalized.startsWith("x3") || normalized.startsWith("3")) return 3;
  if (normalized.startsWith("x2") || normalized.startsWith("2")) return 2;
  return null;
};

const buildPromptKeyboard = (multiplier: DoubleGameMultiplier, lastBet: number, balance: number): string => {
  const safeLast = lastBet > 0 ? lastBet : 50;
  return buildKeyboard({
    inline: true,
    buttons: [[
      { label: `x${multiplier} ${formatWithSpaces(safeLast)}`, color: "default", command: `x${multiplier} ${formatWithSpaces(safeLast)}` },
      { label: `x${multiplier} ${formatWithSpaces(safeLast * 2)}`, color: "default", command: `x${multiplier} ${formatWithSpaces(safeLast * 2)}` },
      { label: `x${multiplier} ${formatWithSpaces(balance)}`, color: "default", command: `x${multiplier} ${formatWithSpaces(balance)}` }
    ]]
  });
};

export const doubleBetCommand: CommandDefinition<VkMessageContext> = {
  name: "double.bet",
  pattern: /^(?:(?:x)?(?:2|3|5|50))(?:\s+(.+))?$/i,
  guard: context => Boolean(context.chat && context.chat.type === 1 && context.user),
  handler: async context => {
    const { chat, user } = context;
    if (!chat || !user || chat.type !== 1) return;

    const multiplier = getMultiplierFromText(context.text);
    if (!multiplier) {
      return;
    }

    const currentGame = (chat.games[chat.games.length - 1] as DoubleGame | undefined) ?? undefined;
    if (!currentGame || !currentGame.stavka || chat.gametime < 6) {
      await botSend(context, "ставки сейчас не принимаются.");
      return;
    }

    const rawAmount = context.match?.[1];
    if (!rawAmount) {
      const keyboard = buildPromptKeyboard(multiplier, user.lastbet, user.balance);
      await botSend(context, `нажми кнопку ИЛИ введи команду: "x${multiplier} [сумма ставки]"`, {
        keyboard
      });
      return;
    }

    const amount = parseAmount(rawAmount);
    if (!Number.isFinite(amount) || amount <= 0) {
      const keyboard = buildPromptKeyboard(multiplier, user.lastbet, user.balance);
      await botSend(context, `нажми кнопку ИЛИ введи команду: "x${multiplier} [сумма ставки]"`, {
        keyboard
      });
      return;
    }

    if (amount > user.balance) {
      await botSend(context, "на твоем балансе нет столько коинов...");
      return;
    }

    user.balance -= amount;
    user.lastbet = amount;

    const existingStake = currentGame.stavki.find(s => s.id === user.id && s.type === multiplier);
    if (existingStake) {
      existingStake.amount += amount;
    } else {
      currentGame.stavki.push({
        uid: user.uid,
        id: user.id,
        type: multiplier,
        amount,
        platform: context.platform,
        peerId: context.peerId
      });
    }

    await botSend(context, `успешная ставка ${formatWithSpaces(amount)} FP на x${multiplier}`);
  }
};
