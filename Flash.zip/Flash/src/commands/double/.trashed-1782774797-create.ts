import { CommandDefinition } from "../../core/command/Command";
import { botSend, VkMessageContext } from "../../core/mode/GameMode";
import { buildKeyboard } from "../../utils/keyboard";

export const doubleCreateCommand: CommandDefinition<VkMessageContext> = {
  name: "double.create",
  pattern: /^(?:дабл создать)$/i,
  guard: context => Boolean(context.chat && context.user && context.isChat && context.chat.type !== 1),
  handler: async context => {
    const keyboard = buildKeyboard({
      inline: true,
      buttons: [
        [
          {
            label: "Игра создать",
            color: "positive",
            command: "игра создать"
          }
        ]
      ]
    });

    await botSend(context, 'Используйте команду "игра создать".', { keyboard });
  }
};

export const doubleConfirmCreateCommand: CommandDefinition<VkMessageContext> = {
  name: "double.confirmCreate",
  pattern: /^(?:дабл\.уверен)$/i,
  guard: context => Boolean(context.chat && context.user && context.isChat && context.chat.type !== 1),
  handler: async context => {
    const keyboard = buildKeyboard({
      inline: true,
      buttons: [[{ label: "Игра создать", color: "positive", command: "игра создать" }]]
    });
    await botSend(context, 'Используйте команду "игра создать".', { keyboard });
  }
};
