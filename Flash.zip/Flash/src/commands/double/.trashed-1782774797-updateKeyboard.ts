import { CommandDefinition } from "../../core/command/Command";
import { botSend, VkMessageContext } from "../../core/mode/GameMode";
import { buildKeyboard } from "../../utils/keyboard";

const doubleKeyboard = buildKeyboard({
  oneTime: false,
  buttons: [
    [
      { label: "Банк", color: "positive", command: "банк" },
      { label: "Баланс", color: "positive", command: "баланс" }
    ],
    [
      { label: "x2", color: "primary", command: "x2" },
      { label: "x3", color: "primary", command: "x3" },
      { label: "x5", color: "primary", command: "x5" }
    ],
    [{ label: "x50", color: "positive", command: "x50" }],
    [
      { label: "Рейтинг", color: "negative", command: "рейтинг" },
      { label: "Бонус", color: "default", command: "бонус" }
    ]
  ]
});

export const doubleUpdateKeyboardCommand: CommandDefinition<VkMessageContext> = {
  name: "double.updateKeyboard",
  pattern: /^(?:обновить кнопки)$/i,
  guard: context => Boolean(context.chat && context.chat.type === 1),
  handler: async context => {
    const { chat } = context;
    if (!chat) {
      return;
    }

    await botSend(context, "Обновляю...", {
      keyboard: doubleKeyboard
    });
  }
};
