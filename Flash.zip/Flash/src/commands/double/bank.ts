import { CommandDefinition } from "../../core/command/Command";
import { botSend, VkMessageContext } from "../../core/mode/GameMode";
import { DoubleGame, DoubleGameStake } from "../../types/database";
import { formatWithSpaces } from "../../utils/number";
import { buildKeyboard } from "../../utils/keyboard";

export const doubleBankCommand: CommandDefinition<VkMessageContext> = {
    name: "double.bank",
    pattern: /^(?:банк)$/i,
    guard: context => Boolean(context.chat && context.chat.type === 1),
    handler: async context => {
        const { chat } = context;
        if (!chat || chat.type !== 1) return;
        const currentGame = chat.games[chat.games.length - 1] as DoubleGame | undefined;
        if (!currentGame) return;

        if (currentGame.stavki.length === 0) {
            const keyboard = buildKeyboard({
                inline: true,
                buttons: [[{ label: "Последние игры", color: "positive", command: "Последние игры" }]]
            });

            await botSend(context, 
                `В этом раунде еще никто не поставил.\n\nХеш игры: ${currentGame.hash}\nДо конца раунда: ${chat.gametime} сек.`,
                { keyboard }
            );
            return;
        }

        const users = context.state.users ?? [];
        let totalAmount = 0;

        let x2 = "\nСтавки на x2:\n";
        let x3 = "\nСтавки на x3:\n";
        let x5 = "\nСтавки на x5:\n";
        let x50 = "\nСтавки на x50:\n";

        for (const stake of currentGame.stavki as DoubleGameStake[]) {
            totalAmount += stake.amount;
            
            let displayName: string;
            const hasId = stake.id && stake.id > 0;
            
            if (hasId) {
                const user = users.find(u => u.id === stake.id);
                const tag = user?.tag ?? "User";
                displayName = `[id${stake.id}|${tag}]`;
            } else {
                
                displayName = (stake as any).tag || "Bot";
            }
            
            const line = `${displayName} — ${formatWithSpaces(stake.amount)} FP\n`;
            
            if (stake.type === 2) x2 += line;
            if (stake.type === 3) x3 += line;
            if (stake.type === 5) x5 += line;
            if (stake.type === 50) x50 += line;
        }

        let stakesText = "";
        if (x2.length > "\nСтавки на x2:\n".length) stakesText += x2;
        if (x3.length > "\nСтавки на x3:\n".length) stakesText += x3;
        if (x5.length > "\nСтавки на x5:\n".length) stakesText += x5;
        if (x50.length > "\nСтавки на x50:\n".length) stakesText += x50;

        const keyboard = buildKeyboard({
            inline: true,
            buttons: [[{ label: "Последние игры", color: "positive", command: "Последние игры" }]]
        });

        await botSend(context, 
            `Всего поставлено: ${formatWithSpaces(totalAmount)} FP\n\n${stakesText}\nХеш игры: ${currentGame.hash}\nДо конца раунда: ${chat.gametime} сек.`,
            { keyboard }
        );
    }
};