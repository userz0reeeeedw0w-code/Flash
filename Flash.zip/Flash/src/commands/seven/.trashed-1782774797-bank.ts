import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { formatWithSpaces } from "../../utils/number";
import { SevenGame, SevenGameStake } from "../../types/database";
import { buildKeyboard } from "../../utils/keyboard";

export const sevenBankCommand: CommandDefinition<VkMessageContext> = {
  name: "seven.bank",
  pattern: /^(?:банк)$/i,
  guard: context => Boolean(context.chat && context.chat.type === 3),
  handler: async context => {
    const { chat } = context;
    if (!chat || chat.type !== 3) return;

    const currentGame = chat.games[chat.games.length - 1] as SevenGame;
    if (!currentGame) return;

    if (currentGame.stavki.length === 0) {
      const keyboard = buildKeyboard({
        inline: true,
        buttons: [[{ label: "Последние игры", color: "positive", command: "Последние игры" }]]
      });

      return botSend(context, `в этом раунде еще никто не поставил.\n\nХеш игры: ${currentGame.hash}\nДо конца раунда: ${chat.gametime} сек.`, {
        keyboard
      });
    }

    const users = context.state.users ?? [];
    let totalAmount = 0;
    let x2 = "\nCтавки на >7:\n";
    let x3 = "\nСтавки на =7:\n";
    let x5 = "\nСтавки на <7:\n";

    for (const stake of currentGame.stavki as SevenGameStake[]) {
      totalAmount += stake.amount;
      const user = users.find(u => u.id === stake.id);
      const tag = user?.tag ?? "User";
      const line = `[id${stake.id}|${tag}] - ${formatWithSpaces(stake.amount)} FP\n`;
      if (stake.type === ">7") x2 += line;
      if (stake.type === "=7") x3 += line;
      if (stake.type === "<7") x5 += line;
    }

    let stakesText = "";
    if (x2.length !== "\nCтавки на >7:\n".length) stakesText += x2;
    if (x3.length !== "\nСтавки на =7:\n".length) stakesText += x3;
    if (x5.length !== "\nСтавки на <7:\n".length) stakesText += x5;

    const keyboard = buildKeyboard({
      inline: true,
      buttons: [[{ label: "Последние игры", color: "positive", command: "Последние игры" }]]
    });

    return botSend(context, `всего поставлено: ${formatWithSpaces(totalAmount)} FP\n\n${stakesText}\n\nХеш игры: ${currentGame.hash}\nДо конца раунда: ${chat.gametime} сек.`, {
      keyboard
    });
  }
};
