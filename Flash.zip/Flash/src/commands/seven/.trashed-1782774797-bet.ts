import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { formatWithSpaces } from "../../utils/number";
import { SevenGame } from "../../types/database";
import { buildKeyboard } from "../../utils/keyboard";

export const sevenBetCommand: CommandDefinition<VkMessageContext> = {
  name: "seven.bet",
  pattern: /^(?:>7|над|<7|под|=7|7)\s+(.+)$/i,
  guard: context => Boolean(context.chat && context.chat.type === 3 && context.user),
  handler: async context => {
    const { chat, user } = context;
    if (!chat || !user) return;

    const currentGame = chat.games[chat.games.length - 1] as SevenGame;
    if (!currentGame || chat.gametime < 6) return;

    let amountStr = context.match![1];
    amountStr = amountStr.replace(/[.,]/g, "").replace(/[кk]/gi, "000").replace(/[мm]/gi, "000000");

    let amount = parseInt(amountStr);

    let type: ">7" | "<7" | "=7" = ">7";
    let label = ">7";
    let typeLabel = "над";
    const text = context.text || "";

    if (/^(?:<7|под)/i.test(text)) {
      type = "<7";
      label = "<7";
      typeLabel = "под";
    } else if (/^(?:=7|7)/i.test(text)) {
      type = "=7";
      label = "=7";
      typeLabel = "7";
    }

    const lastBet = user.lastbet || 0;
    const balance = user.balance;

    if (isNaN(amount) || amount <= 0) {
      const keyboard = buildKeyboard({
        inline: true,
        buttons: [[
          {
            label: `${label} ${formatWithSpaces(lastBet)}`,
            color: "default",
            command: `${label} ${formatWithSpaces(lastBet)}`
          },
          {
            label: `${label} ${formatWithSpaces(lastBet * 2)}`,
            color: "default",
            command: `${label} ${formatWithSpaces(lastBet * 2)}`
          },
          {
            label: `${label} ${formatWithSpaces(balance)}`,
            color: "default",
            command: `${label} ${formatWithSpaces(balance)}`
          }
        ]]
      });

      return botSend(context, `нажми кнопку ИЛИ введи команду: "${typeLabel} [сумма ставки]"`, {
        keyboard
      });
    }

    if (amount > user.balance) {
      return botSend(context, `на твоем балансе нет столько коинов...`);
    }

    user.balance -= amount;
    user.lastbet = amount;

    const existingStake = currentGame.stavki.find(s => s.id === user.id && s.type === type);
    if (existingStake) {
      existingStake.amount += amount;
    } else {
      currentGame.stavki.push({
        uid: user.uid,
        id: user.id,
        type,
        amount,
        platform: context.platform,
        peerId: context.peerId
      });
    }

    const typeMsg = type === ">7" ? "больше 7" : type === "<7" ? "меньше 7" : "7";
    return botSend(context, `успешная ставка ${formatWithSpaces(amount)} FP на число ${typeMsg}`);
  }
};
