import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { formatWithSpaces } from "../../utils/number";
import { buildKeyboard } from "../../utils/keyboard";

export const sevenPromptCommand: CommandDefinition<VkMessageContext> = {
  name: "seven.prompt",
  pattern: /^(?:>7|над|<7|под|=7|7)$/i,
  guard: context => Boolean(context.chat && context.chat.type === 3 && context.user),
  handler: async context => {
    const { chat, user } = context;
    if (!chat || !user) return;

    const text = context.text || "";
    let label = "";
    let typeLabel = "";

    if (/^(?:>7|над)$/i.test(text)) {
      label = ">7";
      typeLabel = "над";
    } else if (/^(?:<7|под)$/i.test(text)) {
      label = "<7";
      typeLabel = "под";
    } else if (/^(?:=7|7)$/i.test(text)) {
      label = "=7";
      typeLabel = "7";
    }

    const lastBet = user.lastbet || 0;
    const balance = user.balance;

    const keyboard = buildKeyboard({
      inline: true,
      buttons: [[
        {
          label: `${label} ${formatWithSpaces(lastBet)}`,
          color: "default",
          command: `${label} ${formatWithSpaces(lastBet)}`
        },
        {
          label: `${label} ${formatWithSpaces(lastBet * 2)}`,
          color: "default",
          command: `${label} ${formatWithSpaces(lastBet * 2)}`
        },
        {
          label: `${label} ${formatWithSpaces(balance)}`,
          color: "default",
          command: `${label} ${formatWithSpaces(balance)}`
        }
      ]]
    });

    return botSend(context, `нажми кнопку ИЛИ введи команду: "${typeLabel} [сумма ставки]"`, {
      keyboard
    });
  }
};
