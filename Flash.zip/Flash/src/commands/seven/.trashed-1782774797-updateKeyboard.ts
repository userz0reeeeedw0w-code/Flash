import { CommandDefinition } from "../../core/command/Command";
import { VkMessageContext, botSend } from "../../core/mode/GameMode";
import { buildKeyboard } from "../../utils/keyboard";

const sevenMainKeyboard = buildKeyboard({
  buttons: [
    [
      {
        label: "Банк",
        color: "positive",
        command: "банк"
      }
    ],
    [
      {
        label: ">7",
        color: "default",
        command: ">7"
      },
      {
        label: "<7",
        color: "default",
        command: "<7"
      },
      {
        label: "=7",
        color: "default",
        command: "=7"
      }
    ]
  ]
});

export const sevenUpdateKeyboardCommand: CommandDefinition<VkMessageContext> = {
  name: "seven.updateKeyboard",
  pattern: /^(?:обновить кнопки)$/i,
  guard: context => Boolean(context.chat && context.chat.type === 3),
  handler: async context => {
    const { chat } = context;
    if (!chat) {
      return;
    }

    await botSend(context, "Обновляю...", {
      keyboard: sevenMainKeyboard
    });
  }
};

