import dotenv from "dotenv";
import path from "path";
import { BotConfig } from "../types/config";

dotenv.config();

const vkToken = process.env.VK_TOKEN;
const vkUserToken = process.env.VK_USER_TOKEN;
const vkGroupId = process.env.VK_GROUP_ID;
const tgToken = process.env.TG_TOKEN;
const tgPollingTimeout = process.env.TG_POLLING_TIMEOUT;
const tgPollingIntervalMs = process.env.TG_POLLING_INTERVAL_MS;
const tgPollingTimeoutValue = tgPollingTimeout ? Number(tgPollingTimeout) : undefined;
const tgPollingIntervalMsValue = tgPollingIntervalMs ? Number(tgPollingIntervalMs) : undefined;
const tgPollingTimeoutParsed = Number.isFinite(tgPollingTimeoutValue) ? tgPollingTimeoutValue : undefined;
const tgPollingIntervalMsParsed = Number.isFinite(tgPollingIntervalMsValue) ? tgPollingIntervalMsValue : undefined;

if (!vkToken) {
  throw new Error("VK_TOKEN is required");
}

if (!vkGroupId) {
  throw new Error("VK_GROUP_ID is required");
}

const databaseRoot = process.env.DATABASE_ROOT_PATH ?? path.join(process.cwd(), "database");

export const botConfig: BotConfig = {
  vk: {
    token: vkToken,
    userToken: vkUserToken,
    groupId: Number(vkGroupId)
  },
  tg: tgToken
    ? {
        token: tgToken,
        pollingTimeout: tgPollingTimeoutParsed,
        pollingIntervalMs: tgPollingIntervalMsParsed
      }
    : undefined,
  database: {
    rootPath: databaseRoot
  }
};

