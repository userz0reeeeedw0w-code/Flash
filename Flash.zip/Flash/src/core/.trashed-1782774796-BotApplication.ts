import { CommandRegistry } from "./command/CommandRegistry";
import { UnifiedMessageContext, GameMode } from "./mode/GameMode";
import { botConfig } from "../config";
import { createVkClients } from "../services/VkClient";
import { JsonDatabase } from "../services/JsonDatabase";
import { DoubleChat, DoubleUser, Limits } from "../types/database";
import { DiceMode } from "./mode/DiceMode";
import { SevenMode } from "./mode/SevenMode";
import { CrashMode } from "./mode/CrashMode";
import { AdminMode } from "./mode/AdminMode";
import { attachVkMessageHandler } from "../handlers/VkMessageHandler";
import { IntervalService } from "../services/IntervalService";
import { CommonMode } from "./mode/CommonMode";
import { DoubleMode } from "./mode/DoubleMode";
import { TelegramService } from "../services/TelegramService";
import { TelegramClient } from "../services/TelegramClient";
import { createTelegramMessageHandler } from "../handlers/TelegramMessageHandler";
import { Logger } from "../utils/logger";
import { WinningsTopService } from "../services/WinningsTopService";

export class BotApplication {
  private readonly registry = new CommandRegistry<UnifiedMessageContext>();
  private readonly logger = new Logger("BotApplication");
  private winningsService: WinningsTopService | undefined;

  async start(): Promise<void> {
    try {
      this.logger.info("Starting bot application...");

      const vkClients = createVkClients(botConfig.vk);

      let telegramService: TelegramService | undefined;
      let telegramClient: TelegramClient | undefined;
      if (botConfig.tg?.token) {
        telegramService = new TelegramService(botConfig.tg.token, this.logger);
        telegramClient = new TelegramClient(botConfig.tg);
      }

      const chatsDb = new JsonDatabase<DoubleChat[]>(botConfig.database, "doublechats.json");
      const usersDb = new JsonDatabase<DoubleUser[]>(botConfig.database, "doubleusers.json");
      const limitsDb = new JsonDatabase<Limits>(botConfig.database, "limits.json");

      this.winningsService = new WinningsTopService(usersDb);

      const commonMode = new CommonMode({ limitsDb });
      const doubleMode = new DoubleMode({ usersDb, chatsDb, config: botConfig, telegramService });
      const diceMode = new DiceMode({ usersDb, config: botConfig });
      const sevenMode = new SevenMode({ usersDb, chatsDb, config: botConfig });
      const crashMode = new CrashMode({ usersDb, chatsDb, config: botConfig });
      const adminMode = new AdminMode({ usersDb, chatsDb, limitsDb, clients: vkClients, telegramService });

      this.registerModes(
        [commonMode, doubleMode, diceMode, sevenMode, crashMode, adminMode],
        vkClients,
        telegramClient
      );

      attachVkMessageHandler({
        updates: vkClients.group.updates,
        registry: this.registry,
        config: botConfig,
        chatsDb,
        usersDb,
        limitsDb,
        clients: vkClients,
        telegramService
      });

      if (telegramService) {
        this.logger.info("Starting Telegram message handler...");
        const tgHandlers = createTelegramMessageHandler({
          telegramService,
          registry: this.registry,
          config: botConfig,
          chatsDb,
          usersDb,
          limitsDb,
          vkClients
        });

        telegramService.registerHandlers({
          onMessage: tgHandlers.onMessage,
          onCallbackQuery: tgHandlers.onCallbackQuery,
          onError: async (error) => {
            this.logger.error("Telegram error", error);
          }
        });
      }

      const intervalService = new IntervalService(usersDb, limitsDb, vkClients, telegramService);
      intervalService.start();

      await vkClients.group.updates.start();

      if (telegramService) {
        await telegramService.start();
      }

      this.logger.info("Bot application started successfully ✅");
    } catch (error) {
      this.logger.error("Failed to start bot application", error);
      throw error;
    }
  }

  private registerModes(
    modes: GameMode[],
    vkClients: ReturnType<typeof createVkClients>,
    telegramClient?: TelegramClient
  ): void {
    for (const mode of modes) {
      try {
        this.logger.debug(`Registering mode: ${mode.id}`);
        mode.attach(this.registry, vkClients, telegramClient);
      } catch (error) {
        this.logger.error(`Failed to register mode ${mode.id}`, error);
        throw error;
      }
    }
  }
}
