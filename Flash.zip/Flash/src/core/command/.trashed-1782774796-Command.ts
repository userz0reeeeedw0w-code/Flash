export type CommandContext = {
  text: string;
  peerId: number;
  senderId: number;
  isChat: boolean;
  chatId?: number;
  payload?: unknown;
  state?: unknown;
  vk?: unknown;
};

export type CommandExecuteResult = unknown;

export type CommandHandler<TContext extends CommandContext> = (context: TContext) => CommandExecuteResult;

export type CommandGuard<TContext extends CommandContext> = (context: TContext) => boolean;

export type CommandDefinition<TContext extends CommandContext> = {
  name: string;
  pattern: RegExp;
  guard?: CommandGuard<TContext>;
  handler: CommandHandler<TContext>;
};
