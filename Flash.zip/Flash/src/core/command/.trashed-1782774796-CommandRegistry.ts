import { CommandContext, CommandDefinition } from "./Command";

export class CommandRegistry<TContext extends CommandContext> {
  private readonly commands: CommandDefinition<TContext>[] = [];

  register(command: CommandDefinition<TContext>): void {
    this.commands.push(command);
  }

  registerMany(commands: CommandDefinition<TContext>[]): void {
    commands.forEach(command => this.register(command));
  }

  resolve(
    context: TContext
  ): { command: CommandDefinition<TContext>; match: RegExpMatchArray | null } | undefined {
    for (const command of this.commands) {
      if (command.guard && !command.guard(context)) {
        continue;
      }

      const match = context.text.match(command.pattern);
      if (match) {
        return { command, match };
      }
    }
    return undefined;
  }
}
