import { GameMode, VkMessageContext } from "./GameMode";
import { CommandDefinition } from "../command/Command";
import { CommandRegistry } from "../command/CommandRegistry";
import { VkClients } from "../../services/VkClient";
import { JsonDatabase } from "../../services/JsonDatabase";
import { DoubleChat, DoubleUser, CrashGame } from "../../types/database";
import { BotConfig } from "../../types/config";
import { pick, formatWithSpaces } from "../../utils/number";
import { updateGameStats } from "../../utils/gameStats";
import { crashBetCommand } from "../../commands/crash/bet";
import { crashBankCommand } from "../../commands/crash/bank";
import { crashTakeCommand } from "../../commands/crash/take";
import { crashUpdateKeyboardCommand } from "../../commands/crash/updateKeyboard";
import { TelegramService } from "../../services/TelegramService";
import { normalizeTelegramText, vkKeyboardToTelegramMarkup } from "../../utils/telegram";

type Dependencies = {
  usersDb: JsonDatabase<DoubleUser[]>;
  chatsDb: JsonDatabase<DoubleChat[]>;
  config: BotConfig;
};

export class CrashMode extends GameMode {
  readonly id = "crash";

  readonly commands: CommandDefinition<VkMessageContext>[];

  private readonly dependencies: Dependencies;
  private clients?: VkClients;
  private telegramService?: TelegramService;
  private nextAction: Record<number, string | null> = {};

  constructor(dependencies: Dependencies) {
    super();
    this.dependencies = dependencies;
    this.commands = [
      crashBetCommand,
      crashBankCommand,
      crashTakeCommand,
      crashUpdateKeyboardCommand
    ];
  }

  attach(registry: CommandRegistry<VkMessageContext>, clients: VkClients, telegramService?: TelegramService): void {
      
    this.clients = clients;
    this.telegramService = telegramService;
    if (this.commands.length > 0) {
      registry.registerMany(this.commands);
    }
    this.startLoop();
  }

  private async sendChatMessage(chat: DoubleChat, message: string, keyboard?: string): Promise<void> {
    if (!this.clients) return;

    try {
      if (chat.id < 0) {
        if (!this.telegramService) return;
        await this.telegramService.getTelegram().api.sendMessage({
          chat_id: chat.id,
          text: normalizeTelegramText(message),
          reply_markup: keyboard ? vkKeyboardToTelegramMarkup(keyboard) : undefined
        } as any);
        return;
      }

      await this.clients.group.api.messages.send({
        chat_id: chat.id,
        message,
        keyboard,
        random_id: 0
      });
    } catch (error) {
      console.error("crash.sendChatMessage", { chatId: chat.id, error });
    }
  }

  private startLoop(): void {
    const tick = async (): Promise<void> => {
      let delayMs = 1000;
      try {
        const chats = this.dependencies.chatsDb.load();
        const crashChats = chats.filter(c => c.type === 2);
        if (crashChats.length === 0) {
          delayMs = 5000;
          return;
        }

        for (const chat of crashChats) {
          try {
            await this.processChat(chat);
          } catch (error) {
            console.error("crash.processChat", { chatId: chat.id, error });
          }
        }

        this.dependencies.chatsDb.save(chats);
      } catch (error) {
        console.error("crash.tick", error);
      } finally {
        setTimeout(tick, delayMs);
      }
    };

    void tick();
  }

  private async processChat(chat: DoubleChat): Promise<void> {
    if (!this.clients) return;

    if (!chat.game || chat.games.length === 0) {
      chat.games.push({
        id: chat.games.length,
        result: 1.0,
        stavka: true,
        end: false,
        stavki: []
      } as CrashGame);
      chat.game = true;
      chat.gametime = 30;
      chat.firstbet = false;
      this.nextAction[chat.id] = null;
      return;
    }

    const currentGame = chat.games[chat.games.length - 1] as CrashGame;

    if (currentGame.end) {
      chat.game = false;
      this.nextAction[chat.id] = null;
      return;
    }

    if (chat.gametime > 0) {
      if (currentGame.stavki.length > 0) {
        chat.gametime--;
        if (chat.gametime === 5) {
          await this.sendChatMessage(chat, "До старта осталось 5 секунд. Успей поставить или приготовься забирать!");
        }
      }
      return;
    }

    const wasStavka = currentGame.stavka;
    currentGame.stavka = false;
     if (wasStavka) {
      const playersTotal = currentGame.stavki.length;
      const bank = currentGame.stavki.reduce((sum, s) => sum + s.amount, 0);
      this.nextAction[chat.id] = `${currentGame.id}|0`;
      await this.sendChatMessage(
        chat,
        `🚀 Раунд начался!\n` +
          `📊 Банк: ${formatWithSpaces(bank)} FP • ставок: ${playersTotal}\n\n` +
          `Нажми «Забрать!», чтобы выйти с выигрышем.\n` +
          `Для авто-вывода ставь так: «ставка 1000 2.5»`
      );
    }

    const increase = pick([1, 2, 5, 10, 20]);
    currentGame.result = Math.max(1.00, Math.floor((currentGame.result * 100 + increase)) / 100);

    const users = this.dependencies.usersDb.load();
    let autoText = "";
    for (const stake of currentGame.stavki) {
      if (stake.mnoj) continue;
      if (!stake.target) continue;
      if (stake.target > currentGame.result) continue;

      const user = users.find(u => u.id === stake.id);
      if (!user) continue;

      const cashoutMultiplier = stake.target;
      const winAmount = Math.floor(stake.amount * cashoutMultiplier);
      user.balance += winAmount;
      user.winnings = (user.winnings || 0) + winAmount;
      updateGameStats(user, "win");
      stake.mnoj = cashoutMultiplier;
      stake.cashout = winAmount;

      autoText += `✅ [id${user.id}|${user.tag}] авто-забор на x${cashoutMultiplier.toFixed(2)} (+${formatWithSpaces(winAmount)} FP)\n`;
    }
    if (autoText) {
      this.dependencies.usersDb.save(users);
    }

    const crashChance = pick([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
    if (crashChance === 1) {
      currentGame.end = true;

      let winText = "";
      let looseText = "";

      for (const stake of currentGame.stavki) {
        const user = users.find(u => u.id === stake.id);
        const tag = user?.tag ?? "User";

        if (stake.mnoj) {
          const at = stake.mnoj;
          const winAmount = typeof stake.cashout === "number" ? stake.cashout : Math.floor(stake.amount * at);
          winText += `✅ [id${stake.id}|${tag}] забрал на x${at.toFixed(2)} (+${formatWithSpaces(winAmount)} FP)\n`;
          continue;
        }

        if (user) {
          updateGameStats(user, "lose");
        }
        looseText += `❌ [id${stake.id}|${tag}] ставка ${formatWithSpaces(stake.amount)} проиграла\n`;
      }

      await this.sendChatMessage(
        chat,
        `📉 График упал на отметке x${currentGame.result.toFixed(2)}\n\n` +
          (autoText ? `Авто-выводы этого тика:\n${autoText}\n` : "") +
          (winText ? `Успели забрать:\n${winText}\n` : "") +
          (looseText ? `Проиграли:\n${looseText}` : "В этом раунде ставок не было.")
      );
      this.dependencies.usersDb.save(users);
      return;
    }

    if (autoText) {
      await this.sendChatMessage(
        chat,
        `🎯 Авто-выводы:\n${autoText}\nТекущий множитель: x${currentGame.result.toFixed(2)}`
      );
    }

    const step = 0.5;
    const bucket = Math.floor((currentGame.result - 1) / step);
    const token = this.nextAction[chat.id];
    const [lastGameIdRaw, lastBucketRaw] = String(token ?? "").split("|");
    const lastGameId = Number.parseInt(lastGameIdRaw, 10);
    const lastBucket = Number.parseInt(lastBucketRaw, 10);
    if (!Number.isFinite(lastGameId) || lastGameId !== currentGame.id || !Number.isFinite(lastBucket)) {
      this.nextAction[chat.id] = `${currentGame.id}|${bucket}`;
      return;
    }
    if (lastGameId === currentGame.id && Number.isFinite(lastBucket) && bucket > lastBucket) {
      this.nextAction[chat.id] = `${currentGame.id}|${bucket}`;
      const active = currentGame.stavki.filter(s => !s.mnoj).length;
      const regularActive = currentGame.stavki.filter(s => !s.mnoj && !s.target).length;
      const autoActive = currentGame.stavki.filter(s => !s.mnoj && s.target).length;
      const total = currentGame.stavki.length;
      
      await this.sendChatMessage(
        chat,
        `📈 Текущий множитель: x${currentGame.result.toFixed(2)} • в игре: ${active}/${total} (обычных: ${regularActive}, авто: ${autoActive})`
      );
    }
  }
}
