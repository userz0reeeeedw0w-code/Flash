import { GameMode, UnifiedMessageContext } from "./GameMode";
import { CommandDefinition } from "../command/Command";
import { CommandRegistry } from "../command/CommandRegistry";
import { VkClients } from "../../services/VkClient";
import { JsonDatabase } from "../../services/JsonDatabase";
import { BotConfig } from "../../types/config";
import { DoubleChat, DoubleUser, DoubleGame, DoubleGameMultiplier } from "../../types/database";
import { pick, randomString, formatWithSpaces } from "../../utils/number";
import { updateGameStats } from "../../utils/gameStats";
import md5 from "js-md5";
import { doubleCreateCommand, doubleConfirmCreateCommand } from "../../commands/double/create";
import { doubleBetCommand } from "../../commands/double/bet";
import { doubleUpdateKeyboardCommand } from "../../commands/double/updateKeyboard";
import { doubleBankCommand } from "../../commands/double/bank";
import { TelegramService } from "../../services/TelegramService";
import { normalizeTelegramText, vkKeyboardToTelegramMarkup } from "../../utils/telegram";
import * as fs from 'fs';
import * as path from 'path';
import FormData from 'form-data';

interface DoubleModeDependencies {
  usersDb: JsonDatabase<DoubleUser[]>;
  chatsDb: JsonDatabase<DoubleChat[]>;
  config: BotConfig;
  telegramService?: TelegramService;
}

export class DoubleMode extends GameMode {
  readonly id = "double";
  readonly commands: CommandDefinition<UnifiedMessageContext>[];

  private readonly dependencies: DoubleModeDependencies;
  private clients?: VkClients;
  private telegramService?: TelegramService;
  private readonly errorLogChatId = 5;
  
  private telegramPhotoCache: Map<DoubleGameMultiplier, string> = new Map();
  private telegramToken: string | null = null;

  constructor(dependencies: DoubleModeDependencies) {
    super();
    this.dependencies = dependencies;
    this.commands = [
      doubleCreateCommand,
      doubleConfirmCreateCommand,
      doubleUpdateKeyboardCommand,
      doubleBetCommand,
      doubleBankCommand
    ];
  }

  private async logError(error: Error, context?: string): Promise<void> {
    const errorMessage = `[DoubleMode Error] ${context || ''}\n${error.message}\n${error.stack || ''}`;
    console.error(errorMessage);
    
    if (this.clients) {
      try {
        await this.clients.group.api.messages.send({
          chat_id: this.errorLogChatId,
          message: `⚠️ Ошибка в DoubleMode:\n${context || ''}\n${error.message}\n${error.stack?.substring(0, 500) || ''}`,
          random_id: 0
        });
      } catch (sendError) {
        console.error('Failed to send error log to VK:', sendError);
      }
    }
  }

  attach(registry: CommandRegistry<UnifiedMessageContext>, clients: VkClients, telegramService?: TelegramService): void {
    this.clients = clients;
    this.telegramService = telegramService;
    
    console.log(`[DoubleMode] Attached with telegramService: ${telegramService ? 'present' : 'undefined'}`);
    
    // Берем токен из переменных окружения
    this.telegramToken = process.env.TG_TOKEN || null;
    if (this.telegramToken) {
      console.log('[DoubleMode] Telegram token loaded from env');
    } else {
      console.log('[DoubleMode] No telegram token found in env');
    }
    
    if (this.commands.length > 0) {
      registry.registerMany(this.commands);
    }
    this.startLoop();
  }

  private async getTelegramFileId(multiplier: DoubleGameMultiplier): Promise<string | null> {
    if (this.telegramPhotoCache.has(multiplier)) {
      return this.telegramPhotoCache.get(multiplier)!;
    }
    
    if (!this.telegramToken) {
      console.error('[DoubleMode] No telegram token');
      return null;
    }
    
    const imagePath = path.join(process.cwd(), 'images', 'double', `${multiplier}x.png`);
    
    if (!fs.existsSync(imagePath)) {
      console.error(`[DoubleMode] Image not found: ${imagePath}`);
      return null;
    }
    
    try {
      const formData = new FormData();
      formData.append('photo', fs.createReadStream(imagePath));
      
      const uploadUrl = `https://api.telegram.org/bot${this.telegramToken}/sendPhoto`;
      const uploadResponse = await fetch(uploadUrl, {
        method: 'POST',
        body: formData as any,
        headers: formData.getHeaders()
      });
      
      const result = await uploadResponse.json();
      
      if (result.ok && result.result.photo && result.result.photo.length > 0) {
        const fileId = result.result.photo[result.result.photo.length - 1].file_id;
        this.telegramPhotoCache.set(multiplier, fileId);
        console.log(`[DoubleMode] Got Telegram file_id for x${multiplier}: ${fileId}`);
        return fileId;
      } else {
        console.error(`[DoubleMode] Failed to upload photo for x${multiplier}:`, result.description);
        return null;
      }
    } catch (error) {
      console.error(`[DoubleMode] Error uploading photo for x${multiplier}:`, error);
      return null;
    }
  }

  private async sendTelegramText(chatId: number, message: string, replyMarkup?: any): Promise<void> {
    if (!this.telegramToken) return;
    
    const url = `https://api.telegram.org/bot${this.telegramToken}/sendMessage`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text: normalizeTelegramText(message),
        reply_markup: replyMarkup,
        parse_mode: 'HTML'
      })
    });
    
    const result = await response.json();
    if (!result.ok) {
      console.error('[DoubleMode] Telegram sendMessage error:', result.description);
    } else {
      console.log(`[DoubleMode] Text sent to Telegram chat ${chatId}`);
    }
  }

  private async sendChatMessage(
    chat: DoubleChat,
    message: string,
    options?: { keyboard?: string; attachment?: string; multiplier?: DoubleGameMultiplier }
  ): Promise<void> {
    if (!this.clients) {
      await this.logError(new Error('Clients not initialized'), 'sendChatMessage: clients is undefined');
      return;
    }

    try {
      const isTelegramChat = chat.id < 0;
      
      if (isTelegramChat) {
        if (!this.telegramToken) {
          console.error('[DoubleMode] No telegram token for sending');
          return;
        }
        
        const replyMarkup = options?.keyboard ? vkKeyboardToTelegramMarkup(options.keyboard) : undefined;
        
        if (options?.multiplier) {
          const fileId = await this.getTelegramFileId(options.multiplier);
          
          if (fileId) {
            const url = `https://api.telegram.org/bot${this.telegramToken}/sendPhoto`;
            const formData = new FormData();
            formData.append('chat_id', chat.id.toString());
            formData.append('photo', fileId);
            formData.append('caption', normalizeTelegramText(message));
            formData.append('parse_mode', 'HTML');
            
            if (replyMarkup) {
              formData.append('reply_markup', JSON.stringify(replyMarkup));
            }
            
            const response = await fetch(url, {
              method: 'POST',
              body: formData as any,
              headers: formData.getHeaders()
            });
            
            const result = await response.json();
            if (!result.ok) {
              console.error('[DoubleMode] Telegram sendPhoto error:', result.description);
              await this.sendTelegramText(chat.id, message, replyMarkup);
            } else {
              console.log(`[DoubleMode] Photo sent to Telegram chat ${chat.id}`);
            }
            return;
          }
        }
        
        await this.sendTelegramText(chat.id, message, replyMarkup);
        return;
      }
      
      if (!isTelegramChat) {
        const sendOptions: any = {
          chat_id: chat.id,
          message,
          random_id: 0
        };

        if (options?.attachment) sendOptions.attachment = options.attachment;
        if (options?.keyboard) sendOptions.keyboard = options.keyboard;

        await this.clients.group.api.messages.send(sendOptions);
      }
    } catch (error) {
      await this.logError(error as Error, `sendChatMessage to chat ${chat.id}`);
    }
  }

  private startLoop(): void {
    const tick = async (): Promise<void> => {
      try {
        const chats = this.dependencies.chatsDb.load();
        const doubleChats = chats.filter(c => c.type === 1);

        if (doubleChats.length === 0) {
          setTimeout(tick, 5000);
          return;
        }

        for (const chat of doubleChats) {
          await this.processChat(chat);
        }

        this.dependencies.chatsDb.save(chats);
        setTimeout(tick, 1000);
      } catch (error) {
        await this.logError(error as Error, 'startLoop tick');
        setTimeout(tick, 5000);
      }
    };

    void tick();
  }

  private buildGameResult(chatId: number): DoubleGameMultiplier {
    if (chatId === 96) {
      return pick([
        2, 3, 5, 5, 50, 3, 3, 2, 5, 2, 5, 2, 3, 3, 5, 2, 2, 2, 2, 2, 2, 3, 3, 3,
        5, 50, 5, 5, 5, 2, 3, 50, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 5, 2, 5, 5, 5, 2,
        2, 3, 2, 2, 5, 50
      ]);
    }

    return pick([
      2, 2, 2, 2, 2, 5, 2, 2, 5, 2, 2, 3, 3, 3, 5, 3, 5, 3, 3, 50, 3, 2, 2, 2, 3,
      2, 2, 5, 3, 3, 2, 3, 3, 2, 2, 2, 5, 5, 3, 3, 3, 3, 2, 5, 2, 2, 2, 2
    ]);
  }

  private async processChat(chat: DoubleChat): Promise<void> {
    if (!this.clients) {
      await this.logError(new Error('Clients not initialized'), 'processChat');
      return;
    }

    try {
      if (!chat.game || chat.games.length === 0) {
        const result = this.buildGameResult(chat.id);
        const salt = randomString(18);
        const proverka = `${result}|${salt}`;
        const hash = md5(proverka);

        chat.games.push({
          result,
          stavka: true,
          hash,
          proverka,
          stavki: []
        } as DoubleGame);

        chat.gametime = 30;
        chat.game = true;

        await this.clients.group.api.messages.send({
          chat_id: 5,
          message: `(double) Выпадет множитель: x${result}\nID чата: ${chat.id}`,
          random_id: 0
        });

        if (chat.games.length > 4) {
          chat.games = chat.games.slice(chat.games.length - 4);
        }
        return;
      }

      const currentGame = chat.games[chat.games.length - 1] as DoubleGame;

      if (currentGame.stavki.length === 0) {
        chat.gametime = 30;
        currentGame.stavka = true;
        return;
      }

      chat.gametime--;

      if (chat.gametime === 5) {
        currentGame.stavka = false;
        await this.sendChatMessage(chat, "До конца раунда осталось менее пяти секунд, ставки не принимаются");
      }

      if (chat.gametime === 2) {
        await this.sendChatMessage(chat, "Итак, результаты раунда...");
      }

      if (chat.gametime !== 0) {
        return;
      }

      chat.game = false;

      const users = this.dependencies.usersDb.load();
      let text = "";
      let winUser: DoubleUser[] = [];

      const sorted = [...currentGame.stavki].sort((a, b) => a.type - b.type);
      for (const stake of sorted) {
        const user = users.find(u => u.id === stake.id);
        if (!user) continue;

        if (stake.type === currentGame.result) {
          const winAmount = stake.amount * stake.type;
          user.balance += winAmount;
          user.winnings = (user.winnings || 0) + winAmount;
          updateGameStats(user, "win");
          text += `✅ [id${user.id}|${user.tag}] ставка ${formatWithSpaces(stake.amount)} на x${stake.type} выиграла! (приз ${formatWithSpaces(winAmount)} FP)\n`;
          if(!winUser.find(({ id }) => id === user.id)) {
            winUser.push(user);
          }
          continue;
        } else {
          if (!winUser.find(({ id }) => id === user.id)) {
            updateGameStats(user, "lose");
          }
          text += `❌ [id${user.id}|${user.tag}] ставка ${formatWithSpaces(stake.amount)} на x${stake.type} проиграла\n`;
        }
      }

      this.dependencies.usersDb.save(users);

      const photoMap: Record<DoubleGameMultiplier, string> = {
        2: "photo-78431819_457239025",
        3: "photo-78431819_457239024",
        5: "photo-78431819_457239023",
        50: "photo-78431819_457239026"
      };

      const provUrl = `https://www.gigacalculator.com/calculators/md5-online-generator.php?instring=${encodeURIComponent(currentGame.proverka)}`;

      await this.sendChatMessage(
        chat,
        `Выпал множитель x${currentGame.result}\n\n${text}\n\nХеш игры: ${currentGame.hash}\nПроверка честности: ${currentGame.proverka}`,
        {
          attachment: photoMap[currentGame.result],
          multiplier: currentGame.result,
          keyboard: JSON.stringify({
            inline: true,
            buttons: [[
              {
                action: {
                  type: "open_link",
                  link: provUrl,
                  label: "Проверить результат!"
                }
              }
            ]]
          })
        }
      );
    } catch (error) {
      await this.logError(error as Error, `processChat for chat ${chat.id}`);
    }
  }
}