import { GameMode, UnifiedMessageContext } from "./GameMode";
import { CommandDefinition } from "../command/Command";
import { CommandRegistry } from "../command/CommandRegistry";
import { VkClients } from "../../services/VkClient";
import { JsonDatabase } from "../../services/JsonDatabase";
import { DoubleChat, DoubleUser, Limits } from "../../types/database";
import { TelegramClient } from "../../services/TelegramClient";
import { TelegramService } from "../../services/TelegramService";
import { createBroadcastCommand } from "../../commands/admin/broadcast";
import { createAdminCommands } from "../../commands/admin";
import { profileCommand } from "../../commands/common/profile";
import { transferCommand } from "../../commands/common/transfer";

interface AdminModeDependencies {
  usersDb: JsonDatabase<DoubleUser[]>;
  chatsDb: JsonDatabase<DoubleChat[]>;
  limitsDb: JsonDatabase<Limits>;
  clients: VkClients;
  telegramService?: TelegramService;
}

export class AdminMode extends GameMode {
  readonly id = "admin";
  readonly commands: CommandDefinition<UnifiedMessageContext>[];
  private readonly dependencies: AdminModeDependencies;

  constructor(dependencies: AdminModeDependencies) {
    super();
    this.dependencies = dependencies;
    this.commands = [
      ...createAdminCommands(dependencies.limitsDb, dependencies.usersDb, dependencies.telegramService),
      profileCommand,
      transferCommand
    ];
  }

  attach(registry: CommandRegistry<UnifiedMessageContext>, _clients: VkClients, telegram?: any): void {
    registry.registerMany([
      createBroadcastCommand(
        this.dependencies.usersDb,
        this.dependencies.chatsDb,
        this.dependencies.clients,
        telegram
      ),
      ...this.commands
    ]);
  }
}
