import { GameMode, UnifiedMessageContext } from "./GameMode";
import { CommandDefinition } from "../command/Command";
import { CommandRegistry } from "../command/CommandRegistry";
import { VkClients } from "../../services/VkClient";
import { JsonDatabase } from "../../services/JsonDatabase";
import { chatsCommand } from "../../commands/common/chats"
import { profileCommand } from "../../commands/common/profile";
import { transferCommand } from "../../commands/common/transfer";
import { balanceCommand } from "../../commands/common/balance";
import { bonusCommand } from "../../commands/common/bonus";
import { promoListCommand, promoActivateCommand } from "../../commands/common/promo"
import { ratingCommand, topRefCommand } from "../../commands/common/rating";
import { donateCommand, topUpCommand } from "../../commands/common/donate";
import { lastGamesCommand } from "../../commands/common/lastGames";
import { keyboardToggleCommand } from "../../commands/common/keyboardToggle";
import { gameCancelCommand, gameConfirmCommand, gameCreateCommand, gameSelectCommand } from "../../commands/common/game";
import { helpCommand } from "../../commands/common/help";
import { kkCommand } from "../../commands/common/kk";
import { casesCommand, buyCaseCommand, openCaseCommand } from "../../commands/common/cases";
import { blackjackCommand } from "../../commands/common/blackjack";
import { hlCommand } from "../../commands/common/hl";
import { tgLinkCommand } from "../../commands/common/tgLink";
import { slotsCommand } from "../../commands/common/slots";
import { minesCommand } from "../../commands/common/mines";
import { winningsTopCommand } from "../../commands/common/winnings";
import { myRefCommand, referralLinkCommand, topReferrersCommand } from "../../commands/common/referrals";
import { Limits } from "../../types/database";
import { TelegramService } from "../../services/TelegramService";

interface CommonModeDependencies {
  limitsDb: JsonDatabase<Limits>;
}

export class CommonMode extends GameMode {
  readonly id = "common";
  readonly commands: CommandDefinition<UnifiedMessageContext>[];

  private readonly dependencies: CommonModeDependencies;

  constructor(dependencies: CommonModeDependencies) {
    super();
    this.dependencies = dependencies;
    this.commands = [
      helpCommand,
      tgLinkCommand,
      blackjackCommand,
      profileCommand,
      transferCommand,
      balanceCommand,
      bonusCommand,
      ratingCommand,
      donateCommand,
      topUpCommand,
      lastGamesCommand,
      gameCreateCommand,
      gameSelectCommand,
      gameConfirmCommand,
      gameCancelCommand,
      casesCommand,
      chatsCommand,
      buyCaseCommand,
      openCaseCommand,
      promoActivateCommand,
      promoListCommand,
      kkCommand,
      topRefCommand,
      keyboardToggleCommand,
      hlCommand,
      slotsCommand,
      minesCommand,
      winningsTopCommand,
      myRefCommand,
      referralLinkCommand,
      topReferrersCommand,
    ];
  }

  attach(
    registry: CommandRegistry<UnifiedMessageContext>,
    clients: VkClients,
    telegramService?: TelegramService
  ): void {
    registry.registerMany(this.commands);
  }
}