import { GameMode, UnifiedMessageContext } from "./GameMode";
import { CommandDefinition } from "../command/Command";
import { CommandRegistry } from "../command/CommandRegistry";
import { VkClients } from "../../services/VkClient";
import { updateGameStats } from "../../utils/gameStats";
import { diceBetCommand } from "../../commands/dice/bet";
import { diceCreateCommand, diceConfirmCreateCommand } from "../../commands/dice/create";
import { diceCancelCommand } from "../../commands/dice/cancel";
import { diceStakePromptCommand } from "../../commands/dice/stakePrompt";
import { diceUpdateKeyboardCommand } from "../../commands/dice/updateKeyboard";
import { diceAcceptCommand } from "../../commands/dice/accept";
import { JsonDatabase } from "../../services/JsonDatabase";
import { DoubleUser } from "../../types/database";
import { BotConfig } from "../../types/config";
import { TelegramService } from "../../services/TelegramService";

interface DiceModeDependencies {
  usersDb: JsonDatabase<DoubleUser[]>;
  config: BotConfig;
}

export class DiceMode extends GameMode {
  readonly id = "dice";

  readonly commands: CommandDefinition<UnifiedMessageContext>[];

  private readonly dependencies: DiceModeDependencies;

  constructor(dependencies: DiceModeDependencies) {
    super();
    this.dependencies = dependencies;
    this.commands = [
      diceCreateCommand,
      diceConfirmCreateCommand,
      diceStakePromptCommand,
      diceBetCommand,
      diceCancelCommand,
      diceUpdateKeyboardCommand,
      diceAcceptCommand(this.getAllUsers)
    ];
  }

  attach(registry: CommandRegistry<UnifiedMessageContext>, _clients: VkClients, _telegramService?: TelegramService): void {
    registry.registerMany(this.commands);
  }

  private getAllUsers = (): DoubleUser[] => {
    return this.dependencies.usersDb.load();
  };
}

