import { GameMode, UnifiedMessageContext } from "./GameMode";
import { CommandDefinition } from "../command/Command";
import { CommandRegistry } from "../command/CommandRegistry";
import { VkClients } from "../../services/VkClient";
import { JsonDatabase } from "../../services/JsonDatabase";
import { DoubleChat, DoubleUser, SevenGame } from "../../types/database";
import { BotConfig } from "../../types/config";
import { pick, randomString, formatWithSpaces } from "../../utils/number";
import { updateGameStats } from "../../utils/gameStats";
import md5 from "js-md5";
import { sevenBetCommand } from "../../commands/seven/bet";
import { sevenBankCommand } from "../../commands/seven/bank";
import { sevenPromptCommand } from "../../commands/seven/prompt";
import { sevenUpdateKeyboardCommand } from "../../commands/seven/updateKeyboard";
import { TelegramService } from "../../services/TelegramService";
import { normalizeTelegramText, vkKeyboardToTelegramMarkup } from "../../utils/telegram";

interface SevenModeDependencies {
  usersDb: JsonDatabase<DoubleUser[]>;
  chatsDb: JsonDatabase<DoubleChat[]>;
  config: BotConfig;
}

export class SevenMode extends GameMode {
  readonly id = "seven";

  readonly commands: CommandDefinition<UnifiedMessageContext>[];

  private readonly dependencies: SevenModeDependencies;
  private clients?: VkClients;
  private telegramService?: TelegramService;
  private readonly errorLogChatId = 5;

  constructor(dependencies: SevenModeDependencies) {
    super();
    this.dependencies = dependencies;
    this.commands = [
      sevenBetCommand,
      sevenBankCommand,
      sevenPromptCommand,
      sevenUpdateKeyboardCommand
    ];
  }

  private async logError(error: Error, context?: string): Promise<void> {
    const errorMessage = `[SevenMode Error] ${context || ''}\n${error.message}\n${error.stack || ''}`;
    console.error(errorMessage);
    
    if (this.clients) {
      try {
        await this.clients.group.api.messages.send({
          chat_id: this.errorLogChatId,
          message: `⚠️ Ошибка в SevenMode:\n${context || ''}\n${error.message}\n${error.stack?.substring(0, 500) || ''}`,
          random_id: 0
        });
      } catch (sendError) {
        console.error('Failed to send error log to VK:', sendError);
      }
    }
  }

  attach(registry: CommandRegistry<UnifiedMessageContext>, clients: VkClients, telegramService?: TelegramService): void {
    this.clients = clients;
    this.telegramService = telegramService;
    
    console.log(`[SevenMode] Attached with telegramService: ${telegramService ? 'present' : 'undefined'}`);
    
    if (this.commands.length > 0) {
      registry.registerMany(this.commands);
    }
    this.startLoop();
  }

  private async sendChatMessage(
    chat: DoubleChat,
    message: string,
    options?: { keyboard?: string; attachment?: string }
  ): Promise<void> {
    if (!this.clients) {
      await this.logError(new Error('Clients not initialized'), 'sendChatMessage: clients is undefined');
      return;
    }

    try {
      // Проверяем, является ли чат Telegram чатом (отрицательный ID)
      const isTelegramChat = chat.id < 0;
      
      if (isTelegramChat && this.telegramService && typeof this.telegramService.getTelegram === 'function') {
        // Отправляем через Telegram API
        await this.telegramService.getTelegram().api.sendMessage({
          chat_id: chat.id,
          text: normalizeTelegramText(message),
          reply_markup: options?.keyboard ? vkKeyboardToTelegramMarkup(options.keyboard) : undefined
        } as any);
        return;
      }
      
      // Для VK чатов (ID >= 0) отправляем через VK API
      if (!isTelegramChat) {
        await this.clients.group.api.messages.send({
          chat_id: chat.id,
          message,
          attachment: options?.attachment,
          keyboard: options?.keyboard,
          random_id: 0
        });
      } else {
        // Это Telegram чат, но нет TelegramService или метода getTelegram
        await this.logError(
          new Error('Cannot send to Telegram chat: telegramService not available'),
          `sendChatMessage to chat ${chat.id} (Telegram chat)`
        );
      }
    } catch (error) {
      await this.logError(error as Error, `sendChatMessage to chat ${chat.id}`);
    }
  }

  private startLoop(): void {
    const tick = async (): Promise<void> => {
      try {
        const chats = this.dependencies.chatsDb.load();
        const sevenChats = chats.filter(c => c.type === 3);

        if (sevenChats.length === 0) {
          setTimeout(tick, 5000);
          return;
        }

        for (const chat of sevenChats) {
          await this.processChat(chat);
        }

        this.dependencies.chatsDb.save(chats);
        setTimeout(tick, 1000);
      } catch (error) {
        await this.logError(error as Error, 'startLoop tick');
        setTimeout(tick, 5000);
      }
    };

    void tick();
  }

  private async processChat(chat: DoubleChat): Promise<void> {
    if (!this.clients) {
      await this.logError(new Error('Clients not initialized'), 'processChat');
      return;
    }

    try {
      if (chat.games.length === 0 || !chat.start) {
        const result = pick([2, 8, 3, 5, 9, 11, 7, 4, 10, 6, 3, 4, 8, 9, 11, 2, 5, 11, 8, 7, 3, 3, 6, 7, 3, 9, 10, 8, 5, 5, 4, 11, 2, 2]);
        const salt = randomString(18);
        const proverka = `${result}|${salt}`;
        const hash = md5(proverka);

        chat.games.push({
          result,
          stavka: true,
          hash,
          proverka,
          stavki: []
        } as SevenGame);

        chat.gametime = 30;
        chat.start = true;

        // Отправляем лог в админский чат (ID 6) - это VK чат
        await this.clients.group.api.messages.send({
          chat_id: 5,
          message: `(7pod) Выпадет число: ${result}\nID чата: ${chat.id}`,
          random_id: 0
        });

        if (chat.games.length > 4) {
          chat.games = chat.games.slice(chat.games.length - 4);
        }
        return;
      }

      const currentGame = chat.games[chat.games.length - 1] as SevenGame;
      
      if (currentGame.stavki.length === 0) {
        chat.gametime = 30;
        currentGame.stavka = true;
        return;
      }

      chat.gametime--;

      if (chat.gametime === 5) {
        currentGame.stavka = false;
        await this.sendChatMessage(chat, "До конца раунда осталось менее пяти секунд, ставки не принимаются");
      }

      if (chat.gametime === 2) {
        await this.sendChatMessage(chat, "Итак, результаты раунда...");
      }

      if (chat.gametime === 0) {
        chat.start = false;
        const users = this.dependencies.usersDb.load();
        let winText = "";

        const photoMap: Record<number, string> = {
          2: 'photo-78431819_457239033',
          3: 'photo-78431819_457239034',
          4: 'photo-78431819_457239035',
          5: 'photo-78431819_457239036',
          6: 'photo-78431819_457239037',
          7: 'photo-78431819_457239038',
          8: 'photo-78431819_457239039',
          9: 'photo-78431819_457239040',
          10: 'photo-78431819_457239041',
          11: 'photo-78431819_457239042'
        };

        let winUser: DoubleUser[] = [];

        for (const stake of currentGame.stavki) {
          const user = users.find(u => u.id === stake.id);
          if (!user) continue;

          let won = false;
          let multiplier = 0;

          if (stake.type === ">7" && currentGame.result > 7) {
            won = true;
            multiplier = 2.2;
          } else if (stake.type === "<7" && currentGame.result < 7) {
            won = true;
            multiplier = 2.2;
          } else if (stake.type === "=7" && currentGame.result === 7) {
            won = true;
            multiplier = 5;
          }

          if (won) {
            const winAmount = Math.round(stake.amount * multiplier);
            user.balance += winAmount;
            user.winnings = (user.winnings || 0) + winAmount;
            updateGameStats(user, "win");
            winText += `✅ [id${user.id}|${user.tag}] ставка ${formatWithSpaces(stake.amount)} на ${stake.type} выиграла! (приз ${formatWithSpaces(winAmount)} FP)\n`;
            if(!winUser.find(({ id }) => id === user.id)) {
              winUser.push(user);
            }
          } else {
            if (!winUser.find(({ id }) => id === user.id)) {
              updateGameStats(user, "lose");
            }
            winText += `❌ [id${user.id}|${user.tag}] ставка ${formatWithSpaces(stake.amount)} на ${stake.type} проиграла\n`;
          }
        }

        this.dependencies.usersDb.save(users);

        const provUrl = `https://www.gigacalculator.com/calculators/md5-online-generator.php?instring=${encodeURIComponent(currentGame.proverka)}`;

        await this.sendChatMessage(
          chat,
          `Выпало число ${currentGame.result}\n\n${winText}\n\nХеш игры: ${currentGame.hash}\nПроверка честности: ${currentGame.proverka}`,
          {
            attachment: photoMap[currentGame.result],
            keyboard: JSON.stringify({
              inline: true,
              buttons: [[{
                action: {
                  type: "open_link",
                  link: provUrl,
                  label: "Проверить результат!"
                }
              }]]
            })
          }
        );
      }
    } catch (error) {
      await this.logError(error as Error, `processChat for chat ${chat.id}`);
    }
  }
}