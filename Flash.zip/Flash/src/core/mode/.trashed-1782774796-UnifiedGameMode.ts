import { CommandDefinition } from "../command/Command";
import { CommandRegistry } from "../command/CommandRegistry";
import { VkClients } from "../../services/VkClient";
import { DoubleChat, DoubleUser } from "../../types/database";
import type { MessageContext as VkMessageContext, VK } from "vk-io";
import type { MessageContext as TgMessageContext, CallbackQueryContext } from "puregram";
import type { TelegramService } from "../../services/TelegramService";
import { normalizeTelegramText, vkKeyboardToTelegramMarkup } from "../../utils/telegram";

export type VkMessageState = {
  chat?: DoubleChat;
  user?: DoubleUser;
  chats?: DoubleChat[];
  users?: DoubleUser[];
};

export type UnifiedMessageContext = {
  peerId: number;
  senderId: number;
  isChat: boolean;
  platform: "vk" | "tg";
  text: string;
  requestId: string;

  vkContext?: VkMessageContext;
  vk?: VK;
  message?: any;
  chatId?: number;

  tgContext?: TgMessageContext;
  tgService?: TelegramService;
  tgUserId?: number;
  tgUsername?: string;
  tg?: any;

  chat?: DoubleChat;
  user?: DoubleUser;
  state: VkMessageState;

  payload?: Record<string, unknown> | null;
  match?: RegExpMatchArray | null;

  send: (text: string, params?: Record<string, unknown>) => Promise<any>;
  sendWithKeyboard: (text: string, keyboard: unknown) => Promise<any>;
  reply: (text: string, params?: Record<string, unknown>) => Promise<any>;
};

export const formatUserLabel = (user: DoubleUser, mention: boolean): string => {
  return mention && user.id > 0 ? `[id${user.id}|${user.tag}]` : user.tag;
};

const escapeHtml = (value: string): string => {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
};

export const formatContextUserLabel = (context: UnifiedMessageContext): string => {
  const user = context.user;
  if (!user) return "";

  if (user.disable_mentions) {
    if (context.platform === "tg") {
      return escapeHtml(String(user.tag ?? "").trim() || "Игрок");
    }
    return formatUserLabel(user, false);
  }

  if (context.platform === "tg") {
    const label = String(user.tag ?? "").trim() || "Игрок";
    const mentionId =
      typeof context.tgUserId === "number" && Number.isFinite(context.tgUserId)
        ? context.tgUserId
        : typeof user.tgId === "number" && Number.isFinite(user.tgId)
          ? user.tgId
          : null;
    if (mentionId) {
      return `<a href="tg://user?id=${mentionId}">${escapeHtml(label)}</a>`;
    }
    if (context.tgUsername) {
      const username = context.tgUsername.replace(/[^\w]/g, "");
      if (username) return `<a href="https://t.me/${username}">@${username}</a>`;
    }
    return escapeHtml(label);
  }

  const mention = Boolean((context.isChat || !context.isChat) && !user.disable_mentions);
  return formatUserLabel(user, mention);
};

export const botSend = async (
  context: UnifiedMessageContext,
  text: string,
  params?: Record<string, unknown>
): Promise<any> => {
  const label = formatContextUserLabel(context);
  const rawText = String(text ?? "");
  const trimmed = rawText.trimStart();
  const hasLeadingMention = /^(?:\[id\d+\||@id\d+|\*id\d+|@\w{3,32}|<a\s+href=)/i.test(trimmed);
  const prefix = label && !hasLeadingMention ? `${label}, ` : "";
  
  const hasHtmlTags = /<[^>]+>/i.test(rawText);
  const messageText = context.platform === "tg" 
    ? `${prefix}${hasHtmlTags ? rawText : escapeHtml(rawText)}` 
    : `${prefix}${rawText}`;

  return context.send(messageText, {
    disable_mentions: context.platform === "vk" ? 1 : undefined,
    parse_mode: context.platform === "tg" ? "html" : undefined,
    ...params
  });
};

export const botEdit = async (
  context: UnifiedMessageContext,
  text: string,
  params: Record<string, unknown>
): Promise<any> => {
  const rawText = String(text ?? "");

  if (context.platform === "vk") {
    const editMessage = (context.message as any)?.editMessage;
    if (typeof editMessage !== "function") {
      return botSend(context, rawText, params);
    }
    return editMessage.call(context.message, {
      message: rawText,
      ...params
    });
  }

  const messageId = Number(params?.message_id ?? "");
  if (!Number.isFinite(messageId) || messageId <= 0) {
    return botSend(context, rawText, params);
  }

  const tgApi = context.tgService?.getAPI();
  if (!tgApi) {
    return botSend(context, rawText, params);
  }

  const keyboard = params?.keyboard;
  const hasHtmlTags = /<[^>]+>/i.test(rawText);
  const normalizedText = normalizeTelegramText(hasHtmlTags ? rawText : escapeHtml(rawText));

  return tgApi.editMessageText({
    chat_id: context.peerId,
    message_id: messageId,
    text: normalizedText,
    parse_mode: params?.parse_mode as "html" | "HTML" | "markdown" | "MarkdownV2" | undefined,
    reply_markup: keyboard ? vkKeyboardToTelegramMarkup(keyboard) : undefined
  } as any);
};

export abstract class GameMode {
  abstract readonly id: string;
  abstract readonly commands: CommandDefinition<UnifiedMessageContext>[];

  abstract attach(
    registry: CommandRegistry<UnifiedMessageContext>,
    clients: VkClients,
    telegram?: any
  ): void;
}
