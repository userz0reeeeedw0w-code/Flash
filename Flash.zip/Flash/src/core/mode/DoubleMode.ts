import { GameMode, UnifiedMessageContext } from "./GameMode";
import { CommandDefinition } from "../command/Command";
import { CommandRegistry } from "../command/CommandRegistry";
import { VkClients } from "../../services/VkClient";
import { JsonDatabase } from "../../services/JsonDatabase";
import { BotConfig } from "../../types/config";
import { DoubleChat, DoubleUser, DoubleGame, DoubleGameMultiplier } from "../../types/database";
import { pick, randomString, formatWithSpaces } from "../../utils/number";
import { updateGameStats } from "../../utils/gameStats";
import md5 from "js-md5";
import { doubleCreateCommand, doubleConfirmCreateCommand } from "../../commands/double/create";
import { doubleBetCommand } from "../../commands/double/bet";
import { doubleUpdateKeyboardCommand } from "../../commands/double/updateKeyboard";
import { doubleBankCommand } from "../../commands/double/bank";
import { TelegramService } from "../../services/TelegramService";
import { normalizeTelegramText, vkKeyboardToTelegramMarkup } from "../../utils/telegram";
import { readFileSync } from "fs";
import { join } from "path";

interface DoubleModeDependencies {
    usersDb: JsonDatabase<DoubleUser[]>;
    chatsDb: JsonDatabase<DoubleChat[]>;
    config: BotConfig;
    telegramService?: TelegramService;
}

export class DoubleMode extends GameMode {
    readonly id = "double";
    readonly commands: CommandDefinition<UnifiedMessageContext>[];
    private readonly dependencies: DoubleModeDependencies;
    private clients?: VkClients;
    private telegramService?: TelegramService;
    private telegramToken: string | null = null;
    private readonly imagesPath = "/root/flash/images/double";
    
    private readonly photoMap: Record<number, string> = {
        2: 'photo-212896919_457298287',
        3: 'photo-212896919_457298288',
        5: 'photo-212896919_457298283',
        50: 'photo-212896919_457298281'
    };

    constructor(dependencies: DoubleModeDependencies) {
        super();
        this.dependencies = dependencies;
        this.commands = [
            doubleCreateCommand,
            doubleConfirmCreateCommand,
            doubleUpdateKeyboardCommand,
            doubleBetCommand,
            doubleBankCommand
        ];
    }

    attach(registry: CommandRegistry<UnifiedMessageContext>, clients: VkClients, telegramService?: TelegramService): void {
        this.clients = clients;
        this.telegramService = telegramService;
        this.telegramToken = process.env.TG_TOKEN || null;

        if (this.commands.length > 0) {
            registry.registerMany(this.commands);
        }
        this.startLoop();
    }

    private async sendTelegramText(chatId: number, message: string, replyMarkup?: any): Promise<void> {
        if (!this.telegramToken) return;
        try {
            const response = await fetch(`https://api.telegram.org/bot${this.telegramToken}/sendMessage`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    chat_id: chatId,
                    text: normalizeTelegramText(message),
                    reply_markup: replyMarkup,
                    parse_mode: 'HTML'
                })
            });
            const apiResult = await response.json();
            if (!apiResult.ok) {
                console.error('[DoubleMode] Telegram sendMessage error:', apiResult.description);
            }
        } catch (error) {
            console.error('[DoubleMode] Telegram sendMessage failed:', (error as Error).message);
        }
    }

    private async sendTelegramPhoto(chatId: number, multiplier: number, caption: string, replyMarkup?: any): Promise<void> {
        if (!this.telegramToken) return;

        const imagePath = join(this.imagesPath, `${multiplier}.jpg`);
        let imageBuffer: Buffer;

        try {
            imageBuffer = readFileSync(imagePath);
        } catch (error) {
            console.error(`[DoubleMode] Image not found: ${imagePath}`);
            await this.sendTelegramText(chatId, caption, replyMarkup);
            return;
        }
        const formData = new FormData();
        formData.append('chat_id', chatId.toString());
        formData.append('photo', new Blob([new Uint8Array(imageBuffer)], { type: 'image/jpeg' }), `${multiplier}.jpg`);
        formData.append('caption', normalizeTelegramText(caption));
        formData.append('parse_mode', 'HTML');
        if (replyMarkup) {
            formData.append('reply_markup', JSON.stringify(replyMarkup));
        }

        try {
            const response = await fetch(`https://api.telegram.org/bot${this.telegramToken}/sendPhoto`, {
                method: 'POST',
                body: formData
            });
            const apiResult = await response.json();
            if (!apiResult.ok) {
                console.error('[DoubleMode] Telegram sendPhoto error:', apiResult.description);
                await this.sendTelegramText(chatId, caption, replyMarkup);
            }
        } catch (error) {
            console.error('[DoubleMode] Telegram sendPhoto failed:', (error as Error).message);
            await this.sendTelegramText(chatId, caption, replyMarkup);
        }
    }

    private async sendChatMessage(
        chat: DoubleChat,
        message: string,
        options?: { keyboard?: string; attachment?: string; result?: number }
    ): Promise<void> {
        if (!this.clients) return;

        try {
            const isTelegramChat = chat.id < 0;

            if (isTelegramChat) {
                if (!this.telegramToken) return;
                const replyMarkup = options?.keyboard ? vkKeyboardToTelegramMarkup(options.keyboard) : undefined;

                if (options?.result !== undefined) {
                    await this.sendTelegramPhoto(chat.id, options.result, message, replyMarkup);
                } else {
                    await this.sendTelegramText(chat.id, message, replyMarkup);
                }
                return;
            }

            const sendOptions: any = {
                chat_id: chat.id,
                message: message,
                random_id: 0
            };

            if (options?.keyboard) {
                sendOptions.keyboard = options.keyboard;
            }

            if (options?.result !== undefined) {
                const vkAttachment = this.photoMap[options.result];
                if (vkAttachment) {
                    sendOptions.attachment = vkAttachment;
                }
            } else if (options?.attachment) {
                sendOptions.attachment = options.attachment;
            }

            await this.clients.group.api.messages.send(sendOptions);
        } catch (error) {
            console.error('[DoubleMode] sendChatMessage error:', (error as Error).message);
        }
    }

    private startLoop(): void {
        const tick = async (): Promise<void> => {
            try {
                const chats = this.dependencies.chatsDb.load();
                const doubleChats = chats.filter(c => c.type === 1);

                if (doubleChats.length === 0) {
                    setTimeout(tick, 5000);
                    return;
                }

                for (const chat of doubleChats) {
                    await this.processChat(chat);
                }

                this.dependencies.chatsDb.save(chats);
                setTimeout(tick, 1000);
            } catch (error) {
                console.error('[DoubleMode] startLoop error:', (error as Error).message);
                setTimeout(tick, 5000);
            }
        };
        void tick();
    }

    private buildGameResult(chatId: number): DoubleGameMultiplier {
        if (chatId === 96) {
            return pick([2, 3, 5, 5, 50, 3, 3, 2, 5, 2, 5, 2, 3, 3, 5, 2, 2, 2, 2, 2, 2, 3, 3, 3, 5, 50, 5, 5, 5, 2, 3, 50, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 5, 2, 5, 5, 5, 2, 2, 3, 2, 2, 5, 50]);
        }
        return pick([2, 2, 2, 2, 2, 5, 2, 2, 5, 2, 2, 3, 3, 3, 5, 3, 5, 3, 3, 50, 3, 2, 2, 2, 3, 2, 2, 5, 3, 3, 2, 3, 3, 2, 2, 2, 5, 5, 3, 3, 3, 3, 2, 5, 2, 2, 2, 2]);
    }

    private async processChat(chat: DoubleChat): Promise<void> {
        if (!this.clients) return;

        try {
            if (!chat.game || chat.games.length === 0) {
                const result = this.buildGameResult(chat.id);
                const salt = randomString(18);
                const proverka = `${result}|${salt}`;
                const hash = md5(proverka);

                chat.games.push({
                    result,
                    stavka: true,
                    hash,
                    proverka,
                    stavki: []
                } as DoubleGame);

                chat.gametime = 60;
                chat.game = true;

                if (chat.games.length > 4) {
                    chat.games = chat.games.slice(chat.games.length - 4);
                }
                return;
            }

            const currentGame = chat.games[chat.games.length - 1] as DoubleGame;

            if (currentGame.stavki.length === 0) {
                chat.gametime = 60;
                currentGame.stavka = true;
                return;
            }

            chat.gametime--;

            if (chat.gametime === 5) {
                currentGame.stavka = false;
                await this.sendChatMessage(chat, "До конца раунда осталось менее пяти секунд, ставки не принимаются");
            }

            if (chat.gametime === 2) {
                await this.sendChatMessage(chat, "Итак, результаты раунда...");
            }

            if (chat.gametime !== 0) return;

            chat.game = false;
            const users = this.dependencies.usersDb.load();
            let text = "";
            const sorted = [...currentGame.stavki].sort((a, b) => a.type - b.type);

            for (const stake of sorted) {
                const user = users.find(u => u.id === stake.id);
                if (!user) continue;

                if (stake.type === currentGame.result) {
                    const winAmount = stake.amount * stake.type;
                    user.balance += winAmount;
                    user.winnings = (user.winnings || 0) + winAmount;
                    updateGameStats(user, "win");
                    text += `✅ [id${user.id}|${user.tag}] ставка ${formatWithSpaces(stake.amount)} на x${stake.type} выиграла! (приз ${formatWithSpaces(winAmount)} FP)\n`;
                } else {
                    updateGameStats(user, "lose");
                    text += `❌ [id${user.id}|${user.tag}] ставка ${formatWithSpaces(stake.amount)} на x${stake.type} проиграла\n`;
                }
            }

            this.dependencies.usersDb.save(users);

            const provUrl = `https://www.gigacalculator.com/calculators/md5-online-generator.php?instring=${encodeURIComponent(currentGame.proverka)}`;

            await this.sendChatMessage(
                chat,
                `Выпал множитель x${currentGame.result}\n\n${text}\n\nХеш игры: ${currentGame.hash}\nПроверка честности: ${currentGame.proverka}`,
                {
                    result: currentGame.result,
                    keyboard: JSON.stringify({
                        inline: true,
                        buttons: [[{
                            action: {
                                type: "open_link",
                                link: provUrl,
                                label: "Проверить результат!"
                            }
                        }]]
                    })
                }
            );
        } catch (error) {
            console.error('[DoubleMode] processChat error:', (error as Error).message);
        }
    }
}