import { CommandRegistry } from "../core/command/CommandRegistry";
import { UnifiedMessageContext, VkMessageState } from "../core/mode/GameMode";
import { JsonDatabase } from "../services/JsonDatabase";
import { BotConfig } from "../types/config";
import { DoubleChat, DoubleUser, Limits } from "../types/database";
import { VkClients } from "../services/VkClient";
import { TelegramService } from "../services/TelegramService";
import { Logger } from "../utils/logger";
import { normalizeTelegramText, parseTelegramCallbackData, vkKeyboardToTelegramMarkup } from "../utils/telegram";
import type { MessageContext, CallbackQueryContext } from "puregram";

interface TelegramMessageHandlerDependencies {
  telegramService: TelegramService;
  registry: CommandRegistry<UnifiedMessageContext>;
  config: BotConfig;
  chatsDb: JsonDatabase<DoubleChat[]>;
  usersDb: JsonDatabase<DoubleUser[]>;
  limitsDb: JsonDatabase<Limits>;
  vkClients: VkClients;
}

const normalizeTelegramCommand = (text: string): string => {
  const raw = String(text ?? "").trim();
  if (!raw) return "";
  if (!raw.startsWith("/")) return raw;
  
  const [head, ...rest] = raw.split(/\s+/);
  const command = head.slice(1).split("@")[0];
  if (!command) return "";
  
  return [command, ...rest].join(" ").trim();
};

const isGroupChat = (type: string): boolean => {
  return type === "group" || type === "supergroup";
};

const generateRequestId = (): string => {
  return `tg_${Date.now()}_${Math.random().toString(36).substring(7)}`;
};

const resolveTelegramBotLink = (): string => {
  const direct = String(process.env.TG_BOT_LINK ?? "").trim();
  if (direct) return direct;
  const username = String(process.env.TG_BOT_USERNAME ?? "").trim().replace(/^@/, "");
  if (username) return `https://t.me/${username}`;
  return "";
};

const resolveVkBotLink = (config: BotConfig): string => {
  return `https://vk.com/club${Math.abs(config.vk.groupId)}`;
};

const findTelegramUser = (users: DoubleUser[], tgUser: any): DoubleUser | undefined => {
  const tgId = tgUser.id;
  return users.find(u => u.tgId === tgId);
};

const upsertTelegramIdentity = (user: DoubleUser, tgUser: any): void => {
  const tgId = tgUser.id;
  const fullName = `${tgUser.first_name || ""} ${tgUser.last_name || ""}`.trim();
  const normalizedTag = user?.tag || fullName || tgUser.username || `User${tgId}`;
  user.tgId = tgId;
  user.tag = normalizedTag;
  if (tgUser.username) {
    user.tgUsername = tgUser.username;
  } else {
    user.tgUsername = undefined;
  }
};

const createTelegramUser = (users: DoubleUser[], tgUser: any): DoubleUser => {
  const tgId = tgUser.id;
  const fullName = `${tgUser.first_name || ""} ${tgUser.last_name || ""}`.trim();
  const normalizedTag = fullName || tgUser.username || `User${tgId}`;
  const user = {
    id: tgId,
    uid: users.length,
    balance: 1000,
    tag: normalizedTag,
    regDate: Date.now(),
    bonustime: 0,
    lastbet: 0,
    uvedu: true,
    donate_rub: 0,
    ref_bonus: 0,
    refCount: 0,
    limit: 0,
    permiss: {},
    tgId,
    tgUsername: tgUser.username || undefined
  } as DoubleUser;
  users.push(user);
  return user;
};

const isCreateProfileCommand = (text: string): boolean => {
  return /^(?:регистрация\s+создать|создать\s+профиль|создать)$/i.test(text);
};

const isBindVkCommand = (text: string): boolean => {
  return /^(?:регистрация\s+привязать\s+вк|привязать\s+вк|привязать)$/i.test(text);
};

const getStartCode = (text: string): string => {
  const match = text.match(/^(?:start|\/start)\s+([A-Za-z0-9_]+)$/i);
  return String(match?.[1] ?? "").trim().toUpperCase();
};

const addPendingReferral = (users: DoubleUser[], referrerUid: number, newUserUid: number, newUserId: number, platform: "vk" | "tg"): boolean => {
  const referrer = users.find(u => u.uid === referrerUid);
  const newUser = users.find(u => u.uid === newUserUid);

  if (!referrer || !newUser) return false;

  if (!referrer.referrals) {
    referrer.referrals = [];
  }

  if (referrer.referrals.some(r => r.uid === newUserUid)) {
    return false;
  }

  referrer.referrals.push({
    uid: newUserUid,
    id: newUserId,
    addedAt: Date.now(),
    platform,
    confirmed: false
  });

  newUser.referrerUid = referrerUid;

  return true;
};

const updateUserActivity = (users: DoubleUser[], uid: number): void => {
  const user = users.find(u => u.uid === uid);
  if (user) {
    user.lastActiveAt = Date.now();
  }
};

const findOrCreateChat = (chats: DoubleChat[], chatId: number, chatTitle: string): { chat: DoubleChat; isNew: boolean } => {
  let chat = chats.find(c => c.id === chatId);
  let isNew = false;

  if (!chat) {
    chat = {
      uid: chats.length,
      id: chatId,
      name: chatTitle || "Telegram Chat",
      lvl: 0,
      give: 0,
      uvedu: true,
      podarok: 0,
      newpodarok: 0,
      attachment: "",
      type: 0,
      start: false,
      gametime: 60,
      game: false,
      games: []
    } as DoubleChat;

    chats.push(chat);
    isNew = true;
  }

  return { chat, isNew };
};

const createUnifiedContext = (
  tgContext: MessageContext | CallbackQueryContext,
  isCallbackQuery: boolean,
  user: DoubleUser,
  chat: DoubleChat | undefined,
  isChat: boolean,
  commandText: string,
  state: VkMessageState,
  payload: Record<string, unknown> | null,
  telegramService: TelegramService,
  vkClients: VkClients,
  requestId: string
): UnifiedMessageContext => {
  const message = isCallbackQuery ? (tgContext as CallbackQueryContext).message : (tgContext as MessageContext);
  const chatId = message?.chat?.id || 0;
  const userId = message?.from?.id || 0;
  const api = telegramService.getTelegram().api;
  const tgCompat = {
    sendMessage: async (
      targetChatId: number,
      text: string,
      params?: {
        reply_markup?: unknown;
        disable_web_page_preview?: boolean;
        reply_to_message_id?: number;
        parse_mode?: "html" | "HTML" | "markdown" | "MarkdownV2";
      }
    ): Promise<void> => {
      await api.sendMessage({
        chat_id: targetChatId,
        text: normalizeTelegramText(text),
        reply_markup: params?.reply_markup,
        disable_web_page_preview: params?.disable_web_page_preview,
        reply_to_message_id: params?.reply_to_message_id,
        parse_mode: params?.parse_mode
      } as any);
    },
    getChatMember: async (targetChatId: number, targetUserId: number): Promise<any | null> => {
      try {
        return await api.getChatMember({
          chat_id: targetChatId,
          user_id: targetUserId
        } as any);
      } catch {
        return null;
      }
    }
  };

  return {
    peerId: chatId,
    senderId: user.id,
    isChat,
    platform: "tg",
    text: commandText,
    requestId,
    vkContext: undefined,
    vk: vkClients.group,
    message: message as any,
    chatId,
    tgContext: isCallbackQuery ? undefined : (tgContext as MessageContext),
    tgService: telegramService,
    tgUserId: userId,
    tgUsername: message?.from?.username,
    tg: tgCompat as any,
    chat,
    user,
    state,
    payload,

    send: async (text: string, params?: Record<string, unknown>) => {
      try {
        await tgCompat.sendMessage(chatId, text, {
          reply_markup: params?.keyboard ? vkKeyboardToTelegramMarkup(params.keyboard) : undefined,
          disable_web_page_preview: params?.disable_web_page_preview as boolean | undefined,
          parse_mode: params?.parse_mode as "html" | "HTML" | "markdown" | "MarkdownV2" | undefined
        });
      } catch (error) {
        throw new Error(`Failed to send Telegram message: ${error}`);
      }
    },

    sendWithKeyboard: async (text: string, keyboard: unknown) => {
      try {
        await tgCompat.sendMessage(chatId, text, {
          reply_markup: vkKeyboardToTelegramMarkup(keyboard)
        });
      } catch (error) {
        throw new Error(`Failed to send Telegram message with keyboard: ${error}`);
      }
    },

    reply: async (text: string, params?: Record<string, unknown>) => {
      try {
        const messageId = (message as any)?.message_id || (message as any)?.id;
        await tgCompat.sendMessage(chatId, text, {
          reply_to_message_id: messageId,
          reply_markup: params?.keyboard ? vkKeyboardToTelegramMarkup(params.keyboard) : undefined,
          disable_web_page_preview: params?.disable_web_page_preview as boolean | undefined,
          parse_mode: params?.parse_mode as "html" | "HTML" | "markdown" | "MarkdownV2" | undefined
        } as any);
      } catch (error) {
        throw new Error(`Failed to reply to Telegram message: ${error}`);
      }
    }
  };
};

const calculateReward = (minutesSincePublished: number): { rewardFp: number; rewardDonate: number } => {
  const MAX_REWARD = 100000;
  const MIN_REWARD = 3000;
  
  if (minutesSincePublished <= 5) {
    return { rewardFp: MAX_REWARD, rewardDonate: 5 };
  } else if (minutesSincePublished <= 60) {
    const decayMinutes = minutesSincePublished - 5;
    const totalDecayRange = 55;
    const rewardRange = MAX_REWARD - MIN_REWARD;
    const decayFactor = Math.max(0, 1 - (decayMinutes / totalDecayRange));
    const rewardFp = Math.floor(MIN_REWARD + (rewardRange * decayFactor));
    return { rewardFp, rewardDonate: 0 };
  } else if (minutesSincePublished <= 24 * 60) {
    return { rewardFp: MIN_REWARD, rewardDonate: 0 };
  }
  return { rewardFp: 0, rewardDonate: 0 };
};

const sendRewardNotification = async (
  clients: VkClients,
  userId: number,
  user: DoubleUser,
  rewardFp: number,
  rewardDonate: number,
  minutesSincePublished: number
): Promise<void> => {
  if (!user.uvedu || !clients.group) return;
  
  try {
    let rewardMessage = `❤️ Спасибо за реакцию!\n\n`;
    
    if (minutesSincePublished <= 5) {
      rewardMessage += `🔥 ГОРЯЧИЙ ПОСТ! Максимальная награда!\n`;
    } else if (minutesSincePublished <= 60) {
      const percent = Math.floor((rewardFp / 100000) * 100);
      rewardMessage += `⏱️ Пост ещё свежий! Награда: ${percent}% от максимума\n`;
    } else {
      rewardMessage += `📌 Стандартная награда\n`;
    }
    
    rewardMessage += `\n💰 Награда: +${new Intl.NumberFormat('ru-RU').format(rewardFp)} FP`;
    
    if (rewardDonate > 0) {
      rewardMessage += `\n💎 Донат-рубли: +${rewardDonate}`;
    }
    
    await clients.group.api.messages.send({
      user_id: userId,
      random_id: 0,
      message: rewardMessage
    }).catch(() => undefined);
  } catch {}
};

const processedReactions = new Map<string, number>();

setInterval(() => {
  const now = Date.now();
  for (const [key, timestamp] of processedReactions.entries()) {
    if (now - timestamp > 24 * 60 * 60 * 1000) {
      processedReactions.delete(key);
    }
  }
}, 60 * 60 * 1000);

const handleMessageReaction = async (
  deps: TelegramMessageHandlerDependencies,
  update: any
): Promise<void> => {
  const logger = new Logger("TelegramReaction");
  
  try {
    const targetChatId = -1003635924096;
    
    if (update.chat_id !== targetChatId) {
      return;
    }
    
    const limits = deps.limitsDb.load();
    const isActive = Boolean(limits.like?.active);
    const give = typeof limits.like?.give === "number" && Number.isFinite(limits.like.give) ? limits.like.give : 0;
    
    if (!isActive || give <= 0) {
      return;
    }
    
    const userId = update.user_id;
    const messageId = update.message_id;
    const newReactions = update.new_reactions || [];
    const oldReactions = update.old_reactions || [];
    
    const addedReaction = newReactions.find((r: any) => 
      !oldReactions.some((o: any) => o.type === r.type) && r.type === "❤"
    );
    
    if (!addedReaction) {
      return;
    }
    
    const reactionKey = `${messageId}_${userId}`;
    
    if (processedReactions.has(reactionKey)) {
      return;
    }
    
    let publishedAt: number;
    try {
      const message = await deps.telegramService.getTelegram().api.getChatMessage({
        chat_id: targetChatId,
        message_id: messageId
      } as any);
      
      publishedAt = message.date * 1000;
    } catch (error) {
      logger.error("Failed to get message date", error);
      return;
    }
    
    const currentTime = Date.now();
    const MAX_POST_AGE_MS = 24 * 60 * 60 * 1000;
    const timeSincePublished = currentTime - publishedAt;
    
    if (timeSincePublished > MAX_POST_AGE_MS) {
      return;
    }
    
    const minutesSincePublished = timeSincePublished / (60 * 1000);
    const { rewardFp, rewardDonate } = calculateReward(minutesSincePublished);
    
    if (rewardFp <= 0) {
      return;
    }
    
    const users = deps.usersDb.load();
    const user = users.find(u => u.tgId === userId);
    
    if (!user) {
      return;
    }
    
    const postKey = `tg_reaction_${targetChatId}_${messageId}`;
    
    if (user.tgReactionClaims?.[postKey]) {
      return;
    }
    
    user.tgReactionClaims = user.tgReactionClaims ?? {};
    user.tgReactionClaims[postKey] = Date.now();
    
    user.balance += rewardFp;
    if (rewardDonate > 0) {
      user.donate_rub = (user.donate_rub || 0) + rewardDonate;
    }
    
    deps.usersDb.save(users);
    
    processedReactions.set(reactionKey, Date.now());
    
    await sendRewardNotification(deps.vkClients, user.id, user, rewardFp, rewardDonate, minutesSincePublished);
    
    logger.info(`Reward granted to user ${user.id} for reaction on post ${messageId}`);
    
  } catch (error) {
    console.error("Error handling message reaction", error);
  }
};

export const createTelegramMessageHandler = (
  deps: TelegramMessageHandlerDependencies
): { onMessage: (ctx: MessageContext) => Promise<void>; onCallbackQuery: (ctx: CallbackQueryContext) => Promise<void>; onMessageReaction: (update: any) => Promise<void> } => {
  const logger = new Logger("TelegramMessageHandler");

  const handleMessage = async (ctx: MessageContext): Promise<void> => {
    let chats: DoubleChat[] | undefined;
    let users: DoubleUser[] | undefined;

    try {
      if (!ctx.text || (!ctx.chat || ctx.chat.type === "channel")) {
        return;
      }

      const text = normalizeTelegramCommand(ctx.text);
      if (!text) return;

      const fromUser = ctx.from;
      if (!fromUser) return;
      
      const startCode = getStartCode(text);

      const isChat = isGroupChat(ctx.chat.type);
      const chatId = ctx.chat.id;
      const requestId = generateRequestId();

      chats = deps.chatsDb.load();
      users = deps.usersDb.load();

      if (!chats || !users) {
        logger.error("Failed to load database", { chats: Boolean(chats), users: Boolean(users) });
        return;
      }

      let user = findTelegramUser(users, fromUser);
      if (!user) {
        const probeUser = {
          id: fromUser.id,
          uid: -1,
          balance: 0,
          tag: fromUser.firstName || fromUser.username || "User",
          regDate: Date.now(),
          bonustime: 0,
          lastbet: 0,
          donate_rub: 0,
          ref_bonus: 0,
          refCount: 0,
          limit: 0,
          permiss: {},
          tgId: fromUser.id,
          tgUsername: fromUser.username || undefined
        } as DoubleUser;
        const probeContext: UnifiedMessageContext = createUnifiedContext(
          ctx,
          false,
          probeUser,
          undefined,
          isChat,
          text,
          { chat: undefined, user: probeUser, chats, users },
          null,
          deps.telegramService,
          deps.vkClients,
          `${requestId}_probe`
        );
        const hasCommandIntent =
          Boolean(getStartCode(text)) ||
          isCreateProfileCommand(text) ||
          isBindVkCommand(text) ||
          Boolean(deps.registry.resolve(probeContext));
        if (!hasCommandIntent) {
          return;
        }

        const linkCode = getStartCode(text);
        if (linkCode) {
          logger.debug(`Raw start code: ${linkCode}`);
          const isRefLink = linkCode.startsWith("REF_");
          
          if (isRefLink) {
            const referrerUid = Number(linkCode.substring(4));
            logger.debug(`Detected ref link! Referrer UID: ${referrerUid}`);
            if (Number.isFinite(referrerUid)) {
              user = createTelegramUser(users, fromUser);
              upsertTelegramIdentity(user, fromUser);
              
              deps.usersDb.save(users);
              
              if (addPendingReferral(users, referrerUid, user.uid, user.id, "tg")) {
                deps.usersDb.save(users);
              }
              
              await ctx.send(
                "👋 Профиль создан ✅\n" +
                "💸 Стартовый баланс: 1 000 FP\n" +
                "👥 Вы присоединились по реф ссылке!\n" +
                "📖 Команды: помощь"
              );
              return;
            }
          }
          
          const now = Date.now();
          const target = users.find(
            entry =>
              typeof entry.tgLinkCode === "string" &&
              entry.tgLinkCode.toUpperCase() === linkCode &&
              typeof entry.tgLinkExpires === "number" &&
              entry.tgLinkExpires > now
          );
          if (!target) {
            await ctx.send("Неверный или просроченный код. Получите новый код в VK командой tg.");
            return;
          }
          const existing = users.find(entry => entry.tgId === fromUser.id && entry.id !== target.id);
          if (existing) {
            existing.tgId = undefined;
            existing.tgUsername = undefined;
          }
          target.tgId = fromUser.id;
          target.tgUsername = fromUser.username || undefined;
          target.tgLinkCode = undefined;
          target.tgLinkExpires = undefined;
          await ctx.send("Аккаунт VK привязан к Telegram ✅");
          return;
        }

        if (isChat) {
          const tgLink = resolveTelegramBotLink();
          await ctx.send(
            "Чтобы играть, сначала зарегистрируйтесь в личных сообщениях с ботом.\n" +
            (tgLink ? `ЛС бота: ${tgLink}` : "Откройте ЛС бота и напишите /start")
          );
          return;
        }

        if (isCreateProfileCommand(text)) {
          user = createTelegramUser(users, fromUser);
          upsertTelegramIdentity(user, fromUser);
          
          if (startCode && startCode.startsWith("REF_")) {
            const referrerUid = Number(startCode.substring(4));
            if (Number.isFinite(referrerUid) && referrerUid > 0) {
              deps.usersDb.save(users);
              if (addPendingReferral(users, referrerUid, user.uid, user.id, "tg")) {
                deps.usersDb.save(users);
              }
              await ctx.send(
                "👋 Профиль создан ✅\n" +
                "💸 Стартовый баланс: 1 000 FP\n" +
                "👥 Вы присоединились по реф ссылке!\n" +
                "📖 Команды: помощь"
              );
              deps.usersDb.save(users);
              return;
            }
          }
          
          await ctx.send(
            "👋 Профиль создан ✅\n" +
            "💸 Стартовый баланс: 1 000 FP\n" +
            "📖 Команды: помощь"
          );
          deps.usersDb.save(users);
          return;
        }

        if (isBindVkCommand(text)) {
          await ctx.send(
            "Для привязки VK:\n" +
            `1) Откройте VK-бота: ${resolveVkBotLink(deps.config)}\n` +
            "2) Отправьте команду: tg\n" +
            "3) Пришлите сюда: /start КОД"
          );
          return;
        }

        await ctx.send("👋 Добро пожаловать! Выберите, как начать:", {
          reply_markup: {
            inline_keyboard: [
              [{ text: "🔗 Привязать VK", callback_data: JSON.stringify({ command: "регистрация привязать вк" }) }],
              [{ text: "🆕 Создать новый профиль", callback_data: JSON.stringify({ command: "регистрация создать" }) }]
            ]
          }
        } as any);
        return;
      }
      upsertTelegramIdentity(user, fromUser);
      let chat: DoubleChat | undefined;
      let isNewChat = false;
      if (isChat) {
        const result = findOrCreateChat(chats, chatId, ctx.chat.title || "Telegram Chat");
        chat = result.chat;
        isNewChat = result.isNew;
      }

      const state: VkMessageState = { chat, user, chats, users };
      if (isNewChat) {
        try {
          await ctx.send(
            "👋 Привет! Бот активирован в этом чате.\n\n" +
            "⚡ Быстрый старт:\n" +
            "1️⃣ Дайте боту права администратора\n" +
            "2️⃣ Напишите: игра создать\n" +
            "3️⃣ Подтвердите: игра.уверен\n\n" +
            "📖 Команды: помощь"
          );
        } catch (error) {
          logger.error("Failed to send welcome message to new chat", error);
        }
      }

      const context: UnifiedMessageContext = createUnifiedContext(
        ctx,
        false,
        user,
        chat,
        isChat,
        text,
        state,
        null,
        deps.telegramService,
        deps.vkClients,
        requestId
      );

      const resolved = deps.registry.resolve(context);
      if (!resolved) {
        return;
      }

      context.match = resolved.match;
      
      updateUserActivity(users, user.uid);
      
      await resolved.command.handler(context);
      deps.usersDb.save(users);
    } catch (error) {
      logger.error("Error handling Telegram message", error);
      try {
        await ctx.send("❌ Ошибка при выполнении команды.");
      } catch (sendError) {
        logger.error("Failed to send error message", sendError);
      }
    } finally {
      if (chats && users) {
        try {
          deps.chatsDb.save(chats);
          deps.usersDb.save(users);
        } catch (saveError) {
          logger.error("Error saving database changes", saveError);
        }
      }
    }
  };

  const handleCallbackQuery = async (ctx: CallbackQueryContext): Promise<void> => {
    let chats: DoubleChat[] | undefined;
    let users: DoubleUser[] | undefined;

    try {
      const message = ctx.message;
      if (!message || !message.chat) {
        await ctx.answerCallbackQuery({ text: "Message not found", show_alert: true });
        return;
      }

      const parsedCallback = parseTelegramCallbackData(ctx.data);
      const text = normalizeTelegramCommand(parsedCallback.commandText);
      if (!text) {
        await ctx.answerCallbackQuery({ text: "Command not found" });
        return;
      }

      const fromUser = ctx.from;
      if (!fromUser) {
        await ctx.answerCallbackQuery({ text: "User not found", show_alert: true });
        return;
      }

      const isChat = isGroupChat(message.chat.type);
      const chatId = message.chat.id;
      const requestId = generateRequestId();
      const startCode = getStartCode(text);

      chats = deps.chatsDb.load();
      users = deps.usersDb.load();

      if (!chats || !users) {
        logger.error("Failed to load database", { chats: Boolean(chats), users: Boolean(users) });
        await ctx.answerCallbackQuery({ text: "Database error", show_alert: true });
        return;
      }

      let user = findTelegramUser(users, fromUser);
      if (!user) {
        if (isChat) {
          await ctx.answerCallbackQuery({ text: "Сначала зарегистрируйтесь в ЛС бота", show_alert: true });
          return;
        }

        if (isCreateProfileCommand(text)) {
          logger.debug(`Creating profile via callback, startCode: ${startCode}`);
          user = createTelegramUser(users, fromUser);
          upsertTelegramIdentity(user, fromUser);
          
          if (startCode && startCode.startsWith("REF_")) {
            const referrerUid = Number(startCode.substring(4));
            logger.debug(`Detected ref link in callback! Referrer UID: ${referrerUid}`);
            if (Number.isFinite(referrerUid) && referrerUid > 0) {
              deps.usersDb.save(users);
              if (addPendingReferral(users, referrerUid, user.uid, user.id, "tg")) {
                deps.usersDb.save(users);
              }
              await deps.telegramService.getTelegram().api.sendMessage({
                chat_id: chatId,
                text: "👋 Профиль создан ✅\n💸 Стартовый баланс: 1 000 FP\n👥 Вы присоединились по реф ссылке!\n📖 Команды: помощь"
              } as any);
              await ctx.answerCallbackQuery({ text: "Профиль создан" });
              return;
            }
          }
          
          await deps.telegramService.getTelegram().api.sendMessage({
            chat_id: chatId,
            text: "👋 Профиль создан ✅\n💸 Стартовый баланс: 1 000 FP\n📖 Команды: помощь"
          } as any);
          deps.usersDb.save(users);
          await ctx.answerCallbackQuery({ text: "Профиль создан" });
          return;
        }

        if (isBindVkCommand(text)) {
          await deps.telegramService.getTelegram().api.sendMessage({
            chat_id: chatId,
            text:
              "Для привязки VK:\n" +
              `1) Откройте VK-бота: ${resolveVkBotLink(deps.config)}\n` +
              "2) Отправьте команду: tg\n" +
              "3) Пришлите сюда: /start КОД"
          } as any);
          await ctx.answerCallbackQuery({ text: "Отправил инструкцию" });
          return;
        }

        await ctx.answerCallbackQuery({ text: "Сначала зарегистрируйтесь", show_alert: true });
        return;
      }
      upsertTelegramIdentity(user, fromUser);

      let chat: DoubleChat | undefined;
      if (isChat) {
        chat = chats.find(c => c.id === chatId);
      }

      const state: VkMessageState = { chat, user, chats, users };
      const payload = {
        ...parsedCallback.payload,
        callback_query_id: ctx.id
      };

      const context: UnifiedMessageContext = createUnifiedContext(
        ctx,
        true,
        user,
        chat,
        isChat,
        text,
        state,
        payload,
        deps.telegramService,
        deps.vkClients,
        requestId
      );

      const resolved = deps.registry.resolve(context);
      if (!resolved) {
        await ctx.answerCallbackQuery({ text: "Command not found" });
        return;
      }

      context.match = resolved.match;
      
      updateUserActivity(users, user.uid);
      
      await resolved.command.handler(context);
      deps.usersDb.save(users);
      await ctx.answerCallbackQuery();
    } catch (error) {
      logger.error("Error handling Telegram callback query", error);
      try {
        await ctx.answerCallbackQuery({ text: "Error executing command", show_alert: true });
      } catch (answerError) {
        logger.error("Failed to answer callback query", answerError);
      }
    } finally {
      if (chats && users) {
        try {
          deps.chatsDb.save(chats);
          deps.usersDb.save(users);
        } catch (saveError) {
          logger.error("Error saving database changes", saveError);
        }
      }
    }
  };

  const onMessageReaction = async (update: any): Promise<void> => {
    await handleMessageReaction(deps, update);
  };

  return { onMessage: handleMessage, onCallbackQuery: handleCallbackQuery, onMessageReaction };
};