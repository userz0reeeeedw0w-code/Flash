import { CommandRegistry } from "../core/command/CommandRegistry";
import { UnifiedMessageContext, VkMessageState } from "../core/mode/GameMode";
import { JsonDatabase } from "../services/JsonDatabase";
import { BotConfig } from "../types/config";
import { DoubleChat, DoubleUser, Limits } from "../types/database";
import { VkClients } from "../services/VkClient";
import { TelegramService } from "../services/TelegramService";
import { Logger } from "../utils/logger";
import { normalizeTelegramText, parseTelegramCallbackData, vkKeyboardToTelegramMarkup } from "../utils/telegram";
import type { MessageContext, CallbackQueryContext } from "puregram";

interface TelegramMessageHandlerDependencies {
    telegramService: TelegramService;
    registry: CommandRegistry<UnifiedMessageContext>;
    config: BotConfig;
    chatsDb: JsonDatabase<DoubleChat[]>;
    usersDb: JsonDatabase<DoubleUser[]>;
    limitsDb: JsonDatabase<Limits>;
    vkClients: VkClients;
}

const TARGET_CHANNEL_ID = -1003635924096;

const normalizeTelegramCommand = (text: string): string => {
    const raw = String(text ?? "").trim();
    if (!raw || !raw.startsWith("/")) return raw;
    const [head, ...rest] = raw.split(/\s+/);
    const command = head.slice(1).split("@")[0];
    return command ? [command, ...rest].join(" ").trim() : "";
};

const isGroupChat = (type: string) => type === "group" || type === "supergroup";
const generateRequestId = () => `tg_${Date.now()}_${Math.random().toString(36).substring(7)}`;
const resolveTelegramBotLink = () => {
    const direct = String(process.env.TG_BOT_LINK ?? "").trim();
    if (direct) return direct;
    const username = String(process.env.TG_BOT_USERNAME ?? "").trim().replace(/^@/, "");
    return username ? `https://t.me/${username}` : "";
};
const resolveVkBotLink = (config: BotConfig) => `https://vk.com/club${Math.abs(config.vk.groupId)}`;

const findOrCreateUser = (users: DoubleUser[], tgUser: any, isChat: boolean): { user: DoubleUser; isNew: boolean } => {
    let user = users.find(u => u.tgId === tgUser.id);
    if (user) {
        user.tag = user.tag || `${tgUser.first_name || ""} ${tgUser.last_name || ""}`.trim() || tgUser.username || `User${tgUser.id}`;
        user.tgUsername = tgUser.username || user.tgUsername;
        return { user, isNew: false };
    }
    if (isChat) return { user: null as any, isNew: false };
    const fullName = `${tgUser.first_name || ""} ${tgUser.last_name || ""}`.trim();
    user = {
        id: tgUser.id, uid: users.length, balance: 1000,
        tag: fullName || tgUser.username || `User${tgUser.id}`,
        regDate: Date.now(), bonustime: 0, lastbet: 0, uvedu: true,
        donate_rub: 0, ref_bonus: 0, refCount: 0, limit: 0, permiss: {},
        tgId: tgUser.id, tgUsername: tgUser.username || undefined
    } as DoubleUser;
    users.push(user);
    return { user, isNew: true };
};

const findOrCreateChat = (chats: DoubleChat[], chatId: number, title: string) => {
    let chat = chats.find(c => c.id === chatId);
    if (!chat) {
        chat = { uid: chats.length, id: chatId, name: title || "Telegram Chat", lvl: 0, give: 0, uvedu: true, podarok: 0, newpodarok: 0, attachment: "", type: 0, start: false, gametime: 60, game: false, games: [] } as DoubleChat;
        chats.push(chat);
    }
    return { chat, isNew: !chat.uid };
};

const createUnifiedContext = (tgCtx: MessageContext | CallbackQueryContext, isCb: boolean, user: DoubleUser, chat: DoubleChat | undefined, isChat: boolean, text: string, state: VkMessageState, payload: any, deps: TelegramMessageHandlerDependencies, reqId: string): UnifiedMessageContext => {
    const msg = isCb ? (tgCtx as CallbackQueryContext).message : (tgCtx as MessageContext);
    const chatId = msg?.chat?.id || 0;
    const api = deps.telegramService.getTelegram().api;
    const tgCompat = {
        sendMessage: (id: number, txt: string, p?: any) => api.sendMessage({ chat_id: id, text: normalizeTelegramText(txt), ...p } as any),
        getChatMember: (id: number, uid: number) => api.getChatMember({ chat_id: id, user_id: uid } as any).catch(() => null)
    };

    return {
        peerId: chatId, senderId: user.id, isChat, platform: "tg", text, requestId: reqId,
        vkContext: undefined, vk: deps.vkClients.group, message: msg as any, chatId,
        tgContext: isCb ? undefined : (tgCtx as MessageContext), tgService: deps.telegramService,
        tgUserId: msg?.from?.id, tgUsername: msg?.from?.username, tg: tgCompat as any,
        chat, user, state, payload,
        send: (txt: string, p?: any) => tgCompat.sendMessage(chatId, txt, { reply_markup: p?.keyboard ? vkKeyboardToTelegramMarkup(p.keyboard) : undefined, disable_web_page_preview: p?.disable_web_page_preview, parse_mode: p?.parse_mode }),
        sendWithKeyboard: (txt: string, kb: any) => tgCompat.sendMessage(chatId, txt, { reply_markup: vkKeyboardToTelegramMarkup(kb) }),
        reply: (txt: string, p?: any) => tgCompat.sendMessage(chatId, txt, { reply_to_message_id: (msg as any)?.message_id || (msg as any)?.id, reply_markup: p?.keyboard ? vkKeyboardToTelegramMarkup(p.keyboard) : undefined, parse_mode: p?.parse_mode })
    };
};

const calculateReward = (minutes: number) => {
    if (minutes <= 2) return { fp: 100000, donate: 5 };
    if (minutes <= 60) {
        const decay = Math.max(0, 1 - ((minutes - 2) / 58));
        return { fp: Math.floor(3000 + (97000 * decay)), donate: 0 };
    }
    if (minutes <= 1440) return { fp: 3000, donate: 0 };
    return { fp: 0, donate: 0 };};

const sendRewardNotification = async (clients: VkClients, userId: number, user: DoubleUser, rewardFp: number, rewardDonate: number, actionType: "реакцию" | "комментарий") => {
    if (!user.uvedu || !clients.group) return;
    try {
        let msg = `${actionType === "реакцию" ? "❤️" : ""} Спасибо за ${actionType}!\n\n +${new Intl.NumberFormat('ru-RU').format(rewardFp)} FP`;
        if (rewardDonate > 0) msg += `\n💎 +${rewardDonate} донат-руб.`;
        await clients.group.api.messages.send({ user_id: userId, random_id: 0, message: msg }).catch(() => undefined);
    } catch {}
};

const processReward = async (deps: TelegramMessageHandlerDependencies, userId: number, postId: number, publishedAt: number, actionType: "reaction" | "comment") => {
    const limits = deps.limitsDb.load();
    if (!limits.like?.active || (limits.like.give ?? 0) <= 0) return;

    const users = deps.usersDb.load();
    const user = users.find(u => u.tgId === userId);
    if (!user) return;

    const claimKey = `tg_${actionType}_${TARGET_CHANNEL_ID}_${postId}`;
    const claimsRecord = actionType === "reaction" ? (user.tgReactionClaims ??= {}) : (user.tgCommentClaims ??= {});
    if (claimsRecord[claimKey]) return;

    const minutes = (Date.now() - publishedAt) / 60000;
    if (minutes > 1440 || minutes < 0) return;

    const { fp: rewardFp, donate: rewardDonate } = calculateReward(minutes);
    if (rewardFp <= 0) return;

    claimsRecord[claimKey] = Date.now();
    user.balance += rewardFp;
    if (rewardDonate > 0) user.donate_rub = (user.donate_rub || 0) + rewardDonate;
    
    deps.usersDb.save(users);
    await sendRewardNotification(deps.vkClients, user.id, user, rewardFp, rewardDonate, actionType === "reaction" ? "реакцию" : "комментарий");
};

const handleMessageReaction = async (deps: TelegramMessageHandlerDependencies, update: any) => {
    if (update.chat_id !== TARGET_CHANNEL_ID) return;
    
    const userId = update.user_id;
    const messageId = update.message_id;
    const newR = update.new_reactions || [];
    const oldR = update.old_reactions || [];

    if (!newR.some((r: any) => r.type === "❤" && !oldR.some((o: any) => o.type === r.type))) return;

    let publishedAt: number;
    try {
        const message: any = await deps.telegramService.getTelegram().api.getChatMessage({ chat_id: TARGET_CHANNEL_ID, message_id: messageId } as any);        if (!message || typeof message.date !== 'number') return;
        publishedAt = message.date * 1000;
    } catch { return; }

    await processReward(deps, userId, messageId, publishedAt, "reaction");
};

const handleComment = async (deps: TelegramMessageHandlerDependencies, ctx: MessageContext) => {
    if (!ctx.text || ctx.text.startsWith('/') || ctx.text.trim().length < 5) return;
    
    const reply = ctx.replyToMessage;
    if (!reply) return;

    const forwardChat = (reply as any).forwardFromChat;
    if (!forwardChat || forwardChat.id !== TARGET_CHANNEL_ID) return;

    const userId = ctx.from?.id;
    if (!userId) return;

    const postId = (reply as any).forwardFromMessageId || reply.id;
    const messageDate = (reply as any).forwardDate || (ctx as any).date || Math.floor(Date.now() / 1000);
    const publishedAt = messageDate * 1000;

    await processReward(deps, userId, postId, publishedAt, "comment");
};

export const createTelegramMessageHandler = (deps: TelegramMessageHandlerDependencies) => {
    const logger = new Logger("TelegramMessageHandler");

    const checkBan = async (user: DoubleUser, ctx: MessageContext | CallbackQueryContext): Promise<boolean> => {
        if (user.ba?.value && (!user.ba.time || user.ba.time > Date.now())) {
            const rem = user.ba.time ? user.ba.time - Date.now() : 0;
            const timeStr = rem > 0 ? `\n⏳ Осталось: ${Math.floor(rem / 3600000)} ч. ${Math.floor((rem % 3600000) / 60000)} мин.` : "";
            const msg = `🚫 Ваш аккаунт заблокирован.${timeStr}`;
            if ('send' in ctx) await (ctx as MessageContext).send(msg).catch(() => undefined);
            else await (ctx as CallbackQueryContext).answerCallbackQuery({ text: msg, show_alert: true }).catch(() => undefined);
            return true;
        }
        if (user.ba) { user.ba.value = false; user.ba.time = 0; }
        return false;
    };

    const handleMessage = async (ctx: MessageContext) => {
        if (!ctx.text || ctx.chat?.type === "channel") return;
        const text = normalizeTelegramCommand(ctx.text);
        if (!text || !ctx.from) return;

        const chats = deps.chatsDb.load();
        const users = deps.usersDb.load();
        const isChat = isGroupChat(ctx.chat.type);        
        const { user } = findOrCreateUser(users, ctx.from, isChat);
        if (!user) {
            await ctx.send(`Чтобы играть, зарегистрируйтесь в ЛС: ${resolveTelegramBotLink() || "откройте ЛС бота и напишите /start"}`);
            return;
        }

        let chat: DoubleChat | undefined;
        if (isChat) {
            const res = findOrCreateChat(chats, ctx.chat.id, ctx.chat.title || "Telegram Chat");
            chat = res.chat;
            if (res.isNew) await ctx.send("👋 Бот активирован! Дайте права админа и напишите: игра создать").catch(() => undefined);
        }

        const state: VkMessageState = { chat, user, chats, users };
        const context = createUnifiedContext(ctx, false, user, chat, isChat, text, state, null, deps, generateRequestId());
        const resolved = deps.registry.resolve(context);
        
        if (!resolved || await checkBan(user, ctx)) return;

        context.match = resolved.match;
        user.lastActiveAt = Date.now();
        
        try {
            await resolved.command.handler(context);
            deps.usersDb.save(users);
            deps.chatsDb.save(chats);
        } catch (error) {
            logger.error("Error handling message", error);
            await ctx.send("❌ Ошибка при выполнении команды.").catch(() => undefined);
        }
    };

    const handleCallbackQuery = async (ctx: CallbackQueryContext) => {
        const msg = ctx.message;
        if (!msg?.chat) { await ctx.answerCallbackQuery({ text: "Message not found", show_alert: true }); return; }
        
        const parsed = parseTelegramCallbackData(ctx.data);
        const text = normalizeTelegramCommand(parsed.commandText);
        if (!text || !ctx.from) { await ctx.answerCallbackQuery({ text: "Invalid data", show_alert: true }); return; }

        const chats = deps.chatsDb.load();
        const users = deps.usersDb.load();
        const isChat = isGroupChat(msg.chat.type);

        const { user } = findOrCreateUser(users, ctx.from, isChat);
        if (!user) {
            await ctx.answerCallbackQuery({ text: "Сначала зарегистрируйтесь в ЛС бота", show_alert: true });
            return;
        }
        const chat = isChat ? chats.find(c => c.id === msg.chat.id) : undefined;
        const state: VkMessageState = { chat, user, chats, users };
        const context = createUnifiedContext(ctx, true, user, chat, isChat, text, state, { ...parsed.payload, callback_query_id: ctx.id }, deps, generateRequestId());
        const resolved = deps.registry.resolve(context);

        if (!resolved || await checkBan(user, ctx)) return;

        context.match = resolved.match;
        user.lastActiveAt = Date.now();

        try {
            await resolved.command.handler(context);
            deps.usersDb.save(users);
            deps.chatsDb.save(chats);
            await ctx.answerCallbackQuery();
        } catch (error) {
            logger.error("Error handling callback", error);
            await ctx.answerCallbackQuery({ text: "Ошибка выполнения", show_alert: true });
        }
    };

    return { 
        onMessage: handleMessage, 
        onCallbackQuery: handleCallbackQuery, 
        onMessageReaction: (update: any) => handleMessageReaction(deps, update),
        onComment: (ctx: MessageContext) => handleComment(deps, ctx)
    };
};