import { Updates } from "vk-io";
import { CommandRegistry } from "../core/command/CommandRegistry";
import { UnifiedMessageContext, VkMessageState } from "../core/mode/GameMode";
import { JsonDatabase } from "../services/JsonDatabase";
import { BotConfig } from "../types/config";
import { DoubleChat, DoubleUser, Limits } from "../types/database";
import { VkClients } from "../services/VkClient";
import { MessageLogService } from "../services/MessageLogService";
import { buildKeyboard } from "../utils/keyboard";
import { TelegramService } from "../services/TelegramService";

interface VkMessageHandlerDependencies {
    updates: Updates;
    registry: CommandRegistry<UnifiedMessageContext>;
    config: BotConfig;
    chatsDb: JsonDatabase<DoubleChat[]>;
    usersDb: JsonDatabase<DoubleUser[]>;
    limitsDb: JsonDatabase<Limits>;
    clients: VkClients;
    telegramService?: TelegramService;
}

export const messageLogService = new MessageLogService();

const dmKeyboard = buildKeyboard({
    oneTime: false,
    buttons: [
        [
            { label: "👤 Профиль", color: "primary", command: "профиль" },
            { label: "💰 Баланс", color: "positive", command: "баланс" }
        ],
        [
            { label: "🏆 Рейтинг", color: "negative", command: "рейтинг" },
            { label: "🎁 Бонус", color: "positive", command: "бонус" }
        ],
        [
            { label: "🃏 21 очко", color: "primary", command: "21" },
            { label: "⬆️ Выше/Ниже", color: "primary", command: "hl" },
            { label: "🎰 Слоты", color: "primary", command: "slots" }
        ],
        [
            { label: "💣 Мины", color: "primary", command: "mines" },
            { label: "💳 Донат", color: "default", command: "донат" },
            { label: "❤️ Лайк", color: "default", command: "лайк" }
        ],
        [
            { label: "ℹ️ Помощь", color: "secondary", command: "помощь" },
            { label: "💬 Беседы", color: "secondary", command: "беседы" }
        ]
    ]});

const addPendingReferral = (users: DoubleUser[], referrerUid: number, newUserUid: number, newUserId: number, platform: "vk" | "tg"): boolean => {
    const referrer = users.find(u => u.uid === referrerUid);
    const newUser = users.find(u => u.uid === newUserUid);
    if (!referrer || !newUser) return false;
    if (!referrer.referrals) referrer.referrals = [];
    if (referrer.referrals.some(r => r.uid === newUserUid)) return false;
    referrer.referrals.push({ uid: newUserUid, id: newUserId, addedAt: Date.now(), platform, confirmed: false });
    newUser.referrerUid = referrerUid;
    return true;
};

const updateUserActivity = (users: DoubleUser[], uid: number): void => {
    const user = users.find(u => u.uid === uid);
    if (user) user.lastActiveAt = Date.now();
};

const calculateReward = (minutesSincePublished: number): { rewardFp: number; rewardDonate: number } => {
    const MAX_REWARD = 100000;
    const MIN_REWARD = 3000;
    if (minutesSincePublished <= 2) return { rewardFp: MAX_REWARD, rewardDonate: 5 };
    if (minutesSincePublished <= 60) {
        const decayMinutes = minutesSincePublished - 2;
        const rewardRange = MAX_REWARD - MIN_REWARD;
        const decayFactor = Math.max(0, 1 - (decayMinutes / 58));
        return { rewardFp: Math.floor(MIN_REWARD + (rewardRange * decayFactor)), rewardDonate: 0 };
    }
    if (minutesSincePublished <= 1440) return { rewardFp: MIN_REWARD, rewardDonate: 0 };
    return { rewardFp: 0, rewardDonate: 0 };
};

const sendRewardNotification = async (clients: VkClients, userId: number, user: DoubleUser, rewardFp: number, rewardDonate: number, type: "like" | "comment"): Promise<void> => {
    if (!user.uvedu || !clients.group) return;
    try {
        const emoji = type === "like" ? "❤️" : "💬";
        let msg = `${emoji} Спасибо за ${type === "like" ? "лайк" : "комментарий"}!\n\n💰 +${new Intl.NumberFormat("ru-RU").format(rewardFp)} FP`;
        if (rewardDonate > 0) msg += `\n💎 +${rewardDonate} донат-руб.`;
        await clients.group.api.messages.send({ user_id: userId, random_id: 0, message: msg }).catch(() => undefined);
    } catch {}
};

const ALLOWED_CLUB_ID = 212896919;
const ALLOWED_TG_BOT = "realflashgamebot";
const ALLOWED_VK_MENTIONS = ["@realflashgame_bot", "@flashh_bot"];

const isAllowedVkLink = (path: string): boolean => {
    const p = path.toLowerCase().trim();
    if (p === `club${ALLOWED_CLUB_ID}`) return true;
    if (/^id\d+$/.test(p)) return true;    if (/^[a-z][a-z0-9_]*$/.test(p) && !p.startsWith("club") && !p.startsWith("page") && !p.includes("/")) return true;
    return false;
};

const hasAdvertisingInText = (text: string): boolean => {
    if (!text || text.trim().length === 0) return false;
    const urlRegex = /https?:\/\/(?:www\.)?([^\s/]+)/gi;
    const urls = text.match(urlRegex);
    if (urls) {
        for (const url of urls) {
            const lower = url.toLowerCase();
            if (lower.includes("vk.com/")) {
                const match = lower.match(/vk\.com\/([^/\s?]+)/);
                if (match && !isAllowedVkLink(match[1])) return true;
            } else if (lower.includes("t.me/")) {
                const match = lower.match(/t\.me\/([^/\s?]+)/);
                if (match && match[1].toLowerCase() !== ALLOWED_TG_BOT) return true;
            } else if (!lower.includes("vk.com")) {
                return true;
            }
        }
    }
    const vkShortRegex = /vk\.com\/([^\s]+)/gi;
    const vkLinks = text.match(vkShortRegex);
    if (vkLinks) {
        for (const link of vkLinks) {
            const match = link.match(/vk\.com\/([^\s/]+)/);
            if (match && !isAllowedVkLink(match[1])) return true;
        }
    }
    const mentionRegex = /@[a-zA-Z0-9_]+/g;
    const mentions = text.match(mentionRegex);
    if (mentions) {
        for (const m of mentions) {
            const isAllowed = ALLOWED_VK_MENTIONS.some(allowed => m.toLowerCase() === allowed.toLowerCase());
            if (!isAllowed) return true;
        }
    }
    return false;
};

const hasAdvertisingInAttachments = (attachments: any[]): boolean => {
    if (!attachments || attachments.length === 0) return false;
    for (const att of attachments) {
        const type = att.type;
        if (type === "audio") continue;
        if (type === "link") {
            const url = att.link?.url || "";
            if (url.includes("vk.com/")) {
                const match = url.match(/vk\.com\/([^/\s?]+)/);                if (match && !isAllowedVkLink(match[1])) return true;
            } else if (url.includes("t.me/")) {
                const match = url.match(/t\.me\/([^/\s?]+)/);
                if (match && match[1].toLowerCase() !== ALLOWED_TG_BOT) return true;
            } else {
                return true;
            }
        }
        if (type === "wall" || type === "wall_reply") {
            const ownerId = att.wall?.owner_id || att.wall_reply?.owner_id;
            if (ownerId && ownerId < 0 && Math.abs(ownerId) !== ALLOWED_CLUB_ID) return true;
        }
        if (type === "video" || type === "doc" || type === "photo") {
            const ownerId = att[type]?.owner_id;
            if (ownerId && ownerId < 0 && Math.abs(ownerId) !== ALLOWED_CLUB_ID) return true;
        }
        if (type === "market" || type === "market_market_group") {
            const ownerId = att.market?.owner_id || att.market_market_group?.owner_id;
            if (ownerId && ownerId < 0 && Math.abs(ownerId) !== ALLOWED_CLUB_ID) return true;
        }
    }
    return false;
};

export const attachVkMessageHandler = (dependencies: VkMessageHandlerDependencies): void => {
    const { updates, registry, chatsDb, usersDb, limitsDb, clients } = dependencies;

    const fetchPostDate = async (ownerId: number, postId: number, eventDate?: number): Promise<number | null> => {
        let ts: number | null = null;
        if (eventDate && eventDate > 0) ts = eventDate < 10000000000 ? eventDate * 1000 : eventDate;
        if (!ts) {
            try {
                const wall = await clients.user?.api.wall.getById({ posts: `${ownerId}_${postId}` } as any);
                if (wall?.items?.[0]?.date) ts = wall.items[0].date * 1000;
            } catch {}
        }
        return ts;
    };

    const processActivity = async (type: "like" | "wall_reply", ownerId: number, postId: number, itemId: number, userId: number, publishedAt?: number) => {
        const limits = limitsDb.load();
        if (!limits.like?.active || typeof limits.like.give !== "number" || limits.like.give <= 0) return;
        const users = usersDb.load();
        const user = users.find(u => u.id === userId);
        if (!user) return;
        const postPublishedAt = await fetchPostDate(ownerId, postId, publishedAt);
        if (!postPublishedAt) return;
        const timeDiff = Date.now() - postPublishedAt;
        if (timeDiff > 24 * 60 * 60 * 1000 || timeDiff < 0) return;
        const minutes = timeDiff / 60000;        const { rewardFp, rewardDonate } = calculateReward(minutes);
        if (rewardFp <= 0) return;
        const claimKey = `${type}_${ownerId}_${postId}${itemId ? `_${itemId}` : ``}`;
        const claimsRecord = type === "like" ? (user.like_claims ??= {}) : (user.comments ??= {});
        if (claimsRecord[claimKey]) return;
        claimsRecord[claimKey] = Date.now();
        user.balance += rewardFp;
        if (rewardDonate > 0) user.donate_rub = (user.donate_rub || 0) + rewardDonate;
        updateUserActivity(users, user.uid);
        usersDb.save(users);
        console.log(`${type.toUpperCase()}: ${userId} +${rewardFp} FP (${minutes.toFixed(1)} мин)`);
        if (user.uvedu && clients.group) await sendRewardNotification(clients, userId, user, rewardFp, rewardDonate, type === "wall_reply" ? "comment" : type);
    };

    updates.on("message", async message => {
        let chats: DoubleChat[] | undefined;
        let users: DoubleUser[] | undefined;
        try {
            if (Number(message.senderId) <= 0) return;
            const rawText = typeof message.text === "string" ? message.text : "";
            const isChat = Boolean(message.isChat);
            const attachments = message.attachments || [];
            const senderId = Number(message.senderId);
            const botGroupId = Math.abs(dependencies.config.vk.groupId);

            if (isChat && senderId !== botGroupId) {
                const hasTextAd = hasAdvertisingInText(rawText);
                const hasAttAd = hasAdvertisingInAttachments(attachments);

                if (hasTextAd || hasAttAd) {
                    users = usersDb.load();
                    const userForName = users.find(u => u.id === senderId);
                    const userName = userForName?.tag || `id${senderId}`;

                    try {
                        await clients.group.api.messages.delete({
                            message_ids: [message.id],
                            delete_for_all: true,
                            peer_id: message.peerId
                        }).catch(() => undefined);
                    } catch {}

                    try {
                        await message.send(
                            `⚠️ ${userName}, реклама запрещена!\n\n` +
                            `Разрешены только:\n` +
                            `• Ссылки на пользователей VK (vk.com/id123, vk.com/username)\n` +
                            `• https://vk.com/club${ALLOWED_CLUB_ID}\n` +
                            `• https://t.me/${ALLOWED_TG_BOT}\n` +
                            `• ${ALLOWED_VK_MENTIONS.join(", ")}\n` +                            `• Аудиозаписи (музыка)`
                        ).catch(() => undefined);
                    } catch {}

                    console.log(`[ANTI-AD] Удалено сообщение от ${senderId} (${userName})`);
                    return;
                }
            }

            const rawPayload = message.messagePayload as Record<string, unknown> | null;
            let commandText = rawText;
            if (rawPayload) {
                const candidate = (typeof rawPayload.command === "string" && rawPayload.command) ||
                    (typeof rawPayload.cmd === "string" && rawPayload.cmd) ||
                    (typeof rawPayload.c === "string" && rawPayload.c) ||
                    (typeof rawPayload.text === "string" && rawPayload.text);
                if (candidate) commandText = candidate;
            }
            const peerId = Number(message.peerId);
            const chatId = message.chatId ? Number(message.chatId) : undefined;
            const referralValue = message.referralValue;
            const maybeAction = (message as any).action;
            const actionType = typeof maybeAction?.type === "string" ? String(maybeAction.type) : "";
            const actionMemberIdRaw = maybeAction?.member_id ?? maybeAction?.memberId;
            const actionMemberId = typeof actionMemberIdRaw === "number" ? actionMemberIdRaw : Number(String(actionMemberIdRaw ?? ""));
            const botInvite = isChat && (actionType === "chat_invite_user" || actionType === "chat_invite_user_by_link") && Number.isFinite(actionMemberId) && actionMemberId === -Math.abs(dependencies.config.vk.groupId);
            if (!commandText && !botInvite) return;
            chats = chatsDb.load();
            users = usersDb.load();
            let chat: DoubleChat | undefined;
            let isNewChat = false;
            if (isChat && chatId !== undefined) {
                chat = chats.find(entry => entry.id === chatId);
                if (!chat) {
                    chat = { uid: chats.length, id: chatId, name: "Чат", lvl: 0, give: 0, uvedu: true, podarok: 0, newpodarok: 0, attachment: "", type: 0, start: false, gametime: 60, game: false, games: [] };
                    chats.push(chat);
                    isNewChat = true;
                }
                if (botInvite || isNewChat) {
                    await message.send(`👋 Привет! Я бот для игр.\n\n🎮 Игры: Дабл / Краш / Под7Над\n\n✅ Старт:\n1) Дайте права админа\n2) «игра создать»\n3) «игра подтвердить»\n\n— vk.com/club${dependencies.config.vk.groupId}`);
                }
            }
            if (!commandText) return;
            let user = users.find(entry => entry.id === senderId);
            let isNewUser = false;
            if (!user) {
                if (isChat) {
                    const probeUser = { id: senderId, uid: -1, balance: 0, tag: "User", regDate: Date.now(), bonustime: 0, lastbet: 0, donate_rub: 0, ref_bonus: 0, refCount: 0, limit: 0, permiss: {} } as DoubleUser;
                    const probeContext: UnifiedMessageContext = { peerId, senderId, isChat, platform: "vk", text: commandText, requestId: `vk_probe_${Date.now()}`, vkContext: message, vk: clients.group, message, chatId, tgService: dependencies.telegramService, chat, user: probeUser, state: { chat, user: probeUser, chats, users }, payload: rawPayload, send: async () => undefined, sendWithKeyboard: async () => undefined, reply: async () => undefined };
                    if (!registry.resolve(probeContext)) return;                    await message.send(`👋 [id${senderId}|Пользователь], зарегистрируйтесь в ЛС: https://vk.com/club${dependencies.config.vk.groupId}`);
                    return;
                }
                const [{ first_name, last_name }] = await clients.group.api.users.get({ user_ids: [senderId] });
                const tag = [first_name, last_name].filter(Boolean).join(" ").trim() || first_name;
                user = { id: senderId, uid: users.length, balance: 1000, tag, regDate: Date.now(), bonustime: 0, lastbet: 0, uvedu: true, donate_rub: 0, ref_bonus: 0, refCount: 0, limit: 0, permiss: {} } as DoubleUser;
                users.push(user);
                isNewUser = true;
                if (referralValue) {
                    const referrerUid = Number(referralValue);
                    if (Number.isFinite(referrerUid) && referrerUid > 0 && addPendingReferral(users, referrerUid, user.uid, user.id, "vk")) usersDb.save(users);
                }
            }
            if (isNewUser) {
                if (isChat) await message.send(`👋 [id${user.id}|${user.tag}]! Аккаунт создан. Баланс: 1000 FP`);
                else {
                    let msg = `👋 Привет, ${user.tag}! Аккаунт создан ✅\n\n💸 Баланс: 1000 FP\nКоманды: «баланс», «бонус», «рейтинг»\n❤️ Лайки и 💬 комментарии = награды`;
                    if (referralValue) msg += "\n👥 Вы по реф. ссылке!";
                    await message.send(msg + `\n\n— vk.com/club${dependencies.config.vk.groupId}`, { keyboard: dmKeyboard });
                }
            }
            if (rawText.trim()) messageLogService.add(senderId, rawText);
            const context: UnifiedMessageContext = {
                peerId, senderId, isChat, platform: "vk", text: commandText, requestId: `vk_${Date.now()}`,
                vkContext: message, vk: clients.group, message, chatId, tgService: dependencies.telegramService,
                chat, user, state: { chat, user, chats, users }, payload: rawPayload,
                send: async (text: string, params?: Record<string, unknown>) => message.send(text, { disable_mentions: 1, ...params }),
                sendWithKeyboard: async (text: string, keyboard: unknown) => message.send(text, { keyboard: keyboard as any }),
                reply: async (text: string, params?: Record<string, unknown>) => message.reply(text, { disable_mentions: 1, ...params })
            };
            const resolved = registry.resolve(context);
            if (!resolved) return;
            if (user.ba && user.ba.value) {
                const isBanned = !user.ba.time || user.ba.time > Date.now();
                if (isBanned) {
                    let banMessage = "🚫 Ваш аккаунт заблокирован.";
                    if (user.ba.time && user.ba.time > 0) {
                        const remainingMs = user.ba.time - Date.now();
                        if (remainingMs > 0) {
                            const hours = Math.floor(remainingMs / (1000 * 60 * 60));
                            const minutes = Math.floor((remainingMs % (1000 * 60 * 60)) / (1000 * 60));
                            banMessage += `\n⏳ Осталось времени: ${hours} ч. ${minutes} мин.`;
                        }
                    }
                    await message.send(banMessage);
                    return;
                } else {
                    user.ba.value = false;
                    user.ba.time = 0;
                }            }
            context.match = resolved.match;
            updateUserActivity(users, user.uid);
            await resolved.command.handler(context);
            usersDb.save(users);
        } catch (error) {
            console.error("vk.message", error);
            await message.send("Ошибка.").catch(() => undefined);
        } finally {
            if (chats && users) { chatsDb.save(chats); usersDb.save(users); }
        }
    });

    updates.on("like_add", async e => {
        try {
            if (String(e.objectType) !== "post" || !Number.isFinite(e.likerId) || e.likerId <= 0) return;
            await processActivity("like", Number(e.objectOwnerId), Number(e.objectId), 0, Number(e.likerId), Number(e.publishedAt));
        } catch (err) { console.error("vk.like_add", err); }
    });

    updates.on("wall_reply_new", async e => {
        try {
            if (!e.fromId || e.fromId < 0) return;
            const userId = Number(e.fromId);
            const postId = Number(e.objectId);
            const ownerId = Number(e.ownerId);
            const commentId = Number(e.id);
            const commentText = String(e.text ?? "").trim();
            const users = usersDb.load();
            const user = users.find(u => u.id === userId);
            if (!user) {
                try { await clients.group?.api.wall.createComment({ owner_id: ownerId, post_id: postId, reply_to_comment: commentId, message: "⛔️ Вы не игрок бота. Напишите /start в ЛС." }).catch(() => undefined); } catch {}
                return;
            }
            const minRequiredLength = Math.floor(Math.random() * 16) + 5;
            if (commentText.length < minRequiredLength) {
                if (user.uvedu && clients.group) {
                    await clients.group.api.messages.send({ user_id: userId, random_id: 0, message: "😴 Комментарий слишком скучный! Напиши что-нибудь поинтереснее." }).catch(() => undefined);
                }
                return;
            }
            await processActivity("wall_reply", Number(e.ownerId), Number(e.objectId), Number(e.id), userId);
        } catch (err) { console.error("vk.wall_reply_new", err); }
    });
};