import { JsonDatabase } from "./JsonDatabase";
import { DoubleUser } from "../types/database";

export interface WinningsRecord {
  uid: number;
  id: number;
  winnings: number;
  tag: string;
  platform: "vk" | "tg";
}

export class WinningsTopService {
  private readonly usersDb: JsonDatabase<DoubleUser[]>;

  constructor(usersDb: JsonDatabase<DoubleUser[]>) {
    this.usersDb = usersDb;
  }

  addWinning(uid: number, amount: number): void {
    const users = this.usersDb.load();
    const user = users.find((u) => u.uid === uid);

    if (user) {
      user.winnings = (user.winnings || 0) + amount;
      this.usersDb.save(users);
    }
  }

  getWinnings(uid: number): number {
    const users = this.usersDb.load();
    const user = users.find((u) => u.uid === uid);
    return user?.winnings || 0;
  }

  getTop(limit: number = 10): WinningsRecord[] {
    const users = this.usersDb.load();

    return users
      .filter((u) => (u.winnings || 0) > 0 && !u.ba?.ban_top)
      .map(
        (u) =>
          ({
            uid: u.uid,
            id: u.id,
            winnings: u.winnings || 0,
            tag: u.tag,
            platform: u.tgId ? "tg" : "vk",
          }) as WinningsRecord
      )
      .sort((a, b) => b.winnings - a.winnings)
      .slice(0, limit);
  }

  resetAllWinnings(): WinningsRecord[] {
    const users = this.usersDb.load();
    const topBeforeReset = this.getTop(10);

    for (const user of users) {
      user.winnings = 0;
    }

    this.usersDb.save(users);
    return topBeforeReset;
  }

  getUserRank(uid: number): number {
    const users = this.usersDb.load();
    const sorted = users
      .filter((u) => (u.winnings || 0) > 0 && !u.ba?.ban_top)
      .sort((a, b) => (b.winnings || 0) - (a.winnings || 0));

    return sorted.findIndex((u) => u.uid === uid) + 1;
  }

  // Дополнительный метод для получения топов за разные периоды
  getTopWithDetails(limit: number = 10): (WinningsRecord & { rank: number })[] {
    const top = this.getTop(limit);
    return top.map((winner, index) => ({
      ...winner,
      rank: index + 1,
    }));
  }
}