// Конфигурация уровней кэшбека
export interface CashbackLevel {
  level: number;
  cashbackPercent: number;
  betsRequired: number; // ставок нужно для перехода на этот уровень
  totalBetsRequired: number; // суммарно ставок с начала
}

// Генерация всех 50 уровней
export const generateCashbackLevels = (): CashbackLevel[] => {
  const levels: CashbackLevel[] = [];
  let totalBets = 0;
  
  for (let level = 1; level <= 50; level++) {
    let betsRequired: number;
    let cashbackPercent: number;
    
    // Уровни 1-10: быстрый прогресс
    if (level <= 5) {
      betsRequired = 100 + (level - 1) * 100; // 100, 200, 300, 400, 500
      cashbackPercent = level; // 1%, 2%, 3%, 4%, 5%
    } else if (level <= 10) {
      betsRequired = 500 + (level - 5) * 250; // 750, 1000, 1250, 1500, 1750, 2000
      cashbackPercent = 5 + (level - 5) * 0.5; // 5.5%, 6%, 6.5%, 7%, 7.5%, 8%
    } else if (level <= 20) {
      betsRequired = 2000 + (level - 10) * 500; // 2500-7000
      cashbackPercent = 8 + (level - 10) * 0.25; // 8.25%-10.5%
    } else if (level <= 30) {
      betsRequired = 7000 + (level - 20) * 1000; // 8000-17000
      cashbackPercent = 10.5 + (level - 20) * 0.25; // 10.75%-13%
    } else if (level <= 40) {
      betsRequired = 17000 + (level - 30) * 1500; // 18500-33500
      cashbackPercent = 13 + (level - 30) * 0.1; // 13.1%-14%
    } else {
      betsRequired = 33500 + (level - 40) * 2000; // 35500-55500
      cashbackPercent = 14 + (level - 40) * 0.1; // 14.1%-15%
    }
    
    // Кап на 15%
    if (cashbackPercent > 15) cashbackPercent = 15;
    
    totalBets += betsRequired;
    
    levels.push({
      level,
      cashbackPercent: Math.round(cashbackPercent * 100) / 100,
      betsRequired,
      totalBetsRequired: totalBets
    });
  }  
  return levels;
};

export const CASHBACK_LEVELS = generateCashbackLevels();

// Получить уровень по количеству ставок
export function getCashbackLevelByBets(totalBets: number): CashbackLevel {
  for (let i = CASHBACK_LEVELS.length - 1; i >= 0; i--) {
    if (totalBets >= CASHBACK_LEVELS[i].totalBetsRequired) {
      return CASHBACK_LEVELS[i];
    }
  }
  return CASHBACK_LEVELS[0]; // Уровень 1
}

// Получить следующий уровень
export function getNextCashbackLevel(currentLevel: number): CashbackLevel | null {
  if (currentLevel >= 50) return null;
  return CASHBACK_LEVELS.find(l => l.level === currentLevel + 1) || null;
}

// Рассчитать кэшбек за уровень
export function calculateLevelCashback(
  betsAmount: number, // сумма ставок за уровень
  cashbackPercent: number // процент кэшбека текущего уровня
): number {
  // Кэшбек = сумма ставок * процент / 100
  // С капом чтобы не ломать экономику
  const rawCashback = betsAmount * cashbackPercent / 100;
  
  // Максимальный кэшбек за уровень (чтобы не выдать слишком много)
  const maxCashback = 500000; // 500,000 FP максимум за уровень
  
  return Math.min(Math.floor(rawCashback), maxCashback);
}

// Получить информацию о прогрессе кэшбека
export function getCashbackProgress(
  currentLevel: number,
  betsInCurrentLevel: number,
  totalCashbackEarned: number
) {
  const currentLevelData = CASHBACK_LEVELS.find(l => l.level === currentLevel);
  const nextLevelData = getNextCashbackLevel(currentLevel);
  
  if (!currentLevelData) {
    return {
      level: 50,
      maxLevel: true,      cashbackPercent: 15,
      progress: 100,
      betsInLevel: 0,
      betsRequired: 0,
      nextLevel: null,
      totalEarned: totalCashbackEarned
    };
  }
  
  const progress = nextLevelData 
    ? (betsInCurrentLevel / currentLevelData.betsRequired) * 100 
    : 100;
  
  return {
    level: currentLevel,
    maxLevel: currentLevel >= 50,
    cashbackPercent: currentLevelData.cashbackPercent,
    progress: Math.min(100, progress),
    betsInLevel,
    betsRequired: currentLevelData.betsRequired,
    betsRemaining: nextLevelData ? Math.max(0, currentLevelData.betsRequired - betsInCurrentLevel) : 0,
    nextLevel: nextLevelData,
    totalEarned: totalCashbackEarned
  };
}