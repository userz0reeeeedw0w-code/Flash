import { VK } from "vk-io";
import { DoubleUser } from "../types/database";

export interface AdminAction {
  timestamp: number;
  admin: DoubleUser | null | undefined;
  adminId?: number;
  action: string;
  target?: {
    id?: number;
    uid?: number;
    tag?: string;
  };
  details?: Record<string, unknown>;
}

export class AdminAuditService {
  private auditChatId: number | null;
  private vk: VK | null = null;

  constructor(auditChatIdOrFn: number | (() => number | null)) {
    if (typeof auditChatIdOrFn === "function") {
      this.auditChatId = auditChatIdOrFn();
    } else {
      this.auditChatId = auditChatIdOrFn;
    }
  }

  setVkClient(vk: VK): void {
    this.vk = vk;
  }

  private formatTimestamp(ts: number): string {
    const date = new Date(ts);
    const pad = (n: number) => String(n).padStart(2, "0");
    return `${pad(date.getDate())}.${pad(date.getMonth() + 1)}.${date.getFullYear()} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
  }

  private getActionEmoji(action: string): string {
    const actionLower = action.toLowerCase();
    if (actionLower.includes("выдач") || actionLower.includes("дал")) return "➕";
    if (actionLower.includes("снят") || actionLower.includes("отобр")) return "➖";
    if (actionLower.includes("бан")) return "🚫";
    if (actionLower.includes("разбан") || actionLower.includes("иммун")) return "✅";
    if (actionLower.includes("рассылк")) return "📢";
    if (actionLower.includes("привилег") || actionLower.includes("прав")) return "🔐";
    if (actionLower.includes("логи") || actionLower.includes("лог")) return "📋";
    if (actionLower.includes("топ")) return "🏆";
    if (actionLower.includes("бонус")) return "🎁";
    return "⚙️";
  }

  private buildMessage(action: AdminAction): string {
    const lines: string[] = [];
    const emoji = this.getActionEmoji(action.action);
    const timestamp = this.formatTimestamp(action.timestamp);
    const date = new Date(action.timestamp);
    const dayOfWeek = ["Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"][date.getDay()];
    
    lines.push(`╔═══════════════════════════════════╗`);
    lines.push(`║ ${emoji} АДМИН ЛОГ: ${action.action.toUpperCase()}`);
    lines.push(`╚═══════════════════════════════════╝`);
    lines.push("");

    lines.push(`⏰ ${timestamp} (${dayOfWeek})`);
    lines.push("");

    if (action.admin) {
      lines.push(`┌─ 👤 АДМИНИСТРАТОР`);
      lines.push(`├─ ID VK: *id${action.admin.id}`);
      lines.push(`├─ Ник: ${action.admin.tag}`);
      if (action.admin.uid !== undefined) {
        lines.push(`├─ Игровой ID: ${action.admin.uid}`);
      }
      const perms = this.formatPermissions(action.admin);
      if (perms) {
        lines.push(`├─ Права: ${perms}`);
      }
      lines.push(`└─`);
      lines.push("");
    } else if (action.adminId) {
      lines.push(`┌─ 👤 АДМИНИСТРАТОР`);
      lines.push(`├─ ID VK: ${action.adminId}`);
      lines.push(`└─`);
      lines.push("");
    }

    if (action.target) {
      lines.push(`┌─ 🎯 ЦЕЛЬ`);
      if (action.target.id) {
        lines.push(`├─ ID VK: *id${action.target.id}`);
        lines.push(`├─ Ник: ${action.target.tag || "неизвестно"}`);
      }
      if (action.target.uid !== undefined) {
        lines.push(`├─ Игровой ID: ${action.target.uid}`);
      }
      lines.push(`└─`);
      lines.push("");
    }

    if (action.details && Object.keys(action.details).length > 0) {
      lines.push(`┌─ 📌 ДЕТАЛИ`);
      const detailKeys = Object.keys(action.details);
      detailKeys.forEach((key, idx) => {
        const isLast = idx === detailKeys.length - 1;
        const prefix = isLast ? "└─" : "├─";
        const value = String(action.details![key]);
        lines.push(`${prefix} ${key}: ${value}`);
      });
      lines.push("");
    }

    lines.push(`═══════════════════════════════════`);

    return lines.join("\n");
  }

  private formatPermissions(user: DoubleUser): string {
    const perms = user.permiss;
    if (!perms) return "";

    const flags: string[] = [];
    if ((perms as any).owner) flags.push("👑 Owner");
    if ((perms as any).sponsor) flags.push("💎 Sponsor");
    if ((perms as any).admin) flags.push("⚡ Admin");
    if ((perms as any).helper) flags.push("🤝 Helper");
    if ((perms as any).flash) flags.push("⚡ Flash");
    if ((perms as any).donate) flags.push("💳 Donate");
    if ((perms as any).vip) flags.push("⭐ VIP");
    if ((perms as any).premium) flags.push("✨ Premium");
    if ((perms as any).legend) flags.push("🏅 Legend");

    return flags.join(" | ") || "—";
  }

  async log(action: AdminAction): Promise<void> {
    if (!this.auditChatId || !this.vk) {
      console.warn("AdminAuditService: auditChatId or VK client not configured, skipping audit log");
      return;
    }

    const message = this.buildMessage(action);

    try {
      await this.vk.api.messages.send({
        chat_id: this.auditChatId,
        random_id: 0,
        message,
        disable_mentions: true
      });
    } catch (error) {
      console.error("AdminAuditService: failed to send audit log", error);
    }
  }

  async logTargetAction(
    actionName: string,
    admin: DoubleUser | undefined,
    target: DoubleUser,
    details?: Record<string, unknown>
  ): Promise<void> {
    await this.log({
      timestamp: Date.now(),
      admin,
      action: actionName,
      target: { id: target.id, uid: target.uid, tag: target.tag },
      details
    });
  }

  async logAdminAction(
    actionName: string,
    admin: DoubleUser | undefined,
    details?: Record<string, unknown>
  ): Promise<void> {
    await this.log({
      timestamp: Date.now(),
      admin,
      action: actionName,
      details
    });
  }

  async logPermissionChange(
    permissionName: string,
    admin: DoubleUser | undefined,
    target: DoubleUser,
    isGranting: boolean
  ): Promise<void> {
    const action = isGranting ? `Выдача ${permissionName}` : `Снятие ${permissionName}`;
    await this.logTargetAction(action, admin, target);
  }
}
