import fs from "fs";
import path from "path";
import { DatabaseConfig } from "../types/config";

type JsonData = unknown;

export class JsonDatabase<TData extends JsonData> {
  private readonly filePath: string;

  constructor(private readonly config: DatabaseConfig, private readonly fileName: string) {
    this.filePath = path.join(this.config.rootPath, this.fileName);
  }

  load(): TData {
    if (!fs.existsSync(this.filePath)) {
      throw new Error(`Database file not found: ${this.filePath}`);
    }
    const raw = fs.readFileSync(this.filePath, { encoding: "utf8" });
    return JSON.parse(raw) as TData;
  }

  save(data: TData): void {
    const directory = path.dirname(this.filePath);
    if (!fs.existsSync(directory)) {
      fs.mkdirSync(directory, { recursive: true });
    }
    const serialized = JSON.stringify(data, null, 2);
    fs.writeFileSync(this.filePath, serialized, { encoding: "utf8" });
  }
}

