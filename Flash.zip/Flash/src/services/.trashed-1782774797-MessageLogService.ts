export type MessageLogEntry = {
  time: number;
  text: string;
};

export class MessageLogService {
  private readonly maxPerUser: number;
  private readonly logs = new Map<number, MessageLogEntry[]>();

  constructor(maxPerUser = 50) {
    this.maxPerUser = maxPerUser;
  }

  add(userId: number, text: string, time = Date.now()): void {
    const cleaned = String(text ?? "").trim();
    if (!cleaned) return;

    const current = this.logs.get(userId) ?? [];
    current.push({ time, text: cleaned });
    if (current.length > this.maxPerUser) {
      current.splice(0, current.length - this.maxPerUser);
    }
    this.logs.set(userId, current);
  }

  list(userId: number): MessageLogEntry[] {
    return [...(this.logs.get(userId) ?? [])];
  }
}

export const formatTime = (time: number): string => {
  const date = new Date(time);
  const pad = (n: number): string => String(n).padStart(2, "0");
  return `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
};
