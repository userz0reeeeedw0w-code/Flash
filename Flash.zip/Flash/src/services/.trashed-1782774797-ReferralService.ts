import { JsonDatabase } from "./JsonDatabase";
import { DoubleUser } from "../types/database";
import { TelegramService } from "./TelegramService";
import { VkClients } from "./VkClient";

export interface ReferralConfig {
  minimumActiveTimeMs: number;
  bonusPerReferral: number;
  minimumBetAmountForConfirmation?: number;
}

export class ReferralService {
  private readonly usersDb: JsonDatabase<DoubleUser[]>;
  private readonly config: ReferralConfig;
  private readonly telegramService: TelegramService | undefined;
  private readonly vkClients: VkClients;

  constructor(
    usersDb: JsonDatabase<DoubleUser[]>,
    config: ReferralConfig,
    vkClients: VkClients,
    telegramService?: TelegramService
  ) {
    this.usersDb = usersDb;
    this.config = config;
    this.vkClients = vkClients;
    this.telegramService = telegramService;
  }

  addReferral(referrerUid: number, newUserUid: number, newUserId: number, platform: "vk" | "tg"): boolean {
    const users = this.usersDb.load();
    const referrer = users.find(u => u.uid === referrerUid);
    const newUser = users.find(u => u.uid === newUserUid);

    if (!referrer || !newUser) return false;

    if (!referrer.referrals) {
      referrer.referrals = [];
    }

    const existingRef = referrer.referrals.find(r => r.uid === newUserUid);
    if (existingRef) {
      return false;
    }

    referrer.referrals.push({
      uid: newUserUid,
      id: newUserId,
      addedAt: Date.now(),
      platform,
      confirmed: false
    });

    newUser.referrerUid = referrerUid;

    this.usersDb.save(users);
    return true;
  }

  confirmPendingReferrals(): void {
    const users = this.usersDb.load();
    let changed = false;

    for (const referrer of users) {
      if (!referrer.referrals || referrer.referrals.length === 0) continue;

      const now = Date.now();
      for (const ref of referrer.referrals) {
        if (ref.confirmed) continue;

        const newUser = users.find(u => u.uid === ref.uid);
        if (!newUser) continue;

        const timeActive = (newUser.lastActiveAt || newUser.regDate) - ref.addedAt;

        if (timeActive >= this.config.minimumActiveTimeMs) {
          ref.confirmed = true;
          ref.confirmedAt = now;

          referrer.refCount = (referrer.refCount || 0) + 1;
          referrer.ref_bonus = (referrer.ref_bonus || 0) + this.config.bonusPerReferral;
          
          changed = true;

          this.notifyReferrer(referrer, newUser);
        }
      }
    }

    if (changed) {
      this.usersDb.save(users);
    }
  }

  updateUserActivity(uid: number): void {
    const users = this.usersDb.load();
    const user = users.find(u => u.uid === uid);

    if (user) {
      user.lastActiveAt = Date.now();
      this.usersDb.save(users);
    }
  }

  getConfirmedReferrals(referrerUid: number): number {
    const users = this.usersDb.load();
    const referrer = users.find(u => u.uid === referrerUid);

    if (!referrer || !referrer.referrals) {
      return 0;
    }

    return referrer.referrals.filter(r => r.confirmed).length;
  }

  getPendingReferrals(referrerUid: number): number {
    const users = this.usersDb.load();
    const referrer = users.find(u => u.uid === referrerUid);

    if (!referrer || !referrer.referrals) {
      return 0;
    }

    return referrer.referrals.filter(r => !r.confirmed).length;
  }

  getAllReferrals(referrerUid: number) {
    const users = this.usersDb.load();
    const referrer = users.find(u => u.uid === referrerUid);
    
    if (!referrer || !referrer.referrals) {
      return { confirmed: [], pending: [] };
    }

    return {
      confirmed: referrer.referrals.filter(r => r.confirmed),
      pending: referrer.referrals.filter(r => !r.confirmed)
    };
  }

  private async notifyReferrer(referrer: DoubleUser, newUser: DoubleUser): Promise<void> {
    const message = `✅ Реферал подтвержден!\n👤 ${newUser.tag}\n💰 +${this.config.bonusPerReferral} FP к вашему счету`;
    
    if (referrer.tgId && this.telegramService) {
      await this.telegramService
        .getTelegram()
        .api.sendMessage({
          chat_id: referrer.tgId,
          text: message
        })
        .catch(() => undefined);
    } else if (!referrer.tgId) {
      await this.vkClients.group.api.messages
        .send({
          user_id: referrer.id,
          message,
          random_id: 0
        })
        .catch(() => undefined);
    }
  }
}
