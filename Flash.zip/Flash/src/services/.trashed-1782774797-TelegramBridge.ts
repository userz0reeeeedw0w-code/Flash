import { VK } from "vk-io";
import { JsonDatabase } from "./JsonDatabase";
import { DoubleUser } from "../types/database";
import { TelegramClient } from "./TelegramClient";
import { normalizeTelegramText, vkKeyboardToTelegramMarkup } from "../utils/telegram";

export const patchVkMessageSend = (
  vk: VK,
  telegram: TelegramClient,
  usersDb: JsonDatabase<DoubleUser[]>
): void => {
  const api: any = (vk as any).api;
  const messages: any = api?.messages;
  if (!messages || typeof messages.send !== "function") return;
  if (messages.__telegram_patched) return;

  const originalSend = messages.send.bind(messages);

  messages.send = async (params: any): Promise<any> => {
    const userId = typeof params?.user_id === "number" ? params.user_id : undefined;
    const chatId = typeof params?.chat_id === "number" ? params.chat_id : undefined;
    const message = normalizeTelegramText(String(params?.message ?? ""));
    const replyMarkup = params?.keyboard ? vkKeyboardToTelegramMarkup(params.keyboard) : undefined;

    if (typeof chatId === "number" && chatId < 0) {
      await telegram.sendMessage(chatId, message, { reply_markup: replyMarkup });
      return 0;
    }

    if (typeof userId === "number") {
      let tgId: number | null = null;
      if (userId < 0) {
        tgId = -userId;
      } else {
        const users = usersDb.load();
        const target = users.find(entry => entry.id === userId && typeof entry.tgId === "number");
        if (target && typeof target.tgId === "number") tgId = target.tgId;
      }
      if (tgId) {
        await telegram.sendMessage(tgId, message, { reply_markup: replyMarkup });
        return 0;
      }
    }

    return originalSend(params);
  };

  messages.__telegram_patched = true;
};
