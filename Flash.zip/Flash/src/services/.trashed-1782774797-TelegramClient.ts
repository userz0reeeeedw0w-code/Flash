import https from "https";
import { URL } from "url";
import { TelegramReplyMarkup } from "../utils/telegram";

export type TelegramUser = {
  id: number;
  is_bot?: boolean;
  first_name?: string;
  last_name?: string;
  username?: string;
};

export type TelegramChat = {
  id: number;
  type: "private" | "group" | "supergroup" | "channel";
  title?: string;
  username?: string;
};

export type TelegramMessage = {
  message_id: number;
  from?: TelegramUser;
  chat: TelegramChat;
  date: number;
  text?: string;
  reply_to_message?: TelegramMessage;
  forward_from?: TelegramUser;
  forward_from_chat?: TelegramChat;
  new_chat_members?: TelegramUser[];
};

export type TelegramCallbackQuery = {
  id: string;
  from: TelegramUser;
  message?: TelegramMessage;
  data?: string;
};

export type TelegramUpdate = {
  update_id: number;
  message?: TelegramMessage;
  callback_query?: TelegramCallbackQuery;
};

export type TelegramChatMember = {
  user: TelegramUser;
  status: "creator" | "administrator" | "member" | "restricted" | "left" | "kicked";
};

export type TelegramClientConfig = {
  token: string;
  pollingTimeout?: number;
  pollingIntervalMs?: number;
};

type TelegramApiResponse<T> = {
  ok: boolean;
  result: T;
  description?: string;
  error_code?: number;
};

export class TelegramClient {
  private readonly token: string;
  private readonly baseUrl: string;
  private offset = 0;
  private running = false;
  private readonly pollingTimeout: number;
  private readonly pollingIntervalMs: number;

  constructor(config: TelegramClientConfig) {
    this.token = config.token;
    this.baseUrl = `https://api.telegram.org/bot${this.token}`;
    this.pollingTimeout = typeof config.pollingTimeout === "number" ? config.pollingTimeout : 25;
    this.pollingIntervalMs = typeof config.pollingIntervalMs === "number" ? config.pollingIntervalMs : 1000;
  }

  startPolling(onUpdate: (update: TelegramUpdate) => Promise<void>): void {
    if (this.running) return;
    this.running = true;
    void this.pollLoop(onUpdate);
  }

  stop(): void {
    this.running = false;
  }

  async sendMessage(
    chatId: number,
    text: string,
    options?: { reply_markup?: TelegramReplyMarkup; disable_web_page_preview?: boolean }
  ): Promise<void> {
    await this.callApi("sendMessage", {
      chat_id: chatId,
      text,
      reply_markup: options?.reply_markup,
      disable_web_page_preview: options?.disable_web_page_preview
    });
  }

  async answerCallbackQuery(id: string, text?: string, showAlert?: boolean): Promise<void> {
    await this.callApi("answerCallbackQuery", {
      callback_query_id: id,
      text,
      show_alert: showAlert
    });
  }

  async getChatMember(chatId: number, userId: number): Promise<TelegramChatMember | null> {
    try {
      return await this.callApi<TelegramChatMember>("getChatMember", {
        chat_id: chatId,
        user_id: userId
      });
    } catch {
      return null;
    }
  }

  private async pollLoop(onUpdate: (update: TelegramUpdate) => Promise<void>): Promise<void> {
    while (this.running) {
      try {
        const updates = await this.callApi<TelegramUpdate[]>("getUpdates", {
          offset: this.offset,
          timeout: this.pollingTimeout,
          allowed_updates: ["message", "callback_query"]
        });

        for (const update of updates) {
          this.offset = Math.max(this.offset, update.update_id + 1);
          try {
            await onUpdate(update);
          } catch {
            continue;
          }
        }

        if (updates.length === 0) {
          await this.sleep(this.pollingIntervalMs);
        }
      } catch {
        await this.sleep(this.pollingIntervalMs);
      }
    }
  }

  private async callApi<T>(method: string, params?: Record<string, unknown>): Promise<T> {
    const url = new URL(`${this.baseUrl}/${method}`);
    const body = params ? JSON.stringify(params) : "";

    return new Promise((resolve, reject) => {
      const req = https.request(
        url,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Content-Length": Buffer.byteLength(body)
          }
        },
        res => {
          const chunks: Buffer[] = [];
          res.on("data", chunk => chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)));
          res.on("end", () => {
            const raw = Buffer.concat(chunks).toString("utf8");
            let parsed: TelegramApiResponse<T>;
            try {
              parsed = JSON.parse(raw) as TelegramApiResponse<T>;
            } catch (error) {
              reject(error);
              return;
            }
            if (!parsed.ok) {
              reject(new Error(parsed.description || `Telegram API error ${String(parsed.error_code ?? "")}`));
              return;
            }
            resolve(parsed.result);
          });
        }
      );

      req.on("error", reject);
      req.write(body);
      req.end();
    });
  }

  private async sleep(ms: number): Promise<void> {
    if (ms <= 0) return;
    await new Promise(resolve => setTimeout(resolve, ms));
  }
}
