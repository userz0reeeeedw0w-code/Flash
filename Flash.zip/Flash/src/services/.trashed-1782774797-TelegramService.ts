import { Logger } from "../utils/logger";
import type { MessageContext, CallbackQueryContext } from "puregram";
import { Telegram } from "puregram";

export interface ITelegramService {
  start(): Promise<void>;
  stop(): Promise<void>;
  isRunning(): boolean;
}

export interface TelegramEventHandlers {
  onMessage: (ctx: MessageContext) => Promise<void>;
  onCallbackQuery: (ctx: CallbackQueryContext) => Promise<void>;
  onMessageReaction?: (update: any) => Promise<void>;
  onError: (error: unknown) => Promise<void>;
}

export class TelegramService implements ITelegramService {
  private readonly telegram: Telegram;
  private readonly logger: Logger;
  private running = false;
  private handlers: Partial<TelegramEventHandlers> = {};

  constructor(token: string, logger = new Logger("TelegramService")) {
    this.telegram = new Telegram({ token });
    this.logger = logger;
  }

  public registerHandlers(handlers: Partial<TelegramEventHandlers>): void {
    this.handlers = handlers;
  }

  async start(): Promise<void> {
    if (this.running) {
      this.logger.warn("Telegram service is already running");
      return;
    }

    try {
      this.running = true;
      this.logger.info("Starting Telegram polling...");
      
      this.telegram.updates.on("message", async (ctx: MessageContext) => {
        try {
          await this.handlers.onMessage?.(ctx);
        } catch (error) {
          this.logger.error("Error handling message", error);
          await this.handlers.onError?.(error);
        }
      });

      this.telegram.updates.on("callback_query", async (ctx: CallbackQueryContext) => {
        try {
          await this.handlers.onCallbackQuery?.(ctx);
        } catch (error) {
          this.logger.error("Error handling callback query", error);
          await this.handlers.onError?.(error);
        }
      });

      this.telegram.updates.on("message_reaction", async (update: any) => {
        try {
          if (this.handlers.onMessageReaction) {
            await this.handlers.onMessageReaction(update);
          }
        } catch (error) {
          this.logger.error("Error handling message reaction", error);
          await this.handlers.onError?.(error);
        }
      });

      await this.telegram.updates.startPolling();
      this.logger.info("Telegram polling started successfully");
    } catch (error) {
      this.running = false;
      this.logger.error("Failed to start Telegram polling", error);
      throw error;
    }
  }

  async stop(): Promise<void> {
    if (!this.running) return;

    try {
      this.running = false;
      await this.telegram.updates.stopPolling();
      this.logger.info("Telegram polling stopped");
    } catch (error) {
      this.logger.error("Error stopping Telegram polling", error);
      throw error;
    }
  }

  isRunning(): boolean {
    return this.running;
  }

  getTelegram(): Telegram {
    return this.telegram;
  }

  getAPI() {
    return this.telegram.api;
  }

  async sendMessage(params: {
    chat_id: number;
    text: string;
    reply_markup?: any;
  }): Promise<void> {
    await this.telegram.api.sendMessage(params);
  }
}