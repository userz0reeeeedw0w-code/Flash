import { VK } from "vk-io";
import { VkConfig } from "../types/config";

export type VkClients = {
  group: VK;
  user?: VK;
};

export const createVkClients = (config: VkConfig): VkClients => {
  const group = new VK({
    token: config.token
  });

  const user = config.userToken
    ? new VK({
        token: config.userToken
      })
    : undefined;

  return { group, user };
};

