import { JsonDatabase } from "../services/JsonDatabase";
import { DoubleUser, Limits } from "../types/database";
import { VkClients } from "../services/VkClient";
import { TelegramService } from "../services/TelegramService";
import { ReferralService } from "./ReferralService";
import { WinningsTopService } from "./WinningsTopService";

export class IntervalService {
  private readonly usersDb: JsonDatabase<DoubleUser[]>;
  private readonly limitsDb: JsonDatabase<Limits>;
  private readonly clients: VkClients;
  private readonly telegramService: TelegramService | undefined;
  private readonly referralService: ReferralService;
  private readonly winningsTopService: WinningsTopService;
  private bonusTimerId: NodeJS.Timeout | null = null;
  private unblockTimerId: NodeJS.Timeout | null = null;
  private privilegeTimerId: NodeJS.Timeout | null = null;
  private referralTimerId: NodeJS.Timeout | null = null;
  private dailyTimerId: NodeJS.Timeout | null = null;
  private streakTimerId: NodeJS.Timeout | null = null;

  constructor(
    usersDb: JsonDatabase<DoubleUser[]>,
    limitsDb: JsonDatabase<Limits>,
    clients: VkClients,
    telegramService?: TelegramService
  ) {
    this.usersDb = usersDb;
    this.limitsDb = limitsDb;
    this.clients = clients;
    this.telegramService = telegramService;
    this.referralService = new ReferralService(
      usersDb,
      { minimumActiveTimeMs: 3600000, bonusPerReferral: 5000 },
      clients,
      telegramService
    );
    this.winningsTopService = new WinningsTopService(usersDb);
  }

  private async sendUserNotification(
    user: DoubleUser,
    message: string
  ): Promise<void> {
    if (user.tgId && this.telegramService) {
      await this.telegramService
        .getTelegram()
        .api.sendMessage({
          chat_id: user.tgId,
          text: message,        })
        .catch(() => undefined);
    } else if (!user.tgId) {
      await this.clients.group.api.messages
        .send({
          user_id: user.id,
          message,
          random_id: 0,
        })
        .catch(() => undefined);
    }
  }

  start(): void {
    const bonusTick = async (): Promise<void> => {
      const users = this.usersDb.load();
      const limits = this.limitsDb.load();
      const maxBalance =
        typeof limits.balance === "number" && Number.isFinite(limits.balance)
          ? limits.balance
          : null;
      let changed = false;
      for (const user of users) {
        if (user.bonustime > 0) {
          user.bonustime--;
          changed = true;
        }
        if (maxBalance !== null && user.balance > maxBalance) {
          user.balance = maxBalance;
          changed = true;
        }
      }
      if (changed) {
        this.usersDb.save(users);
      }
      this.bonusTimerId = setTimeout(bonusTick, 1000);
    };

    const unblockTick = async (): Promise<void> => {
      const users = this.usersDb.load();
      let changed = false;
      for (const user of users) {
        if (user.ba && user.ba.value) {
          if (user.ba.time && user.ba.time <= Date.now()) {
            user.ba.time = 0;
            user.ba.value = false;
            changed = true;
            await this.sendUserNotification(
              user,
              `✅ Ваш аккаунт [Double] был разблокирован. Больше не нарушайте.`            );
          }
        }
      }
      if (changed) {
        this.usersDb.save(users);
      }
      this.unblockTimerId = setTimeout(unblockTick, 1000);
    };

    const privilegeTick = async (): Promise<void> => {
      const users = this.usersDb.load();
      let changed = false;
      const now = Date.now();
      for (const user of users) {
        const expire = async (
          flag: keyof DoubleUser["permiss"],
          field: keyof DoubleUser,
          label: string
        ) => {
          const value = user[field] as unknown;
          if (typeof value === "number" && value > 0 && value <= now) {
            (user as any)[field] = false;
            (user.permiss as any)[flag] = false;
            changed = true;
            await this.sendUserNotification(
              user,
              `❗У вас закончился срок использования привилегии ${label}`
            );
          }
        };
        await expire("vip", "vip_expires", "VIP");
        await expire("premium", "premium_expires", "Premium");
        await expire("admin", "admin_expires", "Administrator");
        await expire("legend", "legend_expires", "Legenda");
        await expire("donate", "donate_expires", "DONATE");
        await expire("flash", "flash_expires", "Всемогущий");
        await expire("sponsor", "sponsor_expires", "Спонсор");
      }
      if (changed) {
        this.usersDb.save(users);
      }
      this.privilegeTimerId = setTimeout(privilegeTick, 10_000);
    };

    const streakTick = async (): Promise<void> => {
      const users = this.usersDb.load();
      let changed = false;
      for (const user of users) {
        const lastBonusTime = user.lastBonusTime || 0;        if (lastBonusTime > 0) {
          user.lastBonusTime = lastBonusTime - 1;
          changed = true;
        }
        if (lastBonusTime <= 0 && (user.bonusStreak || 0) > 0) {
          user.bonusStreak = 0;
          changed = true;
        }
      }
      if (changed) {
        this.usersDb.save(users);
      }
      this.streakTimerId = setTimeout(streakTick, 1000);
    };

    const dailyTick = async (): Promise<void> => {
      const now = new Date();
      const nextMidnight = new Date(now);
      nextMidnight.setDate(nextMidnight.getDate() + 1);
      nextMidnight.setHours(0, 0, 0, 0);
      const timeToMidnight = nextMidnight.getTime() - now.getTime();
      
      const limits = this.limitsDb.load();
      const lastReset = limits.winningsTopResetAt || 0;
      const timeSinceLastReset = now.getTime() - lastReset;

      if (timeSinceLastReset >= 24 * 60 * 60 * 1000 || lastReset === 0) {
        const topWinners = this.winningsTopService.getTop(10);
        
        const prizePercentages = [
          0.75, 
          0.70, 
          0.65, 
          0.55, 
          0.50, 
          0.45, 
          0.40, 
          0.30, 
          0.25, 
          0.20, 
        ];

        const users = this.usersDb.load();
        let usersChanged = false;

        for (let i = 0; i < topWinners.length && i < prizePercentages.length; i++) {
          const winner = topWinners[i];
          const percentage = prizePercentages[i];
          
          const prize = Math.floor(winner.winnings * percentage);          
          if (prize <= 0) continue;

          const user = users.find((u) => u.uid === winner.uid);
          
          if (user) {
            user.balance = (user.balance || 0) + prize;
            user.totalWon = (user.totalWon || 0) + prize;
            usersChanged = true;

            await this.sendUserNotification(
              user,
              `🏆 Поздравляем! Вы заняли ${i + 1}-е место в ежедневном топе выигрышей!\n` +
              `💰 Ваш выигрыш за день: ${winner.winnings.toLocaleString()} FP\n` +
              `🎁 Приз (${Math.round(percentage * 100)}% от выигрыша): +${prize.toLocaleString()} FP`
            );
          }
        }

        if (usersChanged) {
          this.usersDb.save(users);
        }

        this.winningsTopService.resetAllWinnings();
        
        limits.winningsTopResetAt = Date.now();
        this.limitsDb.save(limits);

        if (this.telegramService) {
          const adminMessage = `📊 Ежедневный топ выигрышей сброшен\n` +
             `🏆 Победители дня:\n` +
            topWinners.slice(0, 10).map((w, i) =>
              `${i + 1}. ${w.tag} — ${w.winnings.toLocaleString()} FP (Приз: ${Math.round(prizePercentages[i] * 100)}%)`
            ).join('\n');
          
          await this.telegramService
            .getTelegram()
            .api.sendMessage({
               chat_id: process.env.ADMIN_CHAT_ID || "admin_chat_id",
              text: adminMessage,
              parse_mode: "Markdown",
            })
            .catch(() => undefined);
        }
      }
      
      this.dailyTimerId = setTimeout(dailyTick, timeToMidnight);
    };

    const referralTick = async (): Promise<void> => {      this.referralService.confirmPendingReferrals();
      this.referralTimerId = setTimeout(referralTick, 60_000);
    };

    bonusTick();
    unblockTick();
    privilegeTick();
    streakTick(); 
    referralTick();
    dailyTick();
  }

  stop(): void {
    if (this.bonusTimerId) {
      clearTimeout(this.bonusTimerId);
      this.bonusTimerId = null;
    }
    if (this.unblockTimerId) {
      clearTimeout(this.unblockTimerId);
      this.unblockTimerId = null;
    }
    if (this.privilegeTimerId) {
      clearTimeout(this.privilegeTimerId);
      this.privilegeTimerId = null;
    }
    if (this.streakTimerId) {
      clearTimeout(this.streakTimerId);
      this.streakTimerId = null;
    }
    if (this.referralTimerId) {
      clearTimeout(this.referralTimerId);
      this.referralTimerId = null;
    }
    if (this.dailyTimerId) {
      clearTimeout(this.dailyTimerId);
      this.dailyTimerId = null;
    }
  }
}