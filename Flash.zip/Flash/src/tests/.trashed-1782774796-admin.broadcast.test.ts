import { assertEqual, assertOk, createMockContext } from "./assert";
import { createBroadcastCommand } from "../commands/admin/broadcast";
import type { UnifiedMessageContext } from "../core/mode/GameMode";
import type { DoubleChat, DoubleUser } from "../types/database";

export const runAdminBroadcastTests = async (): Promise<void> => {
  const previousEnv = {
    BROADCAST_CONCURRENCY: process.env.BROADCAST_CONCURRENCY,
    BROADCAST_DELAY_MS: process.env.BROADCAST_DELAY_MS,
    BROADCAST_RETRIES: process.env.BROADCAST_RETRIES
  };
  process.env.BROADCAST_CONCURRENCY = "2";
  process.env.BROADCAST_DELAY_MS = "0";
  process.env.BROADCAST_RETRIES = "0";

  const users: DoubleUser[] = [
    { id: 1, uid: 1, balance: 0, tag: "u1", regDate: Date.now(), bonustime: 0, lastbet: 0, donate_rub: 0, ref_bonus: 0, refCount: 0, limit: 0, uvedu: true, permiss: { owner: true } },
    { id: 2, uid: 2, balance: 0, tag: "u2", regDate: Date.now(), bonustime: 0, lastbet: 0, donate_rub: 0, ref_bonus: 0, refCount: 0, limit: 0, uvedu: true, permiss: {} },
    { id: 3, uid: 3, balance: 0, tag: "u3", regDate: Date.now(), bonustime: 0, lastbet: 0, donate_rub: 0, ref_bonus: 0, refCount: 0, limit: 0, uvedu: false, permiss: {} }
  ];
  const chats: DoubleChat[] = [
    {
      uid: 1,
      id: 10,
      name: "c1",
      lvl: 0,
      give: 0,
      uvedu: true,
      podarok: 0,
      newpodarok: 0,
      attachment: "",
      type: 0,
      start: false,
      gametime: 60,
      game: false,
      games: []
    },
    {
      uid: 2,
      id: 11,
      name: "c2",
      lvl: 0,
      give: 0,
      uvedu: false,
      podarok: 0,
      newpodarok: 0,
      attachment: "",
      type: 0,
      start: false,
      gametime: 60,
      game: false,
      games: []
    }
  ];

  const usersDb = { load: () => users, save: () => undefined } as any;
  const chatsDb = { load: () => chats, save: () => undefined } as any;

  const sendCalls: any[] = [];
  const clients = {
    group: {
      api: {
        messages: {
          send: async (params: any) => {
            sendCalls.push(params);
            if (params.user_id === 2) {
              throw new Error("fail");
            }
          }
        }
      }
    }
  } as any;

  const out: string[] = [];
  const context: UnifiedMessageContext = createMockContext({
    peerId: 1,
    senderId: 1,
    isChat: false,
    text: "/Рассылка тест",
    match: ["/Рассылка тест", "", "тест"] as any,
    message: { send: async (text: string) => { out.push(text); } } as any,
    user: users[0],
    state: { users, chats },
    vk: undefined,
    send: async (text: string) => { out.push(text); }
  });

  const cmd = createBroadcastCommand(usersDb, chatsDb, clients);
  await cmd.handler(context);

  const userSends = sendCalls.filter(c => typeof c.user_id === "number");
  const chatSends = sendCalls.filter(c => typeof c.chat_id === "number");

  assertEqual(userSends.length, 2, "broadcast sends to opted-in users");
  assertEqual(chatSends.length, 1, "broadcast sends to opted-in chats");

  const summary = out[out.length - 1] ?? "";
  assertOk(summary.includes("Ошибок: 1"), "broadcast counts failed sends");

  {
    sendCalls.length = 0;
    out.length = 0;
    const ctx: UnifiedMessageContext = createMockContext({
      ...context,
      text: "/Рассылка --users тест",
      match: ["/Рассылка --users тест", "--users", "тест"] as any
    });
    await cmd.handler(ctx);
    const onlyUsers = sendCalls.filter(c => typeof c.user_id === "number").length;
    const onlyChats = sendCalls.filter(c => typeof c.chat_id === "number").length;
    assertEqual(onlyUsers, 2, "broadcast --users sends only to users");
    assertEqual(onlyChats, 0, "broadcast --users sends to zero chats");
  }

  {
    sendCalls.length = 0;
    out.length = 0;
    const ctx: UnifiedMessageContext = createMockContext({
      ...context,
      text: "/Рассылка --chats тест",
      match: ["/Рассылка --chats тест", "--chats", "тест"] as any
    });
    await cmd.handler(ctx);
    const onlyUsers = sendCalls.filter(c => typeof c.user_id === "number").length;
    const onlyChats = sendCalls.filter(c => typeof c.chat_id === "number").length;
    assertEqual(onlyUsers, 0, "broadcast --chats sends to zero users");
    assertEqual(onlyChats, 1, "broadcast --chats sends only to chats");
  }

  process.env.BROADCAST_CONCURRENCY = previousEnv.BROADCAST_CONCURRENCY;
  process.env.BROADCAST_DELAY_MS = previousEnv.BROADCAST_DELAY_MS;
  process.env.BROADCAST_RETRIES = previousEnv.BROADCAST_RETRIES;
};
