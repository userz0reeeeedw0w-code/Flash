import { assertEqual, assertOk, createMockContext } from "./assert";
import { createAdminCommands } from "../commands/admin";
import { messageLogService } from "../handlers/VkMessageHandler";
import type { UnifiedMessageContext } from "../core/mode/GameMode";
import type { DoubleUser, Limits } from "../types/database";

const createStaffUser = (): DoubleUser => ({
  id: 100,
  uid: 100,
  balance: 0,
  tag: "staff",
  regDate: Date.now(),
  bonustime: 0,
  lastbet: 0,
  donate_rub: 0,
  ref_bonus: 0,
  refCount: 0,
  limit: 0,
  permiss: { admin: true }
});

const createTargetUser = (): DoubleUser => ({
  id: 200,
  uid: 5,
  balance: 0,
  tag: "target",
  regDate: Date.now(),
  bonustime: 0,
  lastbet: 0,
  donate_rub: 0,
  ref_bonus: 0,
  refCount: 0,
  limit: 0,
  ba: { value: true, time: 123 },
  permiss: {}
});

export const runAdminModerationTests = async (): Promise<void> => {
  const limits: Limits = { money: 0, keyses: 0, balance: 0 };
  const limitsDb = { load: () => limits, save: (_: Limits) => undefined } as any;
  const users: DoubleUser[] = [createStaffUser(), createTargetUser()];
  const usersDb = { load: () => users, save: (_: DoubleUser[]) => undefined } as any;

  const commands = createAdminCommands(limitsDb, usersDb);
  const byName = (name: string) => {
    const cmd = commands.find(c => c.name === name);
    if (!cmd) throw new Error(`missing admin command: ${name}`);
    return cmd;
  };

  const staff = users[0];
  const target = users[1];

  const sends: any[] = [];
  const out: string[] = [];

  const contextBase: Partial<UnifiedMessageContext> = {
    peerId: 1,
    senderId: staff.id,
    chatId: 29,
    isChat: true,
    user: staff,
    state: { users },
    vk: {
      api: {
        messages: {
          send: async (params: any) => {
            sends.push(params);
          }
        }
      }
    } as any
  };

  {
    out.length = 0;
    const cmd = byName("admin.getLoginCode");
    const ctx: UnifiedMessageContext = createMockContext({
      ...contextBase,
      isChat: false,
      chatId: undefined,
      text: "парольадмин",
      match: ["парольадмин"] as any,
      message: { send: async (text: string) => { out.push(text); } } as any,
      send: async (text: string) => { out.push(text); }
    });

    await cmd.handler(ctx);

    const payload = out.join("\n");
    const match = payload.match(/временный пароль для входа:\s*([A-Z0-9]+)/i);
    assertOk(Boolean(match?.[1]), "admin.getLoginCode returns a code");
    const code = String(match?.[1] ?? "");

    out.length = 0;
    const login = byName("admin.login");
    const loginCtx: UnifiedMessageContext = createMockContext({
      ...contextBase,
      isChat: false,
      chatId: undefined,
      text: `входадмин ${code}`,
      match: [`входадмин ${code}`, code] as any,
      message: { send: async (text: string) => { out.push(text); } } as any,
      send: async (text: string) => { out.push(text); }
    });

    await login.handler(loginCtx);
    assertOk(out.join("\n").includes("вошли"), "admin.login accepts code");

    const helpExtended = byName("admin.helpExtended");
    const helpCtx: UnifiedMessageContext = createMockContext({
      ...contextBase,
      isChat: true,
      chatId: 29,
      text: "админпомощь+",
      match: ["админпомощь+"] as any,
      message: { send: async (text: string) => { out.push(text); } } as any,
      send: async (text: string) => { out.push(text); }
    });

    assertOk(Boolean(helpExtended.guard?.(helpCtx)), "admin session allows extended help");

    out.length = 0;
    await helpExtended.handler(helpCtx);
    assertOk(out.join("\n").includes("Расширенная"), "admin.helpExtended responds");

    out.length = 0;
    await login.handler(loginCtx);
    assertOk(out.join("\n").includes("неверный"), "login code is one-time");
  }

  {
    out.length = 0;
    sends.length = 0;
    const cmd = byName("admin.unban");
    const ctx: UnifiedMessageContext = createMockContext({
      ...contextBase,
      text: "разбан 5",
      match: ["разбан 5", "5"] as any,
      message: { send: async (text: string) => { out.push(text); } } as any,
      send: async (text: string) => { out.push(text); }
    });
    await cmd.handler(ctx);

    assertEqual(Boolean(target.ba?.value), false, "admin.unban clears ban flag");
    assertEqual(target.ba?.time, 0, "admin.unban clears ban time");
    assertOk(out.some(t => t.includes("успешно")), "admin.unban replies with success");
    assertOk(sends.some(p => p.user_id === target.id), "admin.unban notifies target user");
  }

  {
    out.length = 0;
    const cmd = byName("admin.banTop");
    const ctx: UnifiedMessageContext = createMockContext({
      ...contextBase,
      text: "бантоп 5",
      match: ["бантоп 5", "5"] as any,
      message: { send: async (text: string) => { out.push(text); } } as any,
      send: async (text: string) => { out.push(text); }
    });
    await cmd.handler(ctx);
    assertEqual(Boolean(target.ba?.ban_top), true, "admin.banTop sets ban_top flag");
  }

  {
    out.length = 0;
    const cmd = byName("admin.unbanTop");
    const ctx: UnifiedMessageContext = createMockContext({
      ...contextBase,
      text: "разбантоп 5",
      match: ["разбантоп 5", "5"] as any,
      message: { send: async (text: string) => { out.push(text); } } as any,
      send: async (text: string) => { out.push(text); }
    });
    await cmd.handler(ctx);
    assertEqual(Boolean(target.ba?.ban_top), false, "admin.unbanTop clears ban_top flag");
  }

  {
    out.length = 0;
    messageLogService.add(target.id, "привет", 1);
    const cmd = byName("admin.logs");
    const ctx: UnifiedMessageContext = createMockContext({
      ...contextBase,
      text: "логи 5",
      match: ["логи 5", "5"] as any,
      message: { send: async (text: string) => { out.push(text); } } as any,
      send: async (text: string) => { out.push(text); }
    });
    await cmd.handler(ctx);
    const msg = out.join("\n");
    assertOk(msg.includes("логи игрока"), "admin.logs responds with logs header");
    assertOk(msg.includes("привет"), "admin.logs includes logged message text");
  }
};
