import { UnifiedMessageContext } from "../core/mode/GameMode";
import { DoubleUser, DoubleChat } from "../types/database";

export const assertEqual = (actual: unknown, expected: unknown, message: string): void => {
  if (actual !== expected) {
    throw new Error(`${message}. Expected: ${String(expected)}, received: ${String(actual)}`);
  }
};

export const assertOk = (value: unknown, message: string): void => {
  if (!value) {
    throw new Error(message);
  }
};


export const createMockContext = (
  overrides?: Partial<UnifiedMessageContext>
): UnifiedMessageContext => {
  return {
    peerId: 123,
    senderId: 456,
    isChat: false,
    platform: "vk",
    text: "test",
    requestId: `test_${Date.now()}`,
    message: {} as any,
    chatId: undefined,
    vkContext: undefined,
    tgContext: undefined,
    tgService: undefined,
    tg: undefined,
    user: {
      id: 456,
      uid: 0,
      balance: 1000,
      tag: "Test User",
      regDate: Date.now(),
      bonustime: 0,
      lastbet: 0,
      uvedu: true,
      donate_rub: 0,
      ref_bonus: 0,
      refCount: 0,
      limit: 0,
      permiss: {} as any
    } as DoubleUser,
    chat: undefined,
    state: {},
    payload: null,
    match: null,
    vk: {} as any,
    send: (async () => {}) as any,
    sendWithKeyboard: (async () => {}) as any,
    reply: (async () => {}) as any,
    ...overrides
  };
};

