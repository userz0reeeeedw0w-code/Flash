import { assertEqual, assertOk, createMockContext } from "./assert";
import { blackjackCommand } from "../commands/common/blackjack";
import type { UnifiedMessageContext } from "../core/mode/GameMode";
import type { BlackjackCard, DoubleUser } from "../types/database";

const createUser = (): DoubleUser => ({
  id: 1,
  uid: 1,
  balance: 1_000,
  tag: "Игрок",
  regDate: Date.now(),
  bonustime: 0,
  lastbet: 0,
  donate_rub: 0,
  ref_bonus: 0,
  refCount: 0,
  limit: 0,
  permiss: {}
});

const c = (rank: string, suit: BlackjackCard["suit"]): BlackjackCard => ({ rank, suit });

export const runBlackjackTests = async (): Promise<void> => {
  {
    const out: { text: string; keyboard?: string }[] = [];
    const user = createUser();
    const ctx: UnifiedMessageContext = createMockContext({
      peerId: 1,
      senderId: user.id,
      isChat: false,
      text: "21",
      match: ["21"] as any,
      message: {
        send: async (text: string, params?: any) => { out.push({ text, keyboard: params?.keyboard }); }
      } as any,
      user,
      state: { user },
      send: async (text: string, params?: any) => { out.push({ text, keyboard: params?.keyboard }); },
      sendWithKeyboard: async (text: string, keyboard: any) => { out.push({ text, keyboard: String(keyboard) }); }
    });

    await blackjackCommand.handler(ctx);
    const last = out[out.length - 1];
    assertOk(Boolean(last?.text.includes("Выбери ставку")), "blackjack prompts bet on start");
    assertOk(Boolean(last?.keyboard?.includes("21 50")), "blackjack start attaches bet keyboard");
  }

  {
    const out: string[] = [];
    const user = createUser();
    user.blackjack = {
      phase: "betting",
      bet: 0,
      deck: [c("7", "♥"), c("K", "♦"), c("9", "♣"), c("A", "♠")],
      player: [],
      dealer: [],
      updatedAt: Date.now()
    };

    const ctx: UnifiedMessageContext = createMockContext({
      peerId: 1,
      senderId: user.id,
      isChat: false,
      text: "21 100",
      match: ["21 100", "100"] as any,
      message: { send: async (text: string) => { out.push(text); } } as any,
      user,
      state: { user },
      send: async (text: string) => { out.push(text); }
    });

    await blackjackCommand.handler(ctx);

    assertEqual(user.balance, 1_150, "blackjack pays 3:2 on natural blackjack");
    assertEqual(user.blackjack?.phase, "finished", "blackjack ends immediately on natural blackjack");
    assertEqual(user.blackjack?.outcome, "blackjack", "blackjack stores blackjack outcome");
    assertOk(out.join("\n").includes("блэкджек"), "blackjack mentions blackjack outcome");
  }

  {
    const out: string[] = [];
    const user = createUser();
    user.blackjack = {
      phase: "betting",
      bet: 0,
      deck: [c("Q", "♥"), c("K", "♦"), c("A", "♣"), c("A", "♠")],
      player: [],
      dealer: [],
      updatedAt: Date.now()
    };

    const ctx: UnifiedMessageContext = createMockContext({
      peerId: 1,
      senderId: user.id,
      isChat: false,
      text: "21 100",
      match: ["21 100", "100"] as any,
      message: { send: async (text: string) => { out.push(text); } } as any,
      user,
      state: { user },
      send: async (text: string) => { out.push(text); }
    });

    await blackjackCommand.handler(ctx);

    assertEqual(user.balance, 1_000, "blackjack returns bet on push");
    assertEqual(user.blackjack?.outcome, "push", "blackjack stores push outcome");
  }

  {
    const out: string[] = [];
    const user = createUser();
    user.balance = 0;
    user.blackjack = {
      phase: "player",
      bet: 100,
      deck: [c("5", "♠")],
      player: [c("K", "♠"), c("9", "♦")],
      dealer: [c("5", "♣"), c("9", "♥")],
      updatedAt: Date.now()
    };

    const ctx: UnifiedMessageContext = createMockContext({
      peerId: 1,
      senderId: user.id,
      isChat: false,
      text: "21 взять",
      match: ["21 взять", "взять"] as any,
      message: { send: async (text: string) => { out.push(text); } } as any,
      user,
      state: { user },
      send: async (text: string) => { out.push(text); }
    });

    await blackjackCommand.handler(ctx);

    assertEqual(user.balance, 0, "blackjack bust loses bet");
    assertEqual(user.blackjack?.phase, "finished", "blackjack bust finishes game");
    assertEqual(user.blackjack?.outcome, "lose", "blackjack bust stores lose outcome");
  }
};

