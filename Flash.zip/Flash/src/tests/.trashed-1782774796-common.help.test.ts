import { assertOk, createMockContext } from "./assert";
import { helpCommand } from "../commands/common/help";
import { keyboardToggleCommand } from "../commands/common/keyboardToggle";
import type { UnifiedMessageContext } from "../core/mode/GameMode";
import type { DoubleUser } from "../types/database";

const createUser = (): DoubleUser => ({
  id: 1,
  uid: 1,
  balance: 1_000,
  tag: "Игрок",
  regDate: Date.now(),
  bonustime: 0,
  lastbet: 0,
  donate_rub: 0,
  ref_bonus: 0,
  refCount: 0,
  limit: 0,
  permiss: {}
});

export const runHelpTests = async (): Promise<void> => {
  {
    const sends: { text: string; keyboard?: string }[] = [];
    const ctx: UnifiedMessageContext = createMockContext({
      peerId: 1,
      senderId: 1,
      isChat: false,
      text: "помощь",
      match: ["помощь"] as any,
      message: {
        send: async (text: string, params?: any) => {
          sends.push({ text, keyboard: params?.keyboard });
        }
      } as any,
      user: createUser(),
      state: { user: createUser() as any },
      send: async (text: string, params?: any) => { sends.push({ text, keyboard: params?.keyboard }); },
      sendWithKeyboard: async (text: string, keyboard: any) => { sends.push({ text, keyboard: String(keyboard) }); }
    });

    await helpCommand.handler(ctx);

    const last = sends[sends.length - 1];
    assertOk(Boolean(last?.text.includes("Основные команды")), "help sends common section");
    assertOk(Boolean(last?.keyboard && last.keyboard.includes("Профиль")), "help attaches dm keyboard");
  }

  {
    const sends: { text: string; keyboard?: string }[] = [];
    const user = createUser();
    const ctx: UnifiedMessageContext = createMockContext({
      peerId: 1,
      senderId: user.id,
      isChat: false,
      text: "кнопки",
      match: ["кнопки"] as any,
      message: {
        send: async (text: string, params?: any) => {
          sends.push({ text, keyboard: params?.keyboard });
        }
      } as any,
      user,
      state: { user },
      send: async (text: string, params?: any) => { sends.push({ text, keyboard: params?.keyboard }); },
      sendWithKeyboard: async (text: string, keyboard: any) => { sends.push({ text, keyboard: String(keyboard) }); }
    });

    await keyboardToggleCommand.handler(ctx);

    const last = sends[sends.length - 1];
    assertOk(Boolean(last?.keyboard && last.keyboard.includes("Помощь")), "dm buttons command sends keyboard");
  }
};
