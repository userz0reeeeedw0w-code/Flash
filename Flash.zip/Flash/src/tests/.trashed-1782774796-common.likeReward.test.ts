import { assertEqual, assertOk, createMockContext } from "./assert";
import { tryGrantLikeReward } from "../utils/likeReward";
import type { UnifiedMessageContext } from "../core/mode/GameMode";
import type { DoubleUser, Limits } from "../types/database";

export const runLikeRewardTests = async (): Promise<void> => {
  const limits: Limits = {
    money: 0,
    keyses: 0,
    balance: 0,
    active_post: {
      ownerId: -1,
      itemId: 2,
      key: "wall-1_2",
      publishedAt: Date.now() - 2 * 60 * 1000
    } as any,
    like: { give: 500, active: true }
  };

  const limitsDb = { load: () => limits, save: (_: Limits) => undefined } as any;

  const wallCalls: any[] = [];
  const clients = {
    group: {} as any,
    user: {
      api: {
        likes: {
          isLiked: async (params: any) => {
            return { liked: 1 };
          }
        },
        wall: {
          getById: async (params: any) => {
            wallCalls.push(params);
            return { items: [{ date: Math.floor((Date.now() - 2 * 60 * 1000) / 1000) }] };
          }
        }
      }
    }
  } as any;

  const user: DoubleUser = {
    id: 10,
    uid: 10,
    balance: 0,
    tag: "u",
    regDate: Date.now(),
    bonustime: 0,
    lastbet: 0,
    donate_rub: 0,
    ref_bonus: 0,
    refCount: 0,
    limit: 0,
    permiss: {}
  };

  const result1 = await tryGrantLikeReward({ user, limits, clients });

  assertEqual(result1.granted, true, "like reward grants reward");
  assertEqual(user.balance, 500, "like reward adds FP");
  assertOk(result1.message?.includes("Награда"), "like reward sends reward message");

  const result2 = await tryGrantLikeReward({ user, limits, clients });
  assertEqual(result2.granted, false, "like reward blocks second claim");
  assertOk(result2.message?.includes("уже"), "like reward shows already rewarded message");
};
