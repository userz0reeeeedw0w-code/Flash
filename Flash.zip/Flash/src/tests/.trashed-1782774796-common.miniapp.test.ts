import { assertOk, createMockContext } from "./assert";
import { miniAppCommand } from "../commands/common/miniapp";
import type { UnifiedMessageContext } from "../core/mode/GameMode";

export const runMiniAppTests = async (): Promise<void> => {
  {
    const out: { text: string; keyboard?: string }[] = [];
    const ctx: UnifiedMessageContext = createMockContext({
      isChat: false,
      text: "миниапп",
      match: ["миниапп"] as any,
      user: {
        id: 42,
        uid: 7,
        balance: 1000,
        tag: "Игрок",
        bonustime: 0,
        lastbet: 0,
        donate_rub: 0,
        ref_bonus: 0,
        refCount: 0,
        limit: 0,
        permiss: {}
      } as any,
      send: async (text: string, params?: any) => {
        out.push({ text, keyboard: params?.keyboard });
      }
    });

    await miniAppCommand.handler(ctx);

    const payload = out[out.length - 1];
    assertOk(Boolean(payload?.text.includes("мини‑апп")), "miniapp command returns miniapp text");
    assertOk(Boolean(payload?.text.includes("userId=42")), "miniapp command includes user id in url");
    assertOk(Boolean(payload?.keyboard?.includes("Открыть тест-профиль")), "miniapp command returns test profile button");
  }

  {
    const out: string[] = [];
    const ctx: UnifiedMessageContext = createMockContext({
      isChat: false,
      text: "миниапп тест",
      match: ["миниапп тест", "тест"] as any,
      send: async (text: string) => {
        out.push(text);
      }
    });
    await miniAppCommand.handler(ctx);
    assertOk(Boolean(out[out.length - 1]?.includes("test=1")), "miniapp test mode adds test query");
  }
};
