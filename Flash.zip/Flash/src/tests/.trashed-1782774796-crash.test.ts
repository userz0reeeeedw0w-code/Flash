import { assertEqual, assertOk, createMockContext } from "./assert";
import { crashBetCommand } from "../commands/crash/bet";
import { CrashMode } from "../core/mode/CrashMode";
import { DoubleChat, DoubleUser } from "../types/database";
import type { UnifiedMessageContext } from "../core/mode/GameMode";

const createUser = (): DoubleUser => ({
  id: 1,
  uid: 1,
  balance: 1_000_000,
  tag: "Игрок",
  regDate: Date.now(),
  bonustime: 0,
  lastbet: 0,
  donate_rub: 0,
  ref_bonus: 0,
  refCount: 0,
  limit: 0,
  permiss: {}
});

const createChat = (): DoubleChat => ({
  uid: 1,
  id: 1,
  lvl: 0,
  name: "crash",
  give: 0,
  uvedu: true,
  podarok: 0,
  newpodarok: 0,
  attachment: "",
  type: 2,
  start: false,
  gametime: 30,
  game: false,
  games: []
});

export const runCrashTests = async (): Promise<void> => {
  {
    const messages: string[] = [];
    const fakeMessage = {
      async send(text: string): Promise<void> {
        messages.push(text);
      }
    };

    const user = createUser();
    const chat = createChat();

    const context: UnifiedMessageContext = createMockContext({
      peerId: 1,
      senderId: user.id,
      chatId: chat.id,
      isChat: true,
      text: "ставка 1к x2,5",
      message: fakeMessage as unknown as never,
      chat,
      user,
      state: { chat, user },
      match: ["ставка 1к x2,5", "1к x2,5"],
      send: async (text: string) => { (fakeMessage as any).send(text); }
    });

    await crashBetCommand.handler(context);

    assertOk(chat.games.length > 0, "crashBetCommand initializes a game");
    const currentGame = chat.games[chat.games.length - 1] as any;
    assertEqual(currentGame.stavki.length, 1, "crashBetCommand adds a stake");
    assertEqual(currentGame.stavki[0]?.amount, 1_000, "crashBetCommand parses shorthand amount");
    assertEqual(currentGame.stavki[0]?.target, 2.5, "crashBetCommand parses x multiplier");
  }

  {
    const sent: string[] = [];

    let users: DoubleUser[] = [
      {
        id: 1,
        uid: 1,
        balance: 0,
        tag: "Игрок",
        regDate: Date.now(),
        bonustime: 0,
        lastbet: 0,
        donate_rub: 0,
        ref_bonus: 0,
        refCount: 0,
        limit: 0,
        permiss: {}
      }
    ];

    const chat: DoubleChat = {
      uid: 1,
      id: 1,
      lvl: 0,
      name: "crash",
      give: 0,
      uvedu: true,
      podarok: 0,
      newpodarok: 0,
      attachment: "",
      type: 2,
      start: false,
      gametime: 0,
      game: true,
      games: [
        {
          id: 0,
          result: 1.49,
          stavka: false,
          end: false,
          stavki: [{ uid: 1, id: 1, amount: 1000, target: 1.5 }]
        } as any
      ]
    };

    const usersDb = {
      load: () => users,
      save: (data: DoubleUser[]) => {
        users = data;
      }
    } as any;

    const chatsDb = {
      load: () => [chat],
      save: () => undefined
    } as any;

    const mode = new CrashMode({ usersDb, chatsDb, config: {} as any } as any);
    (mode as any).clients = {
      group: {
        api: {
          messages: {
            send: async (params: { message: string }) => {
              sent.push(params.message);
              return 1;
            }
          }
        }
      }
    } as any;
    (mode as any).nextAction[chat.id] = "0|99";

    const originalRandom = Math.random;
    let callIndex = 0;
    Math.random = () => {
      callIndex++;
      if (callIndex === 1) return 0.9;
      if (callIndex === 2) return 0.1;
      return 0.1;
    };

    try {
      await (mode as any).processChat(chat);
    } finally {
      Math.random = originalRandom;
    }

    assertEqual(users[0]?.balance, 1500, "crash auto cashout pays at target multiplier");
    const game = chat.games[0] as any;
    assertEqual(game.stavki[0]?.mnoj, 1.5, "crash auto cashout stores cashout multiplier");
    assertEqual(game.stavki[0]?.cashout, 1500, "crash auto cashout stores cashout amount");
    assertOk(sent.some(m => m.includes("Авто-выводы")), "crash auto cashout sends a message");
  }
};
