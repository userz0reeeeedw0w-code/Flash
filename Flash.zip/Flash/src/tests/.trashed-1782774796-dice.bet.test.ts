import { assertEqual, createMockContext } from "./assert";
import { diceBetCommand } from "../commands/dice/bet";
import { DoubleChat, DoubleUser } from "../types/database";
import type { UnifiedMessageContext } from "../core/mode/GameMode";

const createUser = (): DoubleUser => ({
  id: 1,
  uid: 1,
  balance: 1_000_000,
  tag: "Игрок",
  regDate: Date.now(),
  bonustime: 0,
  lastbet: 0,
  donate_rub: 0,
  ref_bonus: 0,
  refCount: 0,
  limit: 0,
  permiss: {}
});

const createChat = (): DoubleChat => ({
  uid: 1,
  id: 1,
  lvl: 0,
  name: "yrsy",
  give: 0,
  uvedu: true,
  podarok: 0,
  newpodarok: 0,
  attachment: "",
  type: 4,
  start: false,
  gametime: 60,
  game: false,
  games: []
});

export const runDiceBetCommandTests = async (): Promise<void> => {
  const messages: string[] = [];

  const fakeMessage = {
    async send(text: string): Promise<void> {
      messages.push(text);
    }
  };

  const user = createUser();
  const chat = createChat();

  const context: UnifiedMessageContext = createMockContext({
    peerId: 1,
    senderId: user.id,
    chatId: chat.id,
    isChat: true,
    text: "кости 1к",
    message: fakeMessage as unknown as never,
    chat,
    user,
    state: { chat, user },
    match: null as any,
    send: async (text: string) => { (fakeMessage as any).send(text); }
  });

  await diceBetCommand.handler(context);

  assertEqual(chat.games.length, 1, "diceBetCommand creates a game");
  assertEqual(chat.games[0]?.stavki.length, 1, "diceBetCommand adds a single stake");
  assertEqual(chat.games[0]?.stavki[0]?.amount, 1_000, "diceBetCommand parses shorthand bet");
};
