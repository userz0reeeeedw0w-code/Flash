import { assertEqual, assertOk } from "./assert";

type MiniDbModule = {
  findOrCreateUser: (users: any[], id: number, uidHint?: number, tagHint?: string) => any;
  ensureTestUser: (users: any[]) => any;
  applyRound: (user: any, payload: any) => any;
};

export const runMiniAppDbTests = async (): Promise<void> => {
  const miniDb = require("../../miniapp/db.cjs") as MiniDbModule;
  const users: any[] = [];

  const testUser = miniDb.ensureTestUser(users);
  assertOk(Boolean(testUser && Number(testUser.id) > 0), "miniapp db creates test user");

  const user = miniDb.findOrCreateUser(users, 101, 5, "Проверка");
  user.balance = 10_000;

  const win = miniDb.applyRound(user, {
    mode: "highroller",
    bet: 1000,
    outcome: "win"
  });

  assertEqual(win.applied, true, "miniapp db applies round");
  assertOk(Number(user.balance) > 10_000, "miniapp db updates balance on win");
  assertEqual(user.miniapp.rounds, 1, "miniapp db increments total rounds");
  assertEqual(user.miniapp.modes.highroller.rounds, 1, "miniapp db increments mode rounds");

  const lose = miniDb.applyRound(user, {
    mode: "classic",
    bet: 500,
    outcome: "lose"
  });

  assertEqual(lose.applied, true, "miniapp db applies lose round");
  assertEqual(user.miniapp.rounds, 2, "miniapp db increments rounds after second game");
  assertEqual(user.miniapp.losses, 1, "miniapp db increments losses");
};

