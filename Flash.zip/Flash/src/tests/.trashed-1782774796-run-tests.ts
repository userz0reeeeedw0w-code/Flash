import { runNumberUtilsTests } from "./utils.number.test";
import { runTimeUtilsTests } from "./utils.time.test";
import { runDiceBetCommandTests } from "./dice.bet.test";
import { runAdminBroadcastTests } from "./admin.broadcast.test";
import { runAdminModerationTests } from "./admin.moderation.test";
import { runLikeRewardTests } from "./common.likeReward.test";
import { runCrashTests } from "./crash.test";
import { runHelpTests } from "./common.help.test";
import { runBlackjackTests } from "./common.blackjack.test";

const run = async () => {
  runNumberUtilsTests();
  runTimeUtilsTests();
  await runDiceBetCommandTests();
  await runAdminBroadcastTests();
  await runAdminModerationTests();
  await runLikeRewardTests();
  await runCrashTests();
  await runHelpTests();
  await runBlackjackTests();
};

run()
  .then(() => {
    process.stdout.write("Tests passed\n");
  })
  .catch(error => {
    process.stderr.write(`Tests failed: ${String(error)}\n`);
    process.exitCode = 1;
  });
