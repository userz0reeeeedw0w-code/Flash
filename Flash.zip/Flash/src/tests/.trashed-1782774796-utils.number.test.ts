import { assertEqual } from "./assert";
import { formatWithSpaces, randomInt } from "../utils/number";

export const runNumberUtilsTests = (): void => {
  assertEqual(formatWithSpaces(0), "0", "formatWithSpaces formats zero");
  assertEqual(formatWithSpaces(1_000), "1.000", "formatWithSpaces formats thousands");
  assertEqual(formatWithSpaces(1_234_567), "1.234.567", "formatWithSpaces formats millions");

  const randomSample: number[] = [];
  for (let index = 0; index < 10; index += 1) {
    randomSample.push(randomInt(1, 6));
  }

  randomSample.forEach(value => {
    if (value < 1 || value > 6) {
      throw new Error("randomInt produced value out of range 1..6");
    }
  });
};

