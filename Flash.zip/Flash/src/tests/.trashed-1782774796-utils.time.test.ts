import { assertEqual } from "./assert";
import { secondsToHuman } from "../utils/time";

export const runTimeUtilsTests = (): void => {
  assertEqual(secondsToHuman(1), "1 секунда", "secondsToHuman handles seconds");
  assertEqual(secondsToHuman(60), "1 минута", "secondsToHuman handles minutes");
  assertEqual(secondsToHuman(3600), "1 час", "secondsToHuman handles hours");
  assertEqual(secondsToHuman(86400), "1 день", "secondsToHuman handles days");
};

