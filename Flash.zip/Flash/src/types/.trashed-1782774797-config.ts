export type VkConfig = {
  token: string;
  userToken?: string;
  groupId: number;
};

export type DatabaseConfig = {
  rootPath: string;
};

export type TelegramConfig = {
  token: string;
  pollingTimeout?: number;
  pollingIntervalMs?: number;
};

export type BotConfig = {
  vk: VkConfig;
  tg?: TelegramConfig;
  database: DatabaseConfig;
};
