export type DoubleUserSquadSlot = {
  id: number;
};

export type DoubleUserSquad = {
  "1": DoubleUserSquadSlot;
  "2": DoubleUserSquadSlot;
  "3": DoubleUserSquadSlot;
  "4": DoubleUserSquadSlot;
  "5": DoubleUserSquadSlot;
  win: number;
  lose: number;
};

export type DoubleUserPermissions = {
  owner?: boolean;
  flash?: boolean;
  donate?: boolean;
  admin?: boolean;
  legend?: boolean;
  premium?: boolean;
  vip?: boolean;
  [key: string]: unknown;
};

export type DoubleUser = {
  id: number;
  uid: number;
  ban?: boolean;
  balance: number;
  tag: string;
  regDate: number;
  bonustime: number;
  lastbet: number;
  uvedu?: boolean;
  comm?: number;
  otvet?: number;
  anon?: boolean;
  pref?: string;
  attachment?: string;
  squad?: DoubleUserSquad;
  bonusStreak?: number;
  tgReactionClaims?: Record<string, number>;
  cashback_level?: number;
  bets_in_current_level?: number;
  total_bets_for_cashback?: number;
  total_cashback_earned?: number;
  bets_amount_in_current_level?: number;
  pitomnik?: {
    pet: { id: number };
    pitomnik: { id: number };
  };
  case1?: number;
  case2?: number;  case3?: number;
  case4?: number;
  case5?: number;
  case6?: number;
  case7?: number;
  [key: `case${number}`]: number | undefined;
  donate_rub: number;
  ref_bonus: number;
  refCount: number;
  limit: number;
  mention?: string;
  dostupe?: boolean;
  tgId?: number;
  tgUsername?: string;
  tgLinkCode?: string;
  tgLinkExpires?: number;
  ba?: {
    value?: boolean;
    ban_top?: boolean;
    anti_ban?: boolean;
    bancmd?: boolean;
    time?: number;
    limits_give?: number;
    cooldown?: number;
    reset_give?: boolean;
  };
  fake?: boolean;
  banper?: boolean;
  banbonus?: boolean;
  disable_mentions?: number;
  first_msg?: boolean;
  like_check_at?: number;
  permiss: DoubleUserPermissions;
  vip_expires?: number | null;
  premium_expires?: number | null;
  admin_expires?: number | null;
  legend_expires?: number | null;
  donate_expires?: number | null;
  flash_expires?: number | null;
  sponsor_expires?: number | null;
  totalWins?: number;
  totalGames?: number;
  totalLosses?: number;
  promo_used?: string[];
  like_claims?: Record<string, number>;
  comment_claims?: Record<string, number>;
  comments?: Record<string, number>;
  blackjack?: BlackjackGame;
  totalWon?: number;
  lastBonusTime?: number;
  winnings?: number;  referrerUid?: number;
  referrals?: ReferralData[];
  lastActiveAt?: number;
    tgCommentClaims?: Record<string, number>; 
  
};

export type ReferralData = {
  uid: number;
  id: number;
  addedAt: number;
  platform: "vk" | "tg";
  confirmed?: boolean;
  confirmedAt?: number;
};

export type BlackjackPhase = "betting" | "player" | "finished" | "split";

export type BlackjackCard = {
  rank: string;
  suit: "♠" | "♥" | "♦" | "♣";
};

export type BlackjackOutcome = "blackjack" | "win" | "lose" | "push";

export type BlackjackGame = {
  phase: BlackjackPhase;
  bet: number;
  deck: BlackjackCard[];
  player: BlackjackCard[];
  dealer: BlackjackCard[];
  outcome?: BlackjackOutcome;
  payout?: number;
  updatedAt: number;
  splitCards?: BlackjackCard[] | null;
  splitBet?: number;
  activeHand?: "main" | "split";
  mainFinished?: boolean;
  splitFinished?: boolean;
};

export type DoubleGameMultiplier = 2 | 3 | 5 | 50;

export type DoubleGameStake = {
  uid: number;
  id: number;
  type: DoubleGameMultiplier;
  amount: number;
  platform?: "vk" | "tg";
  peerId?: number;
};

export type DoubleGame = {
  result: DoubleGameMultiplier;
  stavka: boolean;
  hash: string;
  proverka: string;
  stavki: DoubleGameStake[];
};

export type DiceGameStake = {
  uid: number;
  id: number;
  number: number;
  amount: number;
  platform?: "vk" | "tg";
  peerId?: number;
};

export type DiceGameStatus = "waiting" | "playing";

export type DiceGame = {
  stavki: DiceGameStake[];
  status: DiceGameStatus;
};

export type SevenGameStakeType = ">7" | "<7" | "=7";

export type SevenGameStake = {
  uid: number;
  id: number;
  type: SevenGameStakeType;
  amount: number;
  platform?: "vk" | "tg";
  peerId?: number;
};

export type SevenGame = {
  result: number;
  stavka: boolean;
  hash: string;
  proverka: string;
  stavki: SevenGameStake[];
};

export type CrashGameStake = {
  uid: number;
  id: number;
  amount: number;
  mnoj?: number;
  target?: number;
  cashout?: number;
  platform?: "vk" | "tg";
  peerId?: number;
};

export type CrashGame = {
  id: number;
  result: number;
  stavka: boolean;
  end: boolean;
  stavki: CrashGameStake[];
};

export type DoubleChat = {
  uid: number;
  id: number;
  name: string;
  lvl: number;
  give: number;
  uvedu: boolean;
  podarok: number;
  newpodarok: number;
  attachment: string;
  type: number;
  start: boolean;
  gametime: number;
  game: boolean;
  firstbet?: boolean;
  pendingGameType?: number;
  pendingGameAt?: number;
  games: (DoubleGame | DiceGame | SevenGame | CrashGame)[];
};

export type Limits = {
  money: number;
  keyses: number;
  balance: number;
  like?: {
    give: number;
    active: boolean;
  };
  active_post?: {
    key: string;
    ownerId: number;
    itemId: number;
    publishedAt: number;
  };
  winningsTopResetAt?: number;
  referralMinActiveTime?: number;
};
