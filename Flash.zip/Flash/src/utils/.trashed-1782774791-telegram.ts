import { resolveResource } from "vk-io";

export const TG_PLATFORM_ID = "tg";

export type TelegramInlineButton = {
  text: string;
  url?: string;
  callback_data?: string;
};

export type TelegramKeyboardButton = {
  text: string;
};

export type TelegramReplyMarkup = {
  inline_keyboard?: TelegramInlineButton[][];
  keyboard?: TelegramKeyboardButton[][];
  resize_keyboard?: boolean;
  one_time_keyboard?: boolean;
};

type VkKeyboardAction = {
  type?: string;
  label?: string;
  payload?: string;
  link?: string;
};

type VkKeyboardButton = {
  action?: VkKeyboardAction;
  color?: string;
};

type VkKeyboard = {
  inline?: boolean;
  one_time?: boolean;
  buttons?: VkKeyboardButton[][];
};

const safeParseJson = (raw: string): any | null => {
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
};

export const normalizeTelegramText = (text: string): string => {
  let result = String(text ?? "");
  result = result.replace(/\[id-?\d+\|([^\]]+)\]/gi, "$1");  result = result.replace(/(?:@|\*)id-?\d+\s*\(([^)]+)\)/gi, "$1");
  result = result.replace(/(?:@|\*)id-?\d+/gi, "");
  result = result.replace(/@online/gi, "");
  result = result.replace(/@all/gi, "");
  result = result.replace(/\r\n/g, "\n");
  const lines = result
    .split("\n")
    .map(line => line.replace(/[ \t]{2,}/g, " ").replace(/[ ]+([,.!?;:])/g, "$1").trimEnd());
  return lines.join("\n").trim();
};

const extractCommandFromPayload = (payload: string | undefined, fallback: string): string => {
  if (!payload) return fallback;
  const parsed = safeParseJson(payload);
  if (parsed && typeof parsed === "object") {
    const candidate = (parsed as any).command ?? (parsed as any).cmd ?? (parsed as any).c ?? (parsed as any).text;
    if (typeof candidate === "string" && candidate.trim()) return candidate.trim();
  }
  return fallback;
};

// 🟢 Универсальная функция поиска пользователя
export async function getUser<T extends { id?: number; uid?: number }>(
  context: any,
  users: T[]
): Promise<T | null> {
  const platform = context.platform ?? "vk";
  let targetId: number | null = null;
  
  // Получаем группы из match (стандартный для vk-io) или $match (если используется другой роутер)
  const groups = context.match?.groups ?? context.$match?.groups;

  if (groups?.id) {
    targetId = Number(groups.id);
  } else if (groups?.link) {
    // Если платформа TG, ссылки VK не резолвим через API VK внутри бота ТГ (обычно требуют явный UID)
    if (platform === TG_PLATFORM_ID || !context.vk) {
      targetId = null;
    } else {
      // Парсинг ссылки VK: https://vk.com/id123 или https://vk.com/durov
      const linkMatch = groups.link.match(/https?:\/\/vk\.(?:ru|com)\/([a-zA-Z0-9_.-]+)/i);
      if (linkMatch) {
        const screenName = linkMatch[1];
        // Проверка на явный числовой ID (id123, club123 и т.д.)
        const explicitIdMatch = screenName.match(/^(?:id|club|public|event)(\d+)$/);
        if (explicitIdMatch) {
          targetId = Number(explicitIdMatch[1]);
        } else {
          // Резолв короткого имени через API VK
          try {            const response = await resolveResource({ api: context.vk.api, resource: screenName });
            targetId = response?.type === "user" ? response?.id : null;
          } catch {
            targetId = null;
          }
        }
      }
    }
  } else if (!groups?.id && !groups?.link) {
    // Если нет явного упоминания, проверяем реплай или пересланное сообщение (только для VK)
    if (platform === "vk") {
      targetId = context.message?.hasReplyMessage
        ? context.message.replyMessage?.senderId ?? null
        : context.message?.hasForwards
          ? context.message.forwards?.[0]?.senderId ?? null
          : null;
    } else {
      targetId = null;
    }
  }

  if (!targetId) return null;

  // Поиск пользователя в массиве в зависимости от платформы
  return platform === TG_PLATFORM_ID
    ? users.find(entry => entry.uid === targetId) ?? null
    : users.find(entry => entry.id === targetId || entry.uid === targetId) ?? null;
}

export const vkKeyboardToTelegramMarkup = (raw: unknown): TelegramReplyMarkup | undefined => {
  if (!raw) return undefined;
  const parsed = typeof raw === "string" ? safeParseJson(raw) : raw;
  if (!parsed || typeof parsed !== "object") return undefined;
  const keyboard = parsed as VkKeyboard;
  const rows = Array.isArray(keyboard.buttons) ? keyboard.buttons : [];
  const inline = Boolean((keyboard as any).inline);

  if (inline) {
    const inlineRows = rows
      .map(row =>
        row
          .map(button => {
            const action = button?.action;
            if (!action || typeof action !== "object") return null;
            const type = String((action as any).type ?? "");
            const label = String((action as any).label ?? "").trim();
            if (type === "open_link") {
              const link = String((action as any).link ?? "").trim();
              if (!label || !link) return null;
              return { text: label, url: link } as TelegramInlineButton;            }
            const payload = typeof (action as any).payload === "string" ? String((action as any).payload) : undefined;
            const commandText = extractCommandFromPayload(payload, label);
            const text = label || commandText;
            const data = payload && payload.length <= 64 && payload !== "{}" ? payload : commandText || label;
            if (!text || !data) return null;
            return { text, callback_data: data } as TelegramInlineButton;
          })
          .filter(Boolean) as TelegramInlineButton[]
      )
      .filter(row => row.length > 0);
    if (inlineRows.length === 0) return undefined;
    return { inline_keyboard: inlineRows };
  }

  const keyboardRows = rows
    .map(row =>
      row
        .map(button => {
          const action = button?.action;
          if (!action || typeof action !== "object") return null;
          const type = String((action as any).type ?? "");
          const label = String((action as any).label ?? "").trim();
          if (type === "open_link") {
            const link = String((action as any).link ?? "").trim();
            const text = label || link;
            if (!text) return null;
            return { text } as TelegramKeyboardButton;
          }
          const payload = typeof (action as any).payload === "string" ? String((action as any).payload) : undefined;
          const commandText = extractCommandFromPayload(payload, label);
          const text = commandText || label;
          if (!text) return null;
          return { text } as TelegramKeyboardButton;
        })
        .filter(Boolean) as TelegramKeyboardButton[]
    )
    .filter(row => row.length > 0);
  if (keyboardRows.length === 0) return undefined;
  return {
    keyboard: keyboardRows,
    resize_keyboard: true,
    one_time_keyboard: Boolean((keyboard as any).one_time)
  };
};

export const parseTelegramCallbackData = (
  data: string | undefined
): { commandText: string; payload: Record<string, unknown> | null } => {
  const raw = String(data ?? "");  if (!raw) return { commandText: "", payload: null };
  const parsed = safeParseJson(raw);
  if (parsed && typeof parsed === "object") {
    const candidate = (parsed as any).command ?? (parsed as any).cmd ?? (parsed as any).c ?? (parsed as any).text;
    const commandText = typeof candidate === "string" && candidate.trim() ? candidate.trim() : raw;
    return { commandText, payload: parsed as Record<string, unknown> };
  }
  return { commandText: raw, payload: null };
};