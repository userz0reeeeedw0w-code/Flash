import { DoubleUser } from "../types/database";

export const updateGameStats = (user: DoubleUser, outcome: "win" | "lose" | "blackjack" | "push"): void => {
  user.totalGames = (user.totalGames ?? 0) + 1;

  if (outcome === "win" || outcome === "blackjack") {
    user.totalWins = (user.totalWins ?? 0) + 1;
  } else if (outcome === "lose") {
    user.totalLosses = (user.totalLosses ?? 0) + 1;
  }
};
