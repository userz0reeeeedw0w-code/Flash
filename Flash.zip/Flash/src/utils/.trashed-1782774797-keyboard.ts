export type ButtonColor = "primary" | "secondary" | "negative" | "positive" | "default";

export type TextButtonOptions = {
  label: string;
  color?: ButtonColor;
  command?: string;
  payload?: Record<string, unknown>;
};

export type UrlButtonOptions = {
  label: string;
  url: string;
};

export type ButtonOptions = TextButtonOptions | UrlButtonOptions;

export type KeyboardOptions = {
  inline?: boolean;
  oneTime?: boolean;
  buttons: ButtonOptions[][];
};

const isUrlButton = (button: ButtonOptions): button is UrlButtonOptions => {
  return (button as UrlButtonOptions).url !== undefined;
};

export const buildKeyboard = (options: KeyboardOptions): string => {
  const mappedButtons = options.buttons.map(row =>
    row.map(button => {
      if (isUrlButton(button)) {
        return {
          action: {
            type: "open_link",
            link: button.url,
            label: button.label
          }
        };
      }

      const payload: Record<string, unknown> = {};

      if (button.command) {
        payload.command = button.command;
      }

      if (button.payload) {
        for (const [key, value] of Object.entries(button.payload)) {
          payload[key] = value;
        }
      }

      return {
        action: {
          type: "text",
          payload: Object.keys(payload).length > 0 ? JSON.stringify(payload) : "{}",
          label: button.label
        },
        color: button.color ?? "default"
      };
    })
  );

  return JSON.stringify({
    one_time: options.oneTime ?? false,
    inline: options.inline ?? false,
    buttons: mappedButtons
  });
};

