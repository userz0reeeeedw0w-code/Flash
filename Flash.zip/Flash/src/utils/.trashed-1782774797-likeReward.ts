import { LikesIsLikedResponse, WallGetByIdResponse } from "vk-io/lib/api/schemas/responses";
import { VkClients } from "../services/VkClient";
import { DoubleUser, Limits } from "../types/database";
import { formatWithSpaces } from "./number";

export const parseWallRef = (value: string): { ownerId: number; itemId: number; key: string; url: string } | null => {
  const raw = String(value ?? "");
  const match = raw.match(/wall(-?\d+)_(\d+)/i);
  if (!match) return null;
  const ownerId = Number(match[1]);
  const itemId = Number(match[2]);
  if (!Number.isFinite(ownerId) || !Number.isFinite(itemId)) return null;
  const key = `wall${ownerId}_${itemId}`;
  const url = `https://vk.com/${key}`;
  return { ownerId, itemId, key, url };
};

type LikeRewardAttempt = {
  granted: boolean;
  message?: string;
};

const calculateLikeReward = (baseReward: number, postPublishedAt: number): number => {
  const now = Date.now();
  const minutesElapsed = (now - postPublishedAt) / (1000 * 60);
  
  if (minutesElapsed <= 5) {
    return baseReward;
  }
  
  if (minutesElapsed <= 30) {
    const percentage = 100 - (minutesElapsed - 5) * 1.6;
    return Math.floor(baseReward * (percentage / 100));
  }
  
  return Math.floor(baseReward * 0.6);
};

export const tryGrantLikeReward = async (params: {
  user: DoubleUser;
  limits: Limits;
  clients: VkClients;
  silentIfNotLiked?: boolean;
}): Promise<LikeRewardAttempt> => {
  const { user, limits, clients } = params;
  const silentIfNotLiked = Boolean(params.silentIfNotLiked);

  const isActive = Boolean(limits.like?.active);
  const give = typeof limits.like?.give === "number" && Number.isFinite(limits.like.give) ? limits.like.give : 0;
  const activePost = limits.active_post as any;
  
  if (!isActive || !activePost || give <= 0) {
    return silentIfNotLiked ? { granted: false } : { granted: false, message: "Награда за лайк сейчас отключена." };
  }

  const postRef = {
    ownerId: Number(activePost.ownerId),
    itemId: Number(activePost.itemId),
    key: String(activePost.key),
    url: `https://vk.com/${activePost.key}`
  };

  if (!Number.isFinite(postRef.ownerId) || !Number.isFinite(postRef.itemId)) {
    return silentIfNotLiked ? { granted: false } : { granted: false, message: "Пост для награды настроен неверно." };
  }

  if (user.like_claims?.[postRef.key]) {
    return silentIfNotLiked ? { granted: false } : { granted: false, message: "Вы уже получали награду за этот пост." };
  }

  if (!clients.user) {
    return silentIfNotLiked ? { granted: false } : { granted: false, message: "Проверка лайка недоступна: не задан VK_USER_TOKEN." };
  }

  const likedResponse = await clients.user.api.likes.isLiked({
    type: "post",
    owner_id: postRef.ownerId,
    item_id: postRef.itemId,
    user_id: user.id
  });

  const liked = Number(likedResponse?.liked) === 1;
  if (!liked) {
    return silentIfNotLiked
      ? { granted: false }
      : { granted: false, message: `Поставьте лайк на пост и повторите команду:\n${postRef.url}` };
  }

  let postPublishedAt = typeof activePost.publishedAt === "number" ? activePost.publishedAt : Date.now();

  if (!Number.isFinite(postPublishedAt) || postPublishedAt <= 0) {
    try {
      const wallResponse = (await clients.user.api.wall.getById({
        posts: `${postRef.ownerId}_${postRef.itemId}`
      })) as WallGetByIdResponse;

      if (wallResponse?.items?.[0]?.date) {
        postPublishedAt = wallResponse.items[0].date * 1000;
      }
    } catch {}
  }

  const reward = calculateLikeReward(give, postPublishedAt);
  const minutesElapsed = (Date.now() - postPublishedAt) / (1000 * 60);
  const timeStatus = minutesElapsed <= 5 
    ? "⏱️ ГОРЯЧИЙ ПОСТ! Максимальная награда!" 
    : `⏳ ${Math.floor(minutesElapsed)} мин. назад: награда снижена`;

  user.like_claims = user.like_claims ?? {};
  user.like_claims[postRef.key] = Date.now();
  user.balance += reward;

  return { granted: true, message: `Спасибо за лайк! ${timeStatus}\nНаграда: +${formatWithSpaces(reward)} FP 💸` };
};
