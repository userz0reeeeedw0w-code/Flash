export class Logger {
  constructor(private readonly context: string = "App") {}

  private formatMessage(level: string, message: string): string {
    const timestamp = new Date().toISOString();
    return `[${timestamp}] [${level}] [${this.context}] ${message}`;
  }

  info(message: string, data?: unknown): void {
    console.log(this.formatMessage("INFO", message), data ? { data } : "");
  }

  warn(message: string, data?: unknown): void {
    console.warn(this.formatMessage("WARN", message), data ? { data } : "");
  }

  error(message: string, error?: unknown): void {
    console.error(this.formatMessage("ERROR", message), error);
  }

  debug(message: string, data?: unknown): void {
    if (process.env.DEBUG) {
      console.debug(this.formatMessage("DEBUG", message), data ? { data } : "");
    }
  }
}
