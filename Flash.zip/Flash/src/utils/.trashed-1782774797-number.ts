interface DropItem<T = string> {
  readonly value: T;
  readonly weight: number;
}



export const formatWithSpaces = (value: number): string => {
  const absolute = Math.floor(Math.abs(value));
  const reversed = absolute.toString().split("").reverse().join("");
  const groups = reversed.match(/[0-9]{1,3}/g);
  if (!groups) {
    return "0";
  }
  return groups.join(".").split("").reverse().join("");
};

export const randomInt = (min: number, max: number): number => {
  const normalizedMin = Math.ceil(min);
  const normalizedMax = Math.floor(max);
  return Math.floor(Math.random() * (normalizedMax - normalizedMin + 1)) + normalizedMin;
};

export const pick = <T>(array: T[]): T => {
  return array[Math.floor(Math.random() * array.length)];
};

export const randomString = (length: number): string => {
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let result = "";
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
};

export const weighted = <T>(items: DropItem<T>[]): T => {
  let total = items.reduce((acc, item) => acc + item.weight, 0);
  let threshold = Math.random() * total;
  for (const item of items) {
    if (threshold < item.weight) return item.value;
    threshold -= item.weight;
  }
  return items[0].value;
}

