export const secondsToHuman = (seconds: number): string => {
  if (seconds <= 0) {
    return "0 секунд";
  }
  if (seconds >= 604800) {
    const total = Math.floor(seconds / 604800);
    const unit = total % 10 === 1 ? "неделя" : total % 10 >= 2 && total % 10 <= 4 ? "недели" : "недель";
    return `${total} ${unit}`;
  }
  if (seconds >= 86400) {
    const total = Math.floor(seconds / 86400);
    const unit = total % 10 === 1 ? "день" : total % 10 >= 2 && total % 10 <= 4 ? "дня" : "дней";
    return `${total} ${unit}`;
  }
  if (seconds >= 3600) {
    const total = Math.floor(seconds / 3600);
    const unit = total % 10 === 1 ? "час" : total % 10 >= 2 && total % 10 <= 4 ? "часа" : "часов";
    return `${total} ${unit}`;
  }
  if (seconds >= 60) {
    const total = Math.floor(seconds / 60);
    const unit = total % 10 === 1 ? "минута" : total % 10 >= 2 && total % 10 <= 4 ? "минуты" : "минут";
    return `${total} ${unit}`;
  }
  const total = seconds;
  const unit = total % 10 === 1 ? "секунда" : total % 10 >= 2 && total % 10 <= 4 ? "секунды" : "секунд";
  return `${total} ${unit}`;
};

