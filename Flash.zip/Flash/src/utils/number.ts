import { resolveResource } from "vk-io";
import { DoubleUser } from "../../types/database";

interface DropItem<T = string> {
  readonly value: T;
  readonly weight: number;
}

interface ResolveTargetIdOptions {
  targetArg: string;
  allUsers: DoubleUser[];
  platform: string;
  vkApi?: any;
  tgContext?: any;
  message?: any;
  tgUserId?: number;
}

export const resolveTargetId = async ({
  targetArg,
  allUsers,
  platform,
  vkApi,
  tgContext,
  message,
  tgUserId
}: ResolveTargetIdOptions): Promise<number | null> => {
  let targetId: number | null = null;

  if (!targetArg) {
    if (platform === "tg") {
      const tgMsg = message as any;
      if (tgMsg?.replyToMessage?.from?.id) {
        return tgMsg.replyToMessage.from.id;
      }
      if (tgUserId !== undefined) {
        return tgUserId;
      }
    } else {
      const vkMsg = message as any;
      if (vkMsg?.hasReplyMessage && vkMsg?.replyMessage?.senderId) {
        return vkMsg.replyMessage.senderId;
      }
      if (vkMsg?.hasForwards && vkMsg?.forwards?.length > 0 && vkMsg?.forwards[0]?.senderId) {
        return vkMsg.forwards[0].senderId;
      }
      if (vkMsg?.senderId) {
        return vkMsg.senderId;
      }
    }    return null;
  }

  if (/^\d+$/.test(targetArg)) {
    return Number(targetArg);
  }

  if (targetArg.startsWith("[id")) {
    const match = targetArg.match(/^\[id(\d+)\|/i);
    if (match) return Number(match[1]);
  }

  if (targetArg.startsWith("@")) {
    const screenName = targetArg.substring(1);

    if (platform === "tg") {
      const msgObj = tgContext || message;

      if (msgObj?.entities && msgObj.entities.length > 0) {
        for (const entity of msgObj.entities) {
          if (entity.type === "text_mention" && entity.user && entity.user.id) {
            return entity.user.id;
          }
          if (entity.type === "mention" && entity.offset !== undefined && entity.length !== undefined) {
            const mentionedText = msgObj.text?.substring(entity.offset, entity.offset + entity.length);
            if (mentionedText && mentionedText.toLowerCase() === `@${screenName.toLowerCase()}`) {
              const foundUser = allUsers.find((entry) => {
                const tgUser = entry as any;
                return tgUser.tgUsername && tgUser.tgUsername.toLowerCase() === screenName.toLowerCase();
              });
              if (foundUser) {
                const tgUser = foundUser as any;
                return tgUser.tgId || foundUser.id;
              }
            }
          }
        }
      }
    }

    const idMatch = screenName.match(/^id(\d+)$/i);
    if (idMatch) {
      return Number(idMatch[1]);
    }

    const foundUser = allUsers.find((entry) => {
      const tgUser = entry as any;
      if (tgUser.tgUsername && tgUser.tgUsername.toLowerCase() === screenName.toLowerCase()) return true;
      if (tgUser.username && tgUser.username.toLowerCase() === screenName.toLowerCase()) return true;
      if (entry.tag) {        const tagWithoutAt = entry.tag.startsWith("@") ? entry.tag.substring(1) : entry.tag;
        if (tagWithoutAt.toLowerCase() === screenName.toLowerCase()) return true;
      }
      return false;
    });

    if (foundUser) {
      const tgUser = foundUser as any;
      return tgUser.tgId || foundUser.id;
    }

    if (platform !== "tg" && vkApi) {
      try {
        const response = await resolveResource({ api: vkApi, resource: screenName });
        if (response?.type === "user") return response.id;
      } catch (e) {
        console.error("Ошибка при резолве тега: ", e);
      }
    }
  }

  if (targetArg.includes("vk.com") || targetArg.includes("vk.ru")) {
    const linkMatch = targetArg.match(/https?:\/\/vk\.(?:ru|com)\/([a-zA-Z0-9_.-]+)/i);
    if (linkMatch && vkApi) {
      const screenName = linkMatch[1];
      const idMatch = screenName.match(/^id(\d+)$/i);
      if (idMatch) {
        return Number(idMatch[1]);
      }
      try {
        const response = await resolveResource({ api: vkApi, resource: screenName });
        if (response?.type === "user") return response.id;
      } catch (e) {
        console.error("Ошибка при резолве ссылки: ", e);
      }
    }
  }

  return null;
};

export const formatWithSpaces = (value: number): string => {
  const absolute = Math.floor(Math.abs(value));
  const reversed = absolute.toString().split("").reverse().join("");
  const groups = reversed.match(/[0-9]{1,3}/g);
  if (!groups) {
    return "0";
  }
  return groups.join(".").split("").reverse().join("");
};
export const randomInt = (min: number, max: number): number => {
  const normalizedMin = Math.ceil(min);
  const normalizedMax = Math.floor(max);
  return Math.floor(Math.random() * (normalizedMax - normalizedMin + 1)) + normalizedMin;
};

export const pick = <T>(array: T[]): T => {
  return array[Math.floor(Math.random() * array.length)];
};

export const randomString = (length: number): string => {
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let result = "";
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
};

export const weighted = <T>(items: DropItem<T>[]): T => {
  let total = items.reduce((acc, item) => acc + item.weight, 0);
  let threshold = Math.random() * total;
  for (const item of items) {
    if (threshold < item.weight) return item.value;
    threshold -= item.weight;
  }
  return items[0].value;
};