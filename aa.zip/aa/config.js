// ⚡ FLASH BOT — ПОЛНАЯ КОНФИГУРАЦИЯ
module.exports = {
  // Telegram
  telegram: {
    token: '8644234766:AAFs2m5KEbfu-QqwHxc-HTPlVk2DlovgExY',
    adminId: 7151740962,
    groupUsername: '@realflashgame_bot'
  },
  
  // VK
  vk: {
    token: 'vk1.a.v-gcimbhAeOzrMW0UNUijtJ3EU74BkjTpgQIS7jyO6KR02DcjavsTxpv8pNc9y8JSP_bfu2DY3enDybPgl7jYbVdpmeTgIjg0KgDo6yemY0xYfyLJ2YK6hF8EzilOf4MyNU_z-qJDHHmPzYKAU7RlOyJQUjcZybX-DM5MUVEPd_ZtmSAezaTlvSmLruM-gw4ttrQ35b-wjCzm-yeSEtDWQ',
    adminId: 211314690,
    groupId: 212896919
  },
  
  // Настройки игры
  game: {
    startMoney: 1000,
    startEnergy: 100,
    maxEnergy: 100,
    energyRegenMinutes: 5,
    bondCodeExpireMinutes: 5,
    
    cooldowns: {
      work: 300,
      mining: 180,
      fishing: 600,
      hunting: 1200,
      race: 300,
      boss: 120,
      robbery: 1800,
      duel: 600,
      bonus: 86400,
      hourlyBonus: 10800,
      businessCollect: 1800,
      farmCollect: 900,
      printerCollect: 600,
      clanAttack: 3600,
      fortune: 43200,
      hobby: 1800,
      petWalk: 3600,
      call: 300
    },
    
    energyCosts: {
      race: 5,
      boss: 3,
      duel: 8,
      robbery: 15,
      clanAttack: 10,
      corpAttack: 15,
      tournament: 15,
      hobby: 5,
      petWalk: 5,
      caseOpen: 1,
      hunting: 10,
      arena: 5
    }
  },
  
  // Работы
  jobs: [
    { id: 1, name: '🧹 Уборщик', salary: 500, minLevel: 1 },
    { id: 2, name: '📦 Грузчик', salary: 800, minLevel: 3 },
    { id: 3, name: '🚕 Таксист', salary: 1200, minLevel: 5 },
    { id: 4, name: '👷 Строитель', salary: 1800, minLevel: 8 },
    { id: 5, name: '🔧 Механик', salary: 2500, minLevel: 12 },
    { id: 6, name: '💼 Менеджер', salary: 3500, minLevel: 16 },
    { id: 7, name: '👨‍💻 Программист', salary: 5000, minLevel: 20 },
    { id: 8, name: '👨‍⚕️ Врач', salary: 7000, minLevel: 25 },
    { id: 9, name: '👨‍✈️ Пилот', salary: 10000, minLevel: 30 },
    { id: 10, name: '🎬 Директор', salary: 15000, minLevel: 40 }
  ],
  
  // Бизнесы
  businesses: [
    { id: 1, name: '🏪 Ларёк', price: 50000, income: 1000, maxLevel: 10 },
    { id: 2, name: '☕ Кофейня', price: 150000, income: 3000, maxLevel: 10 },
    { id: 3, name: '🍕 Пиццерия', price: 300000, income: 6000, maxLevel: 10 },
    { id: 4, name: '🏨 Отель', price: 500000, income: 10000, maxLevel: 10 },
    { id: 5, name: '🏢 Офис', price: 1000000, income: 20000, maxLevel: 10 },
    { id: 6, name: '🏭 Завод', price: 2000000, income: 40000, maxLevel: 10 },
    { id: 7, name: '🎰 Казино', price: 5000000, income: 100000, maxLevel: 10 },
    { id: 8, name: '🏦 Банк', price: 10000000, income: 200000, maxLevel: 10 }
  ],
  
  // Донат бизнесы
  donatBusinesses: [
    { id: 101, name: '💎 VIP Клуб', price: 100, income: 50000, maxLevel: 20 },
    { id: 102, name: '🌟 Элитный Отель', price: 250, income: 150000, maxLevel: 20 },
    { id: 103, name: '👑 Империя', price: 500, income: 400000, maxLevel: 20 }
  ],
  
  // Машины
  cars: [
    { id: 1, name: '🚗 Жигули', price: 10000, speed: 100 },
    { id: 2, name: '🚙 Toyota', price: 50000, speed: 150 },
    { id: 3, name: '🏎️ BMW', price: 150000, speed: 200 },
    { id: 4, name: '🏎️ Mercedes', price: 300000, speed: 250 },
    { id: 5, name: '🏎️ Porsche', price: 500000, speed: 300 },
    { id: 6, name: '🏎️ Ferrari', price: 1000000, speed: 350 },
    { id: 7, name: '🏎️ Lamborghini', price: 2000000, speed: 400 },
    { id: 8, name: '🏎️ Bugatti', price: 5000000, speed: 450 }
  ],
  
  // Фермы
  farms: [
    { id: 1, name: '⚡ Базовая ферма', price: 100000, btcPerHour: 0.0001, maxCount: 5 },
    { id: 2, name: '⚡ Продвинутая ферма', price: 500000, btcPerHour: 0.0005, maxCount: 3 },
    { id: 3, name: '⚡ Мега ферма', price: 2000000, btcPerHour: 0.002, maxCount: 2 },
    { id: 4, name: '⚡ Ультра ферма', price: 10000000, btcPerHour: 0.01, maxCount: 1 }
  ],
  
  // Принтеры
  printers: [
    { id: 1, name: '🖨️ Базовый', price: 50000, income: 500, fuelCost: 100, maxLevel: 10, maxCount: 5 },
    { id: 2, name: '🖨️ Продвинутый', price: 200000, income: 2000, fuelCost: 300, maxLevel: 10, maxCount: 3 },
    { id: 3, name: '🖨️ Промышленный', price: 1000000, income: 10000, fuelCost: 1000, maxLevel: 10, maxCount: 2 }
  ],
  
  // Руды
  ores: [
    { id: 1, name: 'ite Камень', price: 10, minLevel: 1 },
    { id: 2, name: '⬛ Уголь', price: 25, minLevel: 3 },
    { id: 3, name: '🔶 Медь', price: 50, minLevel: 5 },
    { id: 4, name: '⬜ Железо', price: 100, minLevel: 8 },
    { id: 5, name: '🟡 Золото', price: 250, minLevel: 12 },
    { id: 6, name: '💎 Алмаз', price: 500, minLevel: 18 },
    { id: 7, name: '💠 Изумруд', price: 1000, minLevel: 25 }
  ],
  
  // Рыба
  fishes: [
    { id: 1, name: '🐟 Карась', price: 50, chance: 30 },
    { id: 2, name: '🐠 Окунь', price: 100, chance: 25 },
    { id: 3, name: '🐡 Щука', price: 200, chance: 20 },
    { id: 4, name: '🦈 Сом', price: 350, chance: 15 },
    { id: 5, name: '🐋 Осётр', price: 500, chance: 8 },
    { id: 6, name: '🐙 Золотая рыбка', price: 1000, chance: 2 }
  ],
  
  // Животные для охоты
  animals: [
    { id: 1, name: '🐰 Заяц', price: 100, chance: 30 },
    { id: 2, name: '🦊 Лиса', price: 200, chance: 25 },
    { id: 3, name: '🐗 Кабан', price: 350, chance: 20 },
    { id: 4, name: '🦌 Олень', price: 500, chance: 15 },
    { id: 5, name: '🐻 Медведь', price: 1000, chance: 8 },
    { id: 6, name: '🦁 Лев', price: 2000, chance: 2 }
  ],
  
  // Питомцы
  pets: [
    { id: 1, name: '🐕 Собака', price: 10000, bonus: 5 },
    { id: 2, name: '🐈 Кошка', price: 8000, bonus: 3 },
    { id: 3, name: '🐦 Попугай', price: 15000, bonus: 7 },
    { id: 4, name: '🐹 Хомяк', price: 5000, bonus: 2 },
    { id: 5, name: '🐢 Черепаха', price: 12000, bonus: 5 },
    { id: 6, name: '🦎 Ящерица', price: 20000, bonus: 10 },
    { id: 7, name: '🐍 Змея', price: 25000, bonus: 12 },
    { id: 8, name: '🦅 Орёл', price: 50000, bonus: 20 },
    { id: 9, name: '🐉 Дракон', price: 500000, bonus: 50 },
    { id: 10, name: '🦄 Единорог', price: 1000000, bonus: 100 }
  ],
  
  // Дома
  houses: [
    { id: 1, name: '🏚️ Хижина', price: 50000, slots: 1 },
    { id: 2, name: '🏠 Дом', price: 200000, slots: 2 },
    { id: 3, name: '🏡 Коттедж', price: 500000, slots: 3 },
    { id: 4, name: '🏘️ Вилла', price: 1500000, slots: 5 },
    { id: 5, name: '🏰 Особняк', price: 5000000, slots: 10 }
  ],
  
  // Телефоны
  phones: [
    { id: 1, name: '📱 Старый Nokia', price: 1000 },
    { id: 2, name: '📱 Samsung', price: 20000 },
    { id: 3, name: '📱 iPhone', price: 50000 },
    { id: 4, name: '📱 iPhone Pro', price: 100000 }
  ],
  
  // Кейсы
  cases: [
    { id: 1, name: '📦 Обычный кейс', price: 1000, rewards: [500, 1000, 2000, 5000] },
    { id: 2, name: '📦 Редкий кейс', price: 5000, rewards: [2500, 5000, 10000, 25000] },
    { id: 3, name: '📦 Эпический кейс', price: 20000, rewards: [10000, 25000, 50000, 100000] },
    { id: 4, name: '📦 Легендарный кейс', price: 100000, rewards: [50000, 100000, 250000, 500000] }
  ],
  
  // Привилегии
  privileges: {
    vip: {
      name: 'VIP',
      price: 50,
      bonuses: { incomeMultiplier: 1.2, casinoChanceBonus: 5, raceCupsMultiplier: 1.5, cooldownReduction: 0.9, maxBusinesses: 2 }
    },
    premium: {
      name: 'PREMIUM',
      price: 100,
      bonuses: { incomeMultiplier: 1.5, casinoChanceBonus: 10, raceCupsMultiplier: 2, cooldownReduction: 0.75, maxBusinesses: 3 }
    },
    legend: {
      name: 'LEGEND',
      price: 200,
      bonuses: { incomeMultiplier: 2, casinoChanceBonus: 15, raceCupsMultiplier: 2.5, cooldownReduction: 0.5, maxBusinesses: 4 }
    },
    ultimate: {
      name: 'ULTIMATE',
      price: 500,
      bonuses: { incomeMultiplier: 3, casinoChanceBonus: 20, raceCupsMultiplier: 3, cooldownReduction: 0.25, maxBusinesses: 5 }
    }
  },
  
  // Путь новичка
  beginnerPath: [
    { stage: 1, task: 'Написать сообщение', reward: { money: 1000, exp: 50 }, action: 'message', cmd: 'профиль' },
    { stage: 2, task: 'Получить бонус', reward: { money: 2000, exp: 100 }, action: 'bonus', cmd: 'бонус' },
    { stage: 3, task: 'Пополнить банк', reward: { money: 3000, exp: 150 }, action: 'bank', cmd: 'банк положить 100' },
    { stage: 4, task: 'Купить машину', reward: { money: 5000, exp: 200 }, action: 'car', cmd: 'машина купить 1' },
    { stage: 5, task: 'Устроиться на работу', reward: { money: 8000, exp: 250 }, action: 'job', cmd: 'работа 1' },
    { stage: 6, task: 'Отработать смену', reward: { money: 10000, exp: 300 }, action: 'work', cmd: 'работать' },
    { stage: 7, task: 'Купить бизнес', reward: { money: 15000, exp: 400 }, action: 'business', cmd: 'бизнес купить 1' },
    { stage: 8, task: 'Собрать бизнес', reward: { money: 20000, exp: 500 }, action: 'collect', cmd: 'бизнес собрать 1' },
    { stage: 9, task: 'Атаковать босса', reward: { money: 30000, exp: 750 }, action: 'boss', cmd: 'босс атака' },
    { stage: 10, task: 'Накопить 100,000$', reward: { money: 100000, exp: 2000, diamonds: 10 }, action: 'rich', cmd: 'баланс' }
  ],
  
  // Квесты ежедневные
  dailyQuests: [
    { id: 1, name: 'Заработать 10,000$', target: 10000, type: 'earn', reward: { money: 2000, exp: 50 } },
    { id: 2, name: 'Выиграть 3 гонки', target: 3, type: 'race_wins', reward: { money: 5000, exp: 100, cups: 5 } },
    { id: 3, name: 'Атаковать босса 5 раз', target: 5, type: 'boss_attacks', reward: { money: 3000, exp: 75 } },
    { id: 4, name: 'Поймать 10 рыб', target: 10, type: 'fish', reward: { money: 2000, exp: 50 } },
    { id: 5, name: 'Ограбить 2 игроков', target: 2, type: 'robberies', reward: { money: 4000, exp: 100 } },
    { id: 6, name: 'Собрать бизнес 3 раза', target: 3, type: 'business_collect', reward: { money: 3000, exp: 75 } },
    { id: 7, name: 'Сделать 5 ставок', target: 5, type: 'casino_bets', reward: { money: 2000, exp: 50 } },
    { id: 8, name: 'Поработать 2 смены', target: 2, type: 'work_shifts', reward: { money: 3000, exp: 75 } }
  ],
  
  // Квесты недельные
  weeklyQuests: [
    { id: 1, name: 'Заработать 100,000$', target: 100000, type: 'earn', reward: { money: 20000, exp: 500, diamonds: 5 } },
    { id: 2, name: 'Выиграть 20 гонок', target: 20, type: 'race_wins', reward: { money: 30000, exp: 750, diamonds: 10 } },
    { id: 3, name: 'Убить 10 боссов', target: 10, type: 'boss_kills', reward: { money: 25000, exp: 600, diamonds: 5 } },
    { id: 4, name: 'Накопать 1000 руды', target: 1000, type: 'ore_mined', reward: { money: 15000, exp: 400, diamonds: 3 } },
    { id: 5, name: 'Поймать 50 рыб', target: 50, type: 'fish', reward: { money: 15000, exp: 400, diamonds: 3 } }
  ],
  
  // Достижения
  achievements: [
    { id: 1, name: '🎮 Первые шаги', desc: 'Зарегистрироваться', reward: { money: 1000, exp: 100 } },
    { id: 2, name: '💰 Богач', desc: 'Накопить 1,000,000$', reward: { money: 50000, exp: 500, diamonds: 5 } },
    { id: 3, name: '🏎️ Гонщик', desc: 'Выиграть 100 гонок', reward: { money: 100000, exp: 1000, diamonds: 10 } },
    { id: 4, name: '⚔️ Воин', desc: 'Нанести 1,000,000 урона', reward: { money: 100000, exp: 1000, diamonds: 10 } },
    { id: 5, name: '🏢 Магнат', desc: 'Купить 5 бизнесов', reward: { money: 200000, exp: 2000, diamonds: 20 } },
    { id: 6, name: '⛏️ Шахтёр', desc: 'Накопать 10,000 руды', reward: { money: 50000, exp: 500, diamonds: 5 } },
    { id: 7, name: '🎣 Рыболов', desc: 'Поймать 500 рыб', reward: { money: 50000, exp: 500, diamonds: 5 } },
    { id: 8, name: '👑 Легенда', desc: 'Достичь 50 уровня', reward: { money: 500000, exp: 5000, diamonds: 50 } }
  ],
  
  // События
  events: [
    { id: 1, name: '💰 Двойной доход', type: 'double_income', duration: 3600 },
    { id: 2, name: '⚡ Быстрая энергия', type: 'fast_energy', duration: 3600 },
    { id: 3, name: '🎰 Удачное казино', type: 'lucky_casino', duration: 1800 },
    { id: 4, name: '🏎️ Турбо гонки', type: 'turbo_race', duration: 1800 }
  ],
  
  // Хобби
  hobbies: [
    { id: 1, name: '🎸 Гитара', bonusType: 'exp', bonusValue: 5 },
    { id: 2, name: '🎨 Рисование', bonusType: 'money', bonusValue: 100 },
    { id: 3, name: '📚 Чтение', bonusType: 'exp', bonusValue: 10 },
    { id: 4, name: '🏃 Бег', bonusType: 'energy', bonusValue: 5 },
    { id: 5, name: '🎮 Игры', bonusType: 'exp', bonusValue: 3 }
  ]
};
