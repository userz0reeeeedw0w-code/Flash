// handler.js
const db = require('./utils/database');
const keyboards = require('./utils/keyboards');
const config = require('./config');
const { formatMoney, formatNumber, formatTime, checkCooldown, random, randomElement, levelFromExp, progressBar, isAdmin, getCooldownMultiplier, getIncomeMultiplier } = require('./utils/helpers');

const keyboardMap = {
  '👤 профиль': 'профиль',
  '💰 баланс': 'баланс',
  '🏪 магазин': 'магазин',
  '⚔️ босс': 'босс',
  '🏁 гонка': 'гонка',
  '💼 работа': 'работа',
  '🏛️ клан': 'клан',
  '🎰 казино': 'казино',
  '🎁 бонус': 'бонус',
  '📊 топ': 'топ',
  '❓ помощь': 'помощь',
  '📍 путь новичка': 'путь новичка'
};

const commands = {
  async start(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (user) {
      const lvl = levelFromExp(user.exp);
      return {
        text: `⚡ FLASH BOT
━━━━━━━━━━━━━━━━━━━━
👋 С возвращением, ${user.name}!
🆔 ID: #${user.id}

💰 ${formatMoney(user.money)} | 🏦 ${formatMoney(user.bank)}
📊 Уровень: ${lvl.level} | ⚡ ${user.energy}/${config.game.maxEnergy}`,
        keyboard: keyboards.tg.main
      };
    }
    return {
      text: `⚡ ДОБРО ПОЖАЛОВАТЬ В FLASH!
━━━━━━━━━━━━━━━━━━━━
🎮 Экономическая RPG игра

Выберите действие:`,
      keyboard: keyboards.tg.start
    };
  },

  async createAccount(ctx) {
    if (db.getUserByPlatform(ctx.platform, ctx.userId)) {
      return { text: '❌ У вас уже есть аккаунт!', keyboard: keyboards.tg.main };
    }
    const user = db.createUser(ctx.platform, ctx.userId, ctx.userName);
    if (!user) return { text: '❌ Ошибка создания аккаунта', keyboard: keyboards.tg.start };
    db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'message');
    return {
      text: `✅ АККАУНТ СОЗДАН!
━━━━━━━━━━━━━━━━━━━━
👤 Ник: ${user.name}
🆔 ID: #${user.id}
💰 Баланс: ${formatMoney(user.money)}

🎁 Достижение «Первые шаги» получено!
📍 Начните с «путь новичка»!

💡 Промокод: FLASH`,
      keyboard: keyboards.tg.main
    };
  },

  async bind(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Сначала создайте аккаунт!', keyboard: keyboards.tg.start };
    const code = db.createBondCode(ctx.platform, ctx.userId);
    return {
      text: `🔗 КОД ПРИВЯЗКИ
━━━━━━━━━━━━━━━━━━━━
📝 Код: ${code}
⏰ Действует: 5 минут

📌 На другой платформе напишите:
код ${code}`,
      keyboard: keyboards.tg.bind
    };
  },

  async useCode(ctx, code) {
    if (db.getUserByPlatform(ctx.platform, ctx.userId)) {
      return { text: '❌ У вас уже есть аккаунт!', keyboard: keyboards.tg.main };
    }
    const result = db.useBondCode(code, ctx.platform, ctx.userId);
    if (!result.success) return { text: `❌ ${result.error}`, keyboard: keyboards.tg.start };
    return {
      text: `✅ АККАУНТ ПРИВЯЗАН!
━━━━━━━━━━━━━━━━━━━━
👤 ${result.user.name} (#${result.user.id})
💰 ${formatMoney(result.user.money)}`,
      keyboard: keyboards.tg.main
    };
  },

  async profile(ctx, targetId) {
    let user, isSelf = true;
    if (targetId) {
      user = db.getUserById(targetId.replace('#', ''));
      isSelf = false;
    } else {
      user = db.getUserByPlatform(ctx.platform, ctx.userId);
    }
    if (!user) return { text: '❌ Игрок не найден!', keyboard: keyboards.tg.main };
    
    const lvl = levelFromExp(user.exp);
    const job = user.job ? config.jobs.find(j => j.id === user.job)?.name : '❌ Нет';
    const car = user.currentCar ? config.cars.find(c => c.id === user.currentCar)?.name : '❌ Нет';
    const clan = user.clanId ? db.clans[user.clanId]?.name : '❌ Нет';
    const priv = user.privilege && user.privilegeExpires > Date.now() 
      ? `${user.privilege} (${Math.ceil((user.privilegeExpires - Date.now()) / 86400000)} дн.)` : '❌ Нет';

    return {
      text: `👤 ПРОФИЛЬ${isSelf ? '' : ` — ${user.name}`}
━━━━━━━━━━━━━━━━━━━━
🆔 ID: #${user.id}
📝 Ник: ${user.name}
👑 ${priv}

📊 Уровень: ${lvl.level}
${progressBar(lvl.currentExp, lvl.nextExp)} ${lvl.currentExp}/${lvl.nextExp}

💰 ${formatMoney(user.money)} | 🏦 ${formatMoney(user.bank)}
₿ ${user.bitcoin.toFixed(6)} | 💎 ${user.diamonds} | 🏆 ${user.cups}

💼 ${job}
🚗 ${car} | 🔧 Тюнинг: ${user.tuning}/20
🏛️ ${clan}
🏠 ${user.house > 0 ? config.houses[user.house - 1]?.name : '❌ Нет'}
⚡ ${user.energy}/${config.game.maxEnergy}`,
      keyboard: isSelf ? keyboards.tg.profile : keyboards.tg.back('back_main')
    };
  },

  async stats(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    const s = user.stats;
    return {
      text: `📊 СТАТИСТИКА
━━━━━━━━━━━━━━━━━━━━
💰 Заработано: ${formatMoney(s.totalEarned)}

🏁 Гонки: ${s.raceWins} побед / ${s.raceLosses} поражений
⚔️ Босс: ${s.bossAttacks} атак, ${s.bossKills} убийств
💼 Работа: ${s.workShifts} смен
🏢 Бизнес: ${s.businessCollects} сборов

🎰 Казино: ${s.casinoBets} ставок
✅ Побед: ${s.casinoWins} | ❌ Проигрышей: ${s.casinoLosses}

⛏️ Руды: ${formatNumber(s.oreMined)}
🎣 Рыбы: ${s.fishCaught}
🏹 Охота: ${s.huntingSuccess}

⚔️ Дуэли: ${s.duelWins} побед / ${s.duelLosses} поражений
🔫 Ограблений: ${s.robberies} (${s.robberiesSuccess} успешных)`,
      keyboard: keyboards.tg.profile
    };
  },

  async achievements(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    let text = `🏆 ДОСТИЖЕНИЯ (${user.achievements.length}/${config.achievements.length})\n━━━━━━━━━━━━━━━━━━━━`;
    config.achievements.forEach(a => {
      const done = user.achievements.includes(a.id);
      text += `\n${done ? '✅' : '⬜'} ${a.name}\n   ${a.desc}`;
      if (!done) text += `\n   💰 ${formatMoney(a.reward.money)}${a.reward.diamonds ? ` +${a.reward.diamonds}💎` : ''}`;
    });
    return { text, keyboard: keyboards.tg.profile };
  },

  async inventory(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (!user.inventory || user.inventory.length === 0) {
      return { text: '📦 ИНВЕНТАРЬ\n━━━━━━━━━━━━━━━━━━━━\n🗑️ Пусто', keyboard: keyboards.tg.profile };
    }
    let text = `📦 ИНВЕНТАРЬ (${user.inventory.length})\n━━━━━━━━━━━━━━━━━━━━`;
    user.inventory.forEach((item, i) => { text += `\n${i + 1}. ${item.name} x${item.count || 1}`; });
    return { text, keyboard: keyboards.tg.profile };
  },

  async balance(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    const btcRate = 50000 + random(0, 10000);
    return {
      text: `💰 БАЛАНС
━━━━━━━━━━━━━━━━━━━━
💵 Наличные: ${formatMoney(user.money)}
🏦 Банк: ${formatMoney(user.bank)}
━━━━━━━━━━━━━━━━━━━━
₿ BTC: ${user.bitcoin.toFixed(6)}
   ≈ ${formatMoney(Math.floor(user.bitcoin * btcRate))}
💎 Алмазы: ${user.diamonds}
🏆 Кубки: ${user.cups}
💴 Рубли: ${formatNumber(user.rubles)}₽`,
      keyboard: keyboards.tg.balance
    };
  },

  async bank(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    let creditText = user.credit ? `\n💳 Кредит: ${formatMoney(user.credit.amount)}` : '';
    return {
      text: `🏦 БАНК
━━━━━━━━━━━━━━━━━━━━
💵 Наличные: ${formatMoney(user.money)}
🏦 На счету: ${formatMoney(user.bank)}
📊 Лимит: ${formatMoney(user.bankLimit)}${creditText}

📌 Команды:
• банк положить [сумма/все]
• банк снять [сумма/все]`,
      keyboard: keyboards.tg.bank
    };
  },

  async bankDeposit(ctx, amount) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (amount === 'все' || amount === 'all') amount = Math.min(user.money, user.bankLimit - user.bank);
    else amount = parseInt(amount);
    if (!amount || amount <= 0) return { text: '❌ Укажите сумму!', keyboard: keyboards.tg.bank };
    if (user.money < amount) return { text: `❌ Недостаточно! У вас: ${formatMoney(user.money)}`, keyboard: keyboards.tg.bank };
    if (user.bank + amount > user.bankLimit) return { text: `❌ Превышен лимит! Можно: ${formatMoney(user.bankLimit - user.bank)}`, keyboard: keyboards.tg.bank };
    user.money -= amount;
    user.bank += amount;
    db.saveAll();
    const path = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'bank');
    let pathText = path ? `\n\n🎉 ПУТЬ НОВИЧКА: Этап ${path.stage}!\n+${formatMoney(path.reward.money)}` : '';
    return { text: `✅ Положено: ${formatMoney(amount)}\n💵 Наличные: ${formatMoney(user.money)}\n🏦 Банк: ${formatMoney(user.bank)}${pathText}`, keyboard: keyboards.tg.bank };
  },

  async bankWithdraw(ctx, amount) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (amount === 'все' || amount === 'all') amount = user.bank;
    else amount = parseInt(amount);
    if (!amount || amount <= 0) return { text: '❌ Укажите сумму!', keyboard: keyboards.tg.bank };
    if (user.bank < amount) return { text: `❌ В банке: ${formatMoney(user.bank)}`, keyboard: keyboards.tg.bank };
    user.bank -= amount;
    user.money += amount;
    db.saveAll();
    return { text: `✅ Снято: ${formatMoney(amount)}\n💵 Наличные: ${formatMoney(user.money)}\n🏦 Банк: ${formatMoney(user.bank)}`, keyboard: keyboards.tg.bank };
  },

  async transfer(ctx, targetId, amount) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    const target = db.getUserById(String(targetId).replace('#', ''));
    if (!target) return { text: '❌ Игрок не найден!', keyboard: keyboards.tg.balance };
    if (target.uid === user.uid) return { text: '❌ Нельзя перевести себе!', keyboard: keyboards.tg.balance };
    amount = parseInt(amount);
    if (!amount || amount < 100) return { text: '❌ Минимум: 100$', keyboard: keyboards.tg.balance };
    if (user.money < amount) return { text: `❌ Недостаточно! У вас: ${formatMoney(user.money)}`, keyboard: keyboards.tg.balance };
    const commission = Math.floor(amount * 0.03);
    const received = amount - commission;
    user.money -= amount;
    target.money += received;
    target.notifications = target.notifications || [];
    target.notifications.push({ type: 'transfer', from: user.name, fromId: user.id, amount: received, date: Date.now() });
    db.saveAll();
    return {
      text: `✅ ПЕРЕВОД
━━━━━━━━━━━━━━━━━━━━
👤 Кому: ${target.name} (#${target.id})
💰 Сумма: ${formatMoney(amount)}
📊 Комиссия 3%: ${formatMoney(commission)}
✅ Получено: ${formatMoney(received)}`,
      keyboard: keyboards.tg.balance,
      notify: { platform: Object.keys(target.platforms)[0], odid: target.platforms[Object.keys(target.platforms)[0]], text: `💸 ПЕРЕВОД от ${user.name} (#${user.id})\n💰 Сумма: ${formatMoney(received)}` }
    };
  },

  async job(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (!user.job) {
      return { text: `💼 РАБОТА\n━━━━━━━━━━━━━━━━━━━━\n❌ Вы безработный!\n\n📌 работа список\n📌 работа [номер]`, keyboard: keyboards.tg.job };
    }
    const jobInfo = config.jobs.find(j => j.id === user.job);
    const cd = checkCooldown(user.cooldowns?.work, config.game.cooldowns.work * getCooldownMultiplier(user, config));
    return {
      text: `💼 РАБОТА
━━━━━━━━━━━━━━━━━━━━
📋 ${jobInfo.name}
💰 Зарплата: ${formatMoney(jobInfo.salary)}
📊 Смен: ${user.workStreak}
${cd.ready ? '✅ Можно работать!' : `⏰ Ожидание: ${formatTime(cd.remaining)}`}`,
      keyboard: keyboards.tg.job
    };
  },

  async jobList(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    const lvl = levelFromExp(user.exp).level;
    let text = `💼 ВАКАНСИИ\n━━━━━━━━━━━━━━━━━━━━`;
    config.jobs.forEach(j => {
      const avail = lvl >= j.minLevel ? '✅' : '🔒';
      text += `\n${avail} ${j.id}. ${j.name}\n   💰 ${formatMoney(j.salary)} | С ${j.minLevel} ур.`;
    });
    text += `\n\n📌 работа [номер]`;
    return { text, keyboard: keyboards.tg.job };
  },

  async jobApply(ctx, jobId) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (user.job) return { text: '❌ Сначала уволитесь!', keyboard: keyboards.tg.job };
    const job = config.jobs.find(j => j.id === parseInt(jobId));
    if (!job) return { text: '❌ Работа не найдена!', keyboard: keyboards.tg.job };
    const lvl = levelFromExp(user.exp).level;
    if (lvl < job.minLevel) return { text: `❌ Нужен ${job.minLevel} уровень!`, keyboard: keyboards.tg.job };
    user.job = job.id;
    user.workStreak = 0;
    db.saveAll();
    const path = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'job');
    let pathText = path ? `\n\n🎉 ПУТЬ НОВИЧКА: Этап ${path.stage}!` : '';
    return { text: `✅ Вы устроились: ${job.name}\n💰 Зарплата: ${formatMoney(job.salary)}${pathText}`, keyboard: keyboards.tg.job };
  },

  async work(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (!user.job) return { text: '❌ Вы безработный!', keyboard: keyboards.tg.job };
    const cdTime = config.game.cooldowns.work * getCooldownMultiplier(user, config);
    const cd = checkCooldown(user.cooldowns?.work, cdTime);
    if (!cd.ready) return { text: `⏰ Время ожидания: ${formatTime(cd.remaining)}`, keyboard: keyboards.tg.job };
    const job = config.jobs.find(j => j.id === user.job);
    const bonus = random(0, Math.floor(job.salary * 0.3));
    let salary = (job.salary + bonus) * getIncomeMultiplier(user, config);
    salary = Math.floor(salary);
    const exp = random(10, 50);
    user.money += salary;
    user.cooldowns = user.cooldowns || {};
    user.cooldowns.work = Date.now();
    user.workStreak++;
    user.stats.workShifts++;
    user.stats.totalEarned += salary;
    const lvlUp = db.addExp(user, exp);
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'work_shifts', 1);
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'earn', salary);
    db.saveAll();
    const path = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'work');
    let pathText = path ? `\n\n🎉 ПУТЬ НОВИЧКА: Этап ${path.stage}!` : '';
    let lvlText = lvlUp.leveledUp ? `\n\n🎉 УРОВЕНЬ ${lvlUp.newLevel}!` : '';
    return {
      text: `💼 РАБОТА ВЫПОЛНЕНА!
━━━━━━━━━━━━━━━━━━━━
📋 ${job.name}
💰 +${formatMoney(salary)} (бонус: ${formatMoney(bonus)})
⭐ +${exp} XP
📊 Смен: ${user.workStreak}

💵 Баланс: ${formatMoney(user.money)}${pathText}${lvlText}`,
      keyboard: keyboards.tg.job
    };
  },

  async jobQuit(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (!user.job) return { text: '❌ Вы и так безработный!', keyboard: keyboards.tg.job };
    const job = config.jobs.find(j => j.id === user.job);
    user.job = null;
    user.workStreak = 0;
    db.saveAll();
    return { text: `✅ Вы уволились с ${job.name}`, keyboard: keyboards.tg.job };
  },

  async business(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (!user.businesses || user.businesses.length === 0) {
      return { text: `🏢 БИЗНЕСЫ\n━━━━━━━━━━━━━━━━━━━━\n❌ У вас нет бизнесов!\n\n📌 бизнес список\n📌 бизнес купить [номер]`, keyboard: keyboards.tg.business };
    }
    let text = `🏢 ВАШИ БИЗНЕСЫ (${user.businesses.length})\n━━━━━━━━━━━━━━━━━━━━`;
    user.businesses.forEach((biz, i) => {
      const info = config.businesses.find(b => b.id === biz.id) || config.donatBusinesses.find(b => b.id === biz.id);
      const income = Math.floor(info.income * (1 + biz.level * 0.1) * getIncomeMultiplier(user, config));
      const cd = checkCooldown(biz.lastCollect, config.game.cooldowns.businessCollect);
      text += `\n${i + 1}. ${info.name} [Ур.${biz.level}]\n   💰 ${formatMoney(income)} | ${cd.ready ? '✅' : `⏰ ${formatTime(cd.remaining)}`}`;
    });
    return { text, keyboard: keyboards.tg.business };
  },

  async businessList(ctx) {
    let text = `🏢 БИЗНЕСЫ\n━━━━━━━━━━━━━━━━━━━━`;
    config.businesses.forEach(b => {
      text += `\n${b.id}. ${b.name}\n   💰 ${formatMoney(b.price)} | 📈 ${formatMoney(b.income)}/сбор`;
    });
    text += `\n\n💎 ДОНАТ:\n`;
    config.donatBusinesses.forEach(b => {
      text += `\n${b.id}. ${b.name}\n   💎 ${b.price} | 📈 ${formatMoney(b.income)}/сбор`;
    });
    return { text, keyboard: keyboards.tg.business };
  },

  async businessBuy(ctx, bizId) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    let maxBiz = 1;
    if (user.privilege && user.privilegeExpires > Date.now()) {
      const priv = config.privileges[user.privilege.toLowerCase()];
      if (priv) maxBiz = priv.bonuses.maxBusinesses;
    }
    if (user.businesses.length >= maxBiz) return { text: `❌ Макс бизнесов: ${maxBiz}. Купите привилегию!`, keyboard: keyboards.tg.business };
    const id = parseInt(bizId);
    let biz = config.businesses.find(b => b.id === id);
    let isDonate = false;
    if (!biz) { biz = config.donatBusinesses.find(b => b.id === id); isDonate = true; }
    if (!biz) return { text: '❌ Бизнес не найден!', keyboard: keyboards.tg.business };
    if (user.businesses.find(b => b.id === id)) return { text: '❌ Уже есть!', keyboard: keyboards.tg.business };
    if (isDonate) {
      if (user.diamonds < biz.price) return { text: `❌ Нужно: ${biz.price}💎`, keyboard: keyboards.tg.business };
      user.diamonds -= biz.price;
    } else {
      if (user.money < biz.price) return { text: `❌ Нужно: ${formatMoney(biz.price)}`, keyboard: keyboards.tg.business };
      user.money -= biz.price;
    }
    user.businesses.push({ id: biz.id, level: 1, lastCollect: 0, manager: false });
    db.saveAll();
    const path = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'business');
    let pathText = path ? `\n\n🎉 ПУТЬ НОВИЧКА: Этап ${path.stage}!` : '';
    const achs = db.checkAchievements(`${ctx.platform}_${ctx.userId}`);
    let achText = achs.length > 0 ? `\n🏆 ${achs.map(a => a.name).join(', ')}` : '';
    return { text: `✅ Куплен: ${biz.name}\n📈 Доход: ${formatMoney(biz.income)}/сбор${pathText}${achText}`, keyboard: keyboards.tg.business };
  },

  async businessCollect(ctx, idx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (!user.businesses || user.businesses.length === 0) return { text: '❌ Нет бизнесов!', keyboard: keyboards.tg.business };
    
    if (idx === 'все' || idx === 'all' || !idx) {
      let total = 0, count = 0;
      user.businesses.forEach(biz => {
        const cd = checkCooldown(biz.lastCollect, config.game.cooldowns.businessCollect);
        if (cd.ready) {
          const info = config.businesses.find(b => b.id === biz.id) || config.donatBusinesses.find(b => b.id === biz.id);
          let income = Math.floor(info.income * (1 + biz.level * 0.1) * getIncomeMultiplier(user, config));
          if (biz.manager) income = Math.floor(income * 1.15);
          total += income;
          biz.lastCollect = Date.now();
          count++;
        }
      });
      if (count === 0) return { text: '❌ Нечего собирать!', keyboard: keyboards.tg.business };
      user.money += total;
      user.stats.businessCollects += count;
      user.stats.totalEarned += total;
      db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'business_collect', count);
      db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'earn', total);
      db.saveAll();
      const path = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'collect');
      let pathText = path ? `\n\n🎉 ПУТЬ НОВИЧКА: Этап ${path.stage}!` : '';
      return { text: `✅ Собрано с ${count} бизнесов: ${formatMoney(total)}${pathText}`, keyboard: keyboards.tg.business };
    }
    
    const i = parseInt(idx) - 1;
    const biz = user.businesses[i];
    if (!biz) return { text: '❌ Бизнес не найден!', keyboard: keyboards.tg.business };
    const cd = checkCooldown(biz.lastCollect, config.game.cooldowns.businessCollect);
    if (!cd.ready) return { text: `⏰ Ожидание: ${formatTime(cd.remaining)}`, keyboard: keyboards.tg.business };
    const info = config.businesses.find(b => b.id === biz.id) || config.donatBusinesses.find(b => b.id === biz.id);
    let income = Math.floor(info.income * (1 + biz.level * 0.1) * getIncomeMultiplier(user, config));
    user.money += income;
    biz.lastCollect = Date.now();
    user.stats.businessCollects++;
    user.stats.totalEarned += income;
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'business_collect', 1);
    db.saveAll();
    return { text: `✅ ${info.name}: +${formatMoney(income)}`, keyboard: keyboards.tg.business };
  },

  async casino(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    return {
      text: `🎰 КАЗИНО
━━━━━━━━━━━━━━━━━━━━
💰 Баланс: ${formatMoney(user.money)}

🎮 Игры:
• казино [ставка] — слоты
• казино рулетка [ставка] [цвет]
• казино кости [ставка] [число]`,
      keyboard: keyboards.tg.casino
    };
  },

  async casinoSlots(ctx, betStr) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    let bet = betStr === 'все' || betStr === 'all' ? user.money : parseInt(betStr);
    if (!bet || bet < 100) return { text: '❌ Минимум: 100$', keyboard: keyboards.tg.casino };
    if (user.money < bet) return { text: `❌ У вас: ${formatMoney(user.money)}`, keyboard: keyboards.tg.casino };
    
    const symbols = ['🍒', '🍋', '🍊', '🍇', '⭐', '💎', '7️⃣'];
    const weights = [25, 20, 18, 15, 12, 7, 3];
    const spin = () => {
      let total = weights.reduce((a, b) => a + b, 0);
      let r = random(1, total);
      for (let i = 0; i < weights.length; i++) {
        r -= weights[i];
        if (r <= 0) return symbols[i];
      }
      return symbols[0];
    };
    
    const s1 = spin(), s2 = spin(), s3 = spin();
    user.money -= bet;
    user.stats.casinoBets++;
    
    let bonus = 0;
    if (user.privilege && user.privilegeExpires > Date.now()) {
      const priv = config.privileges[user.privilege.toLowerCase()];
      if (priv) bonus = priv.bonuses.casinoChanceBonus;
    }
    
    let mult = 0, result = '❌ Проигрыш';
    if (s1 === s2 && s2 === s3) {
      mult = [2, 3, 4, 5, 8, 15, 50][symbols.indexOf(s1)];
      result = '🎉 ДЖЕКПОТ!';
      user.stats.casinoWins++;
    } else if (s1 === s2 || s2 === s3 || s1 === s3) {
      mult = 1.5;
      result = '✅ Выигрыш!';
      user.stats.casinoWins++;
    } else {
      user.stats.casinoLosses++;
    }
    
    if (mult > 0 && bonus > 0) mult *= (1 + bonus / 100);
    const win = Math.floor(bet * mult);
    user.money += win;
    user.stats.totalEarned += win;
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'casino_bets', 1);
    db.saveAll();
    
    return {
      text: `🎰 СЛОТЫ
━━━━━━━━━━━━━━━━━━━━
┃ ${s1} ┃ ${s2} ┃ ${s3} ┃
━━━━━━━━━━━━━━━━━━━━
${result}

💰 Ставка: ${formatMoney(bet)}
📊 x${mult.toFixed(1)}
✅ Выигрыш: ${formatMoney(win)}
💵 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.casino
    };
  },

  async race(ctx, track) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (!user.currentCar) return { text: '❌ Купите машину! (машина список)', keyboard: keyboards.tg.race };
    if (!track) return { text: `🏁 ГОНКИ\n━━━━━━━━━━━━━━━━━━━━\n🚗 ${config.cars.find(c => c.id === user.currentCar)?.name}\n🔧 Тюнинг: ${user.tuning}/20\n🏆 Кубки: ${user.cups}\n\nВыберите трассу:`, keyboard: keyboards.tg.race };
    
    const cdTime = config.game.cooldowns.race * getCooldownMultiplier(user, config);
    const cd = checkCooldown(user.cooldowns?.race, cdTime);
    if (!cd.ready) return { text: `⏰ Ожидание: ${formatTime(cd.remaining)}`, keyboard: keyboards.tg.race };
    if (user.energy < config.game.energyCosts.race) return { text: `❌ Нужно ${config.game.energyCosts.race}⚡`, keyboard: keyboards.tg.race };
    
    const car = config.cars.find(c => c.id === user.currentCar);
    const speed = car.speed * (1 + user.tuning * 0.05);
    const opponent = randomElement(config.cars);
    const oppSpeed = opponent.speed * (0.8 + Math.random() * 0.4);
    
    user.energy -= config.game.energyCosts.race;
    user.cooldowns = user.cooldowns || {};
    user.cooldowns.race = Date.now();
    
    const win = speed > oppSpeed;
    let cups = win ? random(1, 3) : 0;
    let prize = win ? random(5000, 15000) : 0;
    const exp = win ? random(20, 50) : 10;
    
    if (win && user.privilege && user.privilegeExpires > Date.now()) {
      const priv = config.privileges[user.privilege.toLowerCase()];
      if (priv) {
        cups = Math.floor(cups * priv.bonuses.raceCupsMultiplier);
        prize = Math.floor(prize * priv.bonuses.incomeMultiplier);
      }
    }
    
    if (win) {
      user.money += prize;
      user.cups += cups;
      user.stats.raceWins++;
      user.stats.totalEarned += prize;
      db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'race_wins', 1);
    } else {
      user.stats.raceLosses++;
    }
    db.addExp(user, exp);
    db.saveAll();
    
    const tracks = { city: '🏁 Город', mountain: '🏔️ Горы', beach: '🏖️ Пляж', forest: '🌲 Лес' };
    const achs = db.checkAchievements(`${ctx.platform}_${ctx.userId}`);
    let achText = achs.length > 0 ? `\n🏆 ${achs.map(a => a.name).join(', ')}` : '';
    
    return {
      text: `🏁 ${tracks[track] || 'Гонка'}
━━━━━━━━━━━━━━━━━━━━
🚗 Вы: ${car.name} (${Math.floor(speed)} км/ч)
🚙 Соперник: ${opponent.name} (${Math.floor(oppSpeed)} км/ч)

${win ? '🎉 ПОБЕДА!' : '❌ Поражение'}
💰 +${formatMoney(prize)} | 🏆 +${cups}
⭐ +${exp} XP${achText}`,
      keyboard: keyboards.tg.race
    };
  },

  async boss(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (!db.boss.active) return { text: '⚔️ БОСС\n━━━━━━━━━━━━━━━━━━━━\n❌ Босс сейчас неактивен!\n⏰ Боссы появляются каждые 6 часов', keyboard: keyboards.tg.boss };
    
    const myDmg = db.boss.attackers[`${ctx.platform}_${ctx.userId}`]?.damage || 0;
    return {
      text: `⚔️ БОСС — ${db.boss.name}
━━━━━━━━━━━━━━━━━━━━
📊 Уровень: ${db.boss.level}
❤️ ${formatNumber(db.boss.hp)}/${formatNumber(db.boss.maxHp)}
${progressBar(db.boss.hp, db.boss.maxHp, 15)}

💰 Награда: ${formatMoney(db.boss.reward)}
👥 Атакующих: ${Object.keys(db.boss.attackers).length}
⚔️ Ваш урон: ${formatNumber(myDmg)}

💡 Выберите МЕЧ для макс. урона!`,
      keyboard: keyboards.tg.bossAttack
    };
  },

  async bossAttack(ctx, weapon) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (!db.boss.active) return { text: '❌ Босс не активен!', keyboard: keyboards.tg.boss };
    
    const cd = checkCooldown(user.cooldowns?.boss, config.game.cooldowns.boss);
    if (!cd.ready) return { text: `⏰ Ожидание: ${formatTime(cd.remaining)}`, keyboard: keyboards.tg.boss };
    if (user.energy < config.game.energyCosts.boss) return { text: `❌ Нужно ${config.game.energyCosts.boss}⚡`, keyboard: keyboards.tg.boss };
    if (!weapon) return this.boss(ctx);
    
    const correct = weapon === 'sword' || weapon === 'меч';
    let damage = random(100, 500);
    damage = correct ? Math.floor(damage * 1.5) : Math.floor(damage * 0.5);
    
    user.energy -= config.game.energyCosts.boss;
    user.cooldowns = user.cooldowns || {};
    user.cooldowns.boss = Date.now();
    user.stats.bossAttacks++;
    
    const exp = Math.floor(damage / 10);
    db.addExp(user, exp);
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'boss_attacks', 1);
    
    const result = db.attackBoss(`${ctx.platform}_${ctx.userId}`, damage);
    const path = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'boss');
    let pathText = path ? `\n\n🎉 ПУТЬ НОВИЧКА: Этап ${path.stage}!` : '';
    
    if (result.killed) {
      let rewards = '\n🏆 НАГРАДЫ:\n';
      result.rewards.slice(0, 5).forEach((r, i) => {
        rewards += `${i + 1}. ${r.name}: ${formatMoney(r.reward)}\n`;
      });
      return {
        text: `⚔️ БОСС ПОВЕРЖЕН!
━━━━━━━━━━━━━━━━━━━━
🎯 Ваш удар: ${formatNumber(damage)}
👑 Бонус убийцы: ${formatMoney(result.killerBonus)}
${rewards}⭐ +${exp} XP${pathText}`,
        keyboard: keyboards.tg.boss
      };
    }
    
    const emoji = { sword: '🗡️', bow: '🏹', shield: '🛡️' }[weapon] || '❓';
    return {
      text: `⚔️ АТАКА БОССА
━━━━━━━━━━━━━━━━━━━━
${emoji} ${correct ? '✅ Эффективно!' : '❌ Неэффективно!'}
🎯 Урон: ${formatNumber(damage)}
❤️ HP: ${formatNumber(result.hp)}/${formatNumber(db.boss.maxHp)}
⭐ +${exp} XP${pathText}`,
      keyboard: keyboards.tg.bossAttack
    };
  },

  async mine(ctx, oreId) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    const cd = checkCooldown(user.cooldowns?.mining, config.game.cooldowns.mining);
    if (!cd.ready) return { text: `⏰ Ожидание: ${formatTime(cd.remaining)}`, keyboard: keyboards.tg.mining };
    
    const lvl = levelFromExp(user.exp).level;
    const available = config.ores.filter(o => lvl >= o.minLevel);
    if (available.length === 0) return { text: '❌ Нет доступных руд!', keyboard: keyboards.tg.mining };
    
    if (available.length > 1 && !oreId) {
      return { text: `⛏️ ВЫБОР РУДЫ\n━━━━━━━━━━━━━━━━━━━━\nВыберите руду для добычи:`, keyboard: keyboards.tg.oreSelect(available) };
    }
    
    let ore;
    if (oreId && oreId !== 'random') {
      ore = available.find(o => o.id === parseInt(oreId));
    }
    if (!ore) ore = randomElement(available);
    
    const amount = random(1, 3) * user.pickaxeLevel;
    user.ores = user.ores || {};
    user.ores[ore.id] = (user.ores[ore.id] || 0) + amount;
    user.cooldowns = user.cooldowns || {};
    user.cooldowns.mining = Date.now();
    user.stats.oreMined += amount;
    
    const exp = amount * 5;
    db.addExp(user, exp);
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'ore_mined', amount);
    db.saveAll();
    
    const achs = db.checkAchievements(`${ctx.platform}_${ctx.userId}`);
    let achText = achs.length > 0 ? `\n🏆 ${achs.map(a => a.name).join(', ')}` : '';
    
    return {
      text: `⛏️ ДОБЫЧА
━━━━━━━━━━━━━━━━━━━━
${ore.name} x${amount}
💰 Цена: ${formatMoney(ore.price)}/шт
⭐ +${exp} XP

📦 Всего: ${user.ores[ore.id]} шт${achText}`,
      keyboard: keyboards.tg.mining
    };
  },

  async sellOre(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (!user.ores || Object.keys(user.ores).length === 0) return { text: '❌ Нет руды!', keyboard: keyboards.tg.mining };
    
    let total = 0;
    Object.entries(user.ores).forEach(([id, amount]) => {
      if (amount > 0) {
        const ore = config.ores.find(o => o.id === parseInt(id));
        if (ore) total += ore.price * amount;
      }
    });
    user.ores = {};
    user.money += total;
    user.stats.totalEarned += total;
    db.saveAll();
    
    return { text: `✅ Продано руды на ${formatMoney(total)}`, keyboard: keyboards.tg.mining };
  },

  async fishing(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    const cd = checkCooldown(user.cooldowns?.fishing, config.game.cooldowns.fishing);
    if (!cd.ready) return { text: `⏰ Ожидание: ${formatTime(cd.remaining)}`, keyboard: keyboards.tg.fishing };
    
    const bonus = user.rodLevel * 2;
    let roll = random(1, 100);
    let caught = config.fishes[0];
    for (const fish of config.fishes) {
      if (roll <= fish.chance + bonus) { caught = fish; break; }
      roll -= fish.chance;
    }
    
    const amount = random(1, user.rodLevel);
    user.fish = user.fish || {};
    user.fish[caught.id] = (user.fish[caught.id] || 0) + amount;
    user.cooldowns = user.cooldowns || {};
    user.cooldowns.fishing = Date.now();
    user.stats.fishCaught += amount;
    
    const exp = amount * 10;
    db.addExp(user, exp);
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'fish', amount);
    db.saveAll();
    
    return {
      text: `🎣 РЫБАЛКА
━━━━━━━━━━━━━━━━━━━━
${caught.name} x${amount}
💰 ${formatMoney(caught.price)}/шт
⭐ +${exp} XP`,
      keyboard: keyboards.tg.fishing
    };
  },

  async sellFish(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (!user.fish || Object.keys(user.fish).length === 0) return { text: '❌ Нет рыбы!', keyboard: keyboards.tg.fishing };
    
    let total = 0;
    Object.entries(user.fish).forEach(([id, amount]) => {
      const fish = config.fishes.find(f => f.id === parseInt(id));
      if (fish && amount > 0) total += fish.price * amount;
    });
    user.fish = {};
    user.money += total;
    user.stats.totalEarned += total;
    db.saveAll();
    
    return { text: `✅ Продано рыбы на ${formatMoney(total)}`, keyboard: keyboards.tg.fishing };
  },

  async phone(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (!user.phone) return { text: `📱 ТЕЛЕФОН\n━━━━━━━━━━━━━━━━━━━━\n❌ У вас нет телефона!\n\n📌 телефон купить [номер]`, keyboard: keyboards.tg.phone };
    const phoneInfo = config.phones.find(p => p.id === user.phone);
    return {
      text: `📱 ТЕЛЕФОН — ${phoneInfo.name}
━━━━━━━━━━━━━━━━━━━━
📞 Контактов: ${user.contacts?.length || 0}
👥 Подписчиков: ${user.subscribers?.length || 0}
📝 Подписок: ${user.subscriptions?.length || 0}

📌 Команды:
• телефон контакты
• телефон лента
• телефон пост [текст]
• телефон позвонить [#ID]`,
      keyboard: keyboards.tg.phone
    };
  },

  async phoneBuy(ctx, phoneId) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    const phone = config.phones.find(p => p.id === parseInt(phoneId));
    if (!phone) {
      let list = `📱 ТЕЛЕФОНЫ\n━━━━━━━━━━━━━━━━━━━━`;
      config.phones.forEach(p => { list += `\n${p.id}. ${p.name} — ${formatMoney(p.price)}`; });
      return { text: list, keyboard: keyboards.tg.phone };
    }
    if (user.money < phone.price) return { text: `❌ Нужно: ${formatMoney(phone.price)}`, keyboard: keyboards.tg.phone };
    user.money -= phone.price;
    user.phone = phone.id;
    db.saveAll();
    return { text: `✅ Куплен: ${phone.name}`, keyboard: keyboards.tg.phone };
  },

  async phonePost(ctx, text) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (!user.phone) return { text: '❌ Купите телефон!', keyboard: keyboards.tg.phone };
    if (!text || text.length < 3) return { text: '❌ Минимум 3 символа!', keyboard: keyboards.tg.phone };
    if (user.money < 100) return { text: '❌ Нужно 100$ за пост!', keyboard: keyboards.tg.phone };
    user.money -= 100;
    const post = db.createPost(`${ctx.platform}_${ctx.userId}`, text);
    return { text: `✅ Пост #${post.id} опубликован!`, keyboard: keyboards.tg.phone };
  },

  async phoneFeed(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (db.posts.length === 0) return { text: '📰 Лента пуста!', keyboard: keyboards.tg.phone };
    let text = `📰 ЛЕНТА\n━━━━━━━━━━━━━━━━━━━━`;
    db.posts.slice(0, 5).forEach(p => {
      text += `\n\n#${p.id} ${p.authorName} (#${p.authorId})\n${p.text}\n❤️ ${p.likes.length}`;
    });
    return { text, keyboard: keyboards.tg.phone };
  },

  async bonus(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    const cd = checkCooldown(user.cooldowns?.bonus, config.game.cooldowns.bonus);
    if (!cd.ready) return { text: `🎁 БОНУС\n━━━━━━━━━━━━━━━━━━━━\n⏰ Ожидание: ${formatTime(cd.remaining)}`, keyboard: keyboards.tg.bonus };
    
    const amount = 5000 + random(0, 5000);
    const exp = 50 + random(0, 50);
    user.money += amount;
    user.cooldowns = user.cooldowns || {};
    user.cooldowns.bonus = Date.now();
    user.stats.totalEarned += amount;
    db.addExp(user, exp);
    db.saveAll();
    
    const path = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'bonus');
    let pathText = path ? `\n\n🎉 ПУТЬ НОВИЧКА: Этап ${path.stage}!` : '';
    
    return { text: `🎁 ЕЖЕДНЕВНЫЙ БОНУС\n━━━━━━━━━━━━━━━━━━━━\n💰 +${formatMoney(amount)}\n⭐ +${exp} XP${pathText}`, keyboard: keyboards.tg.bonus };
  },

  async bonusHourly(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    const cd = checkCooldown(user.cooldowns?.hourlyBonus, config.game.cooldowns.hourlyBonus);
    if (!cd.ready) return { text: `⏰ Ожидание: ${formatTime(cd.remaining)}`, keyboard: keyboards.tg.bonus };
    const amount = 1000 + random(0, 2000);
    user.money += amount;
    user.cooldowns = user.cooldowns || {};
    user.cooldowns.hourlyBonus = Date.now();
    db.saveAll();
    return { text: `⏰ ЧАСОВОЙ БОНУС\n━━━━━━━━━━━━━━━━━━━━\n💰 +${formatMoney(amount)}`, keyboard: keyboards.tg.bonus };
  },

  async beginnerPath(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (user.beginnerCompleted) return { text: `📍 ПУТЬ НОВИЧКА\n━━━━━━━━━━━━━━━━━━━━\n✅ ВЫ ПРОШЛИ ПУТЬ НОВИЧКА!\n🎉 Поздравляем!`, keyboard: keyboards.tg.main };
    
    let text = `📍 ПУТЬ НОВИЧКА (${user.beginnerStage - 1}/${config.beginnerPath.length})\n━━━━━━━━━━━━━━━━━━━━`;
    config.beginnerPath.forEach(s => {
      const status = s.stage < user.beginnerStage ? '✅' : (s.stage === user.beginnerStage ? '👉' : '⬜');
      text += `\n${status} ${s.stage}. ${s.task}`;
      if (s.stage === user.beginnerStage) {
        text += `\n   💰 +${formatMoney(s.reward.money)} +${s.reward.exp} XP`;
        if (s.reward.diamonds) text += ` +${s.reward.diamonds}💎`;
      }
    });
    
    const current = config.beginnerPath.find(s => s.stage === user.beginnerStage);
    text += `\n\n📌 ЗАДАНИЕ: ${current.task}\n💡 Команда: ${current.cmd}`;
    
    return { text, keyboard: keyboards.tg.beginnerPath(current.action, current.cmd) };
  },

  async quests(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    db.initDailyQuests(user);
    db.initWeeklyQuests(user);
    const dC = Object.values(user.dailyQuests).filter(q => q.completed).length;
    const wC = Object.values(user.weeklyQuests).filter(q => q.completed).length;
    return {
      text: `📋 КВЕСТЫ\n━━━━━━━━━━━━━━━━━━━━\n📅 Ежедневные: ${dC}/${config.dailyQuests.length}\n📆 Недельные: ${wC}/${config.weeklyQuests.length}`,
      keyboard: keyboards.tg.quests
    };
  },

  async questsDaily(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    db.initDailyQuests(user);
    let text = `📅 ЕЖЕДНЕВНЫЕ КВЕСТЫ\n━━━━━━━━━━━━━━━━━━━━`;
    config.dailyQuests.forEach(q => {
      const p = user.dailyQuests[q.id];
      const status = p.claimed ? '💎' : (p.completed ? '✅' : '⬜');
      text += `\n${status} ${q.id}. ${q.name}\n   ${p.progress}/${q.target}`;
      if (p.completed && !p.claimed) text += ' — СДАТЬ!';
    });
    text += `\n\n📌 квесты сдать [номер]`;
    return { text, keyboard: keyboards.tg.quests };
  },

  async questClaim(ctx, qid, isWeekly) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    const result = db.claimQuest(`${ctx.platform}_${ctx.userId}`, parseInt(qid), !isWeekly);
    if (!result) return { text: '❌ Квест не найден или уже сдан!', keyboard: keyboards.tg.quests };
    let reward = `💰 +${formatMoney(result.reward.money)}`;
    if (result.reward.exp) reward += ` ⭐ +${result.reward.exp} XP`;
    if (result.reward.diamonds) reward += ` 💎 +${result.reward.diamonds}`;
    return { text: `✅ КВЕСТ СДАН!\n━━━━━━━━━━━━━━━━━━━━\n${result.name}\n${reward}`, keyboard: keyboards.tg.quests };
  },

  async help(ctx) {
    return {
      text: `❓ ПОМОЩЬ — FLASH BOT
━━━━━━━━━━━━━━━━━━━━
👤 профиль, баланс, статистика
💼 работа, работать, уволиться
🏢 бизнес, бизнес собрать все
🚗 машина, гонка, тюнинг
🎰 казино [ставка]
⚔️ босс, босс атака
⛏️ копать, руда продать
🎣 рыбалка, рыба продать
🏛️ клан, кланы
🎁 бонус, промокод [код]
📱 телефон
📋 квесты, путь новичка
📊 топ

⌨️ клавиатура вкл/выкл`,
      keyboard: keyboards.tg.help
    };
  },

  async keyboardOn(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    user.settings = user.settings || {};
    user.settings.keyboard = true;
    db.saveAll();
    return { text: '⌨️ КЛАВИАТУРА ВКЛЮЧЕНА', replyKeyboard: keyboards.tgReply };
  },

  async keyboardOff(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    user.settings = user.settings || {};
    user.settings.keyboard = false;
    db.saveAll();
    return { text: '⌨️ КЛАВИАТУРА ВЫКЛЮЧЕНА', removeKeyboard: true };
  },

  async keyboardStatus(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    const status = user.settings?.keyboard ? 'ВКЛЮЧЕНА ✅' : 'ВЫКЛЮЧЕНА ❌';
    return { text: `⌨️ Клавиатура: ${status}`, keyboard: keyboards.tg.settings };
  },

  async top(ctx, category) {
    const users = Object.values(db.users);
    let sorted, title;
    switch (category) {
      case 'level': case 'уровень':
        sorted = [...users].sort((a, b) => b.exp - a.exp);
        title = '📈 ТОП ПО УРОВНЮ';
        break;
      case 'business': case 'бизнес':
        sorted = [...users].sort((a, b) => (b.businesses?.length || 0) - (a.businesses?.length || 0));
        title = '🏢 ТОП ПО БИЗНЕСАМ';
        break;
      default:
        sorted = [...users].sort((a, b) => (b.money + b.bank) - (a.money + a.bank));
        title = '💰 ТОП ПО ДЕНЬГАМ';
    }
    const medals = ['🥇', '🥈', '🥉'];
    let text = `${title}\n━━━━━━━━━━━━━━━━━━━━`;
    sorted.slice(0, 10).forEach((u, i) => {
      const m = medals[i] || `${i + 1}.`;
      let val = category === 'level' ? `${levelFromExp(u.exp).level} ур.` : 
                category === 'business' ? `${u.businesses?.length || 0} биз.` :
                formatMoney(u.money + u.bank);
      text += `\n${m} ${u.name} — ${val}`;
    });
    return { text, keyboard: keyboards.tg.tops };
  },

  async clan(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (!user.clanId) return {
      text: `🏛️ КЛАНЫ\n━━━━━━━━━━━━━━━━━━━━\n❌ Вы не в клане!\n\n📌 клан создать [название] — 100K$\n📌 кланы — список`,
      keyboard: keyboards.tg.clan
    };
    const clan = db.clans[user.clanId];
    if (!clan) { user.clanId = null; db.saveAll(); return this.clan(ctx); }
    const isLeader = clan.leader === `${ctx.platform}_${ctx.userId}`;
    return {
      text: `🏛️ ${clan.name}
━━━━━━━━━━━━━━━━━━━━
👥 ${clan.members.length}/50
💰 Казна: ${formatMoney(clan.treasury)}
👑 Лидер: ${isLeader ? 'ВЫ' : 'другой'}
⚔️ ${clan.wars.wins} побед / ${clan.wars.losses} поражений`,
      keyboard: keyboards.tg.clan
    };
  },

  async clanCreate(ctx, name) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (user.clanId) return { text: '❌ Вы уже в клане!', keyboard: keyboards.tg.clan };
    if (!name || name.length < 2) return { text: '❌ Название 2-20 символов!', keyboard: keyboards.tg.clan };
    if (user.money < 100000) return { text: `❌ Нужно: ${formatMoney(100000)}`, keyboard: keyboards.tg.clan };
    const clan = db.createClan(`${ctx.platform}_${ctx.userId}`, name);
    return { text: `✅ Клан «${clan.name}» создан!`, keyboard: keyboards.tg.clan };
  },

  async clanDeposit(ctx, amount) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user || !user.clanId) return { text: '❌ Вы не в клане!', keyboard: keyboards.tg.clan };
    amount = parseInt(amount);
    if (!amount || amount < 100) return { text: '❌ Минимум 100$!', keyboard: keyboards.tg.clan };
    if (user.money < amount) return { text: `❌ У вас: ${formatMoney(user.money)}`, keyboard: keyboards.tg.clan };
    user.money -= amount;
    db.clans[user.clanId].treasury += amount;
    db.saveAll();
    return { text: `✅ +${formatMoney(amount)} в казну\n💰 Казна: ${formatMoney(db.clans[user.clanId].treasury)}`, keyboard: keyboards.tg.clan };
  },

  async referral(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    const link = ctx.platform === 'telegram' ? `https://t.me/gamebotflash_bot?start=ref_${user.id}` : `https://vk.com/club237124814?ref=${user.id}`;
    return {
      text: `🎁 РЕФЕРАЛЫ
━━━━━━━━━━━━━━━━━━━━
👥 Рефералов: ${user.referrals?.length || 0}
💰 Заработано: ${formatMoney(user.referralEarnings || 0)}

🔗 Ваша ссылка:
${link}

💡 За каждого друга:
• +5,000$ вам
• +2,000$ другу
• 10% от его заработка!`,
      keyboard: keyboards.tg.referral
    };
  },

  async donate(ctx) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    const priv = user.privilege && user.privilegeExpires > Date.now() 
      ? `${user.privilege} (${Math.ceil((user.privilegeExpires - Date.now()) / 86400000)} дн.)` : '❌ Нет';
    return {
      text: `💎 ДОНАТ
━━━━━━━━━━━━━━━━━━━━
💎 Алмазы: ${user.diamonds}
👑 Привилегия: ${priv}

👑 VIP — 50💎 (30 дн.)
├ +20% доход, +5% казино
├ x1.5 кубков, -10% кулдауны
└ 2 бизнеса

⭐ PREMIUM — 100💎
├ +50% доход, +10% казино
└ 3 бизнеса

🌟 LEGEND — 200💎
├ x2 доход, +15% казино
└ 4 бизнеса

💎 ULTIMATE — 500💎
├ x3 доход, +20% казино
└ 5 бизнесов`,
      keyboard: keyboards.tg.donate
    };
  },

  async buyPrivilege(ctx, privName) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    const priv = config.privileges[privName.toLowerCase()];
    if (!priv) return { text: '❌ Не найдено!', keyboard: keyboards.tg.donate };
    if (user.diamonds < priv.price) return { text: `❌ Нужно: ${priv.price}💎`, keyboard: keyboards.tg.donate };
    user.diamonds -= priv.price;
    user.privilege = priv.name;
    user.privilegeExpires = Date.now() + 30 * 86400000;
    db.saveAll();
    return { text: `✅ ${priv.name} на 30 дней!`, keyboard: keyboards.tg.main };
  },

  async promo(ctx, code) {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (!code) return { text: '📌 промокод [код]', keyboard: keyboards.tg.main };
    const result = db.usePromoCode(`${ctx.platform}_${ctx.userId}`, code);
    if (!result.success) return { text: `❌ ${result.error}`, keyboard: keyboards.tg.main };
    let reward = '';
    if (result.reward.money) reward += `💰 +${formatMoney(result.reward.money)}\n`;
    if (result.reward.exp) reward += `⭐ +${result.reward.exp} XP\n`;
    if (result.reward.diamonds) reward += `💎 +${result.reward.diamonds}\n`;
    return { text: `✅ ПРОМОКОД АКТИВИРОВАН!\n━━━━━━━━━━━━━━━━━━━━\n${reward}`, keyboard: keyboards.tg.main };
  },

  async adminHelp(ctx) {
    if (!isAdmin(ctx.userId, ctx.platform, config)) return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    return {
      text: `👑 АДМИН-КОМАНДЫ
━━━━━━━━━━━━━━━━━━━━
📊 админ статистика
👤 профиль [#ID]
💰 выдать [#ID] [сумма]
💎 выдать алмазы [#ID] [кол-во]
👑 выдать привилегию [#ID] [тип] [дней]
🏢 выдать бизнес [#ID] [номер]
🚗 выдать машину [#ID] [номер]
🔨 бан [#ID] [причина]
✅ разбан [#ID]
🐉 босс создать / завершить
📢 рассылка [текст]
🎁 промокод создать [код] [деньги] [опыт] [алмазы] [лимит]`,
      keyboard: keyboards.tg.main
    };
  },

  async adminStats(ctx) {
    if (!isAdmin(ctx.userId, ctx.platform, config)) return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    const users = Object.values(db.users);
    const total = users.reduce((s, u) => s + u.money + u.bank, 0);
    const today = new Date().setHours(0, 0, 0, 0);
    const active = users.filter(u => u.lastActive > today).length;
    return {
      text: `📊 СТАТИСТИКА
━━━━━━━━━━━━━━━━━━━━
👥 Всего: ${users.length}
📈 Активных сегодня: ${active}
💰 Всего денег: ${formatMoney(total)}
🏛️ Кланов: ${Object.keys(db.clans).length}
⚔️ Босс: ${db.boss.active ? 'Активен' : 'Нет'}`,
      keyboard: keyboards.tg.main
    };
  },

  async adminGive(ctx, targetId, amount, currency = 'money') {
    if (!isAdmin(ctx.userId, ctx.platform, config)) return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    const target = db.getUserById(String(targetId).replace('#', ''));
    if (!target) return { text: '❌ Не найден!', keyboard: keyboards.tg.main };
    amount = parseInt(amount);
    if (!amount) return { text: '❌ Укажите сумму!', keyboard: keyboards.tg.main };
    
    switch (currency) {
      case 'diamonds': case 'алмазы': target.diamonds += amount; break;
      case 'exp': case 'опыт': db.addExp(target, amount); break;
      default: target.money += amount;
    }
    db.saveAll();
    return { text: `✅ Выдано ${target.name} (#${target.id}): ${amount}`, keyboard: keyboards.tg.main };
  },

  async adminBan(ctx, targetId, reason) {
    if (!isAdmin(ctx.userId, ctx.platform, config)) return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    const target = db.getUserById(String(targetId).replace('#', ''));
    if (!target) return { text: '❌ Не найден!', keyboard: keyboards.tg.main };
    target.banned = true;
    target.banReason = reason || 'Нарушение правил';
    db.saveAll();
    return { text: `🔨 ${target.name} забанен: ${target.banReason}`, keyboard: keyboards.tg.main };
  },

  async adminUnban(ctx, targetId) {
    if (!isAdmin(ctx.userId, ctx.platform, config)) return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    const target = db.getUserById(String(targetId).replace('#', ''));
    if (!target) return { text: '❌ Не найден!', keyboard: keyboards.tg.main };
    target.banned = false;
    target.banReason = null;
    db.saveAll();
    return { text: `✅ ${target.name} разбанен`, keyboard: keyboards.tg.main };
  },

  async adminBossCreate(ctx) {
    if (!isAdmin(ctx.userId, ctx.platform, config)) return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    if (db.boss.active) return { text: '❌ Босс уже активен!', keyboard: keyboards.tg.main };
    const boss = db.spawnBoss();
    return {
      text: `⚔️ БОСС СОЗДАН!\n${boss.name} Ур.${boss.level}\n❤️ ${formatNumber(boss.maxHp)} HP\n💰 ${formatMoney(boss.reward)}`,
      keyboard: keyboards.tg.main,
      broadcast: `⚔️ ПОЯВИЛСЯ БОСС!\n${boss.name} (Ур.${boss.level})\n❤️ ${formatNumber(boss.maxHp)} | 💰 ${formatMoney(boss.reward)}\n\nКоманда: босс атака`
    };
  },

  async adminBossEnd(ctx) {
    if (!isAdmin(ctx.userId, ctx.platform, config)) return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    db.boss.active = false;
    db.saveAll();
    return { text: '✅ Босс завершён', keyboard: keyboards.tg.main };
  },

  async adminPromoCreate(ctx, code, money, exp, diamonds, limit) {
    if (!isAdmin(ctx.userId, ctx.platform, config)) return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    if (!code) return { text: '❌ Укажите код!', keyboard: keyboards.tg.main };
    db.createPromoCode(code, {
      money: parseInt(money) || 0,
      exp: parseInt(exp) || 0,
      diamonds: parseInt(diamonds) || 0
    }, parseInt(limit) || 100);
    return { text: `✅ Промокод ${code.toUpperCase()} создан!`, keyboard: keyboards.tg.main };
  },

  async adminBroadcast(ctx, text) {
    if (!isAdmin(ctx.userId, ctx.platform, config)) return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    if (!text) return { text: '❌ Текст!', keyboard: keyboards.tg.main };
    return { text: '✅ Рассылка запущена', keyboard: keyboards.tg.main, broadcast: `📢 ОБЪЯВЛЕНИЕ\n━━━━━━━━━━━━━━━━━━━━\n${text}` };
  }
};

const handleCallback = async (ctx, data) => {
  const callbackMap = {
    'back_main': () => commands.start(ctx),
    'auth_create': () => commands.createAccount(ctx),
    'auth_bind': () => commands.bind(ctx),
    'bind_newcode': () => commands.bind(ctx),
    
    'cmd_profile': () => commands.profile(ctx),
    'cmd_stats': () => commands.stats(ctx),
    'cmd_achievements': () => commands.achievements(ctx),
    'cmd_inventory': () => commands.inventory(ctx),
    'cmd_referral': () => commands.referral(ctx),
    
    'cmd_balance': () => commands.balance(ctx),
    'cmd_bank': () => commands.bank(ctx),
    'cmd_exchange': () => commands.balance(ctx),
    'cmd_donate': () => commands.donate(ctx),
    'transfer_start': () => ({ text: '📌 перевод [#ID] [сумма]', keyboard: keyboards.tg.balance }),
    
    'bank_dep': () => ({ text: '📌 банк положить [сумма/все]', keyboard: keyboards.tg.bank }),
    'bank_with': () => ({ text: '📌 банк снять [сумма/все]', keyboard: keyboards.tg.bank }),
    'bank_limit': () => ({ text: '📌 банк лимит', keyboard: keyboards.tg.bank }),
    
    'cmd_shop': () => ({ text: '🏪 МАГАЗИН', keyboard: keyboards.tg.shop }),
    'shop_cars': () => ({ text: '📌 машина список', keyboard: keyboards.tg.shop }),
    'shop_biz': () => commands.businessList(ctx),
    'shop_farms': () => ({ text: '📌 фермы', keyboard: keyboards.tg.shop }),
    'shop_printers': () => ({ text: '📌 принтер', keyboard: keyboards.tg.shop }),
    'shop_phones': () => commands.phoneBuy(ctx),
    'shop_houses': () => ({ text: '📌 дом список', keyboard: keyboards.tg.shop }),
    'shop_pets': () => ({ text: '📌 питомец список', keyboard: keyboards.tg.shop }),
    'shop_cases': () => ({ text: '📌 кейс список', keyboard: keyboards.tg.shop }),
    
    'cmd_job': () => commands.job(ctx),
    'job_list': () => commands.jobList(ctx),
    'job_info': () => commands.job(ctx),
    'job_quit': () => commands.jobQuit(ctx),
    'do_work': () => commands.work(ctx),
    
    'biz_my': () => commands.business(ctx),
    'biz_collect_all': () => commands.businessCollect(ctx, 'все'),
    
    'farm_my': () => ({ text: '❌', keyboard: keyboards.tg.main }),
    'farm_collect_all': () => ({ text: '📌 ферма собрать все', keyboard: keyboards.tg.farms }),
    
    'printer_my': () => ({ text: '❌', keyboard: keyboards.tg.main }),
    'printer_collect_all': () => ({ text: '📌 принтер собрать все', keyboard: keyboards.tg.printers }),
    'printer_fuel_all': () => ({ text: '📌 принтер заправить все', keyboard: keyboards.tg.printers }),
    
    'cmd_casino': () => commands.casino(ctx),
    'casino_slots': () => ({ text: '📌 казино [ставка]', keyboard: keyboards.tg.casinoBet('slots') }),
    'casino_roulette': () => ({ text: '📌 казино рулетка [ставка] [цвет]', keyboard: keyboards.tg.casino }),
    'casino_dice': () => ({ text: '📌 казино кости [ставка] [число]', keyboard: keyboards.tg.casino }),
    'casino_cards': () => ({ text: '📌 казино карты [ставка]', keyboard: keyboards.tg.casino }),
    'casino_stats': () => commands.stats(ctx),
    
    'cmd_race': () => commands.race(ctx),
    'race_city': () => commands.race(ctx, 'city'),
    'race_mountain': () => commands.race(ctx, 'mountain'),
    'race_beach': () => commands.race(ctx, 'beach'),
    'race_forest': () => commands.race(ctx, 'forest'),
    'cmd_cars': () => ({ text: '📌 машина', keyboard: keyboards.tg.race }),
    'cmd_tuning': () => ({ text: '📌 тюнинг', keyboard: keyboards.tg.race }),
    
    'cmd_boss': () => commands.boss(ctx),
    'boss_attack_menu': () => commands.boss(ctx),
    'boss_hit_sword': () => commands.bossAttack(ctx, 'sword'),
    'boss_hit_bow': () => commands.bossAttack(ctx, 'bow'),
    'boss_hit_shield': () => commands.bossAttack(ctx, 'shield'),
    'boss_stats': () => commands.boss(ctx),
    'boss_top': () => commands.boss(ctx),
    
    'cmd_mining': () => commands.mine(ctx),
    'do_mine': () => commands.mine(ctx),
    'cmd_pickaxe': () => ({ text: '📌 кирка', keyboard: keyboards.tg.mining }),
    'sell_ore_all': () => commands.sellOre(ctx),
    'mine_ore_random': () => commands.mine(ctx, 'random'),
    
    'cmd_fishing': () => commands.fishing(ctx),
    'do_fish': () => commands.fishing(ctx),
    'cmd_rod': () => ({ text: '📌 удочка', keyboard: keyboards.tg.fishing }),
    'sell_fish_all': () => commands.sellFish(ctx),
    
    'cmd_phone': () => commands.phone(ctx),
    'phone_contacts': () => ({ text: '📌 телефон контакты', keyboard: keyboards.tg.phone }),
    'phone_feed': () => commands.phoneFeed(ctx),
    'phone_post': () => ({ text: '📌 телефон пост [текст]', keyboard: keyboards.tg.phone }),
    'phone_call': () => ({ text: '📌 телефон позвонить [#ID]', keyboard: keyboards.tg.phone }),
    
    'cmd_clan': () => commands.clan(ctx),
    'clan_members': () => ({ text: '📌 клан состав', keyboard: keyboards.tg.clan }),
    'clan_treasury': () => ({ text: '📌 клан пополнить [сумма]', keyboard: keyboards.tg.clan }),
    'clan_war': () => ({ text: '📌 клан атака [ID]', keyboard: keyboards.tg.clan }),
    'clan_leave': () => ({ text: '📌 клан покинуть', keyboard: keyboards.tg.clan }),
    
    'quests_daily': () => commands.questsDaily(ctx),
    'quests_weekly': () => ({ text: '📌 квесты недельные', keyboard: keyboards.tg.quests }),
    
    'bonus_daily': () => commands.bonus(ctx),
    'bonus_hourly': () => commands.bonusHourly(ctx),
    
    'top_money': () => commands.top(ctx, 'money'),
    'top_level': () => commands.top(ctx, 'level'),
    'top_business': () => commands.top(ctx, 'business'),
    'top_clans': () => ({ text: '📌 кланы', keyboard: keyboards.tg.tops }),
    
    'buy_vip': () => commands.buyPrivilege(ctx, 'vip'),
    'buy_premium': () => commands.buyPrivilege(ctx, 'premium'),
    'buy_legend': () => commands.buyPrivilege(ctx, 'legend'),
    'buy_ultimate': () => commands.buyPrivilege(ctx, 'ultimate'),
    
    'settings_keyboard': () => {
      const user = db.getUserByPlatform(ctx.platform, ctx.userId);
      return user?.settings?.keyboard ? commands.keyboardOff(ctx) : commands.keyboardOn(ctx);
    },
    'settings_notif': () => ({ text: '📌 уведомления вкл/выкл', keyboard: keyboards.tg.settings }),
    
    'ref_link': () => commands.referral(ctx),
    'ref_stats': () => commands.referral(ctx),
    'ref_list': () => commands.referral(ctx),
    
    'help_economy': () => ({ text: '💰 ЭКОНОМИКА\nработа, бизнес, фермы, принтер, банк', keyboard: keyboards.tg.help }),
    'help_games': () => ({ text: '🎮 ИГРЫ\nказино, гонка, босс, копать, рыбалка', keyboard: keyboards.tg.help }),
    'help_social': () => ({ text: '👥 СОЦИАЛЬНОЕ\nклан, семья, телефон, топ', keyboard: keyboards.tg.help }),
    'help_ref': () => commands.referral(ctx),
    
    'cancel': () => commands.start(ctx)
  };
  
  if (callbackMap[data]) return callbackMap[data]();
  
  if (data.startsWith('slots_')) {
    const bet = data.replace('slots_', '');
    return commands.casinoSlots(ctx, bet);
  }
  if (data.startsWith('mine_ore_')) {
    const oreId = data.replace('mine_ore_', '');
    return commands.mine(ctx, oreId);
  }
  if (data.startsWith('beginner_go_')) {
    const action = data.replace('beginner_go_', '');
    const stage = config.beginnerPath.find(s => s.action === action);
    if (stage) return { text: `📌 Выполните: ${stage.cmd}`, keyboard: keyboards.tg.main };
  }
  
  return null;
};

const handleMessage = async (ctx) => {
  if (ctx.callbackData) return handleCallback(ctx, ctx.callbackData);
  
  let text = ctx.text || '';
  
  const mapped = keyboardMap[text.toLowerCase()];
  if (mapped) text = mapped;
  
  const parts = text.toLowerCase().trim().split(/\s+/);
  const cmd = parts[0];
  const args = parts.slice(1);
  
  if (!cmd) return null;
  
  const user = db.getUserByPlatform(ctx.platform, ctx.userId);
  
  if (!user && ctx.isChat) {
    return { 
      text: `❌ Для использования в беседе создайте аккаунт в ЛС бота\n\n📌 Напишите @Flash и команду: профиль, баланс, путь и т.д.`
    };
  }
  
  if (user?.banned) return { text: `🔨 Вы забанены: ${user.banReason}` };
  if (user) db.regenerateEnergy(user);
  
  try {
    if (cmd === 'старт' || cmd === 'start') return commands.start(ctx);
    if (cmd === 'привязать' || cmd === 'bind') return commands.bind(ctx);
    if (cmd === 'код' || cmd === 'code') return commands.useCode(ctx, args[0]);
    if (cmd === 'помощь' || cmd === 'help') return commands.help(ctx);
    
    if (cmd === 'клавиатура') {
      if (args[0] === 'вкл' || args[0] === 'on') return commands.keyboardOn(ctx);
      if (args[0] === 'выкл' || args[0] === 'off') return commands.keyboardOff(ctx);
      return commands.keyboardStatus(ctx);
    }
    
    if (cmd === 'профиль' || cmd === 'profile') return commands.profile(ctx, args[0]);
    if (cmd === 'статистика' || cmd === 'stats') return commands.stats(ctx);
    if (cmd === 'достижения') return commands.achievements(ctx);
    if (cmd === 'инвентарь') return commands.inventory(ctx);
    
    if (cmd === 'баланс' || cmd === 'balance' || cmd === 'bal') return commands.balance(ctx);
    if (cmd === 'банк' || cmd === 'bank') {
      if (args[0] === 'положить') return commands.bankDeposit(ctx, args[1]);
      if (args[0] === 'снять') return commands.bankWithdraw(ctx, args[1]);
      return commands.bank(ctx);
    }
    if (cmd === 'перевод' || cmd === 'transfer') return commands.transfer(ctx, args[0], args[1]);
    
    if (cmd === 'работа' || cmd === 'job') {
      if (args[0] === 'список') return commands.jobList(ctx);
      if (args[0]) return commands.jobApply(ctx, args[0]);
      return commands.job(ctx);
    }
    if (cmd === 'работать' || cmd === 'work') return commands.work(ctx);
    if (cmd === 'уволиться') return commands.jobQuit(ctx);
    
    if (cmd === 'бизнес' || cmd === 'business') {
      if (args[0] === 'список') return commands.businessList(ctx);
      if (args[0] === 'купить') return commands.businessBuy(ctx, args[1]);
      if (args[0] === 'собрать') return commands.businessCollect(ctx, args[1] || 'все');
      return commands.business(ctx);
    }
    
    if (cmd === 'казино' || cmd === 'casino') {
      if (args[0] === 'рулетка') return ({ text: '📌 казино рулетка [ставка] [красное/чёрное]', keyboard: keyboards.tg.casino });
      if (args[0]) return commands.casinoSlots(ctx, args[0]);
      return commands.casino(ctx);
    }
    if (cmd === 'гонка' || cmd === 'race') return commands.race(ctx, args[0]);
    if (cmd === 'машина' || cmd === 'car') {
      if (args[0] === 'список') {
        let list = '🚗 МАШИНЫ\n━━━━━━━━━━━━━━━━━━━━';
        config.cars.forEach(c => { list += `\n${c.id}. ${c.name} — ${formatMoney(c.price)}`; });
        return { text: list, keyboard: keyboards.tg.race };
      }
      if (args[0] === 'купить') {
        const car = config.cars.find(c => c.id === parseInt(args[1]));
        if (!car) return { text: '❌ Не найдена!', keyboard: keyboards.tg.race };
        if (user.money < car.price) return { text: `❌ Нужно: ${formatMoney(car.price)}`, keyboard: keyboards.tg.race };
        user.money -= car.price;
        user.cars = user.cars || [];
        user.cars.push(car.id);
        if (!user.currentCar) user.currentCar = car.id;
        db.saveAll();
        const path = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'car');
        return { text: `✅ Куплен: ${car.name}${path ? '\n\n🎉 ПУТЬ НОВИЧКА!' : ''}`, keyboard: keyboards.tg.race };
      }
      return { text: '📌 машина список\n📌 машина купить [номер]', keyboard: keyboards.tg.race };
    }
    if (cmd === 'тюнинг') {
      if (args[0] === 'купить') {
        if (user.tuning >= 20) return { text: '❌ Максимум!', keyboard: keyboards.tg.race };
        const cost = 100000 * (1 + user.tuning * 0.1);
        if (user.money < cost) return { text: `❌ Нужно: ${formatMoney(cost)}`, keyboard: keyboards.tg.race };
        user.money -= cost;
        user.tuning++;
        db.saveAll();
        return { text: `✅ Тюнинг: ${user.tuning}/20 (+${user.tuning * 5}%)`, keyboard: keyboards.tg.race };
      }
      return { text: `🔧 ТЮНИНГ\n${user.tuning}/20 (+${user.tuning * 5}%)\n📌 тюнинг купить`, keyboard: keyboards.tg.race };
    }
    
    if (cmd === 'босс' || cmd === 'boss') {
      if (args[0] === 'атака') return commands.bossAttack(ctx, args[1]);
      return commands.boss(ctx);
    }
    
    if (cmd === 'копать' || cmd === 'mine' || cmd === 'майнинг') return commands.mine(ctx, args[0]);
    if (cmd === 'кирка') {
      if (args[0] === 'улучшить') {
        if (user.pickaxeLevel >= 20) return { text: '❌ Максимум!', keyboard: keyboards.tg.mining };
        const cost = 10000 * user.pickaxeLevel;
        if (user.money < cost) return { text: `❌ Нужно: ${formatMoney(cost)}`, keyboard: keyboards.tg.mining };
        user.money -= cost;
        user.pickaxeLevel++;
        db.saveAll();
        return { text: `✅ Кирка: ${user.pickaxeLevel}/20`, keyboard: keyboards.tg.mining };
      }
      return { text: `⛏️ КИРКА\nУровень: ${user.pickaxeLevel}/20\n📌 кирка улучшить`, keyboard: keyboards.tg.mining };
    }
    if (cmd === 'руда' && args[0] === 'продать') return commands.sellOre(ctx);
    
    if (cmd === 'рыбалка' || cmd === 'fishing') return commands.fishing(ctx);
    if (cmd === 'рыба' && args[0] === 'продать') return commands.sellFish(ctx);
    
    if (cmd === 'телефон' || cmd === 'phone') {
      if (args[0] === 'купить') return commands.phoneBuy(ctx, args[1]);
      if (args[0] === 'пост') return commands.phonePost(ctx, args.slice(1).join(' '));
      if (args[0] === 'лента') return commands.phoneFeed(ctx);
      return commands.phone(ctx);
    }
    
    if (cmd === 'клан' || cmd === 'clan') {
      if (args[0] === 'создать') return commands.clanCreate(ctx, args.slice(1).join(' '));
      if (args[0] === 'пополнить') return commands.clanDeposit(ctx, args[1]);
      return commands.clan(ctx);
    }
    if (cmd === 'кланы') return commands.top(ctx, 'clans');
    
    if (cmd === 'реферал' || cmd === 'ref') return commands.referral(ctx);
    if (cmd === 'бонус' || cmd === 'bonus') {
      if (args[0] === 'часовой') return commands.bonusHourly(ctx);
      return commands.bonus(ctx);
    }
    
    if (text === 'путь новичка' || cmd === 'путь') return commands.beginnerPath(ctx);
    if (cmd === 'квесты' || cmd === 'quests') {
      if (args[0] === 'ежедневные') return commands.questsDaily(ctx);
      if (args[0] === 'сдать') return commands.questClaim(ctx, args[1], args[2]?.startsWith('н'));
      return commands.quests(ctx);
    }
    if (cmd === 'промокод' || cmd === 'promo') return commands.promo(ctx, args[0]);
    if (cmd === 'донат' || cmd === 'donate' || cmd === 'магазин') return commands.donate(ctx);
    if (cmd === 'топ' || cmd === 'top') return commands.top(ctx, args[0]);
    
    if (cmd === 'админ' || cmd === 'admin') {
      if (args[0] === 'статистика') return commands.adminStats(ctx);
      return commands.adminHelp(ctx);
    }
    if (cmd === 'выдать' || cmd === 'give') {
      if (args[0] === 'алмазы') return commands.adminGive(ctx, args[1], args[2], 'diamonds');
      return commands.adminGive(ctx, args[0], args[1], 'money');
    }
    if (cmd === 'бан') return commands.adminBan(ctx, args[0], args.slice(1).join(' '));
    if (cmd === 'разбан') return commands.adminUnban(ctx, args[0]);
    if (text === 'босс создать') return commands.adminBossCreate(ctx);
    if (text === 'босс завершить') return commands.adminBossEnd(ctx);
    if (cmd === 'рассылка') return commands.adminBroadcast(ctx, args.join(' '));
    
    return null;
  } catch (e) {
    console.error('Handler error:', e);
    return { text: '❌ Ошибка! Попробуйте позже.', keyboard: keyboards.tg.main };
  }
};

module.exports = { handleMessage };