// ⚡ FLASH BOT — ГЛАВНЫЙ ФАЙЛ v1.0
const fs = require('fs');
const path = require('path');
const cron = require('node-cron');

// Создание директорий
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(path.join(dataDir, 'backups'))) fs.mkdirSync(path.join(dataDir, 'backups'), { recursive: true });

// Инициализация JSON
const defaults = {
  'users.json': {},
  'clans.json': {},
  'families.json': {},
  'boss.json': { active: false },
  'events.json': { active: [], history: [] },
  'promoCodes.json': {},
  'bonds.json': {},
  'newspaper.json': [],
  'posts.json': [],
  'duels.json': {}
};

Object.entries(defaults).forEach(([file, data]) => {
  const fp = path.join(dataDir, file);
  if (!fs.existsSync(fp)) {
    fs.writeFileSync(fp, JSON.stringify(data, null, 2));
    console.log(`📄 Создан ${file}`);
  }
});

const config = require('./config');
const db = require('./utils/database');
const { createBackup } = require('./utils/helpers');

console.log('⚡ Запуск FLASH BOT...\n━━━━━━━━━━━━━━━━━━━━━━━━');

// Telegram
let tgBot;
try {
  const TG = require('./platforms/telegram');
  tgBot = new TG();
} catch (e) {
  console.error('❌ Telegram:', e.message);
}

// VK
let vkBot;
try {
  const VK = require('./platforms/vk');
  vkBot = new VK();
} catch (e) {
  console.error('❌ VK:', e.message);
}

console.log('━━━━━━━━━━━━━━━━━━━━━━━━');

// ==================== CRON ЗАДАЧИ ====================

// Бэкап каждый час
cron.schedule('0 * * * *', () => {
  console.log('📦 Бэкап...');
  createBackup();
});

// Босс каждые 6 часов
cron.schedule('0 */6 * * *', () => {
  if (!db.boss.active) {
    const boss = db.spawnBoss();
    console.log(`🐉 Босс: ${boss.name}`);
    const msg = `⚔️ ПОЯВИЛСЯ БОСС!\n━━━━━━━━━━━━━━━━━━━━\n${boss.name} (Ур.${boss.level})\n❤️ ${boss.maxHp.toLocaleString()} HP\n💰 ${boss.reward.toLocaleString()}$\n\nКоманда: босс атака`;
    if (tgBot) tgBot.broadcast(msg);
    if (vkBot) vkBot.broadcast(msg);
  }
});

// События каждые 2 часа (30% шанс)
cron.schedule('0 */2 * * *', () => {
  if (Math.random() < 0.3) {
    const events = config.events;
    const evt = events[Math.floor(Math.random() * events.length)];
    const e = db.startEvent(evt);
    console.log(`🎉 Событие: ${e.name}`);
    const msg = `🎉 СОБЫТИЕ!\n━━━━━━━━━━━━━━━━━━━━\n${e.name}\n⏰ ${Math.floor(e.duration / 60)} мин.`;
    if (tgBot) tgBot.broadcast(msg);
    if (vkBot) vkBot.broadcast(msg);
  }
});

// Очистка кодов привязки
cron.schedule('*/10 * * * *', () => {
  const now = Date.now();
  let c = 0;
  Object.entries(db.bonds).forEach(([code, bond]) => {
    if (bond.expires < now) { delete db.bonds[code]; c++; }
  });
  if (c > 0) { db.saveAll(); console.log(`🧹 Очищено ${c} кодов`); }
});

// Сохранение каждые 5 минут
cron.schedule('*/5 * * * *', () => {
  db.saveAll();
  console.log('💾 Сохранено');
});

// Проверка пути новичка
cron.schedule('* * * * *', () => {
  Object.entries(db.users).forEach(([key, user]) => {
    if (!user.beginnerCompleted && user.beginnerStage === 10) {
      if ((user.money + user.bank) >= 100000) {
        db.checkBeginnerPath(key, 'rich');
      }
    }
  });
});

// ==================== СТАРТОВЫЕ ДАННЫЕ ====================

if (!db.promoCodes['FLASH']) {
  db.createPromoCode('FLASH', { money: 10000, exp: 100, diamonds: 5 }, 1000);
  console.log('🎁 Промокод FLASH создан');
}

console.log(`
⚡ FLASH BOT ЗАПУЩЕН!
━━━━━━━━━━━━━━━━━━━━━━━━
📊 v1.0.0
👥 ${Object.keys(db.users).length} игроков
🏛️ ${Object.keys(db.clans).length} кланов
⚔️ Босс: ${db.boss.active ? 'Да' : 'Нет'}

🔗 TG: @gamebotflash_bot
🔗 VK: vk.com/club237124814

💡 Промокод: FLASH
━━━━━━━━━━━━━━━━━━━━━━━━
`);

// Обработка выхода
process.on('SIGINT', () => {
  console.log('\n⏹️ Остановка...');
  db.saveAll();
  createBackup();
  console.log('✅ Сохранено');
  process.exit(0);
});

process.on('uncaughtException', (e) => {
  console.error('❌ Ошибка:', e);
  db.saveAll();
});

process.on('unhandledRejection', (e) => {
  console.error('❌ Promise:', e);
});
