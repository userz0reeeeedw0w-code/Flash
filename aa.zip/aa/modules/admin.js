// ⚡ FLASH BOT — МОДУЛЬ АДМИНИСТРИРОВАНИЯ
const db = require('../utils/database');
const { formatMoney, formatNumber, isAdmin, levelFromExp } = require('../utils/helpers');
const keyboards = require('../utils/keyboards');
const config = require('../config');

module.exports = {
  // Проверка прав администратора
  checkAdmin: (ctx) => {
    return isAdmin(ctx.userId, ctx.platform, config);
  },
  
  // Команда: админ хелп
  adminHelp: async (ctx) => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    return {
      text: `👑 АДМИН-КОМАНДЫ
━━━━━━━━━━━━━━━━━━━━
📊 ИНФОРМАЦИЯ:
• админ статистика — общая статистика
• профиль [UID/#ID] — профиль игрока

💰 ВЫДАЧА:
• выдать [UID] [сумма] — доллары
• выдать рубли [UID] [сумма]
• выдать биткоин [UID] [сумма]
• выдать алмазы [UID] [кол-во]
• выдать опыт [UID] [кол-во]
• выдать привилегию [UID] [тип] [дней]
• выдать бизнес [UID] [номер]
• выдать машину [UID] [номер]

🔨 МОДЕРАЦИЯ:
• бан [UID] [причина]
• разбан [UID]

🎮 ИГРОВЫЕ:
• босс создать — создать босса
• босс завершить — завершить босса
• событие создать [название] [тип] [минуты]
• промокод создать [код] [деньги] [опыт] [алмазы] [лимит]

📢 РАССЫЛКА:
• рассылка [текст]

⚙️ СИСТЕМА:
• админ бэкап — создать бэкап`,
      keyboard: keyboards.tg.main
    };
  },
  
  // Команда: админ статистика
  adminStats: async (ctx) => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    const users = Object.values(db.users);
    const totalMoney = users.reduce((sum, u) => sum + u.money + u.bank, 0);
    const totalBtc = users.reduce((sum, u) => sum + u.bitcoin, 0);
    const totalDiamonds = users.reduce((sum, u) => sum + u.diamonds, 0);
    
    const today = new Date().setHours(0, 0, 0, 0);
    const activeToday = users.filter(u => u.lastActive > today).length;
    
    const clansCount = Object.keys(db.clans).length;
    
    return {
      text: `📊 СТАТИСТИКА БОТА
━━━━━━━━━━━━━━━━━━━━
👥 Всего игроков: ${users.length}
📈 Активных сегодня: ${activeToday}

💰 ЭКОНОМИКА:
├ Всего денег: ${formatMoney(totalMoney)}
├ Всего BTC: ₿${totalBtc.toFixed(4)}
└ Всего алмазов: ${totalDiamonds}💎

🏛️ Кланов: ${clansCount}
⚔️ Босс: ${db.boss.active ? 'Активен' : 'Нет'}

📦 Промокодов: ${Object.keys(db.promoCodes).length}
🎉 Событий: ${db.events.active.length}`,
      keyboard: keyboards.tg.main
    };
  },
  
  // Команда: профиль [UID] (админ версия)
  adminProfile: async (ctx, targetId) => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    const id = parseInt(String(targetId).replace('#', ''));
    const user = db.getUserById(id);
    
    if (!user) {
      return { text: '❌ Игрок не найден!', keyboard: keyboards.tg.main };
    }
    
    const levelInfo = levelFromExp(user.exp);
    const platforms = Object.entries(user.platforms).map(([p, id]) => `${p}: ${id}`).join('\n');
    
    const lastActive = new Date(user.lastActive).toLocaleString();
    const registered = new Date(user.registered).toLocaleString();
    
    return {
      text: `👑 АДМИН-ПРОФИЛЬ
━━━━━━━━━━━━━━━━━━━━
🆔 ID: #${user.id}
📝 UID: ${user.uid}
👤 Ник: ${user.name}
👑 Привилегия: ${user.privilege || 'Нет'}

📱 ПЛАТФОРМЫ:
${platforms}

💰 ФИНАНСЫ:
├ Наличные: ${formatMoney(user.money)}
├ Банк: ${formatMoney(user.bank)}
├ BTC: ₿${user.bitcoin.toFixed(6)}
├ Алмазы: ${user.diamonds}💎
└ Рубли: ${formatNumber(user.rubles)}₽

📊 СТАТИСТИКА:
├ Уровень: ${levelInfo.level}
├ Опыт: ${user.exp}
├ Бизнесов: ${user.businesses.length}
├ Машин: ${user.cars.length}
└ Рефералов: ${user.referrals.length}

⏰ АКТИВНОСТЬ:
├ Регистрация: ${registered}
└ Последняя: ${lastActive}`,
      keyboard: {
        inline_keyboard: [
          [{ text: '💰 ВЫДАТЬ', callback_data: `admin_give_${user.id}` }, { text: '🔨 БАН', callback_data: `admin_ban_${user.id}` }],
          [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
        ]
      }
    };
  },
  
  // Команда: выдать [UID] [сумма]
  give: async (ctx, targetId, amount, currency = 'money') => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    const id = parseInt(String(targetId).replace('#', ''));
    const user = db.getUserById(id);
    
    if (!user) {
      return { text: '❌ Игрок не найден!', keyboard: keyboards.tg.main };
    }
    
    amount = parseFloat(amount);
    if (isNaN(amount)) {
      return { text: '❌ Укажите сумму!', keyboard: keyboards.tg.main };
    }
    
    let currencyName = '';
    switch (currency) {
      case 'money':
      case 'доллары':
        user.money += amount;
        currencyName = '$';
        break;
      case 'rubles':
      case 'рубли':
        user.rubles += amount;
        currencyName = '₽';
        break;
      case 'bitcoin':
      case 'биткоин':
        user.bitcoin += amount;
        currencyName = 'BTC';
        break;
      case 'diamonds':
      case 'алмазы':
        user.diamonds += Math.floor(amount);
        currencyName = '💎';
        break;
      case 'exp':
      case 'опыт':
        db.addExp(user, Math.floor(amount));
        currencyName = 'XP';
        break;
      default:
        user.money += amount;
        currencyName = '$';
    }
    
    // Создаём уведомление
    if (!user.notifications) user.notifications = [];
    user.notifications.push({
      type: 'admin_give',
      amount,
      currency: currencyName,
      date: Date.now()
    });
    
    db.saveAll();
    
    return {
      text: `✅ ВЫДАНО
━━━━━━━━━━━━━━━━━━━━
👤 Игрок: ${user.name} (#${user.id})
💰 Сумма: ${amount} ${currencyName}`,
      keyboard: keyboards.tg.main,
      // Уведомление игроку
      notify: {
        text: `🎁 ВАМ ВЫДАНО
━━━━━━━━━━━━━━━━━━━━
💰 ${amount} ${currencyName}
👑 От администратора`
      }
    };
  },
  
  // Команда: выдать привилегию
  givePrivilege: async (ctx, targetId, privilegeName, days) => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    const id = parseInt(String(targetId).replace('#', ''));
    const user = db.getUserById(id);
    
    if (!user) {
      return { text: '❌ Игрок не найден!', keyboard: keyboards.tg.main };
    }
    
    const priv = config.privileges[privilegeName.toLowerCase()];
    if (!priv) {
      return { text: '❌ Привилегия не найдена! Доступны: vip, premium, legend, ultimate', keyboard: keyboards.tg.main };
    }
    
    days = parseInt(days) || 30;
    
    user.privilege = priv.name;
    user.privilegeExpires = Date.now() + days * 24 * 60 * 60 * 1000;
    db.saveAll();
    
    return {
      text: `✅ ПРИВИЛЕГИЯ ВЫДАНА
━━━━━━━━━━━━━━━━━━━━
👤 Игрок: ${user.name} (#${user.id})
👑 Привилегия: ${priv.name}
⏰ Дней: ${days}`,
      keyboard: keyboards.tg.main
    };
  },
  
  // Команда: выдать бизнес
  giveBusiness: async (ctx, targetId, bizId) => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    const id = parseInt(String(targetId).replace('#', ''));
    const user = db.getUserById(id);
    
    if (!user) {
      return { text: '❌ Игрок не найден!', keyboard: keyboards.tg.main };
    }
    
    const biz = config.businesses.find(b => b.id === parseInt(bizId)) || config.donatBusinesses.find(b => b.id === parseInt(bizId));
    if (!biz) {
      return { text: '❌ Бизнес не найден!', keyboard: keyboards.tg.main };
    }
    
    if (user.businesses.find(b => b.id === biz.id)) {
      return { text: '❌ У игрока уже есть этот бизнес!', keyboard: keyboards.tg.main };
    }
    
    user.businesses.push({
      id: biz.id,
      level: 1,
      lastCollect: 0,
      manager: false
    });
    
    db.saveAll();
    
    return {
      text: `✅ БИЗНЕС ВЫДАН
━━━━━━━━━━━━━━━━━━━━
👤 Игрок: ${user.name} (#${user.id})
🏢 Бизнес: ${biz.name}`,
      keyboard: keyboards.tg.main
    };
  },
  
  // Команда: выдать машину
  giveCar: async (ctx, targetId, carId) => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    const id = parseInt(String(targetId).replace('#', ''));
    const user = db.getUserById(id);
    
    if (!user) {
      return { text: '❌ Игрок не найден!', keyboard: keyboards.tg.main };
    }
    
    const car = config.cars.find(c => c.id === parseInt(carId));
    if (!car) {
      return { text: '❌ Машина не найдена!', keyboard: keyboards.tg.main };
    }
    
    if (user.cars.includes(car.id)) {
      return { text: '❌ У игрока уже есть эта машина!', keyboard: keyboards.tg.main };
    }
    
    user.cars.push(car.id);
    if (!user.currentCar) user.currentCar = car.id;
    
    db.saveAll();
    
    return {
      text: `✅ МАШИНА ВЫДАНА
━━━━━━━━━━━━━━━━━━━━
👤 Игрок: ${user.name} (#${user.id})
🚗 Машина: ${car.name}`,
      keyboard: keyboards.tg.main
    };
  },
  
  // Команда: бан
  ban: async (ctx, targetId, reason = 'Нарушение правил') => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    const id = parseInt(String(targetId).replace('#', ''));
    const user = db.getUserById(id);
    
    if (!user) {
      return { text: '❌ Игрок не найден!', keyboard: keyboards.tg.main };
    }
    
    user.banned = true;
    user.banReason = reason;
    user.banDate = Date.now();
    db.saveAll();
    
    return {
      text: `🔨 ИГРОК ЗАБАНЕН
━━━━━━━━━━━━━━━━━━━━
👤 Игрок: ${user.name} (#${user.id})
📝 Причина: ${reason}`,
      keyboard: keyboards.tg.main
    };
  },
  
  // Команда: разбан
  unban: async (ctx, targetId) => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    const id = parseInt(String(targetId).replace('#', ''));
    const user = db.getUserById(id);
    
    if (!user) {
      return { text: '❌ Игрок не найден!', keyboard: keyboards.tg.main };
    }
    
    user.banned = false;
    user.banReason = null;
    user.banDate = null;
    db.saveAll();
    
    return {
      text: `✅ ИГРОК РАЗБАНЕН
━━━━━━━━━━━━━━━━━━━━
👤 Игрок: ${user.name} (#${user.id})`,
      keyboard: keyboards.tg.main
    };
  },
  
  // Команда: босс создать
  bossCreate: async (ctx) => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    if (db.boss.active) {
      return { text: '❌ Босс уже активен!', keyboard: keyboards.tg.main };
    }
    
    const boss = db.spawnBoss();
    
    return {
      text: `⚔️ БОСС СОЗДАН!
━━━━━━━━━━━━━━━━━━━━
🐉 ${boss.name}
📊 Уровень: ${boss.level}
❤️ HP: ${formatNumber(boss.maxHp)}
💰 Награда: ${formatMoney(boss.reward)}`,
      keyboard: keyboards.tg.main,
      // Рассылка
      broadcast: `⚔️ ПОЯВИЛСЯ БОСС!
━━━━━━━━━━━━━━━━━━━━
🐉 ${boss.name} (Ур. ${boss.level})
❤️ HP: ${formatNumber(boss.maxHp)}
💰 Награда: ${formatMoney(boss.reward)}

Напишите «босс атака» для атаки!`
    };
  },
  
  // Команда: босс завершить
  bossEnd: async (ctx) => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    if (!db.boss.active) {
      return { text: '❌ Босс не активен!', keyboard: keyboards.tg.main };
    }
    
    db.boss.active = false;
    db.saveAll();
    
    return {
      text: `✅ Босс завершён!`,
      keyboard: keyboards.tg.main
    };
  },
  
  // Команда: событие создать
  eventCreate: async (ctx, name, type, duration) => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    const eventConfig = config.events.find(e => e.type === type);
    if (!eventConfig) {
      return { text: '❌ Тип события не найден! Доступны: double_income, fast_energy, lucky_casino, turbo_race', keyboard: keyboards.tg.main };
    }
    
    const event = db.startEvent({
      ...eventConfig,
      name: name || eventConfig.name,
      duration: parseInt(duration) * 60 || eventConfig.duration
    });
    
    return {
      text: `✅ СОБЫТИЕ ЗАПУЩЕНО!
━━━━━━━━━━━━━━━━━━━━
🎉 ${event.name}
⏰ Длительность: ${Math.floor(event.duration / 60)} мин.`,
      keyboard: keyboards.tg.main,
      broadcast: `🎉 СОБЫТИЕ ЗАПУЩЕНО!
━━━━━━━━━━━━━━━━━━━━
${event.name}
⏰ Длительность: ${Math.floor(event.duration / 60)} мин.

Используйте эту возможность!`
    };
  },
  
  // Команда: промокод создать
  promoCreate: async (ctx, code, money, exp, diamonds, limit) => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    if (!code) {
      return { text: '❌ Укажите код!', keyboard: keyboards.tg.main };
    }
    
    db.createPromoCode(code, {
      money: parseInt(money) || 0,
      exp: parseInt(exp) || 0,
      diamonds: parseInt(diamonds) || 0
    }, parseInt(limit) || 100);
    
    return {
      text: `✅ ПРОМОКОД СОЗДАН!
━━━━━━━━━━━━━━━━━━━━
📝 Код: ${code.toUpperCase()}
💰 Деньги: ${formatMoney(parseInt(money) || 0)}
⭐ Опыт: ${parseInt(exp) || 0}
💎 Алмазы: ${parseInt(diamonds) || 0}
📊 Лимит: ${parseInt(limit) || 100}`,
      keyboard: keyboards.tg.main
    };
  },
  
  // Команда: рассылка
  broadcast: async (ctx, text) => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    if (!text) {
      return { text: '❌ Укажите текст рассылки!', keyboard: keyboards.tg.main };
    }
    
    const usersCount = Object.keys(db.users).length;
    
    return {
      text: `✅ Рассылка запущена для ${usersCount} пользователей!`,
      keyboard: keyboards.tg.main,
      broadcast: `📢 ОБЪЯВЛЕНИЕ
━━━━━━━━━━━━━━━━━━━━
${text}`
    };
  },
  
  // Команда: админ бэкап
  backup: async (ctx) => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    const { createBackup } = require('../utils/helpers');
    createBackup();
    
    return {
      text: `✅ Бэкап создан!`,
      keyboard: keyboards.tg.main
    };
  }
};
