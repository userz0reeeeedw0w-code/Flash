// ⚡ FLASH BOT — МОДУЛЬ АВТОРИЗАЦИИ
const db = require('../utils/database');
const { formatTime } = require('../utils/helpers');
const keyboards = require('../utils/keyboards');
const config = require('../config');

module.exports = {
  // Команда: старт
  start: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    
    if (user) {
      return {
        text: `⚡ FLASH — ИГРОВОЙ БОТ
━━━━━━━━━━━━━━━━━━━━
👋 С возвращением, ${user.name}!

💰 Баланс: ${user.money.toLocaleString()}$
🏦 Банк: ${user.bank.toLocaleString()}$
📊 Уровень: ${require('../utils/helpers').levelFromExp(user.exp).level}

Используй команды для игры!`,
        keyboard: keyboards.tg.main
      };
    }
    
    return {
      text: `⚡ ДОБРО ПОЖАЛОВАТЬ В FLASH!
━━━━━━━━━━━━━━━━━━━━
🎮 Это экономическая RPG игра!

Выберите действие:
• Создать новый аккаунт
• Привязать существующий (если играете на другой платформе)`,
      keyboard: keyboards.tg.start
    };
  },
  
  // Callback: создание аккаунта
  authCreate: async (ctx) => {
    let user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (user) {
      return { text: '❌ У вас уже есть аккаунт!', keyboard: keyboards.tg.main };
    }
    
    user = db.createUser(ctx.platform, ctx.userId, ctx.userName);
    
    // Отмечаем путь новичка
    db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'message');
    
    return {
      text: `✅ АККАУНТ СОЗДАН!
━━━━━━━━━━━━━━━━━━━━
👤 Ник: ${user.name}
🆔 ID: #${user.id}

💰 Стартовый капитал: ${config.game.startMoney.toLocaleString()}$
⚡ Энергия: ${config.game.maxEnergy}/${config.game.maxEnergy}

🎁 Вы получили достижение «Первые шаги»!
+1,000$ и +100 опыта

📍 Начните с команды «путь новичка»!`,
      keyboard: keyboards.tg.main
    };
  },
  
  // Callback: начало привязки
  authBind: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (user) {
      return { text: '❌ У вас уже есть аккаунт!', keyboard: keyboards.tg.main };
    }
    
    return {
      text: `🔗 ПРИВЯЗКА АККАУНТА
━━━━━━━━━━━━━━━━━━━━
Чтобы привязать аккаунт:

1️⃣ Зайдите на платформу, где у вас есть аккаунт (${ctx.platform === 'telegram' ? 'VK' : 'Telegram'})

2️⃣ Напишите команду: привязать

3️⃣ Получите 6-значный код

4️⃣ Введите здесь: код XXXXXX`,
      keyboard: keyboards.tg.bind
    };
  },
  
  // Команда: привязать (генерация кода)
  bind: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return {
        text: '❌ Сначала создайте аккаунт командой «старт»',
        keyboard: keyboards.tg.start
      };
    }
    
    const code = db.createBondCode(ctx.platform, ctx.userId);
    
    return {
      text: `🔗 КОД ПРИВЯЗКИ
━━━━━━━━━━━━━━━━━━━━
📝 Ваш код: ${code}

⏰ Действует: ${config.game.bondCodeExpireMinutes} минут

📌 Инструкция:
1. Зайдите на другую платформу
2. Напишите: код ${code}
3. Аккаунты будут связаны!

⚠️ Не сообщайте код посторонним!`,
      keyboard: keyboards.tg.bind
    };
  },
  
  // Команда: код XXXXXX
  useCode: async (ctx, code) => {
    const existingUser = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (existingUser) {
      return { text: '❌ У вас уже есть аккаунт на этой платформе!', keyboard: keyboards.tg.main };
    }
    
    const result = db.useBondCode(code.toUpperCase(), ctx.platform, ctx.userId);
    
    if (!result.success) {
      return { text: `❌ ${result.error}`, keyboard: keyboards.tg.start };
    }
    
    return {
      text: `✅ АККАУНТ ПРИВЯЗАН!
━━━━━━━━━━━━━━━━━━━━
👤 Ник: ${result.user.name}
🆔 ID: #${result.user.id}

💰 Баланс: ${result.user.money.toLocaleString()}$
🏦 Банк: ${result.user.bank.toLocaleString()}$

🔗 Теперь вы можете играть на обеих платформах!`,
      keyboard: keyboards.tg.main
    };
  },
  
  // Команда: привязка статус
  bindStatus: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const platforms = Object.keys(user.platforms);
    const platformsText = platforms.map(p => {
      const emoji = p === 'telegram' ? '📱' : '💬';
      return `${emoji} ${p.charAt(0).toUpperCase() + p.slice(1)}: ✅`;
    }).join('\n');
    
    return {
      text: `🔗 СТАТУС ПРИВЯЗКИ
━━━━━━━━━━━━━━━━━━━━
${platformsText}

📌 Привязанные платформы: ${platforms.length}/2`,
      keyboard: {
        inline_keyboard: [
          [{ text: '🔗 ПРИВЯЗАТЬ ЕЩЁ', callback_data: 'auth_bind' }],
          [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
        ]
      }
    };
  },
  
  // Команда: помощь
  help: async (ctx) => {
    return {
      text: `❓ ПОМОЩЬ — FLASH BOT
━━━━━━━━━━━━━━━━━━━━
📋 ОСНОВНЫЕ КОМАНДЫ:

👤 профиль — ваш профиль
💰 баланс — проверить баланс
🏦 банк — операции с банком
💼 работа — список работ
🏢 бизнес — ваши бизнесы

🎮 ИГРЫ:
🎰 казино — игры казино
🏁 гонка — гоночные заезды
⚔️ босс — атака босса
⛏️ копать — добыча руды
🎣 рыбалка — ловля рыбы

👥 СОЦИАЛЬНОЕ:
🏛️ клан — меню клана
👨‍👩‍👧 семья — семейные дела
📱 телефон — соцсети

🎁 БОНУСЫ:
бонус — ежедневный бонус
📍 путь новичка — гайд для новичков
📋 квесты — задания

⌨️ клавиатура вкл — включить кнопки`,
      keyboard: keyboards.tg.help
    };
  },
  
  // Команда: помощь реферал
  helpRef: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    return {
      text: `🎁 РЕФЕРАЛЬНАЯ СИСТЕМА
━━━━━━━━━━━━━━━━━━━━
📌 Как это работает:

1️⃣ Поделитесь своей ссылкой с друзьями
2️⃣ Друг регистрируется по вашей ссылке
3️⃣ Вы получаете 10% от его заработка!

💰 НАГРАДЫ:
• 1 реферал → 5,000$
• 5 рефералов → 25,000$ + 5💎
• 10 рефералов → 100,000$ + 20💎
• 25 рефералов → 500,000$ + 50💎

📋 КОМАНДЫ:
реферал — меню рефералов
реферал ссылка — ваша ссылка
реферал список — ваши рефералы
реферал статистика — ваш доход`,
      keyboard: {
        inline_keyboard: [
          [{ text: '🔗 МОЯ ССЫЛКА', callback_data: 'ref_link' }],
          [{ text: '📊 СТАТИСТИКА', callback_data: 'ref_stats' }],
          [{ text: '🔙 НАЗАД', callback_data: 'help' }]
        ]
      }
    };
  },
  
  // Команда: настройки
  settings: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const kbStatus = user.settings.keyboard ? '✅ ВКЛ' : '❌ ВЫКЛ';
    const notifStatus = user.settings.notifications ? '✅ ВКЛ' : '❌ ВЫКЛ';
    
    return {
      text: `⚙️ НАСТРОЙКИ
━━━━━━━━━━━━━━━━━━━━
⌨️ Клавиатура: ${kbStatus}
🔔 Уведомления: ${notifStatus}

📌 Команды:
• клавиатура вкл/выкл
• уведомления вкл/выкл`,
      keyboard: keyboards.tg.settings
    };
  },
  
  // Команды клавиатуры
  keyboardOn: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    db.updateUser(ctx.platform, ctx.userId, { 'settings.keyboard': true });
    
    return {
      text: `⌨️ КЛАВИАТУРА ВКЛЮЧЕНА
━━━━━━━━━━━━━━━━━━━━
Теперь у вас отображаются кнопки для быстрого доступа.`,
      replyKeyboard: keyboards.tgReply
    };
  },
  
  keyboardOff: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    db.updateUser(ctx.platform, ctx.userId, { 'settings.keyboard': false });
    
    return {
      text: `⌨️ КЛАВИАТУРА ВЫКЛЮЧЕНА
━━━━━━━━━━━━━━━━━━━━
Постоянная клавиатура скрыта.`,
      removeKeyboard: true
    };
  },
  
  keyboardStatus: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const status = user.settings.keyboard ? 'ВКЛЮЧЕНА ✅' : 'ВЫКЛЮЧЕНА ❌';
    
    return {
      text: `⌨️ СТАТУС КЛАВИАТУРЫ
━━━━━━━━━━━━━━━━━━━━
📊 Текущее состояние: ${status}`,
      keyboard: keyboards.tg.settings
    };
  },
  
  // Команда: правила
  rules: async (ctx) => {
    return {
      text: `📜 ПРАВИЛА FLASH
━━━━━━━━━━━━━━━━━━━━
1️⃣ Запрещён мультиаккаунтинг
2️⃣ Запрещены оскорбления
3️⃣ Запрещён обман игроков
4️⃣ Запрещены баги и читы
5️⃣ Уважайте других игроков

⚠️ Нарушение правил = бан!

📌 По вопросам: @admin`,
      keyboard: keyboards.tg.help
    };
  },
  
  // Команда: инфо
  info: async (ctx) => {
    const totalUsers = Object.keys(db.users).length;
    
    return {
      text: `⚡ FLASH BOT — ИНФОРМАЦИЯ
━━━━━━━━━━━━━━━━━━━━
📊 Версия: 1.0.0
👥 Игроков: ${totalUsers}

🔗 Платформы:
• Telegram: @gamebotflash_bot
• VK: vk.com/club237124814

👨‍💻 Разработчик: @admin

💎 Поддержать проект: донат`,
      keyboard: keyboards.tg.help
    };
  }
};
