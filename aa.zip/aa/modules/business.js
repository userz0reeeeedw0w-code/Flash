// ⚡ FLASH BOT — МОДУЛЬ БИЗНЕСА, РАБОТЫ, ФЕРМ, ПРИНТЕРОВ
const db = require('../utils/database');
const { formatMoney, formatNumber, checkCooldown, formatTime, levelFromExp } = require('../utils/helpers');
const keyboards = require('../utils/keyboards');
const config = require('../config');

module.exports = {
  // ==================== РАБОТА ====================
  
  // Команда: работа
  job: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (user.job) {
      const jobInfo = config.jobs.find(j => j.id === user.job);
      const cooldown = checkCooldown(user.cooldowns.work, config.game.cooldowns.work);
      const cooldownText = cooldown.ready ? '✅ Можно работать' : `⏰ Ожидание: ${formatTime(cooldown.remaining)}`;
      
      return {
        text: `💼 РАБОТА
━━━━━━━━━━━━━━━━━━━━
📋 Должность: ${jobInfo.name}
💰 Зарплата: ${formatMoney(jobInfo.salary)}
📊 Смен отработано: ${user.workStreak}
${cooldownText}

📌 Команды:
• работать — отработать смену
• уволиться — уволиться`,
        keyboard: keyboards.tg.job
      };
    }
    
    return {
      text: `💼 РАБОТА
━━━━━━━━━━━━━━━━━━━━
❌ Вы безработный!

Напишите: работа [номер] — чтобы устроиться.
Или: работа список — посмотреть вакансии.`,
      keyboard: keyboards.tg.job
    };
  },
  
  // Команда: работа список
  jobList: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const level = levelFromExp(user.exp).level;
    
    let text = `💼 СПИСОК РАБОТ
━━━━━━━━━━━━━━━━━━━━\n`;
    
    config.jobs.forEach(job => {
      const available = level >= job.minLevel ? '✅' : '🔒';
      text += `\n${available} ${job.id}. ${job.name}`;
      text += `\n   💰 ${formatMoney(job.salary)} | 📊 С ${job.minLevel} ур.`;
    });
    
    text += `\n\n📌 Устроиться: работа [номер]`;
    
    return { text, keyboard: keyboards.tg.job };
  },
  
  // Команда: работа [номер]
  jobApply: async (ctx, jobId) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (user.job) {
      return { text: '❌ Сначала уволитесь с текущей работы!', keyboard: keyboards.tg.job };
    }
    
    const job = config.jobs.find(j => j.id === parseInt(jobId));
    if (!job) {
      return { text: '❌ Работа не найдена!', keyboard: keyboards.tg.job };
    }
    
    const level = levelFromExp(user.exp).level;
    if (level < job.minLevel) {
      return { text: `❌ Нужен ${job.minLevel} уровень! У вас: ${level}`, keyboard: keyboards.tg.job };
    }
    
    user.job = job.id;
    user.workStreak = 0;
    db.saveAll();
    
    // Путь новичка
    const pathComplete = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'job');
    let pathText = '';
    if (pathComplete) {
      pathText = `\n\n🎉 ПУТЬ НОВИЧКА: Этап ${pathComplete.stage} выполнен!\n+${formatMoney(pathComplete.reward.money)} +${pathComplete.reward.exp} XP`;
    }
    
    return {
      text: `✅ ВЫ УСТРОИЛИСЬ НА РАБОТУ!
━━━━━━━━━━━━━━━━━━━━
📋 Должность: ${job.name}
💰 Зарплата: ${formatMoney(job.salary)}

📌 Напишите «работать» чтобы получить зарплату!${pathText}`,
      keyboard: keyboards.tg.job
    };
  },
  
  // Команда: работать
  work: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (!user.job) {
      return { text: '❌ Вы безработный! Напишите: работа список', keyboard: keyboards.tg.job };
    }
    
    const cooldown = checkCooldown(user.cooldowns.work, config.game.cooldowns.work);
    if (!cooldown.ready) {
      return { text: `⏰ Время ожидания: ${formatTime(cooldown.remaining)}`, keyboard: keyboards.tg.job };
    }
    
    const job = config.jobs.find(j => j.id === user.job);
    const bonus = Math.floor(Math.random() * job.salary * 0.3); // до 30% бонус
    const salary = job.salary + bonus;
    const exp = 10 + Math.floor(Math.random() * 40);
    
    user.money += salary;
    user.cooldowns.work = Date.now();
    user.workStreak++;
    user.stats.workShifts++;
    user.stats.totalEarned += salary;
    
    const levelUp = db.addExp(user, exp);
    
    // Обновляем квесты
    const completedQuests = db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'work_shifts', 1);
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'earn', salary);
    
    db.saveAll();
    
    // Путь новичка
    const pathComplete = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'work');
    let pathText = '';
    if (pathComplete) {
      pathText = `\n\n🎉 ПУТЬ НОВИЧКА: Этап ${pathComplete.stage} выполнен!\n+${formatMoney(pathComplete.reward.money)} +${pathComplete.reward.exp} XP`;
    }
    
    let questText = '';
    if (completedQuests.length > 0) {
      questText = '\n\n🎯 КВЕСТ ВЫПОЛНЕН: ' + completedQuests.map(q => q.name).join(', ');
    }
    
    let levelText = '';
    if (levelUp.leveledUp) {
      levelText = `\n\n🎉 УРОВЕНЬ ПОВЫШЕН! Теперь вы ${levelUp.newLevel} уровня!`;
    }
    
    return {
      text: `💼 РАБОТА ВЫПОЛНЕНА!
━━━━━━━━━━━━━━━━━━━━
📋 Должность: ${job.name}
💰 Зарплата: ${formatMoney(job.salary)}
🎁 Бонус: +${formatMoney(bonus)}
━━━━━━━━━━━━━━━━━━━━
✅ Получено: ${formatMoney(salary)}
⭐ Опыт: +${exp} XP
📊 Смен всего: ${user.workStreak}

💵 Баланс: ${formatMoney(user.money)}${pathText}${questText}${levelText}`,
      keyboard: keyboards.tg.job
    };
  },
  
  // Команда: уволиться
  jobQuit: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (!user.job) {
      return { text: '❌ Вы и так безработный!', keyboard: keyboards.tg.job };
    }
    
    const job = config.jobs.find(j => j.id === user.job);
    user.job = null;
    user.workStreak = 0;
    db.saveAll();
    
    return {
      text: `✅ ВЫ УВОЛИЛИСЬ
━━━━━━━━━━━━━━━━━━━━
📋 Бывшая должность: ${job.name}

Теперь вы безработный. Устройтесь на новую работу!`,
      keyboard: keyboards.tg.job
    };
  },
  
  // ==================== БИЗНЕС ====================
  
  // Команда: бизнес
  business: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (user.businesses.length === 0) {
      return {
        text: `🏢 БИЗНЕС
━━━━━━━━━━━━━━━━━━━━
❌ У вас нет бизнесов!

📌 Команды:
• бизнес список — доступные бизнесы
• бизнес купить [номер]`,
        keyboard: keyboards.tg.business
      };
    }
    
    let text = `🏢 ВАШИ БИЗНЕСЫ (${user.businesses.length})
━━━━━━━━━━━━━━━━━━━━\n`;
    
    user.businesses.forEach((biz, i) => {
      const bizInfo = config.businesses.find(b => b.id === biz.id);
      const income = bizInfo.income * (1 + biz.level * 0.1);
      const cooldown = checkCooldown(biz.lastCollect, config.game.cooldowns.businessCollect);
      const status = cooldown.ready ? '✅ Готов' : `⏰ ${formatTime(cooldown.remaining)}`;
      
      text += `\n${i + 1}. ${bizInfo.name} [Ур.${biz.level}]`;
      text += `\n   💰 ${formatMoney(income)}/сбор | ${status}`;
    });
    
    text += `\n\n📌 Команды:
• бизнес собрать [номер] — собрать доход
• бизнес собрать все — собрать всё
• бизнес улучшить [номер]`;
    
    return { text, keyboard: keyboards.tg.business };
  },
  
  // Команда: бизнес список
  businessList: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    // Определяем максимум бизнесов
    let maxBiz = 1;
    if (user.privilege) {
      const priv = config.privileges[user.privilege.toLowerCase()];
      if (priv) maxBiz = priv.bonuses.maxBusinesses;
    }
    
    let text = `🏢 СПИСОК БИЗНЕСОВ
━━━━━━━━━━━━━━━━━━━━
📊 Слотов: ${user.businesses.length}/${maxBiz}\n`;
    
    config.businesses.forEach(biz => {
      const owned = user.businesses.find(b => b.id === biz.id);
      const status = owned ? '✅' : '🛒';
      text += `\n${status} ${biz.id}. ${biz.name}`;
      text += `\n   💰 ${formatMoney(biz.price)} | 📈 ${formatMoney(biz.income)}/сбор`;
    });
    
    text += `\n\n💎 ДОНАТ БИЗНЕСЫ:\n`;
    config.donatBusinesses.forEach(biz => {
      const owned = user.businesses.find(b => b.id === biz.id);
      const status = owned ? '✅' : '💎';
      text += `\n${status} ${biz.id}. ${biz.name}`;
      text += `\n   💎 ${biz.price} алмазов | 📈 ${formatMoney(biz.income)}/сбор`;
    });
    
    return { text, keyboard: keyboards.tg.business };
  },
  
  // Команда: бизнес купить
  businessBuy: async (ctx, bizId) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    // Максимум бизнесов
    let maxBiz = 1;
    if (user.privilege) {
      const priv = config.privileges[user.privilege.toLowerCase()];
      if (priv) maxBiz = priv.bonuses.maxBusinesses;
    }
    
    if (user.businesses.length >= maxBiz) {
      return { text: `❌ Максимум бизнесов: ${maxBiz}. Купите привилегию для увеличения!`, keyboard: keyboards.tg.business };
    }
    
    const id = parseInt(bizId);
    
    // Проверяем обычные бизнесы
    let biz = config.businesses.find(b => b.id === id);
    let isDonate = false;
    
    if (!biz) {
      // Проверяем донат бизнесы
      biz = config.donatBusinesses.find(b => b.id === id);
      isDonate = true;
    }
    
    if (!biz) {
      return { text: '❌ Бизнес не найден!', keyboard: keyboards.tg.business };
    }
    
    if (user.businesses.find(b => b.id === id)) {
      return { text: '❌ У вас уже есть этот бизнес!', keyboard: keyboards.tg.business };
    }
    
    if (isDonate) {
      if (user.diamonds < biz.price) {
        return { text: `❌ Недостаточно алмазов! Нужно: ${biz.price}💎`, keyboard: keyboards.tg.business };
      }
      user.diamonds -= biz.price;
    } else {
      if (user.money < biz.price) {
        return { text: `❌ Недостаточно денег! Нужно: ${formatMoney(biz.price)}`, keyboard: keyboards.tg.business };
      }
      user.money -= biz.price;
    }
    
    user.businesses.push({
      id: biz.id,
      level: 1,
      lastCollect: 0,
      manager: false
    });
    
    db.saveAll();
    
    // Путь новичка
    const pathComplete = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'business');
    let pathText = '';
    if (pathComplete) {
      pathText = `\n\n🎉 ПУТЬ НОВИЧКА: Этап ${pathComplete.stage} выполнен!\n+${formatMoney(pathComplete.reward.money)} +${pathComplete.reward.exp} XP`;
    }
    
    // Проверяем достижения
    const achievements = db.checkAchievements(`${ctx.platform}_${ctx.userId}`);
    let achText = '';
    if (achievements.length > 0) {
      achText = '\n\n🏆 ДОСТИЖЕНИЕ: ' + achievements.map(a => a.name).join(', ');
    }
    
    return {
      text: `✅ БИЗНЕС КУПЛЕН!
━━━━━━━━━━━━━━━━━━━━
🏢 ${biz.name}
💰 Доход: ${formatMoney(biz.income)}/сбор

📌 Собирайте доход: бизнес собрать 1${pathText}${achText}`,
      keyboard: keyboards.tg.business
    };
  },
  
  // Команда: бизнес собрать
  businessCollect: async (ctx, bizIndex) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (bizIndex === 'все' || bizIndex === 'all') {
      // Собрать все
      let totalIncome = 0;
      let collected = 0;
      
      user.businesses.forEach(biz => {
        const cooldown = checkCooldown(biz.lastCollect, config.game.cooldowns.businessCollect);
        if (cooldown.ready) {
          const bizInfo = config.businesses.find(b => b.id === biz.id) || config.donatBusinesses.find(b => b.id === biz.id);
          let income = bizInfo.income * (1 + biz.level * 0.1);
          if (biz.manager) income *= 1.15;
          
          // Привилегия
          if (user.privilege) {
            const priv = config.privileges[user.privilege.toLowerCase()];
            if (priv) income *= priv.bonuses.incomeMultiplier;
          }
          
          totalIncome += Math.floor(income);
          biz.lastCollect = Date.now();
          collected++;
        }
      });
      
      if (collected === 0) {
        return { text: '❌ Нет готовых к сбору бизнесов!', keyboard: keyboards.tg.business };
      }
      
      user.money += totalIncome;
      user.stats.businessCollects += collected;
      user.stats.totalEarned += totalIncome;
      
      // Квесты
      db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'business_collect', collected);
      db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'earn', totalIncome);
      
      db.saveAll();
      
      return {
        text: `✅ ДОХОД СОБРАН!
━━━━━━━━━━━━━━━━━━━━
🏢 Бизнесов: ${collected}
💰 Получено: ${formatMoney(totalIncome)}

💵 Баланс: ${formatMoney(user.money)}`,
        keyboard: keyboards.tg.business
      };
    }
    
    const index = parseInt(bizIndex) - 1;
    const biz = user.businesses[index];
    
    if (!biz) {
      return { text: '❌ Бизнес не найден!', keyboard: keyboards.tg.business };
    }
    
    const cooldown = checkCooldown(biz.lastCollect, config.game.cooldowns.businessCollect);
    if (!cooldown.ready) {
      return { text: `⏰ Время ожидания: ${formatTime(cooldown.remaining)}`, keyboard: keyboards.tg.business };
    }
    
    const bizInfo = config.businesses.find(b => b.id === biz.id) || config.donatBusinesses.find(b => b.id === biz.id);
    let income = bizInfo.income * (1 + biz.level * 0.1);
    if (biz.manager) income *= 1.15;
    
    // Привилегия
    if (user.privilege) {
      const priv = config.privileges[user.privilege.toLowerCase()];
      if (priv) income *= priv.bonuses.incomeMultiplier;
    }
    
    income = Math.floor(income);
    
    user.money += income;
    biz.lastCollect = Date.now();
    user.stats.businessCollects++;
    user.stats.totalEarned += income;
    
    // Квесты
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'business_collect', 1);
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'earn', income);
    
    db.saveAll();
    
    // Путь новичка
    const pathComplete = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'collect');
    let pathText = '';
    if (pathComplete) {
      pathText = `\n\n🎉 ПУТЬ НОВИЧКА: Этап ${pathComplete.stage} выполнен!\n+${formatMoney(pathComplete.reward.money)} +${pathComplete.reward.exp} XP`;
    }
    
    return {
      text: `✅ ДОХОД СОБРАН!
━━━━━━━━━━━━━━━━━━━━
🏢 ${bizInfo.name}
💰 Получено: ${formatMoney(income)}

💵 Баланс: ${formatMoney(user.money)}${pathText}`,
      keyboard: keyboards.tg.business
    };
  },
  
  // Команда: бизнес улучшить
  businessUpgrade: async (ctx, bizIndex) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const index = parseInt(bizIndex) - 1;
    const biz = user.businesses[index];
    
    if (!biz) {
      return { text: '❌ Бизнес не найден!', keyboard: keyboards.tg.business };
    }
    
    const bizInfo = config.businesses.find(b => b.id === biz.id) || config.donatBusinesses.find(b => b.id === biz.id);
    
    if (biz.level >= bizInfo.maxLevel) {
      return { text: '❌ Максимальный уровень!', keyboard: keyboards.tg.business };
    }
    
    const cost = Math.floor(bizInfo.price * 0.2 * biz.level);
    
    if (user.money < cost) {
      return { text: `❌ Недостаточно денег! Нужно: ${formatMoney(cost)}`, keyboard: keyboards.tg.business };
    }
    
    user.money -= cost;
    biz.level++;
    db.saveAll();
    
    const newIncome = bizInfo.income * (1 + biz.level * 0.1);
    
    return {
      text: `✅ БИЗНЕС УЛУЧШЕН!
━━━━━━━━━━━━━━━━━━━━
🏢 ${bizInfo.name}
📈 Уровень: ${biz.level}/${bizInfo.maxLevel}
💰 Новый доход: ${formatMoney(newIncome)}/сбор

💵 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.business
    };
  },
  
  // ==================== ФЕРМЫ ====================
  
  // Команда: фермы
  farms: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (user.farms.length === 0) {
      let text = `🌾 ФЕРМЫ (МАЙНИНГ BTC)
━━━━━━━━━━━━━━━━━━━━
❌ У вас нет ферм!

📋 ДОСТУПНЫЕ ФЕРМЫ:\n`;
      
      config.farms.forEach(farm => {
        text += `\n${farm.id}. ${farm.name}`;
        text += `\n   💰 ${formatMoney(farm.price)} | ₿${farm.btcPerHour}/час`;
        text += `\n   📊 Макс: ${farm.maxCount} шт.`;
      });
      
      text += `\n\n📌 Купить: фермы купить [номер] [кол-во]`;
      
      return { text, keyboard: keyboards.tg.farms };
    }
    
    let text = `🌾 ВАШИ ФЕРМЫ
━━━━━━━━━━━━━━━━━━━━\n`;
    
    user.farms.forEach((farm, i) => {
      const farmInfo = config.farms.find(f => f.id === farm.id);
      const cooldown = checkCooldown(farm.lastCollect, config.game.cooldowns.farmCollect);
      const status = cooldown.ready ? '✅ Готов' : `⏰ ${formatTime(cooldown.remaining)}`;
      
      text += `\n${i + 1}. ${farmInfo.name} x${farm.count}`;
      text += `\n   ₿${(farmInfo.btcPerHour * farm.count).toFixed(6)}/час | ${status}`;
    });
    
    text += `\n\n📌 Команды:
• ферма собрать [номер]
• ферма собрать все`;
    
    return { text, keyboard: keyboards.tg.farms };
  },
  
  // Команда: фермы купить
  farmBuy: async (ctx, farmId, count = 1) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const farm = config.farms.find(f => f.id === parseInt(farmId));
    if (!farm) {
      return { text: '❌ Ферма не найдена!', keyboard: keyboards.tg.farms };
    }
    
    count = Math.max(1, parseInt(count) || 1);
    
    // Проверяем лимит
    const existing = user.farms.find(f => f.id === farm.id);
    const currentCount = existing ? existing.count : 0;
    
    if (currentCount + count > farm.maxCount) {
      return { text: `❌ Максимум этих ферм: ${farm.maxCount}. У вас: ${currentCount}`, keyboard: keyboards.tg.farms };
    }
    
    const totalCost = farm.price * count;
    
    if (user.money < totalCost) {
      return { text: `❌ Недостаточно денег! Нужно: ${formatMoney(totalCost)}`, keyboard: keyboards.tg.farms };
    }
    
    user.money -= totalCost;
    
    if (existing) {
      existing.count += count;
    } else {
      user.farms.push({
        id: farm.id,
        count,
        lastCollect: Date.now()
      });
    }
    
    db.saveAll();
    
    return {
      text: `✅ ФЕРМА КУПЛЕНА!
━━━━━━━━━━━━━━━━━━━━
🌾 ${farm.name} x${count}
💰 Стоимость: ${formatMoney(totalCost)}
₿ Доход: ${(farm.btcPerHour * count).toFixed(6)} BTC/час

💵 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.farms
    };
  },
  
  // Команда: ферма собрать
  farmCollect: async (ctx, farmIndex) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (farmIndex === 'все' || farmIndex === 'all') {
      let totalBtc = 0;
      let collected = 0;
      
      user.farms.forEach(farm => {
        const cooldown = checkCooldown(farm.lastCollect, config.game.cooldowns.farmCollect);
        if (cooldown.ready) {
          const farmInfo = config.farms.find(f => f.id === farm.id);
          const btc = farmInfo.btcPerHour * farm.count * (config.game.cooldowns.farmCollect / 3600);
          totalBtc += btc;
          farm.lastCollect = Date.now();
          collected++;
        }
      });
      
      if (collected === 0) {
        return { text: '❌ Нет готовых к сбору ферм!', keyboard: keyboards.tg.farms };
      }
      
      user.bitcoin += totalBtc;
      db.saveAll();
      
      return {
        text: `✅ BTC СОБРАН!
━━━━━━━━━━━━━━━━━━━━
🌾 Ферм: ${collected}
₿ Получено: ${totalBtc.toFixed(6)} BTC

₿ Всего BTC: ${user.bitcoin.toFixed(6)}`,
        keyboard: keyboards.tg.farms
      };
    }
    
    const index = parseInt(farmIndex) - 1;
    const farm = user.farms[index];
    
    if (!farm) {
      return { text: '❌ Ферма не найдена!', keyboard: keyboards.tg.farms };
    }
    
    const cooldown = checkCooldown(farm.lastCollect, config.game.cooldowns.farmCollect);
    if (!cooldown.ready) {
      return { text: `⏰ Время ожидания: ${formatTime(cooldown.remaining)}`, keyboard: keyboards.tg.farms };
    }
    
    const farmInfo = config.farms.find(f => f.id === farm.id);
    const btc = farmInfo.btcPerHour * farm.count * (config.game.cooldowns.farmCollect / 3600);
    
    user.bitcoin += btc;
    farm.lastCollect = Date.now();
    db.saveAll();
    
    return {
      text: `✅ BTC СОБРАН!
━━━━━━━━━━━━━━━━━━━━
🌾 ${farmInfo.name}
₿ Получено: ${btc.toFixed(6)} BTC

₿ Всего BTC: ${user.bitcoin.toFixed(6)}`,
      keyboard: keyboards.tg.farms
    };
  },
  
  // ==================== ПРИНТЕРЫ ====================
  
  // Команда: принтер
  printer: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (user.printers.length === 0) {
      let text = `🖨️ ПРИНТЕРЫ (ПЕЧАТЬ ДЕНЕГ)
━━━━━━━━━━━━━━━━━━━━
❌ У вас нет принтеров!

📋 ДОСТУПНЫЕ ПРИНТЕРЫ:\n`;
      
      config.printers.forEach(p => {
        text += `\n${p.id}. ${p.name}`;
        text += `\n   💰 ${formatMoney(p.price)} | 📈 ${formatMoney(p.income)}/сбор`;
        text += `\n   ⛽ Топливо: ${formatMoney(p.fuelCost)} | Макс: ${p.maxCount} шт.`;
      });
      
      text += `\n\n📌 Купить: принтер купить [номер] [кол-во]`;
      
      return { text, keyboard: keyboards.tg.printers };
    }
    
    let text = `🖨️ ВАШИ ПРИНТЕРЫ
━━━━━━━━━━━━━━━━━━━━\n`;
    
    user.printers.forEach((p, i) => {
      const pInfo = config.printers.find(pr => pr.id === p.id);
      const cooldown = checkCooldown(p.lastCollect, config.game.cooldowns.printerCollect);
      const status = cooldown.ready ? '✅' : `⏰ ${formatTime(cooldown.remaining)}`;
      const fuelStatus = p.fuel > 0 ? `⛽ ${p.fuel}%` : '❌ Пусто';
      
      text += `\n${i + 1}. ${pInfo.name} x${p.count} [Ур.${p.level}]`;
      text += `\n   ${fuelStatus} | ${status}`;
    });
    
    text += `\n\n📌 Команды:
• принтер собрать [номер]
• принтер заправить [номер]`;
    
    return { text, keyboard: keyboards.tg.printers };
  },
  
  // Команда: принтер купить
  printerBuy: async (ctx, printerId, count = 1) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const printer = config.printers.find(p => p.id === parseInt(printerId));
    if (!printer) {
      return { text: '❌ Принтер не найден!', keyboard: keyboards.tg.printers };
    }
    
    count = Math.max(1, parseInt(count) || 1);
    
    const existing = user.printers.find(p => p.id === printer.id);
    const currentCount = existing ? existing.count : 0;
    
    if (currentCount + count > printer.maxCount) {
      return { text: `❌ Максимум этих принтеров: ${printer.maxCount}. У вас: ${currentCount}`, keyboard: keyboards.tg.printers };
    }
    
    const totalCost = printer.price * count;
    
    if (user.money < totalCost) {
      return { text: `❌ Недостаточно денег! Нужно: ${formatMoney(totalCost)}`, keyboard: keyboards.tg.printers };
    }
    
    user.money -= totalCost;
    
    if (existing) {
      existing.count += count;
    } else {
      user.printers.push({
        id: printer.id,
        count,
        level: 1,
        fuel: 100,
        lastCollect: 0
      });
    }
    
    db.saveAll();
    
    return {
      text: `✅ ПРИНТЕР КУПЛЕН!
━━━━━━━━━━━━━━━━━━━━
🖨️ ${printer.name} x${count}
💰 Стоимость: ${formatMoney(totalCost)}
📈 Доход: ${formatMoney(printer.income * count)}/сбор

💵 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.printers
    };
  },
  
  // Команда: принтер собрать
  printerCollect: async (ctx, printerIndex) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const index = parseInt(printerIndex) - 1;
    const printer = user.printers[index];
    
    if (!printer) {
      return { text: '❌ Принтер не найден!', keyboard: keyboards.tg.printers };
    }
    
    if (printer.fuel <= 0) {
      return {
        text: `❌ ПРИНТЕР ПУСТ!
━━━━━━━━━━━━━━━━━━━━
⛽ Топливо: 0%

Заправьте принтер: принтер заправить ${printerIndex + 1}`,
        keyboard: keyboards.tg.printers,
        // Уведомление
        alert: true
      };
    }
    
    const cooldown = checkCooldown(printer.lastCollect, config.game.cooldowns.printerCollect);
    if (!cooldown.ready) {
      return { text: `⏰ Время ожидания: ${formatTime(cooldown.remaining)}`, keyboard: keyboards.tg.printers };
    }
    
    const pInfo = config.printers.find(p => p.id === printer.id);
    const income = pInfo.income * printer.count * (1 + printer.level * 0.1);
    
    user.money += Math.floor(income);
    printer.fuel -= 10;
    printer.lastCollect = Date.now();
    user.stats.totalEarned += Math.floor(income);
    
    db.saveAll();
    
    return {
      text: `✅ ДЕНЬГИ НАПЕЧАТАНЫ!
━━━━━━━━━━━━━━━━━━━━
🖨️ ${pInfo.name}
💰 Получено: ${formatMoney(income)}
⛽ Топливо: ${printer.fuel}%

💵 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.printers
    };
  },
  
  // Команда: принтер заправить
  printerFuel: async (ctx, printerIndex) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const index = parseInt(printerIndex) - 1;
    const printer = user.printers[index];
    
    if (!printer) {
      return { text: '❌ Принтер не найден!', keyboard: keyboards.tg.printers };
    }
    
    if (printer.fuel >= 100) {
      return { text: '❌ Принтер уже полный!', keyboard: keyboards.tg.printers };
    }
    
    const pInfo = config.printers.find(p => p.id === printer.id);
    const fuelNeeded = 100 - printer.fuel;
    const cost = Math.floor(pInfo.fuelCost * fuelNeeded / 100);
    
    if (user.money < cost) {
      return { text: `❌ Недостаточно денег! Нужно: ${formatMoney(cost)}`, keyboard: keyboards.tg.printers };
    }
    
    user.money -= cost;
    printer.fuel = 100;
    db.saveAll();
    
    return {
      text: `✅ ПРИНТЕР ЗАПРАВЛЕН!
━━━━━━━━━━━━━━━━━━━━
🖨️ ${pInfo.name}
⛽ Топливо: 100%
💰 Стоимость: ${formatMoney(cost)}

💵 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.printers
    };
  }
};
