// ⚡ FLASH BOT — МОДУЛЬ КОНТЕНТА (КВЕСТЫ, ПУТЬ НОВИЧКА, СОБЫТИЯ, ПРОМОКОДЫ)
const db = require('../utils/database');
const { formatMoney, formatNumber, getDateKey, getWeekKey } = require('../utils/helpers');
const keyboards = require('../utils/keyboards');
const config = require('../config');

module.exports = {
  // ==================== ПУТЬ НОВИЧКА ====================
  
  // Команда: путь новичка
  beginnerPath: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (user.beginnerCompleted) {
      return {
        text: `📍 ПУТЬ НОВИЧКА
━━━━━━━━━━━━━━━━━━━━
✅ ВЫ ПРОШЛИ ПУТЬ НОВИЧКА!

🎉 Поздравляем! Вы освоили основы игры.
Теперь вам доступны все возможности!`,
        keyboard: keyboards.tg.main
      };
    }
    
    const currentStage = config.beginnerPath.find(s => s.stage === user.beginnerStage);
    if (!currentStage) {
      return { text: '❌ Ошибка пути новичка!', keyboard: keyboards.tg.main };
    }
    
    // Список всех этапов
    let text = `📍 ПУТЬ НОВИЧКА (${user.beginnerStage - 1}/${config.beginnerPath.length})
━━━━━━━━━━━━━━━━━━━━\n`;
    
    config.beginnerPath.forEach(stage => {
      let status;
      if (stage.stage < user.beginnerStage) {
        status = '✅';
      } else if (stage.stage === user.beginnerStage) {
        status = '👉';
      } else {
        status = '⬜';
      }
      
      text += `\n${status} ${stage.stage}. ${stage.task}`;
      if (stage.stage === user.beginnerStage) {
        text += `\n   💰 +${formatMoney(stage.reward.money)}`;
        if (stage.reward.exp) text += ` +${stage.reward.exp} XP`;
        if (stage.reward.diamonds) text += ` +${stage.reward.diamonds}💎`;
      }
    });
    
    text += `\n\n📌 ТЕКУЩИЙ ЭТАП: ${currentStage.task}`;
    
    // Определяем команду для навигации
    const navigationMap = {
      'message': 'профиль',
      'bonus': 'бонус',
      'bank': 'банк положить 100',
      'car': 'машина список',
      'job': 'работа список',
      'work': 'работать',
      'business': 'бизнес список',
      'collect': 'бизнес собрать 1',
      'boss': 'босс',
      'rich': 'баланс'
    };
    
    const navCommand = navigationMap[currentStage.action] || 'помощь';
    
    return {
      text,
      keyboard: {
        inline_keyboard: [
          [{ text: `📍 ВЫПОЛНИТЬ: ${currentStage.task}`, callback_data: `beginner_go_${currentStage.action}` }],
          [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
        ]
      }
    };
  },
  
  // ==================== КВЕСТЫ ====================
  
  // Команда: квесты
  quests: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    db.initDailyQuests(user);
    db.initWeeklyQuests(user);
    db.saveAll();
    
    // Считаем выполненные
    const dailyCompleted = Object.values(user.dailyQuests).filter(q => q.completed).length;
    const weeklyCompleted = Object.values(user.weeklyQuests).filter(q => q.completed).length;
    
    return {
      text: `📋 КВЕСТЫ
━━━━━━━━━━━━━━━━━━━━
📅 Ежедневные: ${dailyCompleted}/${config.dailyQuests.length}
📆 Недельные: ${weeklyCompleted}/${config.weeklyQuests.length}

📌 Команды:
• квесты ежедневные
• квесты недельные
• квесты сдать [номер]`,
      keyboard: keyboards.tg.quests
    };
  },
  
  // Команда: квесты ежедневные
  questsDaily: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    db.initDailyQuests(user);
    
    let text = `📅 ЕЖЕДНЕВНЫЕ КВЕСТЫ
━━━━━━━━━━━━━━━━━━━━
📆 Сброс: в полночь\n`;
    
    config.dailyQuests.forEach(quest => {
      const progress = user.dailyQuests[quest.id];
      const status = progress.claimed ? '💎' : (progress.completed ? '✅' : '⬜');
      const progressText = `${progress.progress}/${quest.target}`;
      
      text += `\n${status} ${quest.id}. ${quest.name}`;
      text += `\n   📊 ${progressText}`;
      
      if (progress.completed && !progress.claimed) {
        text += ` — ГОТОВО К СДАЧЕ!`;
      }
      
      text += `\n   💰 ${formatMoney(quest.reward.money)}`;
      if (quest.reward.exp) text += ` +${quest.reward.exp} XP`;
      if (quest.reward.diamonds) text += ` +${quest.reward.diamonds}💎`;
      if (quest.reward.cups) text += ` +${quest.reward.cups}🏆`;
    });
    
    text += `\n\n📌 Сдать: квесты сдать [номер]`;
    
    return { text, keyboard: keyboards.tg.quests };
  },
  
  // Команда: квесты недельные
  questsWeekly: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    db.initWeeklyQuests(user);
    
    let text = `📆 НЕДЕЛЬНЫЕ КВЕСТЫ
━━━━━━━━━━━━━━━━━━━━
📆 Сброс: в понедельник\n`;
    
    config.weeklyQuests.forEach(quest => {
      const progress = user.weeklyQuests[quest.id];
      const status = progress.claimed ? '💎' : (progress.completed ? '✅' : '⬜');
      const progressText = `${progress.progress}/${quest.target}`;
      
      text += `\n${status} ${quest.id}. ${quest.name}`;
      text += `\n   📊 ${progressText}`;
      
      if (progress.completed && !progress.claimed) {
        text += ` — ГОТОВО К СДАЧЕ!`;
      }
      
      text += `\n   💰 ${formatMoney(quest.reward.money)}`;
      if (quest.reward.exp) text += ` +${quest.reward.exp} XP`;
      if (quest.reward.diamonds) text += ` +${quest.reward.diamonds}💎`;
    });
    
    text += `\n\n📌 Сдать: квесты сдать н[номер] (н = недельный)`;
    
    return { text, keyboard: keyboards.tg.quests };
  },
  
  // Команда: квесты сдать
  questClaim: async (ctx, questIdStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const isWeekly = questIdStr.startsWith('н') || questIdStr.startsWith('w');
    const questId = parseInt(questIdStr.replace(/[нw]/i, ''));
    
    const result = db.claimQuest(`${ctx.platform}_${ctx.userId}`, questId, !isWeekly);
    
    if (!result) {
      return { text: '❌ Квест не найден или уже сдан!', keyboard: keyboards.tg.quests };
    }
    
    let rewardText = `💰 +${formatMoney(result.reward.money)}`;
    if (result.reward.exp) rewardText += ` ⭐ +${result.reward.exp} XP`;
    if (result.reward.diamonds) rewardText += ` 💎 +${result.reward.diamonds}`;
    if (result.reward.cups) rewardText += ` 🏆 +${result.reward.cups}`;
    
    return {
      text: `✅ КВЕСТ СДАН!
━━━━━━━━━━━━━━━━━━━━
📋 ${result.name}

🎁 Награда:
${rewardText}

💵 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.quests
    };
  },
  
  // ==================== СОБЫТИЯ ====================
  
  // Команда: события
  events: async (ctx) => {
    const activeEvents = db.getActiveEvents();
    
    if (activeEvents.length === 0) {
      return {
        text: `🎉 СОБЫТИЯ
━━━━━━━━━━━━━━━━━━━━
❌ Нет активных событий.

Следите за объявлениями!`,
        keyboard: keyboards.tg.main
      };
    }
    
    let text = `🎉 АКТИВНЫЕ СОБЫТИЯ
━━━━━━━━━━━━━━━━━━━━\n`;
    
    activeEvents.forEach(event => {
      const remaining = Math.floor((event.endTime - Date.now()) / 60000);
      text += `\n${event.name}`;
      text += `\n⏰ Осталось: ${remaining} мин.`;
    });
    
    return { text, keyboard: keyboards.tg.main };
  },
  
  // ==================== ПРОМОКОДЫ ====================
  
  // Команда: промокод
  promoCode: async (ctx, code) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (!code) {
      return {
        text: `🎁 ПРОМОКОДЫ
━━━━━━━━━━━━━━━━━━━━
Введите промокод для активации!

📌 Использование:
промокод [код]`,
        keyboard: keyboards.tg.main
      };
    }
    
    const result = db.usePromoCode(`${ctx.platform}_${ctx.userId}`, code);
    
    if (!result.success) {
      return { text: `❌ ${result.error}`, keyboard: keyboards.tg.main };
    }
    
    let rewardText = '';
    if (result.reward.money) rewardText += `💰 +${formatMoney(result.reward.money)}\n`;
    if (result.reward.exp) rewardText += `⭐ +${result.reward.exp} XP\n`;
    if (result.reward.diamonds) rewardText += `💎 +${result.reward.diamonds} алмазов\n`;
    
    return {
      text: `✅ ПРОМОКОД АКТИВИРОВАН!
━━━━━━━━━━━━━━━━━━━━
📝 Код: ${code.toUpperCase()}

🎁 Награда:
${rewardText}
💵 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.main
    };
  },
  
  // ==================== ДОСТИЖЕНИЯ (УВЕДОМЛЕНИЯ) ====================
  
  // Функция для отправки уведомления о достижении
  notifyAchievement: (user, achievement) => {
    return {
      text: `🏆 НОВОЕ ДОСТИЖЕНИЕ!
━━━━━━━━━━━━━━━━━━━━
${achievement.name}
📝 ${achievement.desc}

🎁 Награда:
💰 +${formatMoney(achievement.reward.money)}
⭐ +${achievement.reward.exp} XP
${achievement.reward.diamonds ? `💎 +${achievement.reward.diamonds} алмазов` : ''}`
    };
  },
  
  // ==================== ДОНАТ ====================
  
  // Команда: донат
  donate: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    let privilegeStatus = '❌ Нет привилегии';
    if (user.privilege && user.privilegeExpires > Date.now()) {
      const daysLeft = Math.ceil((user.privilegeExpires - Date.now()) / 86400000);
      privilegeStatus = `✅ ${user.privilege} (${daysLeft} дн.)`;
    }
    
    return {
      text: `💎 ДОНАТ-МАГАЗИН
━━━━━━━━━━━━━━━━━━━━
💎 Ваши алмазы: ${user.diamonds}
👑 Привилегия: ${privilegeStatus}

🎁 ПРИВИЛЕГИИ:

👑 VIP — 50💎 (30 дней)
├ +20% к доходу
├ +5% шанс в казино
├ x1.5 кубков за гонки
├ -10% кулдауны
└ 2 слота бизнеса

⭐ PREMIUM — 100💎 (30 дней)
├ +50% к доходу
├ +10% шанс в казино
├ x2 кубков за гонки
├ -25% кулдауны
└ 3 слота бизнеса

🌟 LEGEND — 200💎 (30 дней)
├ x2 доход
├ +15% шанс в казино
├ x2.5 кубков за гонки
├ -50% кулдауны
└ 4 слота бизнеса

💎 ULTIMATE — 500💎 (30 дней)
├ x3 доход
├ +20% шанс в казино
├ x3 кубков за гонки
├ -75% кулдауны
└ 5 слотов бизнеса`,
      keyboard: keyboards.tg.donate
    };
  },
  
  // Команда: купить привилегию
  buyPrivilege: async (ctx, privilegeName) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const priv = config.privileges[privilegeName.toLowerCase()];
    if (!priv) {
      return { text: '❌ Привилегия не найдена!', keyboard: keyboards.tg.donate };
    }
    
    if (user.diamonds < priv.price) {
      return { text: `❌ Недостаточно алмазов! Нужно: ${priv.price}💎`, keyboard: keyboards.tg.donate };
    }
    
    user.diamonds -= priv.price;
    user.privilege = priv.name;
    user.privilegeExpires = Date.now() + 30 * 24 * 60 * 60 * 1000; // 30 дней
    db.saveAll();
    
    return {
      text: `✅ ПРИВИЛЕГИЯ КУПЛЕНА!
━━━━━━━━━━━━━━━━━━━━
👑 ${priv.name}
⏰ Действует: 30 дней

🎁 Ваши бонусы активированы!`,
      keyboard: keyboards.tg.main
    };
  }
};
