// ⚡ FLASH BOT — МОДУЛЬ ЭКОНОМИКИ
const db = require('../utils/database');
const { formatMoney, formatNumber, checkCooldown, formatTime } = require('../utils/helpers');
const keyboards = require('../utils/keyboards');
const config = require('../config');

module.exports = {
  // Команда: баланс
  balance: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    // BTC курс (динамический)
    const btcRate = 50000 + Math.floor(Math.random() * 10000);
    const btcValue = user.bitcoin * btcRate;
    
    return {
      text: `💰 БАЛАНС
━━━━━━━━━━━━━━━━━━━━
💵 Наличные: ${formatMoney(user.money)}
🏦 Банк: ${formatMoney(user.bank)}
━━━━━━━━━━━━━━━━━━━━
₿ Биткоин: ${user.bitcoin.toFixed(6)}
   ≈ ${formatMoney(Math.floor(btcValue))}
━━━━━━━━━━━━━━━━━━━━
💎 Алмазы: ${user.diamonds}
🏆 Кубки: ${user.cups}
💴 Рубли: ${formatNumber(user.rubles)}₽

📊 Всего состояние: ${formatMoney(user.money + user.bank + Math.floor(btcValue))}`,
      keyboard: keyboards.tg.balance
    };
  },
  
  // Команда: перевод
  transfer: async (ctx, targetId, amount) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const id = parseInt(String(targetId).replace('#', ''));
    const target = db.getUserById(id);
    
    if (!target) {
      return { text: '❌ Игрок не найден! Укажите ID (например: #5)', keyboard: keyboards.tg.balance };
    }
    
    if (target.uid === user.uid) {
      return { text: '❌ Нельзя перевести себе!', keyboard: keyboards.tg.balance };
    }
    
    amount = parseInt(amount);
    if (isNaN(amount) || amount < 100) {
      return { text: '❌ Минимальный перевод: 100$', keyboard: keyboards.tg.balance };
    }
    
    if (user.money < amount) {
      return { text: `❌ Недостаточно наличных! У вас: ${formatMoney(user.money)}`, keyboard: keyboards.tg.balance };
    }
    
    // Комиссия 3%
    const commission = Math.floor(amount * 0.03);
    const received = amount - commission;
    
    user.money -= amount;
    target.money += received;
    
    // Сохраняем перевод в историю
    if (!user.transfers) user.transfers = [];
    user.transfers.push({
      to: target.id,
      toName: target.name,
      amount,
      commission,
      date: Date.now()
    });
    
    db.saveAll();
    
    // Создаём уведомление для получателя
    if (!target.notifications) target.notifications = [];
    target.notifications.push({
      type: 'transfer',
      from: user.name,
      fromId: user.id,
      amount: received,
      date: Date.now()
    });
    
    return {
      text: `✅ ПЕРЕВОД ВЫПОЛНЕН
━━━━━━━━━━━━━━━━━━━━
👤 Получатель: ${target.name} (#${target.id})
💰 Сумма: ${formatMoney(amount)}
📊 Комиссия (3%): ${formatMoney(commission)}
✅ Получено: ${formatMoney(received)}

💵 Ваш баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.balance,
      // Уведомление получателю
      notify: {
        userId: Object.keys(target.platforms)[0] === 'telegram' ? target.platforms.telegram : target.platforms.vk,
        platform: Object.keys(target.platforms)[0],
        text: `💸 ВХОДЯЩИЙ ПЕРЕВОД
━━━━━━━━━━━━━━━━━━━━
👤 От: ${user.name} (#${user.id})
💰 Сумма: ${formatMoney(received)}

💵 Ваш баланс: ${formatMoney(target.money)}`
      }
    };
  },
  
  // Команда: банк
  bank: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const creditInfo = user.credit ? `\n💳 Кредит: ${formatMoney(user.credit.amount)} (${user.credit.percent}%)` : '';
    
    return {
      text: `🏦 БАНК
━━━━━━━━━━━━━━━━━━━━
💵 Наличные: ${formatMoney(user.money)}
🏦 На счету: ${formatMoney(user.bank)}
📊 Лимит: ${formatMoney(user.bankLimit)}${creditInfo}

📌 Команды:
• банк положить [сумма]
• банк положить все
• банк снять [сумма]
• банк снять все

💡 Лимит можно увеличить за 10,000$`,
      keyboard: keyboards.tg.bank
    };
  },
  
  // Команда: банк положить
  bankDeposit: async (ctx, amountStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    let amount;
    if (amountStr === 'все' || amountStr === 'all') {
      amount = Math.min(user.money, user.bankLimit - user.bank);
    } else {
      amount = parseInt(amountStr);
    }
    
    if (isNaN(amount) || amount <= 0) {
      return { text: '❌ Укажите сумму!', keyboard: keyboards.tg.bank };
    }
    
    if (user.money < amount) {
      return { text: `❌ Недостаточно наличных! У вас: ${formatMoney(user.money)}`, keyboard: keyboards.tg.bank };
    }
    
    if (user.bank + amount > user.bankLimit) {
      const canDeposit = user.bankLimit - user.bank;
      return { text: `❌ Превышен лимит! Можно положить: ${formatMoney(canDeposit)}`, keyboard: keyboards.tg.bank };
    }
    
    user.money -= amount;
    user.bank += amount;
    db.saveAll();
    
    // Проверяем путь новичка
    const pathComplete = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'bank');
    let pathText = '';
    if (pathComplete) {
      pathText = `\n\n🎉 ПУТЬ НОВИЧКА: Этап ${pathComplete.stage} выполнен!\n+${formatMoney(pathComplete.reward.money)} +${pathComplete.reward.exp} XP`;
    }
    
    return {
      text: `✅ ДЕПОЗИТ
━━━━━━━━━━━━━━━━━━━━
💰 Положено: ${formatMoney(amount)}

💵 Наличные: ${formatMoney(user.money)}
🏦 В банке: ${formatMoney(user.bank)}${pathText}`,
      keyboard: keyboards.tg.bank
    };
  },
  
  // Команда: банк снять
  bankWithdraw: async (ctx, amountStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    let amount;
    if (amountStr === 'все' || amountStr === 'all') {
      amount = user.bank;
    } else {
      amount = parseInt(amountStr);
    }
    
    if (isNaN(amount) || amount <= 0) {
      return { text: '❌ Укажите сумму!', keyboard: keyboards.tg.bank };
    }
    
    if (user.bank < amount) {
      return { text: `❌ Недостаточно в банке! У вас: ${formatMoney(user.bank)}`, keyboard: keyboards.tg.bank };
    }
    
    user.bank -= amount;
    user.money += amount;
    db.saveAll();
    
    return {
      text: `✅ СНЯТИЕ
━━━━━━━━━━━━━━━━━━━━
💰 Снято: ${formatMoney(amount)}

💵 Наличные: ${formatMoney(user.money)}
🏦 В банке: ${formatMoney(user.bank)}`,
      keyboard: keyboards.tg.bank
    };
  },
  
  // Команда: банк лимит увеличить
  bankUpgradeLimit: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const cost = 10000;
    const increase = 50000;
    
    if (user.money < cost) {
      return { text: `❌ Недостаточно денег! Нужно: ${formatMoney(cost)}`, keyboard: keyboards.tg.bank };
    }
    
    user.money -= cost;
    user.bankLimit += increase;
    db.saveAll();
    
    return {
      text: `✅ ЛИМИТ УВЕЛИЧЕН
━━━━━━━━━━━━━━━━━━━━
💰 Списано: ${formatMoney(cost)}
📈 Новый лимит: ${formatMoney(user.bankLimit)}`,
      keyboard: keyboards.tg.bank
    };
  },
  
  // Команда: банк кредит взять
  bankCredit: async (ctx, amountStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (user.credit) {
      return { text: `❌ У вас уже есть кредит: ${formatMoney(user.credit.amount)}`, keyboard: keyboards.tg.bank };
    }
    
    const amount = parseInt(amountStr);
    const maxCredit = 100000;
    
    if (isNaN(amount) || amount < 1000 || amount > maxCredit) {
      return { text: `❌ Сумма кредита: 1,000$ - ${formatMoney(maxCredit)}`, keyboard: keyboards.tg.bank };
    }
    
    user.credit = {
      amount: Math.floor(amount * 1.1), // 10% процент
      original: amount,
      percent: 10,
      date: Date.now()
    };
    user.money += amount;
    db.saveAll();
    
    return {
      text: `✅ КРЕДИТ ОДОБРЕН
━━━━━━━━━━━━━━━━━━━━
💰 Получено: ${formatMoney(amount)}
📊 Процент: 10%
💳 К возврату: ${formatMoney(user.credit.amount)}

⚠️ Верните кредит командой: банк кредит вернуть`,
      keyboard: keyboards.tg.bank
    };
  },
  
  // Команда: банк кредит вернуть
  bankCreditReturn: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (!user.credit) {
      return { text: '❌ У вас нет активного кредита!', keyboard: keyboards.tg.bank };
    }
    
    if (user.money < user.credit.amount) {
      return { text: `❌ Недостаточно денег! Нужно: ${formatMoney(user.credit.amount)}`, keyboard: keyboards.tg.bank };
    }
    
    user.money -= user.credit.amount;
    const returned = user.credit.amount;
    user.credit = null;
    db.saveAll();
    
    return {
      text: `✅ КРЕДИТ ПОГАШЕН
━━━━━━━━━━━━━━━━━━━━
💰 Выплачено: ${formatMoney(returned)}
💵 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.bank
    };
  },
  
  // Команда: курс
  exchangeRate: async (ctx) => {
    // Динамический курс
    const btcRate = 50000 + Math.floor(Math.random() * 10000);
    const rubRate = 90 + Math.floor(Math.random() * 10);
    
    return {
      text: `💱 КУРС ВАЛЮТ
━━━━━━━━━━━━━━━━━━━━
₿ 1 BTC = ${formatMoney(btcRate)}
💴 1$ = ${rubRate}₽

📌 Команды обмена:
• обмен доллары [сумма] — в рубли
• обмен рубли [сумма] — в доллары
• обмен биткоин продать [сумма]`,
      keyboard: keyboards.tg.balance
    };
  },
  
  // Команда: обмен
  exchange: async (ctx, currency, amountStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const btcRate = 50000 + Math.floor(Math.random() * 10000);
    const rubRate = 90 + Math.floor(Math.random() * 10);
    const amount = parseFloat(amountStr);
    
    if (isNaN(amount) || amount <= 0) {
      return { text: '❌ Укажите сумму!', keyboard: keyboards.tg.balance };
    }
    
    switch (currency) {
      case 'доллары':
      case 'dollars':
        if (user.money < amount) {
          return { text: `❌ Недостаточно долларов! У вас: ${formatMoney(user.money)}`, keyboard: keyboards.tg.balance };
        }
        const rubles = Math.floor(amount * rubRate);
        user.money -= amount;
        user.rubles += rubles;
        db.saveAll();
        return {
          text: `✅ ОБМЕН ВЫПОЛНЕН
━━━━━━━━━━━━━━━━━━━━
💵 Продано: ${formatMoney(amount)}
💴 Получено: ${formatNumber(rubles)}₽

📊 Курс: 1$ = ${rubRate}₽`,
          keyboard: keyboards.tg.balance
        };
        
      case 'рубли':
      case 'rubles':
        if (user.rubles < amount) {
          return { text: `❌ Недостаточно рублей! У вас: ${formatNumber(user.rubles)}₽`, keyboard: keyboards.tg.balance };
        }
        const dollars = Math.floor(amount / rubRate);
        user.rubles -= amount;
        user.money += dollars;
        db.saveAll();
        return {
          text: `✅ ОБМЕН ВЫПОЛНЕН
━━━━━━━━━━━━━━━━━━━━
💴 Продано: ${formatNumber(amount)}₽
💵 Получено: ${formatMoney(dollars)}

📊 Курс: 1$ = ${rubRate}₽`,
          keyboard: keyboards.tg.balance
        };
        
      case 'биткоин':
      case 'bitcoin':
        if (user.bitcoin < amount) {
          return { text: `❌ Недостаточно биткоина! У вас: ₿${user.bitcoin.toFixed(6)}`, keyboard: keyboards.tg.balance };
        }
        const btcDollars = Math.floor(amount * btcRate);
        user.bitcoin -= amount;
        user.money += btcDollars;
        db.saveAll();
        return {
          text: `✅ ОБМЕН ВЫПОЛНЕН
━━━━━━━━━━━━━━━━━━━━
₿ Продано: ${amount.toFixed(6)} BTC
💵 Получено: ${formatMoney(btcDollars)}

📊 Курс: 1 BTC = ${formatMoney(btcRate)}`,
          keyboard: keyboards.tg.balance
        };
        
      default:
        return { text: '❌ Укажите валюту: доллары, рубли или биткоин', keyboard: keyboards.tg.balance };
    }
  }
};
