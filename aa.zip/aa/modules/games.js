// ⚡ FLASH BOT — МОДУЛЬ ИГР (КАЗИНО, ГОНКИ, МАЙНИНГ, РЫБАЛКА)
const db = require('../utils/database');
const { formatMoney, formatNumber, checkCooldown, formatTime, random, randomElement, levelFromExp } = require('../utils/helpers');
const keyboards = require('../utils/keyboards');
const config = require('../config');

module.exports = {
  // ==================== КАЗИНО ====================
  
  // Команда: казино
  casino: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    return {
      text: `🎰 КАЗИНО
━━━━━━━━━━━━━━━━━━━━
💰 Баланс: ${formatMoney(user.money)}

🎮 ИГРЫ:
• казино [ставка] — слоты
• казино рулетка [ставка] [цвет]
• казино кости [ставка] [число]
• казино карты [ставка]

📊 Статистика:
├ Ставок: ${user.stats.casinoBets}
└ Побед: ${user.stats.casinoWins}

💡 Минимальная ставка: 100$`,
      keyboard: keyboards.tg.casino
    };
  },
  
  // Команда: казино [ставка] — слоты
  casinoSlots: async (ctx, betStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    let bet;
    if (betStr === 'все' || betStr === 'all') {
      bet = user.money;
    } else {
      bet = parseInt(betStr);
    }
    
    if (isNaN(bet) || bet < 100) {
      return { text: '❌ Минимальная ставка: 100$', keyboard: keyboards.tg.casino };
    }
    
    if (user.money < bet) {
      return { text: `❌ Недостаточно денег! У вас: ${formatMoney(user.money)}`, keyboard: keyboards.tg.casino };
    }
    
    const symbols = ['🍒', '🍋', '🍊', '🍇', '⭐', '💎', '7️⃣'];
    const weights = [25, 20, 18, 15, 12, 7, 3]; // Вероятности
    
    const spinSymbol = () => {
      const total = weights.reduce((a, b) => a + b, 0);
      let rand = random(1, total);
      for (let i = 0; i < weights.length; i++) {
        rand -= weights[i];
        if (rand <= 0) return symbols[i];
      }
      return symbols[0];
    };
    
    const s1 = spinSymbol();
    const s2 = spinSymbol();
    const s3 = spinSymbol();
    
    user.money -= bet;
    user.stats.casinoBets++;
    
    // Бонус привилегии
    let chanceBonus = 0;
    if (user.privilege) {
      const priv = config.privileges[user.privilege.toLowerCase()];
      if (priv) chanceBonus = priv.bonuses.casinoChanceBonus;
    }
    
    let multiplier = 0;
    let result = '❌ Проигрыш';
    
    if (s1 === s2 && s2 === s3) {
      // Три одинаковых
      const idx = symbols.indexOf(s1);
      multiplier = [2, 3, 4, 5, 8, 15, 50][idx];
      result = '🎉 ДЖЕКПОТ!';
      user.stats.casinoWins++;
    } else if (s1 === s2 || s2 === s3 || s1 === s3) {
      // Два одинаковых
      multiplier = 1.5;
      result = '✅ Выигрыш!';
      user.stats.casinoWins++;
    }
    
    // Применяем бонус
    if (multiplier > 0 && chanceBonus > 0) {
      multiplier *= (1 + chanceBonus / 100);
    }
    
    const winnings = Math.floor(bet * multiplier);
    user.money += winnings;
    user.stats.totalEarned += winnings;
    
    // Квесты
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'casino_bets', 1);
    
    db.saveAll();
    
    const profit = winnings - bet;
    const profitText = profit > 0 ? `+${formatMoney(profit)}` : formatMoney(profit);
    
    return {
      text: `🎰 СЛОТЫ
━━━━━━━━━━━━━━━━━━━━
┃ ${s1} ┃ ${s2} ┃ ${s3} ┃
━━━━━━━━━━━━━━━━━━━━
${result}

💰 Ставка: ${formatMoney(bet)}
📊 Множитель: x${multiplier.toFixed(1)}
💵 Выигрыш: ${formatMoney(winnings)}
📈 Профит: ${profitText}

💰 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.casino
    };
  },
  
  // Команда: казино рулетка
  casinoRoulette: async (ctx, betStr, color) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const bet = parseInt(betStr);
    if (isNaN(bet) || bet < 100) {
      return { text: '❌ Минимальная ставка: 100$', keyboard: keyboards.tg.casino };
    }
    
    if (user.money < bet) {
      return { text: `❌ Недостаточно денег! У вас: ${formatMoney(user.money)}`, keyboard: keyboards.tg.casino };
    }
    
    const validColors = ['красное', 'red', 'чёрное', 'черное', 'black', 'зелёное', 'зеленое', 'green'];
    if (!color || !validColors.includes(color.toLowerCase())) {
      return { text: '❌ Укажите цвет: красное, чёрное или зелёное', keyboard: keyboards.tg.casino };
    }
    
    user.money -= bet;
    user.stats.casinoBets++;
    
    const number = random(0, 36);
    const isGreen = number === 0;
    const isRed = !isGreen && number % 2 === 1;
    const isBlack = !isGreen && number % 2 === 0;
    
    const resultColor = isGreen ? '🟢 Зелёное' : (isRed ? '🔴 Красное' : '⚫ Чёрное');
    
    let win = false;
    let multiplier = 0;
    
    const userColor = color.toLowerCase();
    if ((userColor === 'красное' || userColor === 'red') && isRed) {
      win = true;
      multiplier = 2;
    } else if ((userColor === 'чёрное' || userColor === 'черное' || userColor === 'black') && isBlack) {
      win = true;
      multiplier = 2;
    } else if ((userColor === 'зелёное' || userColor === 'зеленое' || userColor === 'green') && isGreen) {
      win = true;
      multiplier = 14;
    }
    
    if (win) user.stats.casinoWins++;
    
    const winnings = Math.floor(bet * multiplier);
    user.money += winnings;
    
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'casino_bets', 1);
    db.saveAll();
    
    return {
      text: `🎯 РУЛЕТКА
━━━━━━━━━━━━━━━━━━━━
🔢 Число: ${number}
🎨 Цвет: ${resultColor}

${win ? '🎉 ВЫ ВЫИГРАЛИ!' : '❌ Проигрыш'}

💰 Ставка: ${formatMoney(bet)}
💵 Выигрыш: ${formatMoney(winnings)}

💰 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.casino
    };
  },
  
  // Команда: казино кости
  casinoDice: async (ctx, betStr, guessStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const bet = parseInt(betStr);
    const guess = parseInt(guessStr);
    
    if (isNaN(bet) || bet < 100) {
      return { text: '❌ Минимальная ставка: 100$', keyboard: keyboards.tg.casino };
    }
    
    if (isNaN(guess) || guess < 1 || guess > 6) {
      return { text: '❌ Угадайте число от 1 до 6', keyboard: keyboards.tg.casino };
    }
    
    if (user.money < bet) {
      return { text: `❌ Недостаточно денег! У вас: ${formatMoney(user.money)}`, keyboard: keyboards.tg.casino };
    }
    
    user.money -= bet;
    user.stats.casinoBets++;
    
    const dice = random(1, 6);
    const diceEmoji = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'][dice - 1];
    
    const win = dice === guess;
    const multiplier = win ? 5 : 0;
    
    if (win) user.stats.casinoWins++;
    
    const winnings = Math.floor(bet * multiplier);
    user.money += winnings;
    
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'casino_bets', 1);
    db.saveAll();
    
    return {
      text: `🎲 КОСТИ
━━━━━━━━━━━━━━━━━━━━
${diceEmoji} Выпало: ${dice}
🎯 Ваша ставка: ${guess}

${win ? '🎉 ВЫ УГАДАЛИ!' : '❌ Мимо!'}

💰 Ставка: ${formatMoney(bet)}
💵 Выигрыш: ${formatMoney(winnings)}

💰 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.casino
    };
  },
  
  // ==================== ГОНКИ ====================
  
  // Команда: гонка
  race: async (ctx, track = null) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (!user.currentCar) {
      return {
        text: `🏁 ГОНКИ
━━━━━━━━━━━━━━━━━━━━
❌ У вас нет машины!

Купите машину: машина купить [номер]
Или посмотрите список: машина список`,
        keyboard: keyboards.tg.race
      };
    }
    
    if (!track) {
      return {
        text: `🏁 ГОНКИ
━━━━━━━━━━━━━━━━━━━━
🚗 Машина: ${config.cars.find(c => c.id === user.currentCar)?.name}
🔧 Тюнинг: ${user.tuning}/20
🏆 Кубки: ${user.cups}

📍 Выберите трассу:`,
        keyboard: keyboards.tg.race
      };
    }
    
    // Кулдаун
    let cooldownTime = config.game.cooldowns.race;
    if (user.privilege) {
      const priv = config.privileges[user.privilege.toLowerCase()];
      if (priv) cooldownTime *= priv.bonuses.cooldownReduction;
    }
    
    const cooldown = checkCooldown(user.cooldowns.race, cooldownTime);
    if (!cooldown.ready) {
      return { text: `⏰ Время ожидания: ${formatTime(cooldown.remaining)}`, keyboard: keyboards.tg.race };
    }
    
    // Энергия
    if (user.energy < config.game.energyCosts.race) {
      return { text: `❌ Недостаточно энергии! Нужно: ${config.game.energyCosts.race}⚡`, keyboard: keyboards.tg.race };
    }
    
    const car = config.cars.find(c => c.id === user.currentCar);
    const speed = car.speed * (1 + user.tuning * 0.05); // +5% за уровень тюнинга
    
    // Генерируем соперника
    const opponentCar = randomElement(config.cars);
    const opponentSpeed = opponentCar.speed * (0.8 + Math.random() * 0.4);
    
    user.energy -= config.game.energyCosts.race;
    user.cooldowns.race = Date.now();
    
    const tracks = ['🏁 Город', '🏔️ Горы', '🏖️ Пляж', '🌲 Лес'];
    const trackName = tracks[random(0, 3)];
    
    const win = speed > opponentSpeed;
    let cups = win ? random(1, 3) : 0;
    let prize = win ? random(5000, 15000) : 0;
    const exp = win ? random(20, 50) : 10;
    
    // Бонус привилегии
    if (win && user.privilege) {
      const priv = config.privileges[user.privilege.toLowerCase()];
      if (priv) {
        cups = Math.floor(cups * priv.bonuses.raceCupsMultiplier);
        prize = Math.floor(prize * priv.bonuses.incomeMultiplier);
      }
    }
    
    if (win) {
      user.money += prize;
      user.cups += cups;
      user.stats.raceWins++;
      user.stats.totalEarned += prize;
      db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'race_wins', 1);
    }
    
    db.addExp(user, exp);
    db.saveAll();
    
    // Путь новичка (если есть машина, значит этап выполнен)
    
    // Достижения
    const achievements = db.checkAchievements(`${ctx.platform}_${ctx.userId}`);
    let achText = '';
    if (achievements.length > 0) {
      achText = '\n\n🏆 ДОСТИЖЕНИЕ: ' + achievements.map(a => a.name).join(', ');
    }
    
    return {
      text: `🏁 ГОНКА — ${trackName}
━━━━━━━━━━━━━━━━━━━━
🚗 Вы: ${car.name}
   ⚡ Скорость: ${Math.floor(speed)} км/ч

🚙 Соперник: ${opponentCar.name}
   ⚡ Скорость: ${Math.floor(opponentSpeed)} км/ч

━━━━━━━━━━━━━━━━━━━━
${win ? '🎉 ПОБЕДА!' : '❌ Поражение'}

💰 Приз: ${formatMoney(prize)}
🏆 Кубки: +${cups}
⭐ Опыт: +${exp}

🏆 Всего кубков: ${user.cups}${achText}`,
      keyboard: keyboards.tg.race
    };
  },
  
  // ==================== МАШИНЫ ====================
  
  // Команда: машина
  car: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (user.cars.length === 0) {
      return {
        text: `🚗 МАШИНЫ
━━━━━━━━━━━━━━━━━━━━
❌ У вас нет машин!

📋 Посмотреть: машина список
🛒 Купить: машина купить [номер]`,
        keyboard: {
          inline_keyboard: [
            [{ text: '📋 СПИСОК', callback_data: 'car_list' }, { text: '🛒 КУПИТЬ', callback_data: 'shop_cars' }],
            [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
          ]
        }
      };
    }
    
    let text = `🚗 ВАШИ МАШИНЫ (${user.cars.length})
━━━━━━━━━━━━━━━━━━━━\n`;
    
    user.cars.forEach((carId, i) => {
      const car = config.cars.find(c => c.id === carId);
      const current = user.currentCar === carId ? '✅' : '';
      text += `\n${i + 1}. ${car.name} ${current}`;
      text += `\n   ⚡ Скорость: ${car.speed} км/ч`;
    });
    
    text += `\n\n🔧 Тюнинг: ${user.tuning}/20 (+${user.tuning * 5}% скорости)`;
    text += `\n\n📌 Команды:
• машина выбрать [номер]
• тюнинг купить`;
    
    return { text, keyboard: keyboards.tg.race };
  },
  
  // Команда: машина список
  carList: async (ctx) => {
    let text = `🚗 СПИСОК МАШИН
━━━━━━━━━━━━━━━━━━━━\n`;
    
    config.cars.forEach(car => {
      text += `\n${car.id}. ${car.name}`;
      text += `\n   💰 ${formatMoney(car.price)} | ⚡ ${car.speed} км/ч`;
    });
    
    text += `\n\n📌 Купить: машина купить [номер]`;
    
    return { text, keyboard: keyboards.tg.race };
  },
  
  // Команда: машина купить
  carBuy: async (ctx, carId) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const car = config.cars.find(c => c.id === parseInt(carId));
    if (!car) {
      return { text: '❌ Машина не найдена!', keyboard: keyboards.tg.race };
    }
    
    if (user.cars.includes(car.id)) {
      return { text: '❌ У вас уже есть эта машина!', keyboard: keyboards.tg.race };
    }
    
    if (user.money < car.price) {
      return { text: `❌ Недостаточно денег! Нужно: ${formatMoney(car.price)}`, keyboard: keyboards.tg.race };
    }
    
    user.money -= car.price;
    user.cars.push(car.id);
    if (!user.currentCar) user.currentCar = car.id;
    
    db.saveAll();
    
    // Путь новичка
    const pathComplete = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'car');
    let pathText = '';
    if (pathComplete) {
      pathText = `\n\n🎉 ПУТЬ НОВИЧКА: Этап ${pathComplete.stage} выполнен!\n+${formatMoney(pathComplete.reward.money)} +${pathComplete.reward.exp} XP`;
    }
    
    return {
      text: `✅ МАШИНА КУПЛЕНА!
━━━━━━━━━━━━━━━━━━━━
🚗 ${car.name}
⚡ Скорость: ${car.speed} км/ч
💰 Цена: ${formatMoney(car.price)}

Теперь вы можете участвовать в гонках!${pathText}`,
      keyboard: keyboards.tg.race
    };
  },
  
  // Команда: машина выбрать
  carSelect: async (ctx, index) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const idx = parseInt(index) - 1;
    if (idx < 0 || idx >= user.cars.length) {
      return { text: '❌ Машина не найдена!', keyboard: keyboards.tg.race };
    }
    
    user.currentCar = user.cars[idx];
    db.saveAll();
    
    const car = config.cars.find(c => c.id === user.currentCar);
    
    return {
      text: `✅ МАШИНА ВЫБРАНА!
━━━━━━━━━━━━━━━━━━━━
🚗 ${car.name}
⚡ Скорость: ${car.speed} км/ч`,
      keyboard: keyboards.tg.race
    };
  },
  
  // Команда: тюнинг
  tuning: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const cost = 100000 * (1 + user.tuning * 0.1);
    
    return {
      text: `🔧 ТЮНИНГ
━━━━━━━━━━━━━━━━━━━━
📊 Уровень: ${user.tuning}/20
⚡ Бонус скорости: +${user.tuning * 5}%

💰 Следующий уровень: ${formatMoney(cost)}

📌 Улучшить: тюнинг купить`,
      keyboard: {
        inline_keyboard: [
          [{ text: `📈 КУПИТЬ (${formatMoney(cost)})`, callback_data: 'tuning_buy' }],
          [{ text: '🔙 НАЗАД', callback_data: 'race' }]
        ]
      }
    };
  },
  
  // Команда: тюнинг купить
  tuningBuy: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (user.tuning >= 20) {
      return { text: '❌ Максимальный уровень тюнинга!', keyboard: keyboards.tg.race };
    }
    
    const cost = Math.floor(100000 * (1 + user.tuning * 0.1));
    
    if (user.money < cost) {
      return { text: `❌ Недостаточно денег! Нужно: ${formatMoney(cost)}`, keyboard: keyboards.tg.race };
    }
    
    user.money -= cost;
    user.tuning++;
    db.saveAll();
    
    return {
      text: `✅ ТЮНИНГ УЛУЧШЕН!
━━━━━━━━━━━━━━━━━━━━
📊 Уровень: ${user.tuning}/20
⚡ Бонус скорости: +${user.tuning * 5}%
💰 Потрачено: ${formatMoney(cost)}

💵 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.race
    };
  },
  
  // ==================== МАЙНИНГ ====================
  
  // Команда: копать
  mine: async (ctx, oreType = null) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const cooldown = checkCooldown(user.cooldowns.mining, config.game.cooldowns.mining);
    if (!cooldown.ready) {
      return { text: `⏰ Время ожидания: ${formatTime(cooldown.remaining)}`, keyboard: keyboards.tg.mining };
    }
    
    const level = levelFromExp(user.exp).level;
    const availableOres = config.ores.filter(o => level >= o.minLevel);
    
    if (availableOres.length === 0) {
      return { text: '❌ Нет доступных руд для вашего уровня!', keyboard: keyboards.tg.mining };
    }
    
    // Если указан тип руды, проверяем доступность
    let selectedOre;
    if (oreType) {
      selectedOre = availableOres.find(o => o.name.toLowerCase().includes(oreType.toLowerCase()));
      if (!selectedOre) {
        return { text: '❌ Эта руда недоступна для вашего уровня!', keyboard: keyboards.tg.mining };
      }
    } else {
      // Случайная руда с учётом уровня кирки
      const weights = availableOres.map((o, i) => Math.max(1, 10 - i + user.pickaxeLevel));
      const total = weights.reduce((a, b) => a + b, 0);
      let rand = random(1, total);
      for (let i = 0; i < weights.length; i++) {
        rand -= weights[i];
        if (rand <= 0) {
          selectedOre = availableOres[i];
          break;
        }
      }
    }
    
    // Количество руды
    const amount = random(1, 3) * user.pickaxeLevel;
    
    if (!user.ores) user.ores = {};
    if (!user.ores[selectedOre.id]) user.ores[selectedOre.id] = 0;
    user.ores[selectedOre.id] += amount;
    
    user.cooldowns.mining = Date.now();
    user.stats.oreMined += amount;
    
    const exp = amount * 5;
    db.addExp(user, exp);
    
    // Квесты
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'ore_mined', amount);
    
    db.saveAll();
    
    // Достижения
    const achievements = db.checkAchievements(`${ctx.platform}_${ctx.userId}`);
    let achText = '';
    if (achievements.length > 0) {
      achText = '\n\n🏆 ДОСТИЖЕНИЕ: ' + achievements.map(a => a.name).join(', ');
    }
    
    return {
      text: `⛏️ ДОБЫЧА
━━━━━━━━━━━━━━━━━━━━
${selectedOre.name} x${amount}
⭐ Опыт: +${exp}

📦 В инвентаре: ${user.ores[selectedOre.id]} шт.
💰 Цена: ${formatMoney(selectedOre.price)}/шт.

📌 Продать: руда продать${achText}`,
      keyboard: keyboards.tg.mining
    };
  },
  
  // Команда: руда продать
  sellOre: async (ctx, oreId = 'все') => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (!user.ores || Object.keys(user.ores).length === 0) {
      return { text: '❌ У вас нет руды!', keyboard: keyboards.tg.mining };
    }
    
    let totalEarned = 0;
    let soldText = '';
    
    if (oreId === 'все' || oreId === 'all') {
      Object.entries(user.ores).forEach(([id, amount]) => {
        if (amount > 0) {
          const ore = config.ores.find(o => o.id === parseInt(id));
          const earned = ore.price * amount;
          totalEarned += earned;
          soldText += `\n${ore.name}: ${amount} шт. = ${formatMoney(earned)}`;
          user.ores[id] = 0;
        }
      });
    } else {
      const ore = config.ores.find(o => o.id === parseInt(oreId));
      if (!ore || !user.ores[ore.id] || user.ores[ore.id] === 0) {
        return { text: '❌ У вас нет этой руды!', keyboard: keyboards.tg.mining };
      }
      totalEarned = ore.price * user.ores[ore.id];
      soldText = `\n${ore.name}: ${user.ores[ore.id]} шт.`;
      user.ores[ore.id] = 0;
    }
    
    user.money += totalEarned;
    user.stats.totalEarned += totalEarned;
    db.saveAll();
    
    return {
      text: `💰 РУДА ПРОДАНА!
━━━━━━━━━━━━━━━━━━━━${soldText}
━━━━━━━━━━━━━━━━━━━━
✅ Получено: ${formatMoney(totalEarned)}

💵 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.mining
    };
  },
  
  // Команда: кирка
  pickaxe: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const cost = 10000 * user.pickaxeLevel;
    
    return {
      text: `⛏️ КИРКА
━━━━━━━━━━━━━━━━━━━━
📊 Уровень: ${user.pickaxeLevel}/20
⚡ Бонус добычи: x${user.pickaxeLevel}

💰 Улучшение: ${formatMoney(cost)}

📌 Улучшить: кирка улучшить`,
      keyboard: keyboards.tg.mining
    };
  },
  
  // Команда: кирка улучшить
  pickaxeUpgrade: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (user.pickaxeLevel >= 20) {
      return { text: '❌ Максимальный уровень кирки!', keyboard: keyboards.tg.mining };
    }
    
    const cost = 10000 * user.pickaxeLevel;
    
    if (user.money < cost) {
      return { text: `❌ Недостаточно денег! Нужно: ${formatMoney(cost)}`, keyboard: keyboards.tg.mining };
    }
    
    user.money -= cost;
    user.pickaxeLevel++;
    db.saveAll();
    
    return {
      text: `✅ КИРКА УЛУЧШЕНА!
━━━━━━━━━━━━━━━━━━━━
📊 Уровень: ${user.pickaxeLevel}/20
⚡ Бонус добычи: x${user.pickaxeLevel}

💵 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.mining
    };
  },
  
  // ==================== РЫБАЛКА ====================
  
  // Команда: рыбалка
  fishing: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const cooldown = checkCooldown(user.cooldowns.fishing, config.game.cooldowns.fishing);
    if (!cooldown.ready) {
      return { text: `⏰ Время ожидания: ${formatTime(cooldown.remaining)}`, keyboard: keyboards.tg.fishing };
    }
    
    const fishes = [
      { name: '🐟 Карась', price: 50, chance: 30 },
      { name: '🐠 Окунь', price: 100, chance: 25 },
      { name: '🐡 Щука', price: 200, chance: 20 },
      { name: '🦈 Сом', price: 350, chance: 15 },
      { name: '🐋 Осётр', price: 500, chance: 8 },
      { name: '🐙 Золотая рыбка', price: 1000, chance: 2 }
    ];
    
    // Бонус удочки
    const bonusChance = user.rodLevel * 2;
    
    // Выбираем рыбу
    let roll = random(1, 100);
    let caught = fishes[0];
    
    for (const fish of fishes) {
      if (roll <= fish.chance + bonusChance) {
        caught = fish;
        break;
      }
      roll -= fish.chance;
    }
    
    const amount = random(1, user.rodLevel);
    
    if (!user.fish) user.fish = {};
    if (!user.fish[caught.name]) user.fish[caught.name] = 0;
    user.fish[caught.name] += amount;
    
    user.cooldowns.fishing = Date.now();
    user.stats.fishCaught += amount;
    
    const exp = amount * 10;
    db.addExp(user, exp);
    
    // Квесты
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'fish', amount);
    
    db.saveAll();
    
    return {
      text: `🎣 РЫБАЛКА
━━━━━━━━━━━━━━━━━━━━
${caught.name} x${amount}
💰 Цена: ${formatMoney(caught.price)}/шт.
⭐ Опыт: +${exp}

📦 Всего этой рыбы: ${user.fish[caught.name]} шт.

📌 Продать: рыба продать`,
      keyboard: keyboards.tg.fishing
    };
  },
  
  // Команда: рыба продать
  sellFish: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (!user.fish || Object.keys(user.fish).length === 0) {
      return { text: '❌ У вас нет рыбы!', keyboard: keyboards.tg.fishing };
    }
    
    const fishes = {
      '🐟 Карась': 50,
      '🐠 Окунь': 100,
      '🐡 Щука': 200,
      '🦈 Сом': 350,
      '🐋 Осётр': 500,
      '🐙 Золотая рыбка': 1000
    };
    
    let totalEarned = 0;
    let soldText = '';
    
    Object.entries(user.fish).forEach(([name, amount]) => {
      if (amount > 0) {
        const price = fishes[name] || 50;
        const earned = price * amount;
        totalEarned += earned;
        soldText += `\n${name}: ${amount} шт. = ${formatMoney(earned)}`;
      }
    });
    
    user.fish = {};
    user.money += totalEarned;
    user.stats.totalEarned += totalEarned;
    db.saveAll();
    
    return {
      text: `💰 РЫБА ПРОДАНА!
━━━━━━━━━━━━━━━━━━━━${soldText}
━━━━━━━━━━━━━━━━━━━━
✅ Получено: ${formatMoney(totalEarned)}

💵 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.fishing
    };
  }
};
