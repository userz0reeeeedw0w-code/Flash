// ⚡ FLASH BOT — МОДУЛЬ ПРОФИЛЯ
const db = require('../utils/database');
const { formatMoney, formatNumber, levelFromExp, progressBar } = require('../utils/helpers');
const keyboards = require('../utils/keyboards');
const config = require('../config');

module.exports = {
  // Команда: профиль
  profile: async (ctx, targetId = null) => {
    let user;
    let isSelf = true;
    
    if (targetId) {
      // Ищем по ID игрока
      const id = parseInt(targetId.replace('#', ''));
      user = db.getUserById(id);
      isSelf = false;
    } else {
      user = db.getUserByPlatform(ctx.platform, ctx.userId);
    }
    
    if (!user) {
      return { text: '❌ Игрок не найден!', keyboard: keyboards.tg.main };
    }
    
    const levelInfo = levelFromExp(user.exp);
    const expProgress = progressBar(levelInfo.currentExp, levelInfo.nextExp, 10);
    
    // Привилегия
    let privilegeText = '❌ Нет';
    if (user.privilege && user.privilegeExpires > Date.now()) {
      const daysLeft = Math.ceil((user.privilegeExpires - Date.now()) / 86400000);
      privilegeText = `${user.privilege} (${daysLeft} дн.)`;
    }
    
    // Работа
    const jobText = user.job 
      ? config.jobs.find(j => j.id === user.job)?.name || 'Неизвестно'
      : '❌ Безработный';
    
    // Машина
    const carText = user.currentCar
      ? config.cars.find(c => c.id === user.currentCar)?.name || 'Неизвестно'
      : '❌ Нет';
    
    // Клан
    const clanText = user.clanId
      ? db.clans[user.clanId]?.name || 'Неизвестно'
      : '❌ Нет';
    
    return {
      text: `👤 ПРОФИЛЬ${isSelf ? '' : ` — ${user.name}`}
━━━━━━━━━━━━━━━━━━━━
🆔 ID: #${user.id}
📝 Ник: ${user.name}
👑 Привилегия: ${privilegeText}

📊 УРОВЕНЬ: ${levelInfo.level}
${expProgress} ${levelInfo.currentExp}/${levelInfo.nextExp}

💰 ФИНАНСЫ:
├ Наличные: ${formatMoney(user.money)}
├ Банк: ${formatMoney(user.bank)}
├ Биткоин: ₿${user.bitcoin.toFixed(6)}
├ Рубли: ${formatNumber(user.rubles)}₽
├ Алмазы: ${user.diamonds}💎
└ Кубки: ${user.cups}🏆

📋 ИНФОРМАЦИЯ:
├ Работа: ${jobText}
├ Машина: ${carText}
├ Тюнинг: ${user.tuning}/20
├ Клан: ${clanText}
├ Бизнесов: ${user.businesses.length}
└ Дом: ${user.house > 0 ? `Уровень ${user.house}` : '❌ Нет'}

⚡ Энергия: ${user.energy}/${config.game.maxEnergy}

📅 В игре с: ${new Date(user.registered).toLocaleDateString()}`,
      keyboard: isSelf ? keyboards.tg.profile : {
        inline_keyboard: [
          [{ text: '💸 ПЕРЕВЕСТИ', callback_data: `transfer_${user.id}` }],
          [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
        ]
      }
    };
  },
  
  // Команда: статистика
  stats: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    return {
      text: `📊 СТАТИСТИКА
━━━━━━━━━━━━━━━━━━━━
💰 Всего заработано: ${formatMoney(user.stats.totalEarned)}

🏁 ГОНКИ:
├ Побед: ${user.stats.raceWins}
└ Кубков: ${user.cups}🏆

⚔️ БОССЫ:
├ Атак: ${user.stats.bossAttacks}
├ Убийств: ${user.stats.bossKills}
└ Урона: ${formatNumber(user.stats.bossDamage)}

💼 РАБОТА:
└ Смен: ${user.stats.workShifts}

🏢 БИЗНЕС:
└ Сборов: ${user.stats.businessCollects}

🎰 КАЗИНО:
├ Ставок: ${user.stats.casinoBets}
└ Побед: ${user.stats.casinoWins}

⛏️ ДОБЫЧА:
├ Руды: ${formatNumber(user.stats.oreMined)}
└ Рыбы: ${user.stats.fishCaught}

🔫 КРИМИНАЛ:
└ Ограблений: ${user.stats.robberies}`,
      keyboard: keyboards.tg.profile
    };
  },
  
  // Команда: уровень
  level: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const levelInfo = levelFromExp(user.exp);
    const expProgress = progressBar(levelInfo.currentExp, levelInfo.nextExp, 20);
    
    return {
      text: `📈 УРОВЕНЬ
━━━━━━━━━━━━━━━━━━━━
🎖️ Текущий уровень: ${levelInfo.level}

📊 Прогресс:
${expProgress}
${levelInfo.currentExp} / ${levelInfo.nextExp} XP

💡 До следующего уровня: ${levelInfo.nextExp - levelInfo.currentExp} XP

📌 Как получить опыт:
• Работа: +10-50 XP
• Босс: +50-200 XP
• Квесты: +50-500 XP
• Гонки: +20-100 XP`,
      keyboard: keyboards.tg.profile
    };
  },
  
  // Команда: энергия
  energy: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    db.regenerateEnergy(user);
    const energyProgress = progressBar(user.energy, config.game.maxEnergy, 20);
    
    let timeToFull = '';
    if (user.energy < config.game.maxEnergy) {
      const needed = config.game.maxEnergy - user.energy;
      const minutes = needed * config.game.energyRegenMinutes;
      timeToFull = `\n⏰ До полного: ${minutes} мин.`;
    }
    
    return {
      text: `⚡ ЭНЕРГИЯ
━━━━━━━━━━━━━━━━━━━━
${energyProgress}
${user.energy} / ${config.game.maxEnergy}${timeToFull}

📌 Восстановление:
+1 энергия каждые ${config.game.energyRegenMinutes} минут

💡 Энергия тратится на:
• Гонка: 5 ⚡
• Босс: 3 ⚡
• Дуэль: 8 ⚡
• Ограбление: 15 ⚡
• Кейс: 1 ⚡`,
      keyboard: {
        inline_keyboard: [
          [{ text: '🔥 ВОССТАНОВИТЬ (5💎)', callback_data: 'energy_restore' }],
          [{ text: '🔙 НАЗАД', callback_data: 'profile' }]
        ]
      }
    };
  },
  
  // Команда: достижения
  achievements: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    let text = `🏆 ДОСТИЖЕНИЯ (${user.achievements.length}/${config.achievements.length})
━━━━━━━━━━━━━━━━━━━━\n`;
    
    config.achievements.forEach(ach => {
      const completed = user.achievements.includes(ach.id);
      const status = completed ? '✅' : '❌';
      text += `\n${status} ${ach.name}\n└ ${ach.desc}`;
      
      if (!completed) {
        text += `\n   💰 Награда: ${formatMoney(ach.reward.money)}`;
        if (ach.reward.diamonds) text += ` + ${ach.reward.diamonds}💎`;
      }
    });
    
    return { text, keyboard: keyboards.tg.profile };
  },
  
  // Команда: инвентарь
  inventory: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (user.inventory.length === 0) {
      return {
        text: `📦 ИНВЕНТАРЬ
━━━━━━━━━━━━━━━━━━━━
🗑️ Пусто

💡 Предметы можно получить из кейсов, событий и квестов.`,
        keyboard: keyboards.tg.profile
      };
    }
    
    let text = `📦 ИНВЕНТАРЬ (${user.inventory.length} предметов)
━━━━━━━━━━━━━━━━━━━━\n`;
    
    user.inventory.forEach((item, i) => {
      text += `\n${i + 1}. ${item.name} x${item.count || 1}`;
    });
    
    return { text, keyboard: keyboards.tg.profile };
  },
  
  // Команда: ник
  changeNick: async (ctx, newNick) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (!newNick || newNick.length < 2 || newNick.length > 20) {
      return { text: '❌ Ник должен быть от 2 до 20 символов!', keyboard: keyboards.tg.profile };
    }
    
    const cost = 5000;
    if (user.money < cost) {
      return { text: `❌ Недостаточно денег! Нужно ${formatMoney(cost)}`, keyboard: keyboards.tg.profile };
    }
    
    const oldNick = user.name;
    db.updateUser(ctx.platform, ctx.userId, { name: newNick, money: user.money - cost });
    
    return {
      text: `✅ НИК ИЗМЕНЁН
━━━━━━━━━━━━━━━━━━━━
📝 Было: ${oldNick}
📝 Стало: ${newNick}
💰 Списано: ${formatMoney(cost)}`,
      keyboard: keyboards.tg.profile
    };
  },
  
  // Команда: топ
  top: async (ctx, category = 'money') => {
    let users = Object.values(db.users);
    let title = '';
    let sortField = '';
    
    switch (category) {
      case 'money':
      case 'деньги':
        users.sort((a, b) => (b.money + b.bank) - (a.money + a.bank));
        title = '💰 ТОП ПО ДЕНЬГАМ';
        sortField = 'money';
        break;
      case 'level':
      case 'уровень':
        users.sort((a, b) => b.exp - a.exp);
        title = '📈 ТОП ПО УРОВНЮ';
        sortField = 'level';
        break;
      case 'business':
      case 'бизнес':
        users.sort((a, b) => b.businesses.length - a.businesses.length);
        title = '🏢 ТОП ПО БИЗНЕСАМ';
        sortField = 'business';
        break;
      default:
        users.sort((a, b) => (b.money + b.bank) - (a.money + a.bank));
        title = '💰 ТОП ПО ДЕНЬГАМ';
        sortField = 'money';
    }
    
    const top10 = users.slice(0, 10);
    
    let text = `${title}
━━━━━━━━━━━━━━━━━━━━\n`;
    
    const medals = ['🥇', '🥈', '🥉'];
    
    top10.forEach((u, i) => {
      const medal = medals[i] || `${i + 1}.`;
      let value = '';
      
      switch (sortField) {
        case 'money':
          value = formatMoney(u.money + u.bank);
          break;
        case 'level':
          value = `${levelFromExp(u.exp).level} уровень`;
          break;
        case 'business':
          value = `${u.businesses.length} бизнесов`;
          break;
      }
      
      text += `\n${medal} ${u.name} — ${value}`;
    });
    
    return { text, keyboard: keyboards.tg.tops };
  },
  
  // Команда: топ кланы
  topClans: async (ctx) => {
    const clans = Object.values(db.clans);
    clans.sort((a, b) => b.treasury - a.treasury);
    const top10 = clans.slice(0, 10);
    
    let text = `🏛️ ТОП КЛАНОВ
━━━━━━━━━━━━━━━━━━━━\n`;
    
    const medals = ['🥇', '🥈', '🥉'];
    
    if (top10.length === 0) {
      text += '\n🗑️ Кланов пока нет';
    } else {
      top10.forEach((c, i) => {
        const medal = medals[i] || `${i + 1}.`;
        text += `\n${medal} ${c.name}\n   👥 ${c.members.length} | 💰 ${formatMoney(c.treasury)}`;
      });
    }
    
    return { text, keyboard: keyboards.tg.tops };
  }
};
