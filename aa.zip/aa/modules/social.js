// ⚡ FLASH BOT — МОДУЛЬ СОЦИАЛЬНЫХ МЕХАНИК (КЛАНЫ, БОСС, СЕМЬЯ, РЕФЕРАЛЫ)
const db = require('../utils/database');
const { formatMoney, formatNumber, checkCooldown, formatTime, random, progressBar } = require('../utils/helpers');
const keyboards = require('../utils/keyboards');
const config = require('../config');

module.exports = {
  // ==================== БОСС ====================
  
  // Команда: босс
  boss: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (!db.boss.active) {
      return {
        text: `⚔️ БОСС
━━━━━━━━━━━━━━━━━━━━
❌ Босс сейчас не активен!

⏰ Боссы появляются каждые 6 часов.
Следите за объявлениями!`,
        keyboard: keyboards.tg.boss
      };
    }
    
    const hpPercent = Math.floor((db.boss.hp / db.boss.maxHp) * 100);
    const hpBar = progressBar(db.boss.hp, db.boss.maxHp, 15);
    
    // Мой урон
    const myDamage = db.boss.attackers[`${ctx.platform}_${ctx.userId}`]?.damage || 0;
    
    return {
      text: `⚔️ БОСС — ${db.boss.name}
━━━━━━━━━━━━━━━━━━━━
📊 Уровень: ${db.boss.level}
❤️ HP: ${formatNumber(db.boss.hp)}/${formatNumber(db.boss.maxHp)}
${hpBar} ${hpPercent}%

💰 Награда: ${formatMoney(db.boss.reward)}
👥 Атакующих: ${Object.keys(db.boss.attackers).length}
⚔️ Ваш урон: ${formatNumber(myDamage)}

📌 Атака стоит 3 энергии`,
      keyboard: keyboards.tg.bossAttack
    };
  },
  
  // Команда: босс атака
  bossAttack: async (ctx, weapon = null) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (!db.boss.active) {
      return { text: '❌ Босс сейчас не активен!', keyboard: keyboards.tg.boss };
    }
    
    // Кулдаун
    const cooldown = checkCooldown(user.cooldowns.boss, config.game.cooldowns.boss);
    if (!cooldown.ready) {
      return { text: `⏰ Время ожидания: ${formatTime(cooldown.remaining)}`, keyboard: keyboards.tg.boss };
    }
    
    // Энергия
    if (user.energy < config.game.energyCosts.boss) {
      return { text: `❌ Недостаточно энергии! Нужно: ${config.game.energyCosts.boss}⚡`, keyboard: keyboards.tg.boss };
    }
    
    // Если не выбрано оружие, показываем выбор
    if (!weapon) {
      return {
        text: `⚔️ АТАКА БОССА
━━━━━━━━━━━━━━━━━━━━
Выберите оружие для атаки!

💡 Подсказка: Меч наносит больше урона!`,
        keyboard: keyboards.tg.bossAttack
      };
    }
    
    // Проверка правильного оружия
    const correctWeapon = weapon === 'sword' || weapon === 'меч';
    const baseDamage = random(100, 500);
    const levelBonus = require('./profile').level ? 1 : 1; // placeholder
    
    let damage = baseDamage;
    if (correctWeapon) {
      damage = Math.floor(damage * 1.5); // +50% за правильный выбор
    } else {
      damage = Math.floor(damage * 0.5); // -50% за неправильный
    }
    
    user.energy -= config.game.energyCosts.boss;
    user.cooldowns.boss = Date.now();
    user.stats.bossAttacks++;
    user.stats.bossDamage += damage;
    
    const exp = Math.floor(damage / 10);
    db.addExp(user, exp);
    
    // Квесты
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'boss_attacks', 1);
    
    const result = db.attackBoss(`${ctx.platform}_${ctx.userId}`, damage);
    
    // Путь новичка
    const pathComplete = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'boss');
    let pathText = '';
    if (pathComplete) {
      pathText = `\n\n🎉 ПУТЬ НОВИЧКА: Этап ${pathComplete.stage} выполнен!\n+${formatMoney(pathComplete.reward.money)} +${pathComplete.reward.exp} XP`;
    }
    
    if (result.killed) {
      // Босс убит
      let rewardsText = '\n🏆 НАГРАДЫ:\n';
      result.rewards.slice(0, 5).forEach((r, i) => {
        rewardsText += `${i + 1}. ${r.name}: ${formatMoney(r.reward)} (${formatNumber(r.damage)} урона)\n`;
      });
      
      return {
        text: `⚔️ БОСС ПОВЕРЖЕН!
━━━━━━━━━━━━━━━━━━━━
🎯 Ваш урон: ${formatNumber(damage)}
👑 Вы нанесли последний удар!
💰 Бонус убийцы: ${formatMoney(result.killerBonus)}
${rewardsText}
⭐ Опыт: +${exp}${pathText}`,
        keyboard: keyboards.tg.boss
      };
    }
    
    const weaponEmoji = correctWeapon ? '🗡️' : (weapon === 'bow' ? '🏹' : '🛡️');
    const effectiveness = correctWeapon ? '✅ Эффективно!' : '❌ Неэффективно!';
    
    return {
      text: `⚔️ АТАКА БОССА
━━━━━━━━━━━━━━━━━━━━
${weaponEmoji} ${effectiveness}
🎯 Урон: ${formatNumber(damage)}
❤️ HP босса: ${formatNumber(result.hp)}/${formatNumber(db.boss.maxHp)}

⚡ Энергия: ${user.energy}/${config.game.maxEnergy}
⭐ Опыт: +${exp}${pathText}`,
      keyboard: keyboards.tg.bossAttack
    };
  },
  
  // ==================== КЛАНЫ ====================
  
  // Команда: клан
  clan: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (!user.clanId) {
      return {
        text: `🏛️ КЛАНЫ
━━━━━━━━━━━━━━━━━━━━
❌ Вы не состоите в клане!

📌 Команды:
• клан создать [название] — 100,000$
• клан вступить [ID]
• кланы — список кланов`,
        keyboard: keyboards.tg.clan
      };
    }
    
    const clan = db.clans[user.clanId];
    if (!clan) {
      user.clanId = null;
      db.saveAll();
      return { text: '❌ Ваш клан был удалён!', keyboard: keyboards.tg.clan };
    }
    
    const isLeader = clan.leader === `${ctx.platform}_${ctx.userId}`;
    
    return {
      text: `🏛️ КЛАН — ${clan.name}
━━━━━━━━━━━━━━━━━━━━
📊 Уровень: ${clan.level}
👥 Участников: ${clan.members.length}/50
💰 Казна: ${formatMoney(clan.treasury)}
👑 Лидер: ${isLeader ? 'ВЫ' : 'другой игрок'}

⚔️ Войны: ${clan.wars.wins} побед / ${clan.wars.losses} поражений

📌 Команды:
• клан пополнить [сумма]
• клан состав
• клан атака [ID]${isLeader ? '\n• клан удалить [ID игрока]' : ''}`,
      keyboard: keyboards.tg.clan
    };
  },
  
  // Команда: клан создать
  clanCreate: async (ctx, name) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (user.clanId) {
      return { text: '❌ Вы уже состоите в клане!', keyboard: keyboards.tg.clan };
    }
    
    if (!name || name.length < 2 || name.length > 20) {
      return { text: '❌ Название должно быть от 2 до 20 символов!', keyboard: keyboards.tg.clan };
    }
    
    if (user.money < 100000) {
      return { text: `❌ Недостаточно денег! Нужно: ${formatMoney(100000)}`, keyboard: keyboards.tg.clan };
    }
    
    const clan = db.createClan(`${ctx.platform}_${ctx.userId}`, name);
    if (!clan) {
      return { text: '❌ Не удалось создать клан!', keyboard: keyboards.tg.clan };
    }
    
    return {
      text: `✅ КЛАН СОЗДАН!
━━━━━━━━━━━━━━━━━━━━
🏛️ Название: ${clan.name}
👑 Лидер: ВЫ
💰 Потрачено: ${formatMoney(100000)}

Приглашайте друзей!`,
      keyboard: keyboards.tg.clan
    };
  },
  
  // Команда: клан пополнить
  clanDeposit: async (ctx, amountStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user || !user.clanId) {
      return { text: '❌ Вы не состоите в клане!', keyboard: keyboards.tg.clan };
    }
    
    const amount = parseInt(amountStr);
    if (isNaN(amount) || amount < 100) {
      return { text: '❌ Минимум 100$!', keyboard: keyboards.tg.clan };
    }
    
    if (user.money < amount) {
      return { text: `❌ Недостаточно денег! У вас: ${formatMoney(user.money)}`, keyboard: keyboards.tg.clan };
    }
    
    user.money -= amount;
    db.clans[user.clanId].treasury += amount;
    db.saveAll();
    
    return {
      text: `✅ КАЗНА ПОПОЛНЕНА!
━━━━━━━━━━━━━━━━━━━━
💰 Внесено: ${formatMoney(amount)}
🏦 В казне: ${formatMoney(db.clans[user.clanId].treasury)}`,
      keyboard: keyboards.tg.clan
    };
  },
  
  // Команда: клан состав
  clanMembers: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user || !user.clanId) {
      return { text: '❌ Вы не состоите в клане!', keyboard: keyboards.tg.clan };
    }
    
    const clan = db.clans[user.clanId];
    let text = `👥 СОСТАВ КЛАНА — ${clan.name}
━━━━━━━━━━━━━━━━━━━━\n`;
    
    clan.members.forEach((memberKey, i) => {
      const member = db.users[memberKey];
      if (member) {
        const role = memberKey === clan.leader ? '👑' : '👤';
        text += `\n${i + 1}. ${role} ${member.name} (#${member.id})`;
      }
    });
    
    return { text, keyboard: keyboards.tg.clan };
  },
  
  // ==================== РЕФЕРАЛЫ ====================
  
  // Команда: реферал
  referral: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const refLink = ctx.platform === 'telegram' 
      ? `https://t.me/gamebotflash_bot?start=ref_${user.id}`
      : `https://vk.com/club237124814?ref=${user.id}`;
    
    return {
      text: `🎁 РЕФЕРАЛЬНАЯ ПРОГРАММА
━━━━━━━━━━━━━━━━━━━━
👥 Ваших рефералов: ${user.referrals.length}
💰 Заработано: ${formatMoney(user.referralEarnings)}

🔗 Ваша ссылка:
${refLink}

📌 За каждого друга:
• +5,000$ вам
• +2,000$ другу
• 10% от его заработка навсегда!`,
      keyboard: {
        inline_keyboard: [
          [{ text: '📊 СТАТИСТИКА', callback_data: 'ref_stats' }],
          [{ text: '📋 МОИ РЕФЕРАЛЫ', callback_data: 'ref_list' }],
          [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
        ]
      }
    };
  },
  
  // Команда: реферал список
  referralList: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    if (user.referrals.length === 0) {
      return { text: '❌ У вас пока нет рефералов!', keyboard: keyboards.tg.main };
    }
    
    let text = `📋 ВАШИ РЕФЕРАЛЫ (${user.referrals.length})
━━━━━━━━━━━━━━━━━━━━\n`;
    
    user.referrals.slice(0, 10).forEach((refId, i) => {
      const ref = db.getUserById(refId);
      if (ref) {
        text += `\n${i + 1}. ${ref.name} (#${ref.id})`;
      }
    });
    
    if (user.referrals.length > 10) {
      text += `\n...и ещё ${user.referrals.length - 10}`;
    }
    
    return { text, keyboard: keyboards.tg.main };
  },
  
  // ==================== БОНУС ====================
  
  // Команда: бонус
  bonus: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const cooldown = checkCooldown(user.cooldowns.bonus, config.game.cooldowns.bonus);
    
    if (!cooldown.ready) {
      return {
        text: `🎁 ЕЖЕДНЕВНЫЙ БОНУС
━━━━━━━━━━━━━━━━━━━━
⏰ Время ожидания: ${formatTime(cooldown.remaining)}

Возвращайтесь позже!`,
        keyboard: keyboards.tg.bonus
      };
    }
    
    const bonus = 5000 + random(0, 5000);
    const exp = 50 + random(0, 50);
    
    user.money += bonus;
    user.cooldowns.bonus = Date.now();
    user.stats.totalEarned += bonus;
    db.addExp(user, exp);
    db.saveAll();
    
    // Путь новичка
    const pathComplete = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'bonus');
    let pathText = '';
    if (pathComplete) {
      pathText = `\n\n🎉 ПУТЬ НОВИЧКА: Этап ${pathComplete.stage} выполнен!\n+${formatMoney(pathComplete.reward.money)} +${pathComplete.reward.exp} XP`;
    }
    
    return {
      text: `🎁 ЕЖЕДНЕВНЫЙ БОНУС
━━━━━━━━━━━━━━━━━━━━
💰 Получено: ${formatMoney(bonus)}
⭐ Опыт: +${exp}

💵 Баланс: ${formatMoney(user.money)}${pathText}`,
      keyboard: keyboards.tg.bonus
    };
  },
  
  // Команда: бонус часовой
  bonusHourly: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    }
    
    const cooldown = checkCooldown(user.cooldowns.hourlyBonus, config.game.cooldowns.hourlyBonus);
    
    if (!cooldown.ready) {
      return {
        text: `⏰ ЧАСОВОЙ БОНУС
━━━━━━━━━━━━━━━━━━━━
⏰ Время ожидания: ${formatTime(cooldown.remaining)}`,
        keyboard: keyboards.tg.bonus
      };
    }
    
    const bonus = 1000 + random(0, 2000);
    
    user.money += bonus;
    user.cooldowns.hourlyBonus = Date.now();
    user.stats.totalEarned += bonus;
    db.saveAll();
    
    return {
      text: `⏰ ЧАСОВОЙ БОНУС
━━━━━━━━━━━━━━━━━━━━
💰 Получено: ${formatMoney(bonus)}

💵 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.bonus
    };
  }
};
