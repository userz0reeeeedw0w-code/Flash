// ⚡ FLASH BOT — TELEGRAM
const TelegramBot = require('node-telegram-bot-api');
const config = require('../config');
const { handleMessage } = require('../handler');
const keyboards = require('../utils/keyboards');
const db = require('../utils/database');

class TelegramPlatform {
  constructor() {
    this.bot = new TelegramBot(config.telegram.token, { polling: true });
    this.setupHandlers();
    console.log('✅ Telegram бот запущен');
  }
  
  setupHandlers() {
    this.bot.on('message', async (msg) => {
      if (!msg.text) return;
      
      const ctx = {
        platform: 'telegram',
        odid: msg.from.id,
        userId: msg.from.id,
        userName: msg.from.first_name + (msg.from.last_name ? ' ' + msg.from.last_name : ''),
        chatId: msg.chat.id,
        isPrivate: msg.chat.type === 'private',
        text: msg.text
      };
      
      try {
        const response = await handleMessage(ctx);
        if (response) await this.sendResponse(ctx, response);
      } catch (e) {
        console.error('TG error:', e);
      }
    });
    
    this.bot.on('callback_query', async (query) => {
      const ctx = {
        platform: 'telegram',
        userId: query.from.id,
        userName: query.from.first_name,
        chatId: query.message.chat.id,
        messageId: query.message.message_id,
        isPrivate: query.message.chat.type === 'private',
        callbackData: query.data
      };
      
      try {
        const response = await handleMessage(ctx);
        await this.bot.answerCallbackQuery(query.id);
        if (response) {
          try {
            await this.bot.editMessageText(response.text, {
              chat_id: ctx.chatId,
              message_id: ctx.messageId,
              reply_markup: response.keyboard
            });
          } catch (e) {
            await this.sendResponse(ctx, response);
          }
        }
      } catch (e) {
        console.error('TG callback error:', e);
        await this.bot.answerCallbackQuery(query.id, { text: '❌ Ошибка' });
      }
    });
    
    this.bot.on('polling_error', (e) => console.error('Polling:', e.code));
  }
  
  async sendResponse(ctx, response) {
    const options = {};
    
    if (response.keyboard) options.reply_markup = response.keyboard;
    if (response.replyKeyboard) options.reply_markup = response.replyKeyboard;
    if (response.removeKeyboard) options.reply_markup = keyboards.tgRemove;
    
    // Автоклавиатура
    if (ctx.isPrivate && !response.replyKeyboard && !response.removeKeyboard && !response.keyboard) {
      const user = db.getUserByPlatform('telegram', ctx.userId);
      if (user?.settings?.keyboard) options.reply_markup = keyboards.tgReply;
    }
    
    try {
      await this.bot.sendMessage(ctx.chatId, response.text, options);
      if (response.broadcast) await this.broadcast(response.broadcast);
    } catch (e) {
      console.error('Send error:', e.message);
    }
  }
  
  async broadcast(text) {
    const users = Object.entries(db.users)
      .filter(([k]) => k.startsWith('telegram_'))
      .map(([k]) => parseInt(k.replace('telegram_', '')));
    
    let sent = 0;
    for (const id of users) {
      try {
        await this.bot.sendMessage(id, text);
        sent++;
        await new Promise(r => setTimeout(r, 50));
      } catch (e) {}
    }
    console.log(`Broadcast: ${sent}/${users.length}`);
  }
}

module.exports = TelegramPlatform;
