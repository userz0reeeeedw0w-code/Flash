// vk.js
const { VK, Keyboard } = require('vk-io');
const config = require('../config');
const { handleMessage } = require('../handler');
const db = require('../utils/database');

class VKPlatform {
  constructor() {
    this.vk = new VK({ token: config.vk.token });
    this.botId = null;
    this.setupHandlers();
    this.startPolling();
  }
  
  async getBotId() {
    if (!this.botId) {
      try {
        const [me] = await this.vk.api.users.get();
        this.botId = me.id;
      } catch (e) {
        this.botId = 0;
      }
    }
    return this.botId;
  }
  
  setupHandlers() {
    this.vk.updates.on('message_new', async (ctx) => {
      if (ctx.senderId === await this.getBotId()) return;
      if (!ctx.text) return;
      
      const isChat = ctx.peerType !== 'user';
      const botId = await this.getBotId();
      
      let commandText = ctx.text;
      
      if (isChat) {
        const mention1 = `[club${Math.abs(botId)}|`;
        const mention2 = `@id${botId}`;
        const mention3 = `@club${Math.abs(botId)}`;
        
        if (ctx.text.includes(mention1)) {
          commandText = ctx.text.replace(new RegExp(`\\[club${Math.abs(botId)}\\|[^\\]]*\\]`, 'g'), '').trim();
        } else if (ctx.text.includes(mention2)) {
          commandText = ctx.text.replace(new RegExp(`@id${botId}[^\\s]*`, 'g'), '').trim();
        } else if (ctx.text.includes(mention3)) {
          commandText = ctx.text.replace(new RegExp(`@club${Math.abs(botId)}[^\\s]*`, 'g'), '').trim();
        } else {
          return;
        }
      }
      
      const context = {
        platform: 'vk',
        userId: ctx.senderId,
        userName: await this.getUserName(ctx.senderId),
        peerId: ctx.peerId,
        isPrivate: !isChat,
        text: commandText || ctx.text,
        isChat: isChat
      };
      
      try {
        const response = await handleMessage(context);
        if (response) await this.sendResponse(ctx, context, response);
      } catch (e) {
        console.error('VK error:', e);
      }
    });
    
    this.vk.updates.on('message_event', async (ctx) => {
      if (ctx.userId === await this.getBotId()) return;
      
      const payload = ctx.eventPayload;
      if (!payload?.action) return;
      
      const context = {
        platform: 'vk',
        userId: ctx.userId,
        userName: await this.getUserName(ctx.userId),
        peerId: ctx.peerId,
        isPrivate: true,
        callbackData: payload.action,
        isChat: false
      };
      
      try {
        const response = await handleMessage(context);
        await ctx.answer({ type: 'show_snackbar', text: '✅' });
        if (response) await this.sendResponse(ctx, context, response);
      } catch (e) {
        console.error('VK callback error:', e);
      }
    });
  }
  
  async startPolling() {
    try {
      await this.getBotId();
      await this.vk.updates.start();
      console.log(`✅ VK бот запущен (ID: ${this.botId})`);
    } catch (e) {
      console.error('VK polling error:', e);
    }
  }
  
  async getUserName(userId) {
    try {
      const [user] = await this.vk.api.users.get({ user_ids: [userId] });
      return `${user.first_name} ${user.last_name}`;
    } catch (e) {
      return 'Пользователь';
    }
  }
  
  buildKeyboard(tgKb) {
    if (!tgKb?.inline_keyboard) return null;
    const kb = Keyboard.builder().inline();
    tgKb.inline_keyboard.forEach(row => {
      row.forEach(btn => {
        kb.callbackButton({
          label: btn.text.substring(0, 40),
          payload: { action: btn.callback_data }
        });
      });
      kb.row();
    });
    return kb;
  }
  
  buildReplyKeyboard() {
    return Keyboard.builder()
      .textButton({ label: '👤 Профиль' })
      .textButton({ label: '💰 Баланс' })
      .textButton({ label: '🏪 Магазин' })
      .row()
      .textButton({ label: '⚔️ Босс' })
      .textButton({ label: '🏁 Гонка' })
      .textButton({ label: '💼 Работа' })
      .row()
      .textButton({ label: '🏛️ Клан' })
      .textButton({ label: '🎰 Казино' })
      .textButton({ label: '🎁 Бонус' })
      .row()
      .textButton({ label: '📊 Топ' })
      .textButton({ label: '❓ Помощь' })
      .textButton({ label: '📍 Путь новичка' });
  }
  
  getButtonsFromKeyboard(keyboard) {
    if (!keyboard) return [];
    const rows = keyboard.inline_keyboard || keyboard.keyboard || [];
    const result = [];
    rows.forEach(row => {
      const rowText = row.map(btn => `"${btn.text}"`).join('  ');
      result.push(rowText);
    });
    return result;
  }
  
  async sendResponse(ctx, context, response) {
    const options = {};
    
    if (context.isChat) {
      let text = `@id${context.userId}, ${response.text}`;
      
      if (response.keyboard || response.replyKeyboard) {
        const kb = response.keyboard || response.replyKeyboard;
        const buttons = this.getButtonsFromKeyboard(kb);
        
        if (buttons.length > 0) {
          text += '\n\n📌 Напишите @Flash и нажмите на команду:\n';
          buttons.forEach(row => {
            text += `   ${row}\n`;
          });
        }
      }
      
      await ctx.send(text);
      if (response.broadcast) await this.broadcast(response.broadcast);
      return;
    }
    
    if (response.keyboard) {
      options.keyboard = this.buildKeyboard(response.keyboard);
    }
    
    if (response.replyKeyboard) {
      options.keyboard = this.buildReplyKeyboard();
    }
    
    if (response.removeKeyboard) {
      options.keyboard = Keyboard.builder();
    }
    
    try {
      await ctx.send(response.text, options);
      if (response.broadcast) await this.broadcast(response.broadcast);
    } catch (e) {
      console.error('VK send error:', e.message);
    }
  }
  
  async broadcast(text) {
    const users = Object.entries(db.users)
      .filter(([k]) => k.startsWith('vk_'))
      .map(([k]) => parseInt(k.replace('vk_', '')));
    
    let sent = 0;
    for (const id of users) {
      try {
        await this.vk.api.messages.send({
          user_id: id,
          message: text,
          random_id: Math.floor(Math.random() * 1e9)
        });
        sent++;
        await new Promise(r => setTimeout(r, 100));
      } catch (e) {}
    }
    console.log(`VK Broadcast: ${sent}/${users.length}`);
  }
}

module.exports = VKPlatform;