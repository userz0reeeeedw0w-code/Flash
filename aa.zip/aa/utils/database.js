// database.js
const { loadJSON, saveJSON, generateUID, levelFromExp, getDateKey, getWeekKey } = require('./helpers');
const config = require('../config');

class Database {
  constructor() {
    this.users = loadJSON('users.json') || {};
    this.clans = loadJSON('clans.json') || {};
    this.families = loadJSON('families.json') || {};
    this.boss = loadJSON('boss.json') || { active: false };
    this.events = loadJSON('events.json') || { active: [], history: [] };
    this.promoCodes = loadJSON('promoCodes.json') || {};
    this.bonds = loadJSON('bonds.json') || {};
    this.newspaper = loadJSON('newspaper.json') || [];
    this.posts = loadJSON('posts.json') || [];
    this.duels = loadJSON('duels.json') || {};
    
    this.nextUserId = this._getNextUserId();
    this.nextPostId = this.posts.length + 1;
    
    setInterval(() => this.saveAll(), 30000);
  }
  
  _getNextUserId() {
    let maxId = 0;
    Object.values(this.users).forEach(u => {
      if (u.id && u.id > maxId) maxId = u.id;
    });
    return maxId + 1;
  }
  
  saveAll() {
    saveJSON('users.json', this.users);
    saveJSON('clans.json', this.clans);
    saveJSON('families.json', this.families);
    saveJSON('boss.json', this.boss);
    saveJSON('events.json', this.events);
    saveJSON('promoCodes.json', this.promoCodes);
    saveJSON('bonds.json', this.bonds);
    saveJSON('newspaper.json', this.newspaper);
    saveJSON('posts.json', this.posts);
    saveJSON('duels.json', this.duels);
  }
  
  getUserKey(platform, platformId) {
    return `${platform}_${platformId}`;
  }
  
  getUserByPlatform(platform, platformId) {
    if (platform === 'vk' && platformId < 0) return null;
    const key = this.getUserKey(platform, platformId);
    return this.users[key] || null;
  }
  
  getUserByUID(uid) {
    return Object.values(this.users).find(u => u.uid === uid) || null;
  }
  
  getUserById(id) {
    id = parseInt(id);
    return Object.values(this.users).find(u => u.id === id) || null;
  }
  
  findUserKey(user) {
    return Object.keys(this.users).find(k => this.users[k].uid === user.uid);
  }
  
  createUser(platform, platformId, name) {
    if (platform === 'vk' && platformId < 0) return null;
    
    const key = this.getUserKey(platform, platformId);
    if (this.users[key]) return this.users[key];
    
    const uid = generateUID();
    const id = this.nextUserId++;
    
    this.users[key] = {
      uid, id, name,
      platforms: { [platform]: platformId },
      registered: Date.now(),
      lastActive: Date.now(),
      
      money: config.game.startMoney,
      bank: 0,
      bankLimit: 100000,
      bitcoin: 0,
      rubles: 0,
      diamonds: 0,
      cups: 0,
      
      exp: 0,
      energy: config.game.maxEnergy,
      lastEnergyRegen: Date.now(),
      
      job: null,
      jobStage: 0,
      workStreak: 0,
      
      businesses: [],
      cars: [],
      currentCar: null,
      tuning: 0,
      farms: [],
      printers: [],
      
      pickaxeLevel: 1,
      mineLevel: 0,
      ores: {},
      rodLevel: 1,
      fish: {},
      trophies: {},
      
      clanId: null,
      familyId: null,
      spouse: null,
      children: 0,
      
      house: 0,
      furniture: [],
      pets: [],
      
      phone: 0,
      contacts: [],
      subscribers: [],
      subscriptions: [],
      
      hobby: null,
      hobbyLevel: 0,
      
      privilege: null,
      privilegeExpires: null,
      
      beginnerStage: 1,
      beginnerCompleted: false,
      
      dailyQuests: {},
      weeklyQuests: {},
      dailyQuestsDate: null,
      weeklyQuestsDate: null,
      
      achievements: [],
      
      inventory: [],
      
      cooldowns: {},
      
      robberyProtection: false,
      robberyProtectionExpires: null,
      
      stats: {
        totalEarned: 0,
        raceWins: 0,
        raceLosses: 0,
        bossAttacks: 0,
        bossKills: 0,
        bossDamage: 0,
        fishCaught: 0,
        oreMined: 0,
        robberies: 0,
        robberiesSuccess: 0,
        casinoBets: 0,
        casinoWins: 0,
        casinoLosses: 0,
        workShifts: 0,
        businessCollects: 0,
        duelWins: 0,
        duelLosses: 0,
        huntingSuccess: 0
      },
      
      settings: {
        keyboard: false,
        notifications: true
      },
      
      referrer: null,
      referrals: [],
      referralEarnings: 0,
      
      credit: null,
      
      banned: false,
      banReason: null,
      
      notifications: []
    };
    
    this.giveAchievement(key, 1);
    this.saveAll();
    return this.users[key];
  }
  
  createBondCode(platform, platformId) {
    const user = this.getUserByPlatform(platform, platformId);
    if (!user) return null;
    
    Object.keys(this.bonds).forEach(code => {
      if (this.bonds[code].uid === user.uid) delete this.bonds[code];
    });
    
    const code = Math.random().toString(36).substring(2, 8).toUpperCase();
    this.bonds[code] = {
      uid: user.uid,
      platform,
      platformId,
      created: Date.now(),
      expires: Date.now() + config.game.bondCodeExpireMinutes * 60 * 1000
    };
    
    this.saveAll();
    return code;
  }
  
  useBondCode(code, newPlatform, newPlatformId) {
    code = code.toUpperCase();
    const bond = this.bonds[code];
    if (!bond) return { success: false, error: 'Код не найден' };
    if (Date.now() > bond.expires) {
      delete this.bonds[code];
      return { success: false, error: 'Код истёк' };
    }
    
    const originalKey = `${bond.platform}_${bond.platformId}`;
    const user = this.users[originalKey];
    if (!user) return { success: false, error: 'Аккаунт не найден' };
    
    const newKey = `${newPlatform}_${newPlatformId}`;
    if (this.users[newKey]) return { success: false, error: 'У вас уже есть аккаунт' };
    
    user.platforms[newPlatform] = newPlatformId;
    this.users[newKey] = user;
    
    delete this.bonds[code];
    this.saveAll();
    return { success: true, user };
  }
  
  regenerateEnergy(user) {
    const now = Date.now();
    const elapsed = (now - (user.lastEnergyRegen || now)) / 1000 / 60;
    const regenAmount = Math.floor(elapsed / config.game.energyRegenMinutes);
    
    if (regenAmount > 0 && user.energy < config.game.maxEnergy) {
      user.energy = Math.min(config.game.maxEnergy, user.energy + regenAmount);
      user.lastEnergyRegen = now;
    }
    return user.energy;
  }
  
  addExp(user, amount) {
    const oldLevel = levelFromExp(user.exp).level;
    user.exp += amount;
    const newInfo = levelFromExp(user.exp);
    return { leveledUp: newInfo.level > oldLevel, newLevel: newInfo.level, exp: amount };
  }
  
  giveAchievement(userKey, achievementId) {
    const user = this.users[userKey];
    if (!user || user.achievements.includes(achievementId)) return null;
    
    const achievement = config.achievements.find(a => a.id === achievementId);
    if (!achievement) return null;
    
    user.achievements.push(achievementId);
    if (achievement.reward.money) user.money += achievement.reward.money;
    if (achievement.reward.exp) this.addExp(user, achievement.reward.exp);
    if (achievement.reward.diamonds) user.diamonds += achievement.reward.diamonds;
    
    return achievement;
  }
  
  checkAchievements(userKey) {
    const user = this.users[userKey];
    if (!user) return [];
    
    const newAchievements = [];
    const checks = [
      { id: 2, check: () => (user.money + user.bank) >= 1000000 },
      { id: 3, check: () => user.stats.raceWins >= 100 },
      { id: 4, check: () => user.stats.bossDamage >= 1000000 },
      { id: 5, check: () => user.businesses.length >= 5 },
      { id: 6, check: () => user.stats.oreMined >= 10000 },
      { id: 7, check: () => user.stats.fishCaught >= 500 },
      { id: 8, check: () => levelFromExp(user.exp).level >= 50 }
    ];
    
    checks.forEach(({ id, check }) => {
      if (!user.achievements.includes(id) && check()) {
        const a = this.giveAchievement(userKey, id);
        if (a) newAchievements.push(a);
      }
    });
    
    if (newAchievements.length > 0) this.saveAll();
    return newAchievements;
  }
  
  checkBeginnerPath(userKey, action) {
    const user = this.users[userKey];
    if (!user || user.beginnerCompleted) return null;
    
    const stage = config.beginnerPath.find(s => s.stage === user.beginnerStage);
    if (!stage || stage.action !== action) return null;
    
    if (action === 'rich' && (user.money + user.bank) < 100000) return null;
    
    if (stage.reward.money) user.money += stage.reward.money;
    if (stage.reward.exp) this.addExp(user, stage.reward.exp);
    if (stage.reward.diamonds) user.diamonds += stage.reward.diamonds;
    
    user.beginnerStage++;
    if (user.beginnerStage > config.beginnerPath.length) {
      user.beginnerCompleted = true;
    }
    
    this.saveAll();
    return stage;
  }
  
  initDailyQuests(user) {
    const today = getDateKey();
    if (user.dailyQuestsDate !== today) {
      user.dailyQuestsDate = today;
      user.dailyQuests = {};
      config.dailyQuests.forEach(q => {
        user.dailyQuests[q.id] = { progress: 0, completed: false, claimed: false };
      });
    }
  }
  
  initWeeklyQuests(user) {
    const week = getWeekKey();
    if (user.weeklyQuestsDate !== week) {
      user.weeklyQuestsDate = week;
      user.weeklyQuests = {};
      config.weeklyQuests.forEach(q => {
        user.weeklyQuests[q.id] = { progress: 0, completed: false, claimed: false };
      });
    }
  }
  
  updateQuestProgress(userKey, type, amount = 1) {
    const user = this.users[userKey];
    if (!user) return [];
    
    this.initDailyQuests(user);
    this.initWeeklyQuests(user);
    
    const completedQuests = [];
    
    const updateQuests = (quests, questConfigs, isDaily) => {
      questConfigs.filter(q => q.type === type).forEach(quest => {
        const progress = quests[quest.id];
        if (progress && !progress.completed) {
          progress.progress += amount;
          if (progress.progress >= quest.target) {
            progress.completed = true;
            completedQuests.push({ ...quest, isDaily });
          }
        }
      });
    };
    
    updateQuests(user.dailyQuests, config.dailyQuests, true);
    updateQuests(user.weeklyQuests, config.weeklyQuests, false);
    
    if (completedQuests.length > 0) this.saveAll();
    return completedQuests;
  }
  
  claimQuest(userKey, questId, isDaily) {
    const user = this.users[userKey];
    if (!user) return null;
    
    const quests = isDaily ? user.dailyQuests : user.weeklyQuests;
    const questConfig = isDaily 
      ? config.dailyQuests.find(q => q.id === questId)
      : config.weeklyQuests.find(q => q.id === questId);
    
    if (!quests || !quests[questId] || !quests[questId].completed || quests[questId].claimed) return null;
    
    quests[questId].claimed = true;
    
    if (questConfig.reward.money) user.money += questConfig.reward.money;
    if (questConfig.reward.exp) this.addExp(user, questConfig.reward.exp);
    if (questConfig.reward.diamonds) user.diamonds += questConfig.reward.diamonds;
    if (questConfig.reward.cups) user.cups += questConfig.reward.cups;
    
    this.saveAll();
    return questConfig;
  }
  
  spawnBoss() {
    const names = ['🐉 Дракон', '👹 Демон', '🦖 Динозавр', '👾 Пришелец', '🤖 Робот', '🧟 Зомби', '👻 Призрак'];
    const level = Math.floor(Math.random() * 10) + 1;
    
    this.boss = {
      active: true,
      name: names[Math.floor(Math.random() * names.length)],
      level,
      maxHp: 100000 * level,
      hp: 100000 * level,
      reward: 50000 * level,
      attackers: {},
      spawnTime: Date.now()
    };
    
    this.saveAll();
    return this.boss;
  }
  
  attackBoss(userKey, damage) {
    if (!this.boss.active) return null;
    
    const user = this.users[userKey];
    if (!user) return null;
    
    if (!this.boss.attackers[userKey]) {
      this.boss.attackers[userKey] = { damage: 0, name: user.name, odid: user.id };
    }
    this.boss.attackers[userKey].damage += damage;
    this.boss.hp -= damage;
    
    user.stats.bossDamage += damage;
    
    if (this.boss.hp <= 0) {
      const totalDamage = Object.values(this.boss.attackers).reduce((s, a) => s + a.damage, 0);
      const rewards = [];
      
      Object.entries(this.boss.attackers).forEach(([key, attacker]) => {
        const share = attacker.damage / totalDamage;
        const reward = Math.floor(this.boss.reward * 0.7 * share);
        if (this.users[key]) {
          this.users[key].money += reward;
          this.users[key].stats.bossKills++;
          rewards.push({ name: attacker.name, odid: attacker.id, reward, damage: attacker.damage });
        }
      });
      
      const killerBonus = Math.floor(this.boss.reward * 0.3);
      user.money += killerBonus;
      
      this.boss.active = false;
      this.saveAll();
      return { killed: true, rewards, killerBonus };
    }
    
    this.saveAll();
    return { killed: false, hp: this.boss.hp, damage };
  }
  
  createClan(userKey, name) {
    const user = this.users[userKey];
    if (!user || user.clanId || user.money < 100000) return null;
    
    const clanId = generateUID();
    this.clans[clanId] = {
      id: clanId, name,
      leader: userKey,
      members: [userKey],
      treasury: 0,
      level: 1,
      exp: 0,
      created: Date.now(),
      wars: { wins: 0, losses: 0 }
    };
    
    user.money -= 100000;
    user.clanId = clanId;
    this.saveAll();
    return this.clans[clanId];
  }
  
  joinClan(userKey, clanId) {
    const user = this.users[userKey];
    const clan = this.clans[clanId];
    if (!user || !clan || user.clanId || clan.members.length >= 50) return null;
    
    clan.members.push(userKey);
    user.clanId = clanId;
    this.saveAll();
    return clan;
  }
  
  leaveClan(userKey) {
    const user = this.users[userKey];
    if (!user || !user.clanId) return null;
    
    const clan = this.clans[user.clanId];
    if (!clan) return null;
    
    if (clan.leader === userKey) {
      if (clan.members.length > 1) {
        clan.leader = clan.members.find(m => m !== userKey);
      } else {
        delete this.clans[user.clanId];
        user.clanId = null;
        this.saveAll();
        return { deleted: true };
      }
    }
    
    clan.members = clan.members.filter(m => m !== userKey);
    user.clanId = null;
    this.saveAll();
    return clan;
  }
  
  createFamily(userKey1, userKey2) {
    const user1 = this.users[userKey1];
    const user2 = this.users[userKey2];
    if (!user1 || !user2 || user1.familyId || user2.familyId) return null;
    
    const familyId = generateUID();
    this.families[familyId] = {
      id: familyId,
      members: [userKey1, userKey2],
      budget: 0,
      created: Date.now()
    };
    
    user1.familyId = familyId;
    user1.spouse = user2.id;
    user2.familyId = familyId;
    user2.spouse = user1.id;
    
    this.saveAll();
    return this.families[familyId];
  }
  
  createPromoCode(code, reward, maxUses = 100) {
    this.promoCodes[code.toUpperCase()] = {
      reward, maxUses, uses: 0, usedBy: [], created: Date.now()
    };
    this.saveAll();
  }
  
  usePromoCode(userKey, code) {
    const promo = this.promoCodes[code.toUpperCase()];
    if (!promo) return { success: false, error: 'Промокод не найден' };
    if (promo.usedBy.includes(userKey)) return { success: false, error: 'Вы уже использовали этот промокод' };
    if (promo.uses >= promo.maxUses) return { success: false, error: 'Промокод исчерпан' };
    
    const user = this.users[userKey];
    if (!user) return { success: false, error: 'Пользователь не найден' };
    
    if (promo.reward.money) user.money += promo.reward.money;
    if (promo.reward.exp) this.addExp(user, promo.reward.exp);
    if (promo.reward.diamonds) user.diamonds += promo.reward.diamonds;
    
    promo.uses++;
    promo.usedBy.push(userKey);
    this.saveAll();
    return { success: true, reward: promo.reward };
  }
  
  getActiveEvents() {
    this.events.active = this.events.active.filter(e => e.endTime > Date.now());
    return this.events.active;
  }
  
  startEvent(eventConfig) {
    const event = {
      ...eventConfig,
      startTime: Date.now(),
      endTime: Date.now() + eventConfig.duration * 1000
    };
    this.events.active.push(event);
    this.saveAll();
    return event;
  }
  
  hasActiveEvent(type) {
    return this.getActiveEvents().some(e => e.type === type);
  }
  
  createPost(userKey, text) {
    const user = this.users[userKey];
    if (!user) return null;
    
    const post = {
      id: this.nextPostId++,
      authorKey: userKey,
      authorName: user.name,
      authorId: user.id,
      text,
      likes: [],
      comments: [],
      created: Date.now()
    };
    
    this.posts.unshift(post);
    if (this.posts.length > 100) this.posts = this.posts.slice(0, 100);
    this.saveAll();
    return post;
  }
  
  likePost(userKey, postId) {
    const post = this.posts.find(p => p.id === postId);
    if (!post) return null;
    
    if (post.likes.includes(userKey)) {
      post.likes = post.likes.filter(k => k !== userKey);
    } else {
      post.likes.push(userKey);
    }
    this.saveAll();
    return post;
  }
  
  createDuel(challengerKey, targetKey, bet) {
    const duelId = generateUID();
    this.duels[duelId] = {
      id: duelId,
      challenger: challengerKey,
      target: targetKey,
      bet,
      status: 'pending',
      created: Date.now()
    };
    this.saveAll();
    return this.duels[duelId];
  }
  
  acceptDuel(duelId) {
    const duel = this.duels[duelId];
    if (!duel || duel.status !== 'pending') return null;
    
    duel.status = 'active';
    const winner = Math.random() > 0.5 ? duel.challenger : duel.target;
    const loser = winner === duel.challenger ? duel.target : duel.challenger;
    
    const winnerUser = this.users[winner];
    const loserUser = this.users[loser];
    
    if (winnerUser && loserUser) {
      winnerUser.money += duel.bet;
      loserUser.money -= duel.bet;
      winnerUser.stats.duelWins++;
      loserUser.stats.duelLosses++;
    }
    
    duel.winner = winner;
    duel.status = 'completed';
    this.saveAll();
    return { duel, winner, loser, winnerUser, loserUser };
  }
}

module.exports = new Database();