// ⚡ FLASH BOT — УТИЛИТЫ
const fs = require('fs');
const path = require('path');

function formatNumber(num) {
  if (num === undefined || num === null) return '0';
  num = Number(num);
  if (isNaN(num)) return '0';
  if (num >= 1000000000) return (num / 1000000000).toFixed(1) + 'B';
  if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
  if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
  return num.toLocaleString('ru-RU');
}

function formatMoney(amount) {
  return formatNumber(amount) + '$';
}

function formatTime(seconds) {
  if (!seconds || seconds <= 0) return '0 сек.';
  seconds = Math.ceil(seconds);
  if (seconds < 60) return `${seconds} сек.`;
  if (seconds < 3600) {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return secs > 0 ? `${mins} мин. ${secs} сек.` : `${mins} мин.`;
  }
  const hours = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  return mins > 0 ? `${hours} ч. ${mins} мин.` : `${hours} ч.`;
}

function generateBondCode() {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}

function generateUID() {
  return Date.now().toString(36) + Math.random().toString(36).substring(2, 8);
}

function expForLevel(level) {
  return Math.floor(100 * Math.pow(1.5, level - 1));
}

function levelFromExp(exp) {
  let level = 1;
  let totalRequired = 0;
  while (true) {
    const required = expForLevel(level);
    if (totalRequired + required > exp) {
      return { level, currentExp: exp - totalRequired, nextExp: required };
    }
    totalRequired += required;
    level++;
    if (level > 100) break;
  }
  return { level: 100, currentExp: 0, nextExp: 0 };
}

function loadJSON(filename) {
  const filepath = path.join(__dirname, '../data', filename);
  try {
    if (fs.existsSync(filepath)) {
      const content = fs.readFileSync(filepath, 'utf8');
      return JSON.parse(content);
    }
  } catch (e) {
    console.error(`Error loading ${filename}:`, e.message);
  }
  return null;
}

function saveJSON(filename, data) {
  const filepath = path.join(__dirname, '../data', filename);
  const dir = path.dirname(filepath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  try {
    fs.writeFileSync(filepath, JSON.stringify(data, null, 2));
  } catch (e) {
    console.error(`Error saving ${filename}:`, e.message);
  }
}

function createBackup() {
  const backupDir = path.join(__dirname, '../data/backups');
  if (!fs.existsSync(backupDir)) {
    fs.mkdirSync(backupDir, { recursive: true });
  }
  
  const files = ['users.json', 'clans.json', 'boss.json', 'events.json', 'promoCodes.json'];
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  
  files.forEach(file => {
    const src = path.join(__dirname, '../data', file);
    if (fs.existsSync(src)) {
      const dest = path.join(backupDir, `${timestamp}_${file}`);
      try {
        fs.copyFileSync(src, dest);
      } catch (e) {}
    }
  });
  
  // Удаляем старые бэкапы
  try {
    const backups = fs.readdirSync(backupDir).sort().reverse();
    if (backups.length > 50) {
      backups.slice(50).forEach(f => {
        try { fs.unlinkSync(path.join(backupDir, f)); } catch (e) {}
      });
    }
  } catch (e) {}
}

function checkCooldown(lastTime, cooldownSeconds) {
  if (!lastTime) return { ready: true, remaining: 0 };
  const now = Date.now();
  const elapsed = (now - lastTime) / 1000;
  if (elapsed >= cooldownSeconds) {
    return { ready: true, remaining: 0 };
  }
  return { ready: false, remaining: Math.ceil(cooldownSeconds - elapsed) };
}

function random(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomElement(arr) {
  if (!arr || arr.length === 0) return null;
  return arr[Math.floor(Math.random() * arr.length)];
}

function progressBar(current, max, length = 10) {
  if (!max || max <= 0) return '░'.repeat(length);
  const filled = Math.min(length, Math.max(0, Math.round((current / max) * length)));
  return '█'.repeat(filled) + '░'.repeat(length - filled);
}

function getDateKey() {
  return new Date().toISOString().split('T')[0];
}

function getWeekKey() {
  const now = new Date();
  const start = new Date(now.getFullYear(), 0, 1);
  const diff = now - start;
  const week = Math.ceil(diff / (7 * 24 * 60 * 60 * 1000));
  return `${now.getFullYear()}-W${week}`;
}

function isAdmin(userId, platform, config) {
  if (platform === 'telegram') {
    return userId === config.telegram.adminId;
  }
  return userId === config.vk.adminId;
}

function getCooldownMultiplier(user, config) {
  if (user.privilege && user.privilegeExpires > Date.now()) {
    const priv = config.privileges[user.privilege.toLowerCase()];
    if (priv) return priv.bonuses.cooldownReduction;
  }
  return 1;
}

function getIncomeMultiplier(user, config) {
  let mult = 1;
  if (user.privilege && user.privilegeExpires > Date.now()) {
    const priv = config.privileges[user.privilege.toLowerCase()];
    if (priv) mult *= priv.bonuses.incomeMultiplier;
  }
  return mult;
}

module.exports = {
  formatNumber,
  formatMoney,
  formatTime,
  generateBondCode,
  generateUID,
  expForLevel,
  levelFromExp,
  loadJSON,
  saveJSON,
  createBackup,
  checkCooldown,
  random,
  randomElement,
  progressBar,
  getDateKey,
  getWeekKey,
  isAdmin,
  getCooldownMultiplier,
  getIncomeMultiplier
};
