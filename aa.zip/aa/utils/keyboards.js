// ⚡ FLASH BOT — ВСЕ КЛАВИАТУРЫ
module.exports = {
  // ==================== TELEGRAM INLINE ====================
  tg: {
    // Стартовое меню
    start: {
      inline_keyboard: [
        [{ text: '✅ СОЗДАТЬ АККАУНТ', callback_data: 'auth_create' }],
        [{ text: '🔗 ПРИВЯЗАТЬ СУЩЕСТВУЮЩИЙ', callback_data: 'auth_bind' }]
      ]
    },
    
    // Главное меню
    main: {
      inline_keyboard: [
        [{ text: '👤 Профиль', callback_data: 'cmd_profile' }, { text: '💰 Баланс', callback_data: 'cmd_balance' }],
        [{ text: '🏪 Магазин', callback_data: 'cmd_shop' }, { text: '💼 Работа', callback_data: 'cmd_job' }],
        [{ text: '🎰 Казино', callback_data: 'cmd_casino' }, { text: '🏁 Гонка', callback_data: 'cmd_race' }],
        [{ text: '⚔️ Босс', callback_data: 'cmd_boss' }, { text: '🏛️ Клан', callback_data: 'cmd_clan' }]
      ]
    },
    
    // Привязка
    bind: {
      inline_keyboard: [
        [{ text: '🔄 НОВЫЙ КОД', callback_data: 'bind_newcode' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Профиль
    profile: {
      inline_keyboard: [
        [{ text: '📊 Статистика', callback_data: 'cmd_stats' }, { text: '🏆 Достижения', callback_data: 'cmd_achievements' }],
        [{ text: '📦 Инвентарь', callback_data: 'cmd_inventory' }, { text: '🎁 Рефералы', callback_data: 'cmd_referral' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Баланс
    balance: {
      inline_keyboard: [
        [{ text: '🏦 Банк', callback_data: 'cmd_bank' }, { text: '💱 Обмен', callback_data: 'cmd_exchange' }],
        [{ text: '💸 Перевести', callback_data: 'transfer_start' }, { text: '💎 Донат', callback_data: 'cmd_donate' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Банк
    bank: {
      inline_keyboard: [
        [{ text: '💰 Положить', callback_data: 'bank_dep' }, { text: '💸 Снять', callback_data: 'bank_with' }],
        [{ text: '📈 Лимит+', callback_data: 'bank_limit' }, { text: '💳 Кредит', callback_data: 'bank_credit' }],
        [{ text: '🔙 НАЗАД', callback_data: 'cmd_balance' }]
      ]
    },
    
    // Магазин
    shop: {
      inline_keyboard: [
        [{ text: '🚗 Машины', callback_data: 'shop_cars' }, { text: '🏢 Бизнесы', callback_data: 'shop_biz' }],
        [{ text: '🌾 Фермы', callback_data: 'shop_farms' }, { text: '🖨️ Принтеры', callback_data: 'shop_printers' }],
        [{ text: '📱 Телефоны', callback_data: 'shop_phones' }, { text: '🏠 Дома', callback_data: 'shop_houses' }],
        [{ text: '🐾 Питомцы', callback_data: 'shop_pets' }, { text: '📦 Кейсы', callback_data: 'shop_cases' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Работа
    job: {
      inline_keyboard: [
        [{ text: '💼 РАБОТАТЬ', callback_data: 'do_work' }],
        [{ text: '📋 Список работ', callback_data: 'job_list' }, { text: '📊 Инфо', callback_data: 'job_info' }],
        [{ text: '🚪 Уволиться', callback_data: 'job_quit' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Бизнес
    business: {
      inline_keyboard: [
        [{ text: '💰 СОБРАТЬ ВСЕ', callback_data: 'biz_collect_all' }],
        [{ text: '📋 Мои бизнесы', callback_data: 'biz_my' }, { text: '🛒 Купить', callback_data: 'shop_biz' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Фермы
    farms: {
      inline_keyboard: [
        [{ text: '₿ СОБРАТЬ ВСЕ', callback_data: 'farm_collect_all' }],
        [{ text: '📋 Мои фермы', callback_data: 'farm_my' }, { text: '🛒 Купить', callback_data: 'shop_farms' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Принтеры
    printers: {
      inline_keyboard: [
        [{ text: '💰 СОБРАТЬ ВСЕ', callback_data: 'printer_collect_all' }],
        [{ text: '📋 Мои принтеры', callback_data: 'printer_my' }, { text: '🛒 Купить', callback_data: 'shop_printers' }],
        [{ text: '⛽ Заправить', callback_data: 'printer_fuel_all' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Казино
    casino: {
      inline_keyboard: [
        [{ text: '🎰 Слоты', callback_data: 'casino_slots' }, { text: '🎯 Рулетка', callback_data: 'casino_roulette' }],
        [{ text: '🎲 Кости', callback_data: 'casino_dice' }, { text: '🃏 Карты', callback_data: 'casino_cards' }],
        [{ text: '📊 Статистика', callback_data: 'casino_stats' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Казино ставки
    casinoBet: (game) => ({
      inline_keyboard: [
        [{ text: '100$', callback_data: `${game}_100` }, { text: '1K$', callback_data: `${game}_1000` }, { text: '10K$', callback_data: `${game}_10000` }],
        [{ text: '50K$', callback_data: `${game}_50000` }, { text: '100K$', callback_data: `${game}_100000` }, { text: 'ВСЕ', callback_data: `${game}_all` }],
        [{ text: '🔙 НАЗАД', callback_data: 'cmd_casino' }]
      ]
    }),
    
    // Гонка
    race: {
      inline_keyboard: [
        [{ text: '🏁 Город', callback_data: 'race_city' }, { text: '🏔️ Горы', callback_data: 'race_mountain' }],
        [{ text: '🏖️ Пляж', callback_data: 'race_beach' }, { text: '🌲 Лес', callback_data: 'race_forest' }],
        [{ text: '🚗 Мои машины', callback_data: 'cmd_cars' }, { text: '🔧 Тюнинг', callback_data: 'cmd_tuning' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Босс
    boss: {
      inline_keyboard: [
        [{ text: '⚔️ АТАКОВАТЬ', callback_data: 'boss_attack_menu' }],
        [{ text: '📊 Статистика', callback_data: 'boss_stats' }, { text: '🏆 Топ урона', callback_data: 'boss_top' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Атака босса
    bossAttack: {
      inline_keyboard: [
        [{ text: '🗡️ МЕЧ', callback_data: 'boss_hit_sword' }, { text: '🏹 ЛУК', callback_data: 'boss_hit_bow' }, { text: '🛡️ ЩИТ', callback_data: 'boss_hit_shield' }],
        [{ text: '🔙 НАЗАД', callback_data: 'cmd_boss' }]
      ]
    },
    
    // Клан
    clan: {
      inline_keyboard: [
        [{ text: '👥 Состав', callback_data: 'clan_members' }, { text: '💰 Казна', callback_data: 'clan_treasury' }],
        [{ text: '⚔️ Война', callback_data: 'clan_war' }, { text: '🚪 Покинуть', callback_data: 'clan_leave' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Майнинг
    mining: {
      inline_keyboard: [
        [{ text: '⛏️ КОПАТЬ', callback_data: 'do_mine' }],
        [{ text: '🔧 Кирка', callback_data: 'cmd_pickaxe' }, { text: '💰 Продать руду', callback_data: 'sell_ore_all' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Выбор руды
    oreSelect: (ores) => ({
      inline_keyboard: [
        ...ores.map(ore => [{ text: ore.name, callback_data: `mine_ore_${ore.id}` }]),
        [{ text: '🎲 Случайная', callback_data: 'mine_ore_random' }],
        [{ text: '🔙 НАЗАД', callback_data: 'cmd_mining' }]
      ]
    }),
    
    // Рыбалка
    fishing: {
      inline_keyboard: [
        [{ text: '🎣 ЛОВИТЬ', callback_data: 'do_fish' }],
        [{ text: '🎣 Удочка', callback_data: 'cmd_rod' }, { text: '💰 Продать рыбу', callback_data: 'sell_fish_all' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Охота
    hunting: {
      inline_keyboard: [
        [{ text: '🏹 ОХОТИТЬСЯ', callback_data: 'do_hunt' }],
        [{ text: '💰 Продать трофеи', callback_data: 'sell_trophies_all' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Телефон
    phone: {
      inline_keyboard: [
        [{ text: '📱 Контакты', callback_data: 'phone_contacts' }, { text: '📰 Лента', callback_data: 'phone_feed' }],
        [{ text: '📝 Новый пост', callback_data: 'phone_post' }, { text: '📞 Позвонить', callback_data: 'phone_call' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Дом
    house: {
      inline_keyboard: [
        [{ text: '🏠 Инфо', callback_data: 'house_info' }, { text: '🪑 Мебель', callback_data: 'house_furniture' }],
        [{ text: '🛡️ Охрана', callback_data: 'house_security' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Питомцы
    pets: {
      inline_keyboard: [
        [{ text: '🐾 Мои питомцы', callback_data: 'pets_my' }, { text: '🛒 Купить', callback_data: 'shop_pets' }],
        [{ text: '🍖 Кормить', callback_data: 'pets_feed' }, { text: '🚶 Гулять', callback_data: 'pets_walk' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Квесты
    quests: {
      inline_keyboard: [
        [{ text: '📅 Ежедневные', callback_data: 'quests_daily' }, { text: '📆 Недельные', callback_data: 'quests_weekly' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Путь новичка
    beginnerPath: (action, cmd) => ({
      inline_keyboard: [
        [{ text: '📍 ВЫПОЛНИТЬ ЗАДАНИЕ', callback_data: `beginner_go_${action}` }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    }),
    
    // Бонус
    bonus: {
      inline_keyboard: [
        [{ text: '🎁 ПОЛУЧИТЬ', callback_data: 'bonus_daily' }],
        [{ text: '⏰ Часовой бонус', callback_data: 'bonus_hourly' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Топы
    tops: {
      inline_keyboard: [
        [{ text: '💰 Деньги', callback_data: 'top_money' }, { text: '📈 Уровень', callback_data: 'top_level' }],
        [{ text: '🏢 Бизнес', callback_data: 'top_business' }, { text: '🏛️ Кланы', callback_data: 'top_clans' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Донат
    donate: {
      inline_keyboard: [
        [{ text: '👑 VIP 50💎', callback_data: 'buy_vip' }, { text: '⭐ PREMIUM 100💎', callback_data: 'buy_premium' }],
        [{ text: '🌟 LEGEND 200💎', callback_data: 'buy_legend' }, { text: '💎 ULTIMATE 500💎', callback_data: 'buy_ultimate' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Помощь
    help: {
      inline_keyboard: [
        [{ text: '💰 Экономика', callback_data: 'help_economy' }, { text: '🎮 Игры', callback_data: 'help_games' }],
        [{ text: '👥 Социальное', callback_data: 'help_social' }, { text: '🎁 Рефералы', callback_data: 'help_ref' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Настройки
    settings: {
      inline_keyboard: [
        [{ text: '⌨️ Клавиатура ВКЛ/ВЫКЛ', callback_data: 'settings_keyboard' }],
        [{ text: '🔔 Уведомления ВКЛ/ВЫКЛ', callback_data: 'settings_notif' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Семья
    family: {
      inline_keyboard: [
        [{ text: '💍 Предложить', callback_data: 'family_propose' }, { text: '💰 Бюджет', callback_data: 'family_budget' }],
        [{ text: '💔 Развод', callback_data: 'family_divorce' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Реферал
    referral: {
      inline_keyboard: [
        [{ text: '🔗 Моя ссылка', callback_data: 'ref_link' }],
        [{ text: '📊 Статистика', callback_data: 'ref_stats' }, { text: '📋 Список', callback_data: 'ref_list' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Криминал
    criminal: {
      inline_keyboard: [
        [{ text: '🔫 Ограбить', callback_data: 'robbery_start' }, { text: '⚔️ Дуэль', callback_data: 'duel_start' }],
        [{ text: '🛡️ Защита', callback_data: 'protection_toggle' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Подтверждение
    confirm: (action) => ({
      inline_keyboard: [
        [{ text: '✅ ДА', callback_data: `confirm_${action}` }, { text: '❌ НЕТ', callback_data: 'cancel' }]
      ]
    }),
    
    // Назад
    back: (to) => ({
      inline_keyboard: [[{ text: '🔙 НАЗАД', callback_data: to }]]
    })
  },
  
  // ==================== СТАТИЧНАЯ КЛАВИАТУРА ====================
  tgReply: {
    keyboard: [
      ['👤 Профиль', '💰 Баланс', '🏪 Магазин'],
      ['⚔️ Босс', '🏁 Гонка', '💼 Работа'],
      ['🏛️ Клан', '🎰 Казино', '🎁 Бонус'],
      ['📊 Топ', '❓ Помощь', '📍 Путь новичка']
    ],
    resize_keyboard: true,
    one_time_keyboard: false
  },
  
  tgRemove: { remove_keyboard: true }
};
