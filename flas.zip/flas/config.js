// ⚡ FLASH BOT v2.0 — ПОЛНАЯ КОНФИГУРАЦИЯ
require('dotenv').config();

module.exports = {
  // ==================== ПЛАТФОРМЫ ====================
  telegram: {
    token: process.env.TG_TOKEN || '',
    adminId: parseInt(process.env.TG_ADMIN_ID) || 0,
    botUsername: process.env.TG_BOT_USERNAME || 'flashbot'
  },
  
  vk: {
    token: process.env.VK_TOKEN || '',
    adminId: parseInt(process.env.VK_ADMIN_ID) || 0,
    groupId: parseInt(process.env.VK_GROUP_ID) || 0
  },
  
  // ==================== ИГРОВЫЕ НАСТРОЙКИ ====================
  game: {
    startMoney: 1000,
    startEnergy: 100,
    maxEnergy: 100,
    energyRegenMinutes: 5,
    bondCodeExpireMinutes: 5,
    minTransfer: 100,
    transferFee: 0.03,
    
    cooldowns: {
      work: 300,
      mining: 180,
      fishing: 600,
      hunting: 1200,
      race: 300,
      boss: 120,
      robbery: 1800,
      duel: 600,
      bonus: 86400,
      hourlyBonus: 10800,
      businessCollect: 1800,
      farmCollect: 900,
      printerCollect: 600,
      clanAttack: 3600,
      fortune: 43200,
      hobby: 1800,
      petWalk: 3600,
      call: 300,
      trade: 60,
      dice: 30,
      cup: 30,
      coinflip: 30,
      arena: 600,
      crime: 900,
      heist: 7200,
      lottery: 3600
    },
    
    energyCosts: {
      race: 5,
      boss: 3,
      duel: 8,
      robbery: 15,
      clanAttack: 10,
      tournament: 15,
      hobby: 5,
      petWalk: 5,
      caseOpen: 1,
      hunting: 10,
      arena: 5,
      heist: 20
    }
  },
  
  // ==================== РАБОТЫ ====================
  jobs: [
    { id: 1, name: '🧹 Уборщик', salary: 500, minLevel: 1, description: 'Уборка помещений' },
    { id: 2, name: '📦 Грузчик', salary: 800, minLevel: 3, description: 'Погрузка и разгрузка' },
    { id: 3, name: '🚕 Таксист', salary: 1200, minLevel: 5, description: 'Перевозка пассажиров' },
    { id: 4, name: '👷 Строитель', salary: 1800, minLevel: 8, description: 'Строительные работы' },
    { id: 5, name: '🔧 Механик', salary: 2500, minLevel: 12, description: 'Ремонт техники' },
    { id: 6, name: '💼 Менеджер', salary: 3500, minLevel: 16, description: 'Управление проектами' },
    { id: 7, name: '👨‍💻 Программист', salary: 5000, minLevel: 20, description: 'Разработка ПО' },
    { id: 8, name: '👨‍⚕️ Врач', salary: 7000, minLevel: 25, description: 'Лечение пациентов' },
    { id: 9, name: '👨‍✈️ Пилот', salary: 10000, minLevel: 30, description: 'Управление самолётом' },
    { id: 10, name: '🎬 Директор', salary: 15000, minLevel: 40, description: 'Руководство компанией' },
    { id: 11, name: '👨‍🔬 Учёный', salary: 20000, minLevel: 50, description: 'Научные исследования' },
    { id: 12, name: '🎭 Актёр', salary: 25000, minLevel: 60, description: 'Съёмки в кино' }
  ],
  
  // ==================== БИЗНЕСЫ ====================
  businesses: [
    { id: 1, name: '🏪 Ларёк', price: 50000, income: 1000, maxLevel: 10, upgradePrice: 5000 },
    { id: 2, name: '☕ Кофейня', price: 150000, income: 3000, maxLevel: 10, upgradePrice: 15000 },
    { id: 3, name: '🍕 Пиццерия', price: 300000, income: 6000, maxLevel: 10, upgradePrice: 30000 },
    { id: 4, name: '🏨 Отель', price: 500000, income: 10000, maxLevel: 10, upgradePrice: 50000 },
    { id: 5, name: '🏢 Офис', price: 1000000, income: 20000, maxLevel: 10, upgradePrice: 100000 },
    { id: 6, name: '🏭 Завод', price: 2000000, income: 40000, maxLevel: 10, upgradePrice: 200000 },
    { id: 7, name: '🎰 Казино', price: 5000000, income: 100000, maxLevel: 10, upgradePrice: 500000 },
    { id: 8, name: '🏦 Банк', price: 10000000, income: 200000, maxLevel: 10, upgradePrice: 1000000 },
    { id: 9, name: '🛢️ Нефтезавод', price: 25000000, income: 500000, maxLevel: 10, upgradePrice: 2500000 },
    { id: 10, name: '💎 Алмазная шахта', price: 50000000, income: 1000000, maxLevel: 10, upgradePrice: 5000000 }
  ],
  
  donatBusinesses: [
    { id: 101, name: '💎 VIP Клуб', price: 100, income: 50000, maxLevel: 20, upgradePrice: 10 },
    { id: 102, name: '🌟 Элитный Отель', price: 250, income: 150000, maxLevel: 20, upgradePrice: 25 },
    { id: 103, name: '👑 Империя', price: 500, income: 400000, maxLevel: 20, upgradePrice: 50 }
  ],
  
  // ==================== МАШИНЫ ====================
  cars: [
    { id: 1, name: '🚗 Жигули', price: 10000, speed: 100 },
    { id: 2, name: '🚙 Toyota Camry', price: 50000, speed: 150 },
    { id: 3, name: '🚙 Volkswagen', price: 80000, speed: 170 },
    { id: 4, name: '🏎️ BMW M5', price: 150000, speed: 200 },
    { id: 5, name: '🏎️ Mercedes AMG', price: 300000, speed: 250 },
    { id: 6, name: '🏎️ Audi RS7', price: 400000, speed: 280 },
    { id: 7, name: '🏎️ Porsche 911', price: 500000, speed: 300 },
    { id: 8, name: '🏎️ Ferrari 488', price: 1000000, speed: 350 },
    { id: 9, name: '🏎️ Lamborghini Huracán', price: 2000000, speed: 400 },
    { id: 10, name: '🏎️ Bugatti Chiron', price: 5000000, speed: 450 },
    { id: 11, name: '🏎️ Koenigsegg Jesko', price: 10000000, speed: 500 },
    { id: 12, name: '🚀 Космолёт', price: 50000000, speed: 1000 }
  ],
  
  // ==================== ФЕРМЫ ====================
  farms: [
    { id: 1, name: '⚡ Базовая ферма', price: 100000, btcPerHour: 0.0001, maxCount: 5 },
    { id: 2, name: '⚡ Продвинутая ферма', price: 500000, btcPerHour: 0.0005, maxCount: 3 },
    { id: 3, name: '⚡ Мега ферма', price: 2000000, btcPerHour: 0.002, maxCount: 2 },
    { id: 4, name: '⚡ Ультра ферма', price: 10000000, btcPerHour: 0.01, maxCount: 1 },
    { id: 5, name: '⚡ Квантовая ферма', price: 50000000, btcPerHour: 0.05, maxCount: 1 }
  ],
  
  // ==================== ПРИНТЕРЫ ====================
  printers: [
    { id: 1, name: '🖨️ Базовый', price: 50000, income: 500, fuelCost: 100, maxLevel: 10, maxCount: 5 },
    { id: 2, name: '🖨️ Продвинутый', price: 200000, income: 2000, fuelCost: 300, maxLevel: 10, maxCount: 3 },
    { id: 3, name: '🖨️ Промышленный', price: 1000000, income: 10000, fuelCost: 1000, maxLevel: 10, maxCount: 2 },
    { id: 4, name: '🖨️ Фабрика', price: 5000000, income: 50000, fuelCost: 5000, maxLevel: 10, maxCount: 1 }
  ],
  
  // ==================== РУДЫ ====================
  ores: [
    { id: 1, name: '�ite Камень', price: 10, minLevel: 1, chance: 30 },
    { id: 2, name: '⬛ Уголь', price: 25, minLevel: 3, chance: 25 },
    { id: 3, name: '🔶 Медь', price: 50, minLevel: 5, chance: 20 },
    { id: 4, name: '⬜ Железо', price: 100, minLevel: 8, chance: 15 },
    { id: 5, name: '🟡 Золото', price: 250, minLevel: 12, chance: 7 },
    { id: 6, name: '💎 Алмаз', price: 500, minLevel: 18, chance: 2 },
    { id: 7, name: '💠 Изумруд', price: 1000, minLevel: 25, chance: 1 }
  ],
  
  // ==================== РЫБА ====================
  fishes: [
    { id: 1, name: '🐟 Карась', price: 50, chance: 30 },
    { id: 2, name: '🐠 Окунь', price: 100, chance: 25 },
    { id: 3, name: '🐡 Щука', price: 200, chance: 20 },
    { id: 4, name: '🦈 Сом', price: 350, chance: 15 },
    { id: 5, name: '🐋 Осётр', price: 500, chance: 8 },
    { id: 6, name: '🐙 Золотая рыбка', price: 1000, chance: 2 }
  ],
  
  // ==================== ЖИВОТНЫЕ ====================
  animals: [
    { id: 1, name: '🐰 Заяц', price: 100, chance: 30 },
    { id: 2, name: '🦊 Лиса', price: 200, chance: 25 },
    { id: 3, name: '🐗 Кабан', price: 350, chance: 20 },
    { id: 4, name: '🦌 Олень', price: 500, chance: 15 },
    { id: 5, name: '🐻 Медведь', price: 1000, chance: 8 },
    { id: 6, name: '🦁 Лев', price: 2000, chance: 2 }
  ],
  
  // ==================== ПИТОМЦЫ ====================
  pets: [
    { id: 1, name: '🐕 Собака', price: 10000, bonus: 5, feedCost: 500 },
    { id: 2, name: '🐈 Кошка', price: 8000, bonus: 3, feedCost: 300 },
    { id: 3, name: '🐦 Попугай', price: 15000, bonus: 7, feedCost: 400 },
    { id: 4, name: '🐹 Хомяк', price: 5000, bonus: 2, feedCost: 200 },
    { id: 5, name: '🐢 Черепаха', price: 12000, bonus: 5, feedCost: 300 },
    { id: 6, name: '🦎 Ящерица', price: 20000, bonus: 10, feedCost: 600 },
    { id: 7, name: '🐍 Змея', price: 25000, bonus: 12, feedCost: 700 },
    { id: 8, name: '🦅 Орёл', price: 50000, bonus: 20, feedCost: 1000 },
    { id: 9, name: '🐉 Дракон', price: 500000, bonus: 50, feedCost: 5000 },
    { id: 10, name: '🦄 Единорог', price: 1000000, bonus: 100, feedCost: 10000 }
  ],
  
  // ==================== ДОМА ====================
  houses: [
    { id: 1, name: '🏚️ Хижина', price: 50000, slots: 1 },
    { id: 2, name: '🏠 Дом', price: 200000, slots: 2 },
    { id: 3, name: '🏡 Коттедж', price: 500000, slots: 3 },
    { id: 4, name: '🏘️ Вилла', price: 1500000, slots: 5 },
    { id: 5, name: '🏰 Особняк', price: 5000000, slots: 10 },
    { id: 6, name: '🏯 Дворец', price: 20000000, slots: 20 }
  ],
  
  // ==================== ТЕЛЕФОНЫ ====================
  phones: [
    { id: 1, name: '📱 Nokia 3310', price: 1000 },
    { id: 2, name: '📱 Samsung A52', price: 20000 },
    { id: 3, name: '📱 iPhone 13', price: 50000 },
    { id: 4, name: '📱 iPhone 15 Pro', price: 100000 },
    { id: 5, name: '📱 Vertu', price: 500000 }
  ],
  
  // ==================== ЯХТЫ ====================
  yachts: [
    { id: 1, name: '⛵ Лодка', price: 100000 },
    { id: 2, name: '🚤 Катер', price: 500000 },
    { id: 3, name: '🛥️ Яхта', price: 2000000 },
    { id: 4, name: '🚢 Круизный лайнер', price: 10000000 }
  ],
  
  // ==================== САМОЛЁТЫ ====================
  planes: [
    { id: 1, name: '🪂 Параплан', price: 50000 },
    { id: 2, name: '🛩️ Cessna', price: 500000 },
    { id: 3, name: '✈️ Боинг', price: 5000000 },
    { id: 4, name: '🛸 Частный джет', price: 25000000 }
  ],
  
  // ==================== ВЕРТОЛЁТЫ ====================
  helicopters: [
    { id: 1, name: '🚁 Robinson', price: 300000 },
    { id: 2, name: '🚁 Bell', price: 1000000 },
    { id: 3, name: '🚁 Airbus H160', price: 5000000 }
  ],
  
  // ==================== КЕЙСЫ ====================
  cases: [
    { id: 1, name: '📦 Обычный кейс', price: 1000, rewards: [500, 1000, 2000, 5000] },
    { id: 2, name: '📦 Редкий кейс', price: 5000, rewards: [2500, 5000, 10000, 25000] },
    { id: 3, name: '📦 Эпический кейс', price: 20000, rewards: [10000, 25000, 50000, 100000] },
    { id: 4, name: '📦 Легендарный кейс', price: 100000, rewards: [50000, 100000, 250000, 500000] },
    { id: 5, name: '📦 Мифический кейс', price: 500000, rewards: [250000, 500000, 1000000, 2500000] }
  ],
  
  // ==================== ПРИВИЛЕГИИ ====================
  privileges: {
    vip: {
      name: 'VIP',
      price: 50,
      bonuses: { incomeMultiplier: 1.2, casinoChanceBonus: 5, raceCupsMultiplier: 1.5, cooldownReduction: 0.9, maxBusinesses: 2 }
    },
    premium: {
      name: 'PREMIUM',
      price: 100,
      bonuses: { incomeMultiplier: 1.5, casinoChanceBonus: 10, raceCupsMultiplier: 2, cooldownReduction: 0.75, maxBusinesses: 3 }
    },
    legend: {
      name: 'LEGEND',
      price: 200,
      bonuses: { incomeMultiplier: 2, casinoChanceBonus: 15, raceCupsMultiplier: 2.5, cooldownReduction: 0.5, maxBusinesses: 4 }
    },
    ultimate: {
      name: 'ULTIMATE',
      price: 500,
      bonuses: { incomeMultiplier: 3, casinoChanceBonus: 20, raceCupsMultiplier: 3, cooldownReduction: 0.25, maxBusinesses: 5 }
    }
  },
  
  // ==================== ПУТЬ НОВИЧКА ====================
  beginnerPath: [
    { stage: 1, task: 'Написать сообщение', reward: { money: 1000, exp: 50 }, action: 'message', cmd: 'профиль' },
    { stage: 2, task: 'Получить бонус', reward: { money: 2000, exp: 100 }, action: 'bonus', cmd: 'бонус' },
    { stage: 3, task: 'Пополнить банк', reward: { money: 3000, exp: 150 }, action: 'bank', cmd: 'банк положить 100' },
    { stage: 4, task: 'Купить машину', reward: { money: 5000, exp: 200 }, action: 'car', cmd: 'машина купить 1' },
    { stage: 5, task: 'Устроиться на работу', reward: { money: 8000, exp: 250 }, action: 'job', cmd: 'работа 1' },
    { stage: 6, task: 'Отработать смену', reward: { money: 10000, exp: 300 }, action: 'work', cmd: 'работать' },
    { stage: 7, task: 'Купить бизнес', reward: { money: 15000, exp: 400 }, action: 'business', cmd: 'бизнес купить 1' },
    { stage: 8, task: 'Собрать бизнес', reward: { money: 20000, exp: 500 }, action: 'collect', cmd: 'бизнес собрать 1' },
    { stage: 9, task: 'Атаковать босса', reward: { money: 30000, exp: 750 }, action: 'boss', cmd: 'босс атака' },
    { stage: 10, task: 'Накопить 100,000$', reward: { money: 100000, exp: 2000, diamonds: 10 }, action: 'rich', cmd: 'баланс' }
  ],
  
  // ==================== ЕЖЕДНЕВНЫЕ КВЕСТЫ ====================
  dailyQuests: [
    { id: 1, name: 'Заработать 10,000$', target: 10000, type: 'earn', reward: { money: 2000, exp: 50 } },
    { id: 2, name: 'Выиграть 3 гонки', target: 3, type: 'race_wins', reward: { money: 5000, exp: 100, cups: 5 } },
    { id: 3, name: 'Атаковать босса 5 раз', target: 5, type: 'boss_attacks', reward: { money: 3000, exp: 75 } },
    { id: 4, name: 'Поймать 10 рыб', target: 10, type: 'fish', reward: { money: 2000, exp: 50 } },
    { id: 5, name: 'Ограбить 2 игроков', target: 2, type: 'robberies', reward: { money: 4000, exp: 100 } },
    { id: 6, name: 'Собрать бизнес 3 раза', target: 3, type: 'business_collect', reward: { money: 3000, exp: 75 } },
    { id: 7, name: 'Сделать 5 ставок', target: 5, type: 'casino_bets', reward: { money: 2000, exp: 50 } },
    { id: 8, name: 'Поработать 2 смены', target: 2, type: 'work_shifts', reward: { money: 3000, exp: 75 } }
  ],
  
  // ==================== НЕДЕЛЬНЫЕ КВЕСТЫ ====================
  weeklyQuests: [
    { id: 1, name: 'Заработать 100,000$', target: 100000, type: 'earn', reward: { money: 20000, exp: 500, diamonds: 5 } },
    { id: 2, name: 'Выиграть 20 гонок', target: 20, type: 'race_wins', reward: { money: 50000, exp: 1000, cups: 50 } },
    { id: 3, name: 'Нанести 100,000 урона боссу', target: 100000, type: 'boss_damage', reward: { money: 30000, exp: 750 } },
    { id: 4, name: 'Выиграть 10 дуэлей', target: 10, type: 'duel_wins', reward: { money: 25000, exp: 500, diamonds: 3 } }
  ],
  
  // ==================== ДОСТИЖЕНИЯ ====================
  achievements: [
    { id: 1, name: '👣 Первые шаги', desc: 'Создать аккаунт', reward: { money: 1000, exp: 100 } },
    { id: 2, name: '💰 Миллионер', desc: 'Накопить 1,000,000$', reward: { money: 50000, exp: 500, diamonds: 10 } },
    { id: 3, name: '🏁 Гонщик', desc: 'Выиграть 100 гонок', reward: { money: 25000, exp: 300, cups: 50 } },
    { id: 4, name: '⚔️ Охотник на боссов', desc: 'Нанести 1,000,000 урона', reward: { money: 30000, exp: 400 } },
    { id: 5, name: '🏢 Магнат', desc: 'Купить 5 бизнесов', reward: { money: 100000, exp: 1000, diamonds: 20 } },
    { id: 6, name: '⛏️ Шахтёр', desc: 'Добыть 10,000 руды', reward: { money: 20000, exp: 250 } },
    { id: 7, name: '🎣 Рыболов', desc: 'Поймать 500 рыб', reward: { money: 15000, exp: 200 } },
    { id: 8, name: '📈 Ветеран', desc: 'Достичь 50 уровня', reward: { money: 200000, exp: 2000, diamonds: 50 } },
    { id: 9, name: '💎 Коллекционер', desc: 'Собрать 100 алмазов', reward: { money: 50000, exp: 500 } },
    { id: 10, name: '🏛️ Лидер', desc: 'Создать клан', reward: { money: 25000, exp: 300 } }
  ],
  
  // ==================== СОБЫТИЯ ====================
  events: [
    { id: 1, name: '💰 x2 Заработок', type: 'income_boost', multiplier: 2, duration: 3600 },
    { id: 2, name: '⚡ x2 Опыт', type: 'exp_boost', multiplier: 2, duration: 3600 },
    { id: 3, name: '🎰 Удача казино +20%', type: 'casino_boost', bonus: 20, duration: 1800 },
    { id: 4, name: '⏰ Кулдауны -50%', type: 'cooldown_reduction', multiplier: 0.5, duration: 1800 }
  ],
  
  // ==================== БОССЫ ====================
  bosses: [
    { name: '🐉 Дракон', minHp: 50000, maxHp: 100000, reward: 50000 },
    { name: '👹 Демон', minHp: 100000, maxHp: 200000, reward: 100000 },
    { name: '🧟 Зомби-гигант', minHp: 200000, maxHp: 400000, reward: 200000 },
    { name: '👾 Инопланетянин', minHp: 400000, maxHp: 800000, reward: 400000 },
    { name: '🤖 Мега-робот', minHp: 800000, maxHp: 1500000, reward: 800000 }
  ],
  
  // ==================== АНЕКДОТЫ ====================
  jokes: [
    "Программист спрашивает у Google: «Как выйти из Vim?» Google отвечает: «У вас нет прав.»",
    "— Папа, а почему солнце встаёт на востоке? — Оно там живёт.",
    "Встретились два друга. Один говорит: — Я вчера видел летающую тарелку! — И что? — Упала и разбилась.",
    "— Официант, у вас мухи в супе! — Тише, а то все попросят!",
    "Студент на экзамене: «Профессор, я заслуживаю больше, чем единица!» — «Согласен, но ниже ставить нечего.»",
    "— Доктор, у меня болит везде! — Покажите пальцем. — Вот тут болит, вот тут... — У вас сломан палец.",
    "Муж говорит жене: — Дорогая, ты похудела! — Нет, я просто далеко стою.",
    "— Почему программисты путают Хэллоуин и Рождество? — Потому что Oct 31 = Dec 25.",
    "Заходит улитка в бар. Бармен её выгоняет. Через неделю улитка: — За что?!",
    "— Что общего между программистом и пилотом? — Оба боятся Java."
  ],
  
  // ==================== ОТВЕТЫ ШАРА ====================
  ballAnswers: [
    "✅ Бесспорно!",
    "✅ Да, определённо!",
    "✅ Можешь быть уверен в этом.",
    "✅ Мне кажется — да.",
    "✅ Вероятнее всего.",
    "🤔 Пока не ясно, попробуй снова.",
    "🤔 Спроси позже.",
    "🤔 Лучше не рассказывать.",
    "🤔 Сейчас нельзя предсказать.",
    "❌ Не рассчитывай на это.",
    "❌ Мой ответ — нет.",
    "❌ Весьма сомнительно.",
    "❌ По моим данным — нет.",
    "❌ Перспективы не очень хорошие."
  ],
  
  // ==================== ФРАЗЫ БОТА ====================
  phrases: {
    welcome: "⚡ Добро пожаловать в FLASH BOT!",
    notRegistered: "❌ Вы не зарегистрированы! Напишите «старт»",
    noMoney: "❌ Недостаточно денег!",
    cooldown: "⏰ Подождите ещё",
    error: "❌ Произошла ошибка!"
  }
};
