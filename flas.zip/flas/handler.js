// ⚡ FLASH BOT v2.0 — ГЛАВНЫЙ ОБРАБОТЧИК
const db = require('./utils/database');
const keyboards = require('./utils/keyboards');
const config = require('./config');
const { 
  formatMoney, formatNumber, formatTime, formatDate,
  checkCooldown, random, randomElement, randomChance,
  levelFromExp, progressBar, isAdmin, parseAmount,
  reverseString, calculateMath, getCooldownMultiplier, getIncomeMultiplier
} = require('./utils/helpers');

// ==================== МАППИНГ КНОПОК ====================
const keyboardMap = {
  '👤 профиль': 'профиль', '👤 Профиль': 'профиль',
  '💰 баланс': 'баланс', '💰 Баланс': 'баланс',
  '🏪 магазин': 'магазин', '🏪 Магазин': 'магазин',
  '⚔️ босс': 'босс', '⚔️ Босс': 'босс',
  '🏁 гонка': 'гонка', '🏁 Гонка': 'гонка',
  '💼 работа': 'работа', '💼 Работа': 'работа',
  '🏛️ клан': 'клан', '🏛️ Клан': 'клан',
  '🎰 казино': 'казино', '🎰 Казино': 'казино',
  '🎁 бонус': 'бонус', '🎁 Бонус': 'бонус',
  '📊 топ': 'топ', '📊 Топ': 'топ',
  '❓ помощь': 'помощь', '❓ Помощь': 'помощь',
  '📍 путь': 'путь новичка', '📍 Путь': 'путь новичка'
};

// ==================== ГЛАВНАЯ ФУНКЦИЯ ОБРАБОТКИ ====================
async function handleMessage(ctx) {
  try {
    // Обрабатываем callback
    if (ctx.callbackData) {
      return await handleCallback(ctx);
    }
    
    // Преобразуем текст кнопки в команду
    let text = ctx.text?.trim() || '';
    if (keyboardMap[text]) {
      text = keyboardMap[text];
    }
    
    const lowerText = text.toLowerCase();
    const args = text.split(/\s+/);
    const command = args[0].toLowerCase();
    
    // Увеличиваем счётчик сообщений
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (user) {
      user.stats.messagesCount++;
    }
    
    // ==================== КОМАНДЫ БЕЗ РЕГИСТРАЦИИ ====================
    
    if (command === 'старт' || command === 'start' || command === '/start') {
      return await commands.start(ctx, args[1]);
    }
    
    if (command === 'код' || command === 'code') {
      return await commands.useCode(ctx, args[1]);
    }
    
    if (command === 'помощь' || command === 'help' || command === 'хелп') {
      return commands.help(ctx);
    }
    
    if (command === 'правила' || command === 'rules') {
      return commands.rules(ctx);
    }
    
    if (command === 'инфо' || command === 'info') {
      return commands.info(ctx);
    }
    
    // ==================== РАЗВЛЕКАТЕЛЬНЫЕ КОМАНДЫ ====================
    
    if (command === 'анекдот' || command === 'шутка' || command === 'joke') {
      return commands.joke(ctx);
    }
    
    if (command === 'шар' || command === '8ball') {
      return commands.ball(ctx, args.slice(1).join(' '));
    }
    
    if (command === 'переверни' || command === 'reverse') {
      return commands.reverse(ctx, args.slice(1).join(' '));
    }
    
    if (command === 'выбери' || command === 'choose') {
      return commands.choose(ctx, args.slice(1).join(' '));
    }
    
    if (command === 'инфа' || command === 'вероятность') {
      return commands.probability(ctx, args.slice(1).join(' '));
    }
    
    if (command === 'реши' || command === 'calc' || command === 'калькулятор') {
      return commands.calculate(ctx, args.slice(1).join(' '));
    }
    
    if (command === 'курс' || command === 'btc' || command === 'биткоин') {
      return commands.btcRate(ctx);
    }
    
    // ==================== КОМАНДЫ С РЕГИСТРАЦИЕЙ ====================
    
    // Проверка регистрации
    if (!user) {
      if (['профиль', 'profile', 'баланс', 'balance', 'работа', 'work', 'бизнес', 'business'].includes(command)) {
        return { text: '❌ Вы не зарегистрированы!\n\nНапишите «старт» для создания аккаунта.', keyboard: keyboards.tg.start };
      }
      return null; // Игнорируем другие команды от незарегистрированных
    }
    
    // Проверка бана
    if (user.banned) {
      return { text: `🚫 ВЫ ЗАБЛОКИРОВАНЫ\n━━━━━━━━━━━━━━━━━━━━\n📝 Причина: ${user.banReason || 'Не указана'}` };
    }
    
    // ==================== ПРОФИЛЬ И СТАТИСТИКА ====================
    
    if (command === 'профиль' || command === 'profile' || command === 'я') {
      return commands.profile(ctx, args[1]);
    }
    
    if (command === 'статистика' || command === 'stats' || command === 'стата') {
      return commands.stats(ctx);
    }
    
    if (command === 'достижения' || command === 'achievements' || command === 'ачивки') {
      return commands.achievements(ctx);
    }
    
    if (command === 'инвентарь' || command === 'inventory' || command === 'рюкзак') {
      return commands.inventory(ctx);
    }
    
    if (command === 'уровень' || command === 'level' || command === 'lvl') {
      return commands.level(ctx);
    }
    
    if (command === 'энергия' || command === 'energy') {
      return commands.energy(ctx);
    }
    
    if (command === 'ник' || command === 'nick') {
      return commands.nick(ctx, args.slice(1).join(' '));
    }
    
    // ==================== ФИНАНСЫ ====================
    
    if (command === 'баланс' || command === 'balance' || command === 'бал') {
      return commands.balance(ctx);
    }
    
    if (command === 'банк' || command === 'bank') {
      if (args[1] === 'положить' || args[1] === 'dep' || args[1] === 'deposit') {
        return commands.bankDeposit(ctx, args[2]);
      }
      if (args[1] === 'снять' || args[1] === 'with' || args[1] === 'withdraw') {
        return commands.bankWithdraw(ctx, args[2]);
      }
      if (args[1] === 'лимит' || args[1] === 'limit') {
        return commands.bankLimit(ctx);
      }
      if (args[1] === 'кредит' || args[1] === 'credit') {
        if (args[2] === 'взять') {
          return commands.bankCreditTake(ctx, args[3]);
        }
        if (args[2] === 'вернуть') {
          return commands.bankCreditReturn(ctx);
        }
        return commands.bankCredit(ctx);
      }
      return commands.bank(ctx);
    }
    
    if (command === 'перевод' || command === 'передать' || command === 'pay' || command === 'transfer') {
      return commands.transfer(ctx, args[1], args[2]);
    }
    
    if (command === 'обмен' || command === 'exchange') {
      return commands.exchange(ctx, args[1], args[2]);
    }
    
    // ==================== РАБОТА ====================
    
    if (command === 'работа' || command === 'job') {
      if (args[1] === 'список' || args[1] === 'list') {
        return commands.jobList(ctx);
      }
      if (args[1] && !isNaN(args[1])) {
        return commands.jobApply(ctx, args[1]);
      }
      return commands.job(ctx);
    }
    
    if (command === 'работать' || command === 'work') {
      return commands.work(ctx);
    }
    
    if (command === 'уволиться' || command === 'quit') {
      return commands.jobQuit(ctx);
    }
    
    // ==================== БИЗНЕС ====================
    
    if (command === 'бизнес' || command === 'business' || command === 'биз') {
      if (args[1] === 'список' || args[1] === 'list') {
        return commands.businessList(ctx);
      }
      if (args[1] === 'купить' || args[1] === 'buy') {
        return commands.businessBuy(ctx, args[2]);
      }
      if (args[1] === 'собрать' || args[1] === 'collect') {
        if (args[2] === 'все' || args[2] === 'all' || !args[2]) {
          return commands.businessCollectAll(ctx);
        }
        return commands.businessCollect(ctx, args[2]);
      }
      if (args[1] === 'улучшить' || args[1] === 'upgrade') {
        return commands.businessUpgrade(ctx, args[2]);
      }
      if (args[1] === 'продать' || args[1] === 'sell') {
        return commands.businessSell(ctx, args[2]);
      }
      return commands.business(ctx);
    }
    
    // ==================== ФЕРМЫ ====================
    
    if (command === 'ферма' || command === 'farm' || command === 'фермы') {
      if (args[1] === 'список' || args[1] === 'list') {
        return commands.farmList(ctx);
      }
      if (args[1] === 'купить' || args[1] === 'buy') {
        return commands.farmBuy(ctx, args[2]);
      }
      if (args[1] === 'собрать' || args[1] === 'collect' || !args[1]) {
        return commands.farmCollect(ctx);
      }
      return commands.farm(ctx);
    }
    
    // ==================== ПРИНТЕРЫ ====================
    
    if (command === 'принтер' || command === 'printer' || command === 'принтеры') {
      if (args[1] === 'список' || args[1] === 'list') {
        return commands.printerList(ctx);
      }
      if (args[1] === 'купить' || args[1] === 'buy') {
        return commands.printerBuy(ctx, args[2]);
      }
      if (args[1] === 'собрать' || args[1] === 'collect' || !args[1]) {
        return commands.printerCollect(ctx);
      }
      if (args[1] === 'заправить' || args[1] === 'fuel') {
        return commands.printerFuel(ctx, args[2]);
      }
      return commands.printer(ctx);
    }
    
    // ==================== МАШИНЫ ====================
    
    if (command === 'машина' || command === 'машины' || command === 'car' || command === 'cars') {
      if (args[1] === 'список' || args[1] === 'list') {
        return commands.carList(ctx);
      }
      if (args[1] === 'купить' || args[1] === 'buy') {
        return commands.carBuy(ctx, args[2]);
      }
      if (args[1] === 'выбрать' || args[1] === 'select') {
        return commands.carSelect(ctx, args[2]);
      }
      if (args[1] === 'продать' || args[1] === 'sell') {
        return commands.carSell(ctx, args[2]);
      }
      return commands.cars(ctx);
    }
    
    if (command === 'тюнинг' || command === 'tuning') {
      return commands.tuning(ctx, args[1]);
    }
    
    // ==================== ГОНКИ ====================
    
    if (command === 'гонка' || command === 'race' || command === 'гонки') {
      return commands.race(ctx);
    }
    
    // ==================== БОСС ====================
    
    if (command === 'босс' || command === 'boss') {
      if (args[1] === 'атака' || args[1] === 'attack' || args[1] === 'атаковать') {
        return commands.bossAttack(ctx);
      }
      if (args[1] === 'топ' || args[1] === 'top') {
        return commands.bossTop(ctx);
      }
      return commands.boss(ctx);
    }
    
    // ==================== КАЗИНО ====================
    
    if (command === 'казино' || command === 'casino') {
      if (args[1]) {
        return commands.casinoSlots(ctx, args[1]);
      }
      return commands.casino(ctx);
    }
    
    if (command === 'слоты' || command === 'slots') {
      return commands.casinoSlots(ctx, args[1]);
    }
    
    if (command === 'рулетка' || command === 'roulette') {
      return commands.casinoRoulette(ctx, args[1], args[2]);
    }
    
    if (command === 'кости' || command === 'dice') {
      return commands.casinoDice(ctx, args[1], args[2]);
    }
    
    if (command === 'монетка' || command === 'coin' || command === 'coinflip') {
      return commands.casinoCoin(ctx, args[1], args[2]);
    }
    
    // ==================== МИНИ-ИГРЫ ====================
    
    if (command === 'трейд' || command === 'trade') {
      return commands.trade(ctx, args[1], args[2]);
    }
    
    if (command === 'кубик' || command === 'cube') {
      return commands.gameDice(ctx, args[1], args[2]);
    }
    
    if (command === 'стаканчик' || command === 'стаканчики' || command === 'cup') {
      return commands.gameCup(ctx, args[1], args[2]);
    }
    
    if (command === 'дуэль' || command === 'duel') {
      return commands.duel(ctx, args[1], args[2]);
    }
    
    // ==================== ДОБЫЧА ====================
    
    if (command === 'копать' || command === 'mine' || command === 'шахта') {
      return commands.mine(ctx);
    }
    
    if (command === 'рыбалка' || command === 'fishing' || command === 'ловить') {
      return commands.fish(ctx);
    }
    
    if (command === 'охота' || command === 'hunt' || command === 'охотиться') {
      return commands.hunt(ctx);
    }
    
    if (command === 'продать') {
      if (args[1] === 'руду' || args[1] === 'руды') {
        return commands.sellOres(ctx);
      }
      if (args[1] === 'рыбу' || args[1] === 'рыба') {
        return commands.sellFish(ctx);
      }
      if (args[1] === 'трофеи' || args[1] === 'трофей') {
        return commands.sellTrophies(ctx);
      }
      if (args[1] === 'биткоины' || args[1] === 'btc') {
        return commands.sellBitcoin(ctx, args[2]);
      }
      if (args[1] === 'рейтинг') {
        return commands.sellRating(ctx, args[2]);
      }
      return { text: '❌ Что продать? руду / рыбу / трофеи / биткоины / рейтинг' };
    }
    
    // ==================== КЛАН ====================
    
    if (command === 'клан' || command === 'clan') {
      if (args[1] === 'создать' || args[1] === 'create') {
        return commands.clanCreate(ctx, args.slice(2).join(' '));
      }
      if (args[1] === 'вступить' || args[1] === 'join') {
        return commands.clanJoin(ctx, args[2]);
      }
      if (args[1] === 'покинуть' || args[1] === 'leave') {
        return commands.clanLeave(ctx);
      }
      if (args[1] === 'пополнить' || args[1] === 'deposit') {
        return commands.clanDeposit(ctx, args[2]);
      }
      if (args[1] === 'состав' || args[1] === 'members') {
        return commands.clanMembers(ctx);
      }
      return commands.clan(ctx);
    }
    
    if (command === 'кланы' || command === 'clans') {
      return commands.clansList(ctx);
    }
    
    // ==================== БОНУСЫ ====================
    
    if (command === 'бонус' || command === 'bonus') {
      return commands.bonus(ctx);
    }
    
    if (command === 'промокод' || command === 'promo') {
      return commands.promoCode(ctx, args[1]);
    }
    
    // ==================== КВЕСТЫ ====================
    
    if (command === 'квесты' || command === 'quests' || command === 'задания') {
      if (args[1] === 'ежедневные' || args[1] === 'daily') {
        return commands.questsDaily(ctx);
      }
      if (args[1] === 'недельные' || args[1] === 'weekly') {
        return commands.questsWeekly(ctx);
      }
      if (args[1] === 'сдать' || args[1] === 'claim') {
        return commands.questClaim(ctx, args[2]);
      }
      return commands.quests(ctx);
    }
    
    // ==================== ПУТЬ НОВИЧКА ====================
    
    if (lowerText.includes('путь') || command === 'beginner') {
      return commands.beginnerPath(ctx);
    }
    
    // ==================== ТОПЫ ====================
    
    if (command === 'топ' || command === 'top' || command === 'рейтинг') {
      if (args[1] === 'деньги' || args[1] === 'money' || args[1] === 'богачи') {
        return commands.topMoney(ctx);
      }
      if (args[1] === 'уровень' || args[1] === 'level' || args[1] === 'lvl') {
        return commands.topLevel(ctx);
      }
      if (args[1] === 'кланы' || args[1] === 'clans') {
        return commands.topClans(ctx);
      }
      if (args[1] === 'рейтинг' || args[1] === 'rating') {
        return commands.topRating(ctx);
      }
      return commands.top(ctx);
    }
    
    // ==================== МАГАЗИН ====================
    
    if (command === 'магазин' || command === 'shop' || command === 'шоп') {
      return commands.shop(ctx);
    }
    
    // ==================== ПРИВЯЗКА ====================
    
    if (command === 'привязать' || command === 'bind' || command === 'привязка') {
      return commands.bind(ctx);
    }
    
    // ==================== НАСТРОЙКИ ====================
    
    if (command === 'настройки' || command === 'settings') {
      return commands.settings(ctx);
    }
    
    if (command === 'клавиатура' || command === 'keyboard') {
      if (args[1] === 'вкл' || args[1] === 'on') {
        return commands.keyboardOn(ctx);
      }
      if (args[1] === 'выкл' || args[1] === 'off') {
        return commands.keyboardOff(ctx);
      }
      return commands.keyboardToggle(ctx);
    }
    
    // ==================== РЕФЕРАЛ ====================
    
    if (command === 'реферал' || command === 'ref' || command === 'рефералы') {
      return commands.referral(ctx);
    }
    
    // ==================== СОБЫТИЯ ====================
    
    if (command === 'события' || command === 'events') {
      return commands.events(ctx);
    }
    
    // ==================== ПИТОМЦЫ ====================
    
    if (command === 'питомец' || command === 'питомцы' || command === 'pet' || command === 'pets') {
      if (args[1] === 'купить' || args[1] === 'buy') {
        return commands.petBuy(ctx, args[2]);
      }
      if (args[1] === 'кормить' || args[1] === 'feed') {
        return commands.petFeed(ctx);
      }
      return commands.pets(ctx);
    }
    
    // ==================== ДОМ ====================
    
    if (command === 'дом' || command === 'house' || command === 'жилье') {
      if (args[1] === 'купить' || args[1] === 'buy') {
        return commands.houseBuy(ctx, args[2]);
      }
      return commands.house(ctx);
    }
    
    // ==================== ТЕЛЕФОН ====================
    
    if (command === 'телефон' || command === 'phone') {
      if (args[1] === 'купить' || args[1] === 'buy') {
        return commands.phoneBuy(ctx, args[2]);
      }
      return commands.phone(ctx);
    }
    
    // ==================== ЯХТЫ, САМОЛЁТЫ, ВЕРТОЛЁТЫ ====================
    
    if (command === 'яхта' || command === 'yacht') {
      if (args[1] === 'купить') return commands.yachtBuy(ctx, args[2]);
      return commands.yacht(ctx);
    }
    
    if (command === 'самолёт' || command === 'самолет' || command === 'plane') {
      if (args[1] === 'купить') return commands.planeBuy(ctx, args[2]);
      return commands.plane(ctx);
    }
    
    if (command === 'вертолёт' || command === 'вертолет' || command === 'helicopter') {
      if (args[1] === 'купить') return commands.helicopterBuy(ctx, args[2]);
      return commands.helicopter(ctx);
    }
    
    // ==================== КЕЙСЫ ====================
    
    if (command === 'кейс' || command === 'case' || command === 'кейсы') {
      if (args[1] === 'открыть' || args[1] === 'open') {
        return commands.caseOpen(ctx, args[2]);
      }
      if (args[1] === 'список' || args[1] === 'list' || !args[1]) {
        return commands.caseList(ctx);
      }
      return commands.caseOpen(ctx, args[1]);
    }
    
    // ==================== КРИМИНАЛ ====================
    
    if (command === 'ограбить' || command === 'rob' || command === 'ограбление') {
      return commands.rob(ctx, args[1]);
    }
    
    if (command === 'преступление' || command === 'crime') {
      return commands.crime(ctx);
    }
    
    // ==================== ЛОТЕРЕЯ ====================
    
    if (command === 'лотерея' || command === 'lottery') {
      if (args[1] === 'купить') {
        return commands.lotteryBuy(ctx, args[2]);
      }
      return commands.lottery(ctx);
    }
    
    // ==================== ДОНАТ ====================
    
    if (command === 'донат' || command === 'donate' || command === 'vip') {
      return commands.donate(ctx);
    }
    
    // ==================== АДМИН КОМАНДЫ ====================
    
    if (isAdmin(ctx.userId, ctx.platform, config)) {
      if (command === 'админ' || command === 'admin') {
        if (args[1] === 'статистика' || args[1] === 'stats') {
          return commands.adminStats(ctx);
        }
        if (args[1] === 'бэкап' || args[1] === 'backup') {
          return commands.adminBackup(ctx);
        }
        return commands.adminHelp(ctx);
      }
      
      if (command === 'выдать' || command === 'give') {
        return commands.adminGive(ctx, args[1], args[2], args[3]);
      }
      
      if (command === 'бан' || command === 'ban') {
        return commands.adminBan(ctx, args[1], args.slice(2).join(' '));
      }
      
      if (command === 'разбан' || command === 'unban') {
        return commands.adminUnban(ctx, args[1]);
      }
      
      if (command === 'рассылка' || command === 'broadcast') {
        return commands.adminBroadcast(ctx, args.slice(1).join(' '));
      }
      
      if (command === 'создатьпромо' || command === 'createpromo') {
        return commands.adminCreatePromo(ctx, args[1], args[2], args[3], args[4], args[5]);
      }
      
      if (command === 'создатьбосса' || command === 'spawnboss') {
        return commands.adminSpawnBoss(ctx);
      }
    }
    
    return null; // Неизвестная команда — игнорируем
    
  } catch (e) {
    console.error('❌ Handler error:', e);
    return { text: '❌ Произошла ошибка при обработке команды.' };
  }
}

// ==================== ОБРАБОТКА CALLBACK ====================
async function handleCallback(ctx) {
  const data = ctx.callbackData;
  const parts = data.split('_');
  
  // Навигация
  if (data === 'back_main') return commands.start(ctx);
  
  // Авторизация
  if (data === 'auth_create') return commands.authCreate(ctx);
  if (data === 'auth_bind') return commands.authBind(ctx);
  if (data === 'bind_newcode') return commands.bind(ctx);
  
  // Основные команды
  if (data === 'cmd_profile') return commands.profile(ctx);
  if (data === 'cmd_balance') return commands.balance(ctx);
  if (data === 'cmd_bank') return commands.bank(ctx);
  if (data === 'cmd_shop') return commands.shop(ctx);
  if (data === 'cmd_job') return commands.job(ctx);
  if (data === 'cmd_casino') return commands.casino(ctx);
  if (data === 'cmd_race') return commands.race(ctx);
  if (data === 'cmd_boss') return commands.boss(ctx);
  if (data === 'cmd_clan') return commands.clan(ctx);
  if (data === 'cmd_games') return commands.games(ctx);
  if (data === 'cmd_help') return commands.help(ctx);
  if (data === 'cmd_stats') return commands.stats(ctx);
  if (data === 'cmd_achievements') return commands.achievements(ctx);
  if (data === 'cmd_inventory') return commands.inventory(ctx);
  if (data === 'cmd_referral') return commands.referral(ctx);
  if (data === 'cmd_settings') return commands.settings(ctx);
  if (data === 'cmd_donate') return commands.donate(ctx);
  if (data === 'cmd_exchange') return commands.exchange(ctx);
  if (data === 'cmd_cars') return commands.cars(ctx);
  if (data === 'cmd_tuning') return commands.tuning(ctx);
  
  // Работа
  if (data === 'do_work') return commands.work(ctx);
  if (data === 'job_list') return commands.jobList(ctx);
  if (data === 'job_quit') return commands.jobQuit(ctx);
  if (data.startsWith('job_apply_')) return commands.jobApply(ctx, parts[2]);
  
  // Босс
  if (data === 'boss_attack') return commands.bossAttack(ctx);
  if (data === 'boss_top') return commands.bossTop(ctx);
  
  // Гонка
  if (data === 'do_race') return commands.race(ctx);
  
  // Бизнес
  if (data === 'biz_collect_all') return commands.businessCollectAll(ctx);
  if (data.startsWith('shop_biz')) return commands.businessList(ctx);
  
  // Фермы
  if (data === 'farm_collect_all') return commands.farmCollect(ctx);
  if (data.startsWith('shop_farms')) return commands.farmList(ctx);
  
  // Принтеры
  if (data === 'printer_collect_all') return commands.printerCollect(ctx);
  if (data.startsWith('shop_printers')) return commands.printerList(ctx);
  
  // Банк
  if (data === 'bank_dep_all') return commands.bankDeposit(ctx, 'все');
  if (data === 'bank_with_all') return commands.bankWithdraw(ctx, 'все');
  if (data === 'bank_limit') return commands.bankLimit(ctx);
  if (data === 'bank_credit') return commands.bankCredit(ctx);
  
  // Квесты
  if (data === 'quests_daily') return commands.questsDaily(ctx);
  if (data === 'quests_weekly') return commands.questsWeekly(ctx);
  
  // Топы
  if (data === 'top_money') return commands.topMoney(ctx);
  if (data === 'top_level') return commands.topLevel(ctx);
  if (data === 'top_clans') return commands.topClans(ctx);
  if (data === 'top_rating') return commands.topRating(ctx);
  
  // Магазин
  if (data === 'shop_cars') return commands.carList(ctx);
  if (data === 'shop_houses') return commands.houseList(ctx);
  if (data === 'shop_phones') return commands.phoneList(ctx);
  if (data === 'shop_pets') return commands.petList(ctx);
  if (data === 'shop_cases') return commands.caseList(ctx);
  
  // Казино ставки
  if (data.startsWith('slots_')) {
    const bet = parts[1] === 'all' ? 'все' : parts[1];
    return commands.casinoSlots(ctx, bet);
  }
  
  // Игры
  if (data === 'game_trade') return commands.trade(ctx);
  if (data === 'game_dice') return commands.gameDice(ctx);
  if (data === 'game_cup') return commands.gameCup(ctx);
  if (data === 'game_coin') return commands.casinoCoin(ctx);
  if (data === 'game_duel') return commands.duel(ctx);
  
  // Помощь
  if (data === 'help_commands') return commands.helpCommands(ctx);
  if (data === 'help_games') return commands.helpGames(ctx);
  if (data === 'help_economy') return commands.helpEconomy(ctx);
  if (data === 'help_ref') return commands.helpRef(ctx);
  if (data === 'help_rules') return commands.rules(ctx);
  if (data === 'help_info') return commands.info(ctx);
  
  // Настройки
  if (data === 'settings_keyboard') return commands.keyboardToggle(ctx);
  
  // Клан
  if (data === 'clan_members') return commands.clanMembers(ctx);
  if (data === 'clan_leave') return commands.clanLeave(ctx);
  
  return null;
}

// ==================== ВСЕ КОМАНДЫ ====================
const commands = {
  // Загружаем модули команд
  ...require('./modules/auth'),
  ...require('./modules/profile'),
  ...require('./modules/economy'),
  ...require('./modules/business'),
  ...require('./modules/games'),
  ...require('./modules/social'),
  ...require('./modules/content'),
  ...require('./modules/admin'),
  ...require('./modules/entertainment'),
  ...require('./modules/shop')
};

module.exports = { handleMessage, handleCallback, commands };
