// ⚡ FLASH BOT v2.0 — МОДУЛЬ АДМИНИСТРИРОВАНИЯ
const db = require('../utils/database');
const keyboards = require('../utils/keyboards');
const config = require('../config');
const { formatMoney, formatNumber, isAdmin, levelFromExp, createBackup } = require('../utils/helpers');

module.exports = {
  adminHelp: async (ctx) => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    return {
      text: `👑 АДМИН-КОМАНДЫ\n━━━━━━━━━━━━━━━━━━━━\n\n📊 ИНФОРМАЦИЯ:\n• админ статистика\n• профиль [ID]\n\n💰 ВЫДАЧА:\n• выдать [ID] [сумма]\n• выдать [ID] алмазы [кол-во]\n• выдать [ID] опыт [кол-во]\n\n🔨 МОДЕРАЦИЯ:\n• бан [ID] [причина]\n• разбан [ID]\n\n🎮 ИГРОВЫЕ:\n• создатьбосса\n• создатьпромо [код] [деньги] [опыт] [алмазы] [лимит]\n\n📢 РАССЫЛКА:\n• рассылка [текст]\n\n⚙️ СИСТЕМА:\n• админ бэкап`,
      keyboard: keyboards.tg.main
    };
  },
  
  adminStats: async (ctx) => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    const users = Object.values(db.users);
    const totalMoney = users.reduce((sum, u) => sum + u.money + u.bank, 0);
    const totalBtc = users.reduce((sum, u) => sum + u.bitcoin, 0);
    const totalDiamonds = users.reduce((sum, u) => sum + u.diamonds, 0);
    
    const today = new Date().setHours(0, 0, 0, 0);
    const activeToday = users.filter(u => u.lastActive > today).length;
    
    return {
      text: `📊 СТАТИСТИКА\n━━━━━━━━━━━━━━━━━━━━\n👥 Игроков: ${users.length}\n📈 Активных: ${activeToday}\n\n💰 ЭКОНОМИКА:\n├ Деньги: ${formatMoney(totalMoney)}\n├ BTC: ₿${totalBtc.toFixed(4)}\n└ Алмазы: ${totalDiamonds}💎\n\n🏛️ Кланов: ${Object.keys(db.clans).length}\n⚔️ Босс: ${db.boss.active ? 'Да' : 'Нет'}\n📦 Промокодов: ${Object.keys(db.promoCodes).length}`,
      keyboard: keyboards.tg.main
    };
  },
  
  adminGive: async (ctx, targetId, amountOrType, amountIfType) => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    if (!targetId) return { text: '❌ выдать [ID] [сумма]', keyboard: keyboards.tg.main };
    
    const id = parseInt(String(targetId).replace('#', ''));
    const user = db.getUserById(id);
    
    if (!user) return { text: '❌ Игрок не найден!', keyboard: keyboards.tg.main };
    
    let currency = 'деньги';
    let amount;
    
    if (['алмазы', 'diamonds'].includes(amountOrType)) {
      currency = 'алмазы';
      amount = parseInt(amountIfType);
      if (amount) user.diamonds += amount;
    } else if (['опыт', 'exp', 'xp'].includes(amountOrType)) {
      currency = 'опыт';
      amount = parseInt(amountIfType);
      if (amount) db.addExp(user, amount);
    } else {
      amount = parseInt(amountOrType);
      if (amount) user.money += amount;
    }
    
    if (!amount) return { text: '❌ Укажите сумму!', keyboard: keyboards.tg.main };
    
    db.saveAll();
    
    return {
      text: `✅ ВЫДАНО\n━━━━━━━━━━━━━━━━━━━━\n👤 ${user.name} (#${user.id})\n💰 ${currency}: +${formatNumber(amount)}`,
      keyboard: keyboards.tg.main
    };
  },
  
  adminBan: async (ctx, targetId, reason = 'Нарушение правил') => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    if (!targetId) return { text: '❌ бан [ID] [причина]', keyboard: keyboards.tg.main };
    
    const id = parseInt(String(targetId).replace('#', ''));
    const user = db.getUserById(id);
    
    if (!user) return { text: '❌ Игрок не найден!', keyboard: keyboards.tg.main };
    
    user.banned = true;
    user.banReason = reason;
    user.banDate = Date.now();
    db.saveAll();
    
    return {
      text: `🔨 ЗАБАНЕН\n━━━━━━━━━━━━━━━━━━━━\n👤 ${user.name} (#${user.id})\n📝 Причина: ${reason}`,
      keyboard: keyboards.tg.main
    };
  },
  
  adminUnban: async (ctx, targetId) => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    if (!targetId) return { text: '❌ разбан [ID]', keyboard: keyboards.tg.main };
    
    const id = parseInt(String(targetId).replace('#', ''));
    const user = db.getUserById(id);
    
    if (!user) return { text: '❌ Игрок не найден!', keyboard: keyboards.tg.main };
    
    user.banned = false;
    user.banReason = null;
    db.saveAll();
    
    return {
      text: `✅ РАЗБАНЕН\n━━━━━━━━━━━━━━━━━━━━\n👤 ${user.name} (#${user.id})`,
      keyboard: keyboards.tg.main
    };
  },
  
  adminBroadcast: async (ctx, text) => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    if (!text) return { text: '❌ рассылка [текст]', keyboard: keyboards.tg.main };
    
    return {
      text: `📢 Рассылка подготовлена:\n\n${text}\n\n⚠️ Рассылка будет выполнена при следующем запуске.`,
      keyboard: keyboards.tg.main,
      broadcast: text
    };
  },
  
  adminCreatePromo: async (ctx, code, money, exp, diamonds, limit) => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    if (!code) return { text: '❌ создатьпромо [код] [деньги] [опыт] [алмазы] [лимит]', keyboard: keyboards.tg.main };
    
    const rewards = {
      money: parseInt(money) || 0,
      exp: parseInt(exp) || 0,
      diamonds: parseInt(diamonds) || 0
    };
    
    db.createPromoCode(code, rewards, parseInt(limit) || 100);
    
    return {
      text: `✅ ПРОМОКОД СОЗДАН\n━━━━━━━━━━━━━━━━━━━━\n📝 Код: ${code.toUpperCase()}\n💰 ${formatMoney(rewards.money)}\n⭐ ${rewards.exp} XP\n💎 ${rewards.diamonds}\n👥 Лимит: ${limit || 100}`,
      keyboard: keyboards.tg.main
    };
  },
  
  adminSpawnBoss: async (ctx) => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    if (db.boss.active) {
      return { text: '❌ Босс уже активен!', keyboard: keyboards.tg.main };
    }
    
    const boss = db.spawnBoss();
    
    return {
      text: `⚔️ БОСС СОЗДАН!\n━━━━━━━━━━━━━━━━━━━━\n${boss.name} (Ур.${boss.level})\n❤️ ${formatNumber(boss.maxHp)} HP\n💰 ${formatMoney(boss.reward)}`,
      keyboard: keyboards.tg.main
    };
  },
  
  adminBackup: async (ctx) => {
    if (!isAdmin(ctx.userId, ctx.platform, config)) {
      return { text: '❌ Нет доступа!', keyboard: keyboards.tg.main };
    }
    
    createBackup();
    
    return {
      text: `✅ Бэкап создан!`,
      keyboard: keyboards.tg.main
    };
  }
};
