// ⚡ FLASH BOT v2.0 — МОДУЛЬ АВТОРИЗАЦИИ
const db = require('../utils/database');
const keyboards = require('../utils/keyboards');
const config = require('../config');
const { formatMoney, levelFromExp } = require('../utils/helpers');

module.exports = {
  // Команда: старт
  start: async (ctx, refCode) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    
    if (user) {
      const lvl = levelFromExp(user.exp);
      return {
        text: `⚡ FLASH BOT\n━━━━━━━━━━━━━━━━━━━━\n👋 С возвращением, ${user.name}!\n🆔 ID: #${user.id}\n\n💰 ${formatMoney(user.money)} | 🏦 ${formatMoney(user.bank)}\n📊 Уровень: ${lvl.level} | ⚡ ${user.energy}/${config.game.maxEnergy}\n\n💡 Напишите «помощь» для списка команд`,
        keyboard: keyboards.tg.main,
        replyKeyboard: user.settings.keyboard ? keyboards.tgReply : null
      };
    }
    
    return {
      text: `⚡ ДОБРО ПОЖАЛОВАТЬ В FLASH!\n━━━━━━━━━━━━━━━━━━━━\n🎮 Это экономическая RPG игра!\n\n✨ Возможности:\n• 💼 Работа и бизнесы\n• 🏎️ Гонки и машины\n• ⚔️ Боссы и дуэли\n• 🎰 Казино и мини-игры\n• 🏛️ Кланы и семьи\n• И многое другое!\n\nВыберите действие:`,
      keyboard: keyboards.tg.start
    };
  },
  
  // Callback: создание аккаунта
  authCreate: async (ctx) => {
    let user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (user) {
      return { text: '❌ У вас уже есть аккаунт!', keyboard: keyboards.tg.main };
    }
    
    user = db.createUser(ctx.platform, ctx.userId, ctx.userName);
    if (!user) {
      return { text: '❌ Ошибка создания аккаунта', keyboard: keyboards.tg.start };
    }
    
    // Путь новичка
    db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'message');
    
    return {
      text: `✅ АККАУНТ СОЗДАН!\n━━━━━━━━━━━━━━━━━━━━\n👤 Ник: ${user.name}\n🆔 ID: #${user.id}\n\n💰 Стартовый капитал: ${formatMoney(config.game.startMoney)}\n⚡ Энергия: ${config.game.maxEnergy}/${config.game.maxEnergy}\n\n🎁 Достижение «Первые шаги» получено!\n+1,000$ и +100 опыта\n\n📍 Начните с команды «путь новичка»!\n💡 Промокод: FLASH`,
      keyboard: keyboards.tg.main
    };
  },
  
  // Callback: начало привязки
  authBind: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (user) {
      return { text: '❌ У вас уже есть аккаунт на этой платформе!', keyboard: keyboards.tg.main };
    }
    
    const otherPlatform = ctx.platform === 'telegram' ? 'VK' : 'Telegram';
    
    return {
      text: `🔗 ПРИВЯЗКА АККАУНТА\n━━━━━━━━━━━━━━━━━━━━\nЧтобы привязать аккаунт:\n\n1️⃣ Зайдите в ${otherPlatform}, где у вас есть аккаунт\n\n2️⃣ Напишите команду: привязать\n\n3️⃣ Получите 6-значный код\n\n4️⃣ Вернитесь сюда и напишите:\nкод XXXXXX`,
      keyboard: keyboards.tg.bind
    };
  },
  
  // Команда: привязать (генерация кода)
  bind: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) {
      return { text: '❌ Сначала создайте аккаунт командой «старт»', keyboard: keyboards.tg.start };
    }
    
    const code = db.createBondCode(ctx.platform, ctx.userId);
    
    return {
      text: `🔗 КОД ПРИВЯЗКИ\n━━━━━━━━━━━━━━━━━━━━\n📝 Ваш код: ${code}\n\n⏰ Действует: ${config.game.bondCodeExpireMinutes} минут\n\n📌 Инструкция:\n1. Зайдите на другую платформу\n2. Напишите: код ${code}\n3. Аккаунты будут связаны!\n\n⚠️ Не сообщайте код посторонним!`,
      keyboard: keyboards.tg.bind
    };
  },
  
  // Команда: код XXXXXX
  useCode: async (ctx, code) => {
    if (!code) {
      return { text: '❌ Укажите код! Пример: код ABC123', keyboard: keyboards.tg.start };
    }
    
    const existingUser = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (existingUser) {
      return { text: '❌ У вас уже есть аккаунт на этой платформе!', keyboard: keyboards.tg.main };
    }
    
    const result = db.useBondCode(code.toUpperCase(), ctx.platform, ctx.userId);
    
    if (!result.success) {
      return { text: `❌ ${result.error}`, keyboard: keyboards.tg.start };
    }
    
    return {
      text: `✅ АККАУНТ ПРИВЯЗАН!\n━━━━━━━━━━━━━━━━━━━━\n👤 Ник: ${result.user.name}\n🆔 ID: #${result.user.id}\n\n💰 Баланс: ${formatMoney(result.user.money)}\n🏦 Банк: ${formatMoney(result.user.bank)}\n\n🔗 Теперь вы можете играть на обеих платформах!`,
      keyboard: keyboards.tg.main
    };
  },
  
  // Команда: помощь
  help: (ctx) => {
    return {
      text: `❓ ПОМОЩЬ — FLASH BOT\n━━━━━━━━━━━━━━━━━━━━\n\n📋 ОСНОВНЫЕ:\nпрофиль • баланс • банк\nработа • бизнес • магазин\n\n🎮 ИГРЫ:\nказино • гонка • босс\nкубик • трейд • стаканчик\nдуэль • рыбалка • копать\n\n👥 СОЦИАЛЬНОЕ:\nклан • топ • реферал\n\n🎁 БОНУСЫ:\nбонус • квесты • путь новичка\nпромокод [код]\n\n🎭 РАЗВЛЕЧЕНИЯ:\nанекдот • шар [вопрос]\nпереверни [текст] • реши [пример]\n\n⚙️ НАСТРОЙКИ:\nклавиатура вкл/выкл\n\n💡 Команда «помощь игры» для подробностей`,
      keyboard: keyboards.tg.help
    };
  },
  
  helpCommands: (ctx) => {
    return {
      text: `📋 ВСЕ КОМАНДЫ\n━━━━━━━━━━━━━━━━━━━━\n\n👤 ПРОФИЛЬ:\nпрофиль [ID] • статистика\nдостижения • инвентарь\nуровень • энергия • ник [имя]\n\n💰 ФИНАНСЫ:\nбаланс • банк положить/снять\nперевод [ID] [сумма]\nобмен • курс\n\n💼 РАБОТА:\nработа список • работа [номер]\nработать • уволиться\n\n🏢 БИЗНЕС:\nбизнес • бизнес список\nбизнес купить/собрать/улучшить\n\n🌾 ФЕРМЫ/ПРИНТЕРЫ:\nферма • принтер\nферма/принтер купить/собрать\n\n🚗 МАШИНЫ:\nмашина список • машина купить\nмашина выбрать • тюнинг`,
      keyboard: keyboards.tg.help
    };
  },
  
  helpGames: (ctx) => {
    return {
      text: `🎮 ИГРЫ\n━━━━━━━━━━━━━━━━━━━━\n\n🎰 КАЗИНО:\nказино [ставка] — слоты\nрулетка [ставка] [цвет]\nкости [ставка] [1-6]\nмонетка [ставка] [орёл/решка]\n\n📈 ТРЕЙДИНГ:\nтрейд [вверх/вниз] [ставка]\n\n🎲 МИНИ-ИГРЫ:\nкубик [1-6] [ставка]\nстаканчик [1-3] [ставка]\n\n⚔️ PVP:\nдуэль [ID] [ставка]\nограбить [ID]\n\n🏁 ГОНКИ:\nгонка — гоночный заезд\n\n⚔️ БОСС:\nбосс — информация\nбосс атака — атаковать\n\n⛏️ ДОБЫЧА:\nкопать • рыбалка • охота\nпродать руду/рыбу/трофеи`,
      keyboard: keyboards.tg.help
    };
  },
  
  helpEconomy: (ctx) => {
    return {
      text: `💰 ЭКОНОМИКА\n━━━━━━━━━━━━━━━━━━━━\n\n💼 РАБОТА:\n• Устройтесь на работу\n• Пишите «работать» каждые 5 мин\n• Повышайте уровень для лучших вакансий\n\n🏢 БИЗНЕСЫ:\n• Пассивный доход\n• Собирайте каждые 30 мин\n• Улучшайте для большего дохода\n\n🌾 ФЕРМЫ:\n• Добывают биткоины\n• Собирайте каждые 15 мин\n\n🖨️ ПРИНТЕРЫ:\n• Печатают деньги\n• Нужно заправлять\n\n🏁 ГОНКИ:\n• Нужна машина\n• Тюнинг увеличивает шансы\n\n🎰 КАЗИНО:\n• Шанс x2-x50\n• Привилегии повышают шансы`,
      keyboard: keyboards.tg.help
    };
  },
  
  helpRef: (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Сначала создайте аккаунт!', keyboard: keyboards.tg.start };
    
    const refLink = ctx.platform === 'telegram' 
      ? `https://t.me/${config.telegram.botUsername}?start=ref_${user.id}`
      : `https://vk.com/club${config.vk.groupId}?ref=${user.id}`;
    
    return {
      text: `🎁 РЕФЕРАЛЬНАЯ ПРОГРАММА\n━━━━━━━━━━━━━━━━━━━━\n\n📌 Как это работает:\n1️⃣ Пригласите друга по ссылке\n2️⃣ Он создаёт аккаунт\n3️⃣ Вы получаете 5,000$\n4️⃣ Друг получает 2,000$ бонус\n\n💰 БОНУСЫ:\n• 1 реф → 5,000$\n• 5 рефов → 25,000$ + 5💎\n• 10 рефов → 100,000$ + 20💎\n• 25 рефов → 500,000$ + 50💎\n\n🔗 Ваша ссылка:\n${refLink}\n\n👥 Ваших рефералов: ${user.referrals.length}\n💰 Заработано: ${formatMoney(user.referralEarnings)}`,
      keyboard: keyboards.tg.help
    };
  },
  
  rules: (ctx) => {
    return {
      text: `📜 ПРАВИЛА FLASH\n━━━━━━━━━━━━━━━━━━━━\n\n1️⃣ Запрещён мультиаккаунтинг\n   Один человек = один аккаунт\n\n2️⃣ Запрещены оскорбления\n   Уважайте других игроков\n\n3️⃣ Запрещён обман игроков\n   Честная игра превыше всего\n\n4️⃣ Запрещены баги и читы\n   Сообщайте о багах админам\n\n5️⃣ Запрещён спам\n   Не флудите командами\n\n⚠️ Нарушение правил = бан!\n\n📌 По вопросам пишите админам`,
      keyboard: keyboards.tg.help
    };
  },
  
  info: (ctx) => {
    const totalUsers = Object.keys(db.users).length;
    const totalClans = Object.keys(db.clans).length;
    
    return {
      text: `⚡ FLASH BOT — v2.0\n━━━━━━━━━━━━━━━━━━━━\n\n📊 СТАТИСТИКА:\n👥 Игроков: ${totalUsers}\n🏛️ Кланов: ${totalClans}\n⚔️ Босс: ${db.boss.active ? '✅ Активен' : '❌ Нет'}\n\n🔗 ПЛАТФОРМЫ:\n📱 Telegram: @${config.telegram.botUsername}\n💬 VK: vk.com/club${config.vk.groupId}\n\n✨ ОСОБЕННОСТИ:\n• 200+ команд\n• Кросс-платформенность\n• Ежедневные обновления\n\n💎 Поддержать: донат\n\n👨‍💻 Разработчик: @admin`,
      keyboard: keyboards.tg.help
    };
  },
  
  // Настройки
  settings: (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const kbStatus = user.settings.keyboard ? '✅ ВКЛ' : '❌ ВЫКЛ';
    const notifStatus = user.settings.notifications ? '✅ ВКЛ' : '❌ ВЫКЛ';
    
    return {
      text: `⚙️ НАСТРОЙКИ\n━━━━━━━━━━━━━━━━━━━━\n⌨️ Клавиатура: ${kbStatus}\n🔔 Уведомления: ${notifStatus}\n\n📌 Команды:\n• клавиатура вкл/выкл`,
      keyboard: keyboards.tg.settings
    };
  },
  
  keyboardOn: (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    user.settings.keyboard = true;
    db.saveAll();
    
    return {
      text: `⌨️ КЛАВИАТУРА ВКЛЮЧЕНА\n━━━━━━━━━━━━━━━━━━━━\nТеперь у вас отображаются кнопки быстрого доступа.`,
      replyKeyboard: keyboards.tgReply
    };
  },
  
  keyboardOff: (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    user.settings.keyboard = false;
    db.saveAll();
    
    return {
      text: `⌨️ КЛАВИАТУРА ВЫКЛЮЧЕНА\n━━━━━━━━━━━━━━━━━━━━\nПостоянная клавиатура скрыта.`,
      removeKeyboard: true
    };
  },
  
  keyboardToggle: (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    user.settings.keyboard = !user.settings.keyboard;
    db.saveAll();
    
    if (user.settings.keyboard) {
      return {
        text: `⌨️ КЛАВИАТУРА ВКЛЮЧЕНА`,
        replyKeyboard: keyboards.tgReply
      };
    } else {
      return {
        text: `⌨️ КЛАВИАТУРА ВЫКЛЮЧЕНА`,
        removeKeyboard: true
      };
    }
  }
};
