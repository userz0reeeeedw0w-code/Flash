// ⚡ FLASH BOT v2.0 — МОДУЛЬ БИЗНЕСА И РАБОТЫ
const db = require('../utils/database');
const keyboards = require('../utils/keyboards');
const config = require('../config');
const { formatMoney, formatNumber, checkCooldown, formatTime, levelFromExp, random, getIncomeMultiplier, getCooldownMultiplier } = require('../utils/helpers');

module.exports = {
  // ==================== РАБОТА ====================
  job: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (user.job) {
      const jobInfo = config.jobs.find(j => j.id === user.job);
      const cooldown = checkCooldown(user.cooldowns.work, config.game.cooldowns.work * getCooldownMultiplier(user, config));
      const status = cooldown.ready ? '✅ Можно работать' : `⏰ ${formatTime(cooldown.remaining)}`;
      
      return {
        text: `💼 РАБОТА\n━━━━━━━━━━━━━━━━━━━━\n📋 Должность: ${jobInfo.name}\n💰 Зарплата: ${formatMoney(jobInfo.salary)}\n📊 Смен: ${user.workStreak}\n${status}\n\n📌 работать — отработать смену\n📌 уволиться — уволиться`,
        keyboard: keyboards.tg.job
      };
    }
    
    return {
      text: `💼 РАБОТА\n━━━━━━━━━━━━━━━━━━━━\n❌ Вы безработный!\n\n📌 работа список — вакансии\n📌 работа [номер] — устроиться`,
      keyboard: keyboards.tg.job
    };
  },
  
  jobList: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const level = levelFromExp(user.exp).level;
    let text = `💼 ВАКАНСИИ\n━━━━━━━━━━━━━━━━━━━━`;
    
    config.jobs.forEach(job => {
      const available = level >= job.minLevel ? '✅' : '🔒';
      text += `\n${available} ${job.id}. ${job.name}`;
      text += `\n   💰 ${formatMoney(job.salary)} | 📊 с ${job.minLevel} ур.`;
    });
    
    text += `\n\n📌 работа [номер] — устроиться`;
    return { text, keyboard: keyboards.tg.job };
  },
  
  jobApply: async (ctx, jobId) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (user.job) return { text: '❌ Сначала уволитесь!', keyboard: keyboards.tg.job };
    
    const job = config.jobs.find(j => j.id === parseInt(jobId));
    if (!job) return { text: '❌ Работа не найдена!', keyboard: keyboards.tg.job };
    
    const level = levelFromExp(user.exp).level;
    if (level < job.minLevel) return { text: `❌ Нужен ${job.minLevel} уровень!`, keyboard: keyboards.tg.job };
    
    user.job = job.id;
    user.workStreak = 0;
    db.saveAll();
    
    const path = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'job');
    let pathText = path ? `\n\n🎉 ПУТЬ НОВИЧКА!\n+${formatMoney(path.reward.money)}` : '';
    
    return {
      text: `✅ ВЫ УСТРОИЛИСЬ!\n━━━━━━━━━━━━━━━━━━━━\n📋 Должность: ${job.name}\n💰 Зарплата: ${formatMoney(job.salary)}\n\n📌 Напишите «работать»${pathText}`,
      keyboard: keyboards.tg.job
    };
  },
  
  work: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (!user.job) return { text: '❌ Вы безработный!', keyboard: keyboards.tg.job };
    
    const cooldownTime = config.game.cooldowns.work * getCooldownMultiplier(user, config);
    const cooldown = checkCooldown(user.cooldowns.work, cooldownTime);
    if (!cooldown.ready) return { text: `⏰ Подождите: ${formatTime(cooldown.remaining)}`, keyboard: keyboards.tg.job };
    
    const job = config.jobs.find(j => j.id === user.job);
    const bonus = Math.floor(Math.random() * job.salary * 0.3);
    let salary = (job.salary + bonus) * getIncomeMultiplier(user, config);
    salary = Math.floor(salary);
    const exp = 10 + random(0, 40);
    
    user.money += salary;
    user.cooldowns.work = Date.now();
    user.workStreak++;
    user.stats.workShifts++;
    user.stats.totalEarned += salary;
    
    const levelUp = db.addExp(user, exp);
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'work_shifts', 1);
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'earn', salary);
    db.saveAll();
    
    const path = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'work');
    let pathText = path ? `\n\n🎉 ПУТЬ НОВИЧКА!\n+${formatMoney(path.reward.money)}` : '';
    let levelText = levelUp.leveledUp ? `\n\n🎉 УРОВЕНЬ ${levelUp.newLevel}!` : '';
    
    return {
      text: `💼 РАБОТА ВЫПОЛНЕНА!\n━━━━━━━━━━━━━━━━━━━━\n📋 ${job.name}\n💰 Зарплата: ${formatMoney(job.salary)}\n🎁 Бонус: +${formatMoney(bonus)}\n✅ Получено: ${formatMoney(salary)}\n⭐ Опыт: +${exp}\n\n💵 Баланс: ${formatMoney(user.money)}${pathText}${levelText}`,
      keyboard: keyboards.tg.job
    };
  },
  
  jobQuit: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (!user.job) return { text: '❌ Вы и так безработный!', keyboard: keyboards.tg.job };
    
    const job = config.jobs.find(j => j.id === user.job);
    user.job = null;
    user.workStreak = 0;
    db.saveAll();
    
    return { text: `✅ Вы уволились с должности ${job.name}`, keyboard: keyboards.tg.job };
  },
  
  // ==================== БИЗНЕС ====================
  business: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (user.businesses.length === 0) {
      return {
        text: `🏢 БИЗНЕС\n━━━━━━━━━━━━━━━━━━━━\n❌ У вас нет бизнесов!\n\n📌 бизнес список — каталог\n📌 бизнес купить [номер]`,
        keyboard: keyboards.tg.business
      };
    }
    
    let text = `🏢 ВАШИ БИЗНЕСЫ (${user.businesses.length})\n━━━━━━━━━━━━━━━━━━━━`;
    
    user.businesses.forEach((biz, i) => {
      const info = config.businesses.find(b => b.id === biz.id) || config.donatBusinesses.find(b => b.id === biz.id);
      const income = Math.floor(info.income * (1 + biz.level * 0.1));
      const cd = checkCooldown(biz.lastCollect, config.game.cooldowns.businessCollect);
      const status = cd.ready ? '✅' : `⏰ ${formatTime(cd.remaining)}`;
      
      text += `\n${i + 1}. ${info.name} [Ур.${biz.level}]\n   💰 ${formatMoney(income)} | ${status}`;
    });
    
    text += `\n\n📌 бизнес собрать все`;
    return { text, keyboard: keyboards.tg.business };
  },
  
  businessList: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    let maxBiz = 1;
    if (user.privilege) {
      const priv = config.privileges[user.privilege.toLowerCase()];
      if (priv) maxBiz = priv.bonuses.maxBusinesses;
    }
    
    let text = `🏢 КАТАЛОГ БИЗНЕСОВ\n━━━━━━━━━━━━━━━━━━━━\n📊 Слотов: ${user.businesses.length}/${maxBiz}\n`;
    
    config.businesses.forEach(biz => {
      const owned = user.businesses.find(b => b.id === biz.id);
      text += `\n${owned ? '✅' : '🛒'} ${biz.id}. ${biz.name}\n   💰 ${formatMoney(biz.price)} | 📈 ${formatMoney(biz.income)}/сбор`;
    });
    
    text += `\n\n📌 бизнес купить [номер]`;
    return { text, keyboard: keyboards.tg.business };
  },
  
  businessBuy: async (ctx, bizId) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    let maxBiz = 1;
    if (user.privilege) {
      const priv = config.privileges[user.privilege.toLowerCase()];
      if (priv) maxBiz = priv.bonuses.maxBusinesses;
    }
    
    if (user.businesses.length >= maxBiz) {
      return { text: `❌ Максимум: ${maxBiz} бизнесов. Купите привилегию!`, keyboard: keyboards.tg.business };
    }
    
    const id = parseInt(bizId);
    let biz = config.businesses.find(b => b.id === id);
    let isDonate = false;
    
    if (!biz) {
      biz = config.donatBusinesses.find(b => b.id === id);
      isDonate = true;
    }
    
    if (!biz) return { text: '❌ Бизнес не найден!', keyboard: keyboards.tg.business };
    if (user.businesses.find(b => b.id === biz.id)) return { text: '❌ Уже есть!', keyboard: keyboards.tg.business };
    
    if (isDonate) {
      if (user.diamonds < biz.price) return { text: `❌ Нужно ${biz.price}💎`, keyboard: keyboards.tg.business };
      user.diamonds -= biz.price;
    } else {
      if (user.money < biz.price) return { text: `❌ Нужно ${formatMoney(biz.price)}`, keyboard: keyboards.tg.business };
      user.money -= biz.price;
    }
    
    user.businesses.push({ id: biz.id, level: 1, lastCollect: 0 });
    db.saveAll();
    
    const path = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'business');
    let pathText = path ? `\n\n🎉 ПУТЬ НОВИЧКА!\n+${formatMoney(path.reward.money)}` : '';
    
    return {
      text: `✅ БИЗНЕС КУПЛЕН!\n━━━━━━━━━━━━━━━━━━━━\n🏢 ${biz.name}\n💰 Доход: ${formatMoney(biz.income)}/сбор\n\n📌 бизнес собрать${pathText}`,
      keyboard: keyboards.tg.business
    };
  },
  
  businessCollectAll: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (user.businesses.length === 0) return { text: '❌ Нет бизнесов!', keyboard: keyboards.tg.business };
    
    let totalIncome = 0;
    let collected = 0;
    
    user.businesses.forEach(biz => {
      const cd = checkCooldown(biz.lastCollect, config.game.cooldowns.businessCollect);
      if (cd.ready) {
        const info = config.businesses.find(b => b.id === biz.id) || config.donatBusinesses.find(b => b.id === biz.id);
        let income = Math.floor(info.income * (1 + biz.level * 0.1) * getIncomeMultiplier(user, config));
        
        user.money += income;
        user.stats.totalEarned += income;
        user.stats.businessCollects++;
        totalIncome += income;
        biz.lastCollect = Date.now();
        collected++;
      }
    });
    
    if (collected === 0) return { text: '❌ Нечего собирать!', keyboard: keyboards.tg.business };
    
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'business_collect', collected);
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'earn', totalIncome);
    db.saveAll();
    
    const path = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'collect');
    let pathText = path ? `\n\n🎉 ПУТЬ НОВИЧКА!\n+${formatMoney(path.reward.money)}` : '';
    
    return {
      text: `✅ СОБРАНО!\n━━━━━━━━━━━━━━━━━━━━\n🏢 Бизнесов: ${collected}\n💰 Получено: ${formatMoney(totalIncome)}\n\n💵 Баланс: ${formatMoney(user.money)}${pathText}`,
      keyboard: keyboards.tg.business
    };
  },
  
  businessCollect: async (ctx, bizNum) => {
    return module.exports.businessCollectAll(ctx);
  },
  
  businessUpgrade: async (ctx, bizNum) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const idx = parseInt(bizNum) - 1;
    if (isNaN(idx) || idx < 0 || idx >= user.businesses.length) {
      return { text: '❌ Укажите номер бизнеса!', keyboard: keyboards.tg.business };
    }
    
    const biz = user.businesses[idx];
    const info = config.businesses.find(b => b.id === biz.id) || config.donatBusinesses.find(b => b.id === biz.id);
    
    if (biz.level >= info.maxLevel) return { text: '❌ Максимальный уровень!', keyboard: keyboards.tg.business };
    
    const cost = info.upgradePrice * biz.level;
    if (user.money < cost) return { text: `❌ Нужно ${formatMoney(cost)}`, keyboard: keyboards.tg.business };
    
    user.money -= cost;
    biz.level++;
    db.saveAll();
    
    const newIncome = Math.floor(info.income * (1 + biz.level * 0.1));
    
    return {
      text: `✅ УЛУЧШЕНО!\n━━━━━━━━━━━━━━━━━━━━\n🏢 ${info.name}\n📈 Уровень: ${biz.level}\n💰 Новый доход: ${formatMoney(newIncome)}`,
      keyboard: keyboards.tg.business
    };
  },
  
  businessSell: async (ctx, bizNum) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const idx = parseInt(bizNum) - 1;
    if (isNaN(idx) || idx < 0 || idx >= user.businesses.length) {
      return { text: '❌ Укажите номер бизнеса!', keyboard: keyboards.tg.business };
    }
    
    const biz = user.businesses[idx];
    const info = config.businesses.find(b => b.id === biz.id) || config.donatBusinesses.find(b => b.id === biz.id);
    const sellPrice = Math.floor(info.price * 0.5);
    
    user.money += sellPrice;
    user.businesses.splice(idx, 1);
    db.saveAll();
    
    return {
      text: `✅ ПРОДАНО!\n━━━━━━━━━━━━━━━━━━━━\n🏢 ${info.name}\n💰 Получено: ${formatMoney(sellPrice)}`,
      keyboard: keyboards.tg.business
    };
  },
  
  // ==================== ФЕРМЫ ====================
  farm: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (user.farms.length === 0) {
      return { text: `🌾 ФЕРМЫ\n━━━━━━━━━━━━━━━━━━━━\n❌ Нет ферм!\n\n📌 ферма список\n📌 ферма купить [номер]`, keyboard: keyboards.tg.farms };
    }
    
    let text = `🌾 ВАШИ ФЕРМЫ (${user.farms.length})\n━━━━━━━━━━━━━━━━━━━━`;
    
    user.farms.forEach((f, i) => {
      const info = config.farms.find(farm => farm.id === f.id);
      const cd = checkCooldown(f.lastCollect, config.game.cooldowns.farmCollect);
      const status = cd.ready ? '✅' : `⏰ ${formatTime(cd.remaining)}`;
      text += `\n${i + 1}. ${info.name}\n   ₿ ${info.btcPerHour}/ч | ${status}`;
    });
    
    return { text, keyboard: keyboards.tg.farms };
  },
  
  farmList: async (ctx) => {
    let text = `🌾 КАТАЛОГ ФЕРМ\n━━━━━━━━━━━━━━━━━━━━`;
    config.farms.forEach(f => {
      text += `\n${f.id}. ${f.name}\n   💰 ${formatMoney(f.price)} | ₿ ${f.btcPerHour}/ч`;
    });
    text += `\n\n📌 ферма купить [номер]`;
    return { text, keyboard: keyboards.tg.farms };
  },
  
  farmBuy: async (ctx, farmId) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const farm = config.farms.find(f => f.id === parseInt(farmId));
    if (!farm) return { text: '❌ Ферма не найдена!', keyboard: keyboards.tg.farms };
    
    const owned = user.farms.filter(f => f.id === farm.id).length;
    if (owned >= farm.maxCount) return { text: `❌ Максимум таких ферм: ${farm.maxCount}`, keyboard: keyboards.tg.farms };
    if (user.money < farm.price) return { text: `❌ Нужно ${formatMoney(farm.price)}`, keyboard: keyboards.tg.farms };
    
    user.money -= farm.price;
    user.farms.push({ id: farm.id, lastCollect: Date.now() });
    db.saveAll();
    
    return { text: `✅ ФЕРМА КУПЛЕНА!\n${farm.name}\n₿ ${farm.btcPerHour}/ч`, keyboard: keyboards.tg.farms };
  },
  
  farmCollect: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (user.farms.length === 0) return { text: '❌ Нет ферм!', keyboard: keyboards.tg.farms };
    
    let totalBtc = 0;
    let collected = 0;
    
    user.farms.forEach(f => {
      const cd = checkCooldown(f.lastCollect, config.game.cooldowns.farmCollect);
      if (cd.ready) {
        const info = config.farms.find(farm => farm.id === f.id);
        const hours = (Date.now() - f.lastCollect) / 3600000;
        const btc = info.btcPerHour * Math.min(hours, 24);
        
        user.bitcoin += btc;
        totalBtc += btc;
        f.lastCollect = Date.now();
        collected++;
      }
    });
    
    if (collected === 0) return { text: '❌ Нечего собирать!', keyboard: keyboards.tg.farms };
    
    db.saveAll();
    
    return {
      text: `✅ СОБРАНО!\n━━━━━━━━━━━━━━━━━━━━\n🌾 Ферм: ${collected}\n₿ Получено: ${totalBtc.toFixed(6)} BTC\n\n₿ Всего: ${user.bitcoin.toFixed(6)} BTC`,
      keyboard: keyboards.tg.farms
    };
  },
  
  // ==================== ПРИНТЕРЫ ====================
  printer: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (user.printers.length === 0) {
      return { text: `🖨️ ПРИНТЕРЫ\n━━━━━━━━━━━━━━━━━━━━\n❌ Нет принтеров!\n\n📌 принтер список\n📌 принтер купить [номер]`, keyboard: keyboards.tg.printers };
    }
    
    let text = `🖨️ ПРИНТЕРЫ (${user.printers.length})\n━━━━━━━━━━━━━━━━━━━━`;
    user.printers.forEach((p, i) => {
      const info = config.printers.find(pr => pr.id === p.id);
      const cd = checkCooldown(p.lastCollect, config.game.cooldowns.printerCollect);
      const status = cd.ready ? '✅' : `⏰ ${formatTime(cd.remaining)}`;
      text += `\n${i + 1}. ${info.name} [Ур.${p.level}]\n   💰 ${formatMoney(info.income)} | ⛽ ${p.fuel}% | ${status}`;
    });
    
    return { text, keyboard: keyboards.tg.printers };
  },
  
  printerList: async (ctx) => {
    let text = `🖨️ КАТАЛОГ ПРИНТЕРОВ\n━━━━━━━━━━━━━━━━━━━━`;
    config.printers.forEach(p => {
      text += `\n${p.id}. ${p.name}\n   💰 ${formatMoney(p.price)} | 📈 ${formatMoney(p.income)}/сбор`;
    });
    text += `\n\n📌 принтер купить [номер]`;
    return { text, keyboard: keyboards.tg.printers };
  },
  
  printerBuy: async (ctx, printerId) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const printer = config.printers.find(p => p.id === parseInt(printerId));
    if (!printer) return { text: '❌ Принтер не найден!', keyboard: keyboards.tg.printers };
    
    const owned = user.printers.filter(p => p.id === printer.id).length;
    if (owned >= printer.maxCount) return { text: `❌ Максимум: ${printer.maxCount}`, keyboard: keyboards.tg.printers };
    if (user.money < printer.price) return { text: `❌ Нужно ${formatMoney(printer.price)}`, keyboard: keyboards.tg.printers };
    
    user.money -= printer.price;
    user.printers.push({ id: printer.id, level: 1, fuel: 100, lastCollect: Date.now() });
    db.saveAll();
    
    return { text: `✅ ПРИНТЕР КУПЛЕН!\n${printer.name}`, keyboard: keyboards.tg.printers };
  },
  
  printerCollect: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (user.printers.length === 0) return { text: '❌ Нет принтеров!', keyboard: keyboards.tg.printers };
    
    let totalIncome = 0;
    let collected = 0;
    
    user.printers.forEach(p => {
      if (p.fuel <= 0) return;
      const cd = checkCooldown(p.lastCollect, config.game.cooldowns.printerCollect);
      if (cd.ready) {
        const info = config.printers.find(pr => pr.id === p.id);
        const income = Math.floor(info.income * (1 + p.level * 0.1) * (p.fuel / 100));
        
        user.money += income;
        totalIncome += income;
        p.fuel = Math.max(0, p.fuel - 10);
        p.lastCollect = Date.now();
        collected++;
      }
    });
    
    if (collected === 0) return { text: '❌ Нечего собирать (или нет топлива)!', keyboard: keyboards.tg.printers };
    
    db.saveAll();
    
    return {
      text: `✅ СОБРАНО!\n━━━━━━━━━━━━━━━━━━━━\n🖨️ Принтеров: ${collected}\n💰 Получено: ${formatMoney(totalIncome)}\n\n⚠️ Не забудьте заправить!`,
      keyboard: keyboards.tg.printers
    };
  },
  
  printerFuel: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (user.printers.length === 0) return { text: '❌ Нет принтеров!', keyboard: keyboards.tg.printers };
    
    let totalCost = 0;
    let refueled = 0;
    
    user.printers.forEach(p => {
      if (p.fuel < 100) {
        const info = config.printers.find(pr => pr.id === p.id);
        const needed = 100 - p.fuel;
        const cost = Math.floor(info.fuelCost * needed / 100);
        
        if (user.money >= cost) {
          user.money -= cost;
          p.fuel = 100;
          totalCost += cost;
          refueled++;
        }
      }
    });
    
    if (refueled === 0) return { text: '❌ Нечего заправлять или нет денег!', keyboard: keyboards.tg.printers };
    
    db.saveAll();
    
    return {
      text: `✅ ЗАПРАВЛЕНО!\n━━━━━━━━━━━━━━━━━━━━\n🖨️ Принтеров: ${refueled}\n💰 Потрачено: ${formatMoney(totalCost)}`,
      keyboard: keyboards.tg.printers
    };
  }
};
