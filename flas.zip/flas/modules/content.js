// ⚡ FLASH BOT v2.0 — МОДУЛЬ КОНТЕНТА
const db = require('../utils/database');
const keyboards = require('../utils/keyboards');
const config = require('../config');
const { formatMoney, formatNumber, checkCooldown, formatTime, random } = require('../utils/helpers');

module.exports = {
  // ==================== ПУТЬ НОВИЧКА ====================
  beginnerPath: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (user.beginnerCompleted) {
      return {
        text: `📍 ПУТЬ НОВИЧКА\n━━━━━━━━━━━━━━━━━━━━\n✅ ЗАВЕРШЁН!\n\n🎉 Поздравляем! Вы освоили основы.`,
        keyboard: keyboards.tg.main
      };
    }
    
    const current = config.beginnerPath.find(s => s.stage === user.beginnerStage);
    
    let text = `📍 ПУТЬ НОВИЧКА (${user.beginnerStage - 1}/${config.beginnerPath.length})\n━━━━━━━━━━━━━━━━━━━━`;
    
    config.beginnerPath.forEach(stage => {
      let status = stage.stage < user.beginnerStage ? '✅' : 
                   stage.stage === user.beginnerStage ? '👉' : '⬜';
      
      text += `\n${status} ${stage.stage}. ${stage.task}`;
      if (stage.stage === user.beginnerStage) {
        text += `\n   💰 +${formatMoney(stage.reward.money)}`;
      }
    });
    
    if (current) {
      text += `\n\n📌 Команда: ${current.cmd}`;
    }
    
    return { text, keyboard: keyboards.tg.main };
  },
  
  // ==================== КВЕСТЫ ====================
  quests: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    db.initDailyQuests(user);
    db.initWeeklyQuests(user);
    db.saveAll();
    
    const dailyDone = Object.values(user.dailyQuests).filter(q => q.completed).length;
    const weeklyDone = Object.values(user.weeklyQuests).filter(q => q.completed).length;
    
    return {
      text: `📋 КВЕСТЫ\n━━━━━━━━━━━━━━━━━━━━\n📅 Ежедневные: ${dailyDone}/${config.dailyQuests.length}\n📆 Недельные: ${weeklyDone}/${config.weeklyQuests.length}\n\n📌 квесты ежедневные\n📌 квесты недельные\n📌 квесты сдать [номер]`,
      keyboard: keyboards.tg.quests
    };
  },
  
  questsDaily: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    db.initDailyQuests(user);
    
    let text = `📅 ЕЖЕДНЕВНЫЕ КВЕСТЫ\n━━━━━━━━━━━━━━━━━━━━`;
    
    config.dailyQuests.forEach(quest => {
      const p = user.dailyQuests[quest.id];
      const status = p.claimed ? '💎' : (p.completed ? '✅' : '⬜');
      
      text += `\n${status} ${quest.id}. ${quest.name}`;
      text += `\n   📊 ${p.progress}/${quest.target}`;
      if (p.completed && !p.claimed) text += ` — СДАТЬ!`;
      text += `\n   💰 ${formatMoney(quest.reward.money)}`;
    });
    
    text += `\n\n📌 квесты сдать [номер]`;
    return { text, keyboard: keyboards.tg.quests };
  },
  
  questsWeekly: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    db.initWeeklyQuests(user);
    
    let text = `📆 НЕДЕЛЬНЫЕ КВЕСТЫ\n━━━━━━━━━━━━━━━━━━━━`;
    
    config.weeklyQuests.forEach(quest => {
      const p = user.weeklyQuests[quest.id];
      const status = p.claimed ? '💎' : (p.completed ? '✅' : '⬜');
      
      text += `\n${status} ${quest.id}. ${quest.name}`;
      text += `\n   📊 ${p.progress}/${quest.target}`;
      if (p.completed && !p.claimed) text += ` — СДАТЬ!`;
      text += `\n   💰 ${formatMoney(quest.reward.money)}`;
    });
    
    text += `\n\n📌 квесты сдать н[номер]`;
    return { text, keyboard: keyboards.tg.quests };
  },
  
  questClaim: async (ctx, questIdStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (!questIdStr) return { text: '❌ Укажите номер квеста!', keyboard: keyboards.tg.quests };
    
    const isWeekly = questIdStr.startsWith('н') || questIdStr.startsWith('w');
    const questId = parseInt(questIdStr.replace(/[нw]/i, ''));
    
    const quest = db.claimQuest(`${ctx.platform}_${ctx.userId}`, questId, !isWeekly);
    
    if (!quest) return { text: '❌ Квест не найден или уже сдан!', keyboard: keyboards.tg.quests };
    
    let rewards = `💰 +${formatMoney(quest.reward.money)}`;
    if (quest.reward.exp) rewards += ` ⭐ +${quest.reward.exp}`;
    if (quest.reward.diamonds) rewards += ` 💎 +${quest.reward.diamonds}`;
    
    return {
      text: `✅ КВЕСТ СДАН!\n━━━━━━━━━━━━━━━━━━━━\n📋 ${quest.name}\n\n🎁 ${rewards}\n\n💵 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.quests
    };
  },
  
  // ==================== БОНУСЫ ====================
  bonus: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const cd = checkCooldown(user.cooldowns.bonus, config.game.cooldowns.bonus);
    
    if (!cd.ready) {
      return {
        text: `🎁 БОНУС\n━━━━━━━━━━━━━━━━━━━━\n⏰ Следующий через: ${formatTime(cd.remaining)}\n\n📌 Ежедневный бонус доступен раз в 24 часа.`,
        keyboard: keyboards.tg.main
      };
    }
    
    user.cooldowns.bonus = Date.now();
    
    const streak = (user.bonusStreak || 0) + 1;
    user.bonusStreak = streak;
    
    const baseMoney = 5000;
    const money = baseMoney * Math.min(streak, 7);
    const exp = 50 * Math.min(streak, 7);
    const diamonds = streak >= 7 ? 5 : 0;
    
    user.money += money;
    db.addExp(user, exp);
    if (diamonds) user.diamonds += diamonds;
    
    const path = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'bonus');
    let pathText = path ? `\n\n🎉 ПУТЬ НОВИЧКА!\n+${formatMoney(path.reward.money)}` : '';
    
    db.saveAll();
    
    return {
      text: `🎁 БОНУС\n━━━━━━━━━━━━━━━━━━━━\n🔥 Серия: ${streak} дней\n\n💰 +${formatMoney(money)}\n⭐ +${exp} XP${diamonds ? `\n💎 +${diamonds}` : ''}\n\n💵 Баланс: ${formatMoney(user.money)}${pathText}`,
      keyboard: keyboards.tg.main
    };
  },
  
  // ==================== ПРОМОКОД ====================
  promoCode: async (ctx, code) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (!code) {
      return {
        text: `🎁 ПРОМОКОДЫ\n━━━━━━━━━━━━━━━━━━━━\n📌 промокод [код]\n\n💡 Следите за новостями!`,
        keyboard: keyboards.tg.main
      };
    }
    
    const result = db.usePromoCode(`${ctx.platform}_${ctx.userId}`, code);
    
    if (!result.success) {
      return { text: `❌ ${result.error}`, keyboard: keyboards.tg.main };
    }
    
    let rewards = '';
    if (result.reward.money) rewards += `💰 +${formatMoney(result.reward.money)}\n`;
    if (result.reward.exp) rewards += `⭐ +${result.reward.exp} XP\n`;
    if (result.reward.diamonds) rewards += `💎 +${result.reward.diamonds}\n`;
    
    return {
      text: `✅ ПРОМОКОД АКТИВИРОВАН!\n━━━━━━━━━━━━━━━━━━━━\n📝 Код: ${code.toUpperCase()}\n\n🎁 Награда:\n${rewards}\n💵 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.main
    };
  },
  
  // ==================== СОБЫТИЯ ====================
  events: async (ctx) => {
    const active = db.getActiveEvents();
    
    if (active.length === 0) {
      return {
        text: `🎉 СОБЫТИЯ\n━━━━━━━━━━━━━━━━━━━━\n❌ Нет активных событий.\n\nСледите за объявлениями!`,
        keyboard: keyboards.tg.main
      };
    }
    
    let text = `🎉 АКТИВНЫЕ СОБЫТИЯ\n━━━━━━━━━━━━━━━━━━━━`;
    
    active.forEach(e => {
      const remaining = Math.floor((e.endTime - Date.now()) / 60000);
      text += `\n\n${e.name}\n⏰ Осталось: ${remaining} мин.`;
    });
    
    return { text, keyboard: keyboards.tg.main };
  },
  
  // ==================== ДОНАТ ====================
  donate: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    let privStatus = '❌ Нет';
    if (user.privilege && user.privilegeExpires > Date.now()) {
      const days = Math.ceil((user.privilegeExpires - Date.now()) / 86400000);
      privStatus = `✅ ${user.privilege} (${days} дн.)`;
    }
    
    return {
      text: `💎 ДОНАТ\n━━━━━━━━━━━━━━━━━━━━\n💎 Ваши алмазы: ${user.diamonds}\n👑 Привилегия: ${privStatus}\n\n🎁 ПРИВИЛЕГИИ:\n• VIP — 50💎 (30 дней)\n• PREMIUM — 100💎 (30 дней)\n• LEGEND — 200💎 (30 дней)\n• ULTIMATE — 500💎 (30 дней)\n\n✨ Бонусы:\n• Увеличенный доход\n• Сниженные кулдауны\n• Больше бизнесов\n• Бонус в казино\n\n📌 Пополнить алмазы — @admin`,
      keyboard: keyboards.tg.main
    };
  },
  
  // ==================== ЛОТЕРЕЯ ====================
  lottery: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    return {
      text: `🎟️ ЛОТЕРЕЯ\n━━━━━━━━━━━━━━━━━━━━\n💰 Джекпот: ${formatMoney(db.lottery.pool)}\n🎟️ Ваших билетов: ${user.lotteryTickets || 0}\n\n📌 лотерея купить [кол-во]\n💵 Цена билета: 1,000$\n\n🎲 Розыгрыш каждый час!`,
      keyboard: keyboards.tg.main
    };
  },
  
  lotteryBuy: async (ctx, countStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const count = parseInt(countStr) || 1;
    const price = count * 1000;
    
    if (user.money < price) return { text: `❌ Нужно ${formatMoney(price)}!`, keyboard: keyboards.tg.main };
    
    user.money -= price;
    user.lotteryTickets = (user.lotteryTickets || 0) + count;
    db.lottery.pool += price;
    
    for (let i = 0; i < count; i++) {
      db.lottery.tickets.push(`${ctx.platform}_${ctx.userId}`);
    }
    
    db.saveAll();
    
    return {
      text: `✅ КУПЛЕНО ${count} БИЛЕТ(ОВ)!\n💰 Потрачено: ${formatMoney(price)}\n🎟️ Всего билетов: ${user.lotteryTickets}\n\n💰 Джекпот: ${formatMoney(db.lottery.pool)}`,
      keyboard: keyboards.tg.main
    };
  }
};
