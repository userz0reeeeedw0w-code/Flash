// ⚡ FLASH BOT v2.0 — МОДУЛЬ ЭКОНОМИКИ
const db = require('../utils/database');
const keyboards = require('../utils/keyboards');
const config = require('../config');
const { formatMoney, formatNumber, checkCooldown, formatTime, parseAmount, random, levelFromExp } = require('../utils/helpers');

module.exports = {
  balance: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const btcRate = db.getCurrentBtcPrice();
    const btcValue = Math.floor(user.bitcoin * btcRate);
    
    return {
      text: `💰 БАЛАНС\n━━━━━━━━━━━━━━━━━━━━\n💵 Наличные: ${formatMoney(user.money)}\n🏦 Банк: ${formatMoney(user.bank)}\n━━━━━━━━━━━━━━━━━━━━\n₿ Биткоин: ${user.bitcoin.toFixed(6)}\n   ≈ ${formatMoney(btcValue)}\n━━━━━━━━━━━━━━━━━━━━\n💎 Алмазы: ${user.diamonds}\n🏆 Кубки: ${user.cups}\n⭐ Рейтинг: ${user.rating}\n💴 Рубли: ${formatNumber(user.rubles)}₽\n\n📊 Всего: ${formatMoney(user.money + user.bank + btcValue)}`,
      keyboard: keyboards.tg.balance
    };
  },
  
  bank: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    let creditText = user.credit ? `\n💳 Кредит: ${formatMoney(user.credit.amount)}` : '';
    
    return {
      text: `🏦 БАНК\n━━━━━━━━━━━━━━━━━━━━\n💵 Наличные: ${formatMoney(user.money)}\n🏦 На счету: ${formatMoney(user.bank)}\n📊 Лимит: ${formatMoney(user.bankLimit)}${creditText}\n\n📌 Команды:\n• банк положить [сумма/все]\n• банк снять [сумма/все]\n• банк лимит — увеличить лимит\n• банк кредит — меню кредита`,
      keyboard: keyboards.tg.bank
    };
  },
  
  bankDeposit: async (ctx, amountStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const maxDeposit = user.bankLimit - user.bank;
    let amount = parseAmount(amountStr, Math.min(user.money, maxDeposit));
    
    if (!amount || amount <= 0) return { text: '❌ Укажите сумму!', keyboard: keyboards.tg.bank };
    if (user.money < amount) return { text: `❌ Недостаточно! У вас: ${formatMoney(user.money)}`, keyboard: keyboards.tg.bank };
    if (user.bank + amount > user.bankLimit) return { text: `❌ Превышен лимит! Можно: ${formatMoney(maxDeposit)}`, keyboard: keyboards.tg.bank };
    
    user.money -= amount;
    user.bank += amount;
    db.saveAll();
    
    const path = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'bank');
    let pathText = path ? `\n\n🎉 ПУТЬ НОВИЧКА: Этап ${path.stage}!\n+${formatMoney(path.reward.money)}` : '';
    
    return {
      text: `✅ ДЕПОЗИТ\n━━━━━━━━━━━━━━━━━━━━\n💰 Положено: ${formatMoney(amount)}\n\n💵 Наличные: ${formatMoney(user.money)}\n🏦 В банке: ${formatMoney(user.bank)}${pathText}`,
      keyboard: keyboards.tg.bank
    };
  },
  
  bankWithdraw: async (ctx, amountStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    let amount = parseAmount(amountStr, user.bank);
    
    if (!amount || amount <= 0) return { text: '❌ Укажите сумму!', keyboard: keyboards.tg.bank };
    if (user.bank < amount) return { text: `❌ В банке: ${formatMoney(user.bank)}`, keyboard: keyboards.tg.bank };
    
    user.bank -= amount;
    user.money += amount;
    db.saveAll();
    
    return {
      text: `✅ СНЯТИЕ\n━━━━━━━━━━━━━━━━━━━━\n💰 Снято: ${formatMoney(amount)}\n\n💵 Наличные: ${formatMoney(user.money)}\n🏦 В банке: ${formatMoney(user.bank)}`,
      keyboard: keyboards.tg.bank
    };
  },
  
  bankLimit: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const cost = 10000;
    const increase = 50000;
    
    if (user.money < cost) return { text: `❌ Нужно ${formatMoney(cost)}!`, keyboard: keyboards.tg.bank };
    
    user.money -= cost;
    user.bankLimit += increase;
    db.saveAll();
    
    return {
      text: `✅ ЛИМИТ УВЕЛИЧЕН\n━━━━━━━━━━━━━━━━━━━━\n💰 Списано: ${formatMoney(cost)}\n📈 Новый лимит: ${formatMoney(user.bankLimit)}`,
      keyboard: keyboards.tg.bank
    };
  },
  
  bankCredit: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (user.credit) {
      return {
        text: `💳 ВАШ КРЕДИТ\n━━━━━━━━━━━━━━━━━━━━\n💰 К возврату: ${formatMoney(user.credit.amount)}\n📊 Процент: ${user.credit.percent}%\n\n📌 банк кредит вернуть — погасить`,
        keyboard: keyboards.tg.bank
      };
    }
    
    return {
      text: `💳 КРЕДИТ\n━━━━━━━━━━━━━━━━━━━━\n📊 Процент: 10%\n💰 Максимум: ${formatMoney(100000)}\n\n📌 банк кредит взять [сумма]`,
      keyboard: keyboards.tg.bank
    };
  },
  
  bankCreditTake: async (ctx, amountStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (user.credit) return { text: '❌ У вас уже есть кредит!', keyboard: keyboards.tg.bank };
    
    const amount = parseInt(amountStr);
    if (!amount || amount < 1000 || amount > 100000) {
      return { text: '❌ Сумма: 1,000$ - 100,000$', keyboard: keyboards.tg.bank };
    }
    
    user.credit = { amount: Math.floor(amount * 1.1), original: amount, percent: 10, date: Date.now() };
    user.money += amount;
    db.saveAll();
    
    return {
      text: `✅ КРЕДИТ ОДОБРЕН\n━━━━━━━━━━━━━━━━━━━━\n💰 Получено: ${formatMoney(amount)}\n📊 Процент: 10%\n💳 К возврату: ${formatMoney(user.credit.amount)}\n\n⚠️ банк кредит вернуть — погасить`,
      keyboard: keyboards.tg.bank
    };
  },
  
  bankCreditReturn: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (!user.credit) return { text: '❌ Нет активного кредита!', keyboard: keyboards.tg.bank };
    if (user.money < user.credit.amount) return { text: `❌ Нужно ${formatMoney(user.credit.amount)}!`, keyboard: keyboards.tg.bank };
    
    user.money -= user.credit.amount;
    const returned = user.credit.amount;
    user.credit = null;
    db.saveAll();
    
    return {
      text: `✅ КРЕДИТ ПОГАШЕН\n━━━━━━━━━━━━━━━━━━━━\n💰 Выплачено: ${formatMoney(returned)}\n💵 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.bank
    };
  },
  
  transfer: async (ctx, targetId, amountStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (!targetId || !amountStr) {
      return { text: '❌ Формат: перевод [ID] [сумма]\nПример: перевод #5 1000', keyboard: keyboards.tg.balance };
    }
    
    const id = parseInt(String(targetId).replace('#', ''));
    const target = db.getUserById(id);
    
    if (!target) return { text: '❌ Игрок не найден!', keyboard: keyboards.tg.balance };
    if (target.uid === user.uid) return { text: '❌ Нельзя перевести себе!', keyboard: keyboards.tg.balance };
    
    const amount = parseAmount(amountStr, user.money);
    if (!amount || amount < config.game.minTransfer) {
      return { text: `❌ Минимум: ${formatMoney(config.game.minTransfer)}`, keyboard: keyboards.tg.balance };
    }
    if (user.money < amount) return { text: `❌ Недостаточно! У вас: ${formatMoney(user.money)}`, keyboard: keyboards.tg.balance };
    
    const commission = Math.floor(amount * config.game.transferFee);
    const received = amount - commission;
    
    user.money -= amount;
    target.money += received;
    db.saveAll();
    
    return {
      text: `✅ ПЕРЕВОД\n━━━━━━━━━━━━━━━━━━━━\n👤 Получатель: ${target.name} (#${target.id})\n💰 Сумма: ${formatMoney(amount)}\n📊 Комиссия (3%): ${formatMoney(commission)}\n✅ Получено: ${formatMoney(received)}\n\n💵 Ваш баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.balance
    };
  },
  
  exchange: async (ctx, currency, amountStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const btcRate = db.getCurrentBtcPrice();
    const rubRate = 90 + random(0, 10);
    
    if (!currency) {
      return {
        text: `💱 ОБМЕН ВАЛЮТ\n━━━━━━━━━━━━━━━━━━━━\n📊 КУРСЫ:\n₿ 1 BTC = ${formatMoney(btcRate)}\n💴 1$ = ${rubRate}₽\n\n📌 Команды:\n• обмен рубли [сумма] — $ в ₽\n• обмен доллары [сумма] — ₽ в $\n• продать биткоины [сумма]`,
        keyboard: keyboards.tg.balance
      };
    }
    
    const amount = parseAmount(amountStr, currency === 'рубли' ? user.money : user.rubles);
    if (!amount) return { text: '❌ Укажите сумму!', keyboard: keyboards.tg.balance };
    
    if (currency === 'рубли') {
      if (user.money < amount) return { text: '❌ Недостаточно долларов!', keyboard: keyboards.tg.balance };
      const rubles = amount * rubRate;
      user.money -= amount;
      user.rubles += rubles;
      db.saveAll();
      return { text: `✅ Обменяно ${formatMoney(amount)} на ${formatNumber(rubles)}₽`, keyboard: keyboards.tg.balance };
    }
    
    if (currency === 'доллары') {
      if (user.rubles < amount) return { text: '❌ Недостаточно рублей!', keyboard: keyboards.tg.balance };
      const dollars = Math.floor(amount / rubRate);
      user.rubles -= amount;
      user.money += dollars;
      db.saveAll();
      return { text: `✅ Обменяно ${formatNumber(amount)}₽ на ${formatMoney(dollars)}`, keyboard: keyboards.tg.balance };
    }
    
    return { text: '❌ Укажите валюту: рубли или доллары', keyboard: keyboards.tg.balance };
  },
  
  sellBitcoin: async (ctx, amountStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const amount = amountStr === 'все' ? user.bitcoin : parseFloat(amountStr);
    if (!amount || amount <= 0) return { text: '❌ Укажите количество BTC!', keyboard: keyboards.tg.balance };
    if (user.bitcoin < amount) return { text: `❌ У вас только ₿${user.bitcoin.toFixed(6)}`, keyboard: keyboards.tg.balance };
    
    const btcRate = db.getCurrentBtcPrice();
    const money = Math.floor(amount * btcRate);
    
    user.bitcoin -= amount;
    user.money += money;
    db.saveAll();
    
    return {
      text: `✅ ПРОДАНО\n━━━━━━━━━━━━━━━━━━━━\n₿ Продано: ${amount.toFixed(6)} BTC\n💰 Получено: ${formatMoney(money)}\n📊 Курс: ${formatMoney(btcRate)}/BTC`,
      keyboard: keyboards.tg.balance
    };
  },
  
  btcRate: async (ctx) => {
    const btcRate = db.getCurrentBtcPrice();
    const rubRate = 90 + random(0, 10);
    
    return {
      text: `📊 КУРСЫ ВАЛЮТ\n━━━━━━━━━━━━━━━━━━━━\n₿ 1 BTC = ${formatMoney(btcRate)}\n💴 1 $ = ${rubRate}₽\n\n📈 Курс обновляется каждую минуту`,
      keyboard: keyboards.tg.balance
    };
  }
};
