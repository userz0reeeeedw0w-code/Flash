// ⚡ FLASH BOT v2.0 — МОДУЛЬ РАЗВЛЕЧЕНИЙ
const config = require('../config');
const { randomElement, reverseString, calculateMath, random } = require('../utils/helpers');

module.exports = {
  // Анекдот
  joke: async (ctx) => {
    const joke = randomElement(config.jokes);
    return {
      text: `😂 АНЕКДОТ\n━━━━━━━━━━━━━━━━━━━━\n${joke}`
    };
  },
  
  // Магический шар
  ball: async (ctx, question) => {
    if (!question) {
      return { text: '❓ Задайте вопрос!\nПример: шар Меня кто-нибудь любит?' };
    }
    
    const answer = randomElement(config.ballAnswers);
    return {
      text: `🔮 МАГИЧЕСКИЙ ШАР\n━━━━━━━━━━━━━━━━━━━━\n❓ ${question}\n\n${answer}`
    };
  },
  
  // Переверни
  reverse: async (ctx, text) => {
    if (!text) {
      return { text: '❌ Укажите текст!\nПример: переверни Привет мир' };
    }
    
    const reversed = reverseString(text);
    return {
      text: `🔄 ПЕРЕВЕРНИ\n━━━━━━━━━━━━━━━━━━━━\n📝 Было: ${text}\n📝 Стало: ${reversed}`
    };
  },
  
  // Выбери
  choose: async (ctx, text) => {
    if (!text || !text.includes(' или ')) {
      return { text: '❌ Формат: выбери вариант1 или вариант2\nПример: выбери пицца или бургер' };
    }
    
    const options = text.split(/ или /i).filter(o => o.trim());
    if (options.length < 2) {
      return { text: '❌ Укажите минимум 2 варианта!' };
    }
    
    const choice = randomElement(options).trim();
    return {
      text: `🎯 ВЫБЕРИ\n━━━━━━━━━━━━━━━━━━━━\n❓ ${text}\n\n✅ Мой выбор: ${choice}`
    };
  },
  
  // Вероятность
  probability: async (ctx, text) => {
    if (!text) {
      return { text: '❌ Укажите фразу!\nПример: инфа я выиграю в лотерею' };
    }
    
    const percent = random(0, 100);
    let emoji = '🤔';
    
    if (percent >= 80) emoji = '✅';
    else if (percent >= 60) emoji = '👍';
    else if (percent >= 40) emoji = '🤷';
    else if (percent >= 20) emoji = '👎';
    else emoji = '❌';
    
    return {
      text: `📊 ВЕРОЯТНОСТЬ\n━━━━━━━━━━━━━━━━━━━━\n❓ ${text}\n\n${emoji} Вероятность: ${percent}%`
    };
  },
  
  // Калькулятор
  calculate: async (ctx, expression) => {
    if (!expression) {
      return { text: '❌ Укажите пример!\nПример: реши 2 + 2 * 2' };
    }
    
    const result = calculateMath(expression);
    
    if (result === null) {
      return { text: '❌ Не могу вычислить! Проверьте выражение.' };
    }
    
    return {
      text: `🧮 КАЛЬКУЛЯТОР\n━━━━━━━━━━━━━━━━━━━━\n📝 ${expression}\n\n✅ Ответ: ${result}`
    };
  },
  
  // Рейтинг
  sellRating: async (ctx, amountStr) => {
    const db = require('../utils/database');
    const { formatMoney, parseAmount } = require('../utils/helpers');
    
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!' };
    
    const amount = parseAmount(amountStr, user.rating);
    if (!amount || amount <= 0) return { text: '❌ Укажите количество рейтинга!' };
    if (user.rating < amount) return { text: `❌ У вас только ⭐${user.rating}` };
    
    const price = amount * 100;
    user.rating -= amount;
    user.money += price;
    db.saveAll();
    
    return {
      text: `✅ ПРОДАНО\n━━━━━━━━━━━━━━━━━━━━\n⭐ Рейтинг: -${amount}\n💰 Получено: ${formatMoney(price)}`
    };
  }
};
