// ⚡ FLASH BOT v2.0 — МОДУЛЬ ИГР
const db = require('../utils/database');
const keyboards = require('../utils/keyboards');
const config = require('../config');
const { formatMoney, formatNumber, checkCooldown, formatTime, random, randomElement, parseAmount, getCooldownMultiplier, getIncomeMultiplier } = require('../utils/helpers');

module.exports = {
  // ==================== КАЗИНО ====================
  casino: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    return {
      text: `🎰 КАЗИНО\n━━━━━━━━━━━━━━━━━━━━\n💰 Баланс: ${formatMoney(user.money)}\n\n🎮 ИГРЫ:\n• казино [ставка] — слоты\n• рулетка [ставка] [красное/чёрное]\n• кости [ставка] [1-6]\n• монетка [ставка] [орёл/решка]\n\n📊 Ставок: ${user.stats.casinoBets}\n✅ Побед: ${user.stats.casinoWins}\n\n💡 Минимум: 100$`,
      keyboard: keyboards.tg.casino
    };
  },
  
  casinoSlots: async (ctx, betStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const bet = parseAmount(betStr, user.money);
    if (!bet || bet < 100) return { text: '❌ Минимум 100$!', keyboard: keyboards.tg.casino };
    if (user.money < bet) return { text: `❌ Недостаточно! У вас: ${formatMoney(user.money)}`, keyboard: keyboards.tg.casino };
    
    const symbols = ['🍒', '🍋', '🍊', '🍇', '⭐', '💎', '7️⃣'];
    const weights = [25, 20, 18, 15, 12, 7, 3];
    
    const spin = () => {
      const total = weights.reduce((a, b) => a + b, 0);
      let rand = random(1, total);
      for (let i = 0; i < weights.length; i++) {
        rand -= weights[i];
        if (rand <= 0) return symbols[i];
      }
      return symbols[0];
    };
    
    const s1 = spin(), s2 = spin(), s3 = spin();
    
    user.money -= bet;
    user.stats.casinoBets++;
    
    let multiplier = 0;
    let result = '❌ Проигрыш';
    
    if (s1 === s2 && s2 === s3) {
      const idx = symbols.indexOf(s1);
      multiplier = [2, 3, 4, 5, 8, 15, 50][idx];
      result = '🎉 ДЖЕКПОТ!';
      user.stats.casinoWins++;
    } else if (s1 === s2 || s2 === s3 || s1 === s3) {
      multiplier = 1.5;
      result = '✅ Выигрыш!';
      user.stats.casinoWins++;
    } else {
      user.stats.casinoLosses++;
    }
    
    const winnings = Math.floor(bet * multiplier);
    user.money += winnings;
    user.stats.totalEarned += Math.max(0, winnings - bet);
    
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'casino_bets', 1);
    db.saveAll();
    
    const profit = winnings - bet;
    const profitText = profit >= 0 ? `+${formatMoney(profit)}` : formatMoney(profit);
    
    return {
      text: `🎰 СЛОТЫ\n━━━━━━━━━━━━━━━━━━━━\n┃ ${s1} ┃ ${s2} ┃ ${s3} ┃\n━━━━━━━━━━━━━━━━━━━━\n${result}\n\n💰 Ставка: ${formatMoney(bet)}\n📊 x${multiplier.toFixed(1)}\n💵 Выигрыш: ${formatMoney(winnings)}\n📈 Профит: ${profitText}\n\n💰 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.casino
    };
  },
  
  casinoRoulette: async (ctx, betStr, color) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const bet = parseInt(betStr);
    if (!bet || bet < 100) return { text: '❌ Минимум 100$!', keyboard: keyboards.tg.casino };
    if (user.money < bet) return { text: `❌ Недостаточно!`, keyboard: keyboards.tg.casino };
    
    const validColors = ['красное', 'red', 'чёрное', 'черное', 'black', 'зелёное', 'зеленое', 'green'];
    if (!color || !validColors.includes(color.toLowerCase())) {
      return { text: '❌ Укажите: красное, чёрное или зелёное', keyboard: keyboards.tg.casino };
    }
    
    user.money -= bet;
    user.stats.casinoBets++;
    
    const number = random(0, 36);
    const isGreen = number === 0;
    const isRed = !isGreen && number % 2 === 1;
    const isBlack = !isGreen && number % 2 === 0;
    
    const resultColor = isGreen ? '🟢 Зелёное' : (isRed ? '🔴 Красное' : '⚫ Чёрное');
    
    let win = false, multiplier = 0;
    const c = color.toLowerCase();
    
    if ((c === 'красное' || c === 'red') && isRed) { win = true; multiplier = 2; }
    else if ((c === 'чёрное' || c === 'черное' || c === 'black') && isBlack) { win = true; multiplier = 2; }
    else if ((c === 'зелёное' || c === 'зеленое' || c === 'green') && isGreen) { win = true; multiplier = 14; }
    
    if (win) user.stats.casinoWins++; else user.stats.casinoLosses++;
    
    const winnings = Math.floor(bet * multiplier);
    user.money += winnings;
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'casino_bets', 1);
    db.saveAll();
    
    return {
      text: `🎯 РУЛЕТКА\n━━━━━━━━━━━━━━━━━━━━\n🔢 Число: ${number}\n🎨 ${resultColor}\n\n${win ? '🎉 ПОБЕДА!' : '❌ Проигрыш'}\n\n💰 Ставка: ${formatMoney(bet)}\n💵 Выигрыш: ${formatMoney(winnings)}\n💰 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.casino
    };
  },
  
  casinoDice: async (ctx, betStr, guessStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const bet = parseInt(betStr);
    const guess = parseInt(guessStr);
    
    if (!bet || bet < 100) return { text: '❌ Минимум 100$!', keyboard: keyboards.tg.casino };
    if (!guess || guess < 1 || guess > 6) return { text: '❌ Укажите число 1-6', keyboard: keyboards.tg.casino };
    if (user.money < bet) return { text: `❌ Недостаточно!`, keyboard: keyboards.tg.casino };
    
    user.money -= bet;
    user.stats.casinoBets++;
    
    const dice = random(1, 6);
    const diceEmoji = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'][dice - 1];
    const win = dice === guess;
    
    if (win) user.stats.casinoWins++; else user.stats.casinoLosses++;
    
    const winnings = win ? bet * 5 : 0;
    user.money += winnings;
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'casino_bets', 1);
    db.saveAll();
    
    return {
      text: `🎲 КОСТИ\n━━━━━━━━━━━━━━━━━━━━\n${diceEmoji} Выпало: ${dice}\n🎯 Ваше: ${guess}\n\n${win ? '🎉 УГАДАЛИ! x5' : '❌ Мимо!'}\n\n💰 Ставка: ${formatMoney(bet)}\n💵 Выигрыш: ${formatMoney(winnings)}\n💰 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.casino
    };
  },
  
  casinoCoin: async (ctx, betStr, sideStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const bet = parseAmount(betStr, user.money);
    if (!bet || bet < 100) return { text: '❌ Минимум 100$!', keyboard: keyboards.tg.casino };
    
    const validSides = ['орёл', 'орел', 'о', 'head', 'решка', 'р', 'tail'];
    if (!sideStr || !validSides.includes(sideStr.toLowerCase())) {
      return { text: '❌ Укажите: орёл или решка', keyboard: keyboards.tg.casino };
    }
    
    if (user.money < bet) return { text: `❌ Недостаточно!`, keyboard: keyboards.tg.casino };
    
    user.money -= bet;
    user.stats.casinoBets++;
    
    const result = Math.random() < 0.5 ? 'орёл' : 'решка';
    const emoji = result === 'орёл' ? '🦅' : '🪙';
    const side = sideStr.toLowerCase();
    const guessedEagle = ['орёл', 'орел', 'о', 'head'].includes(side);
    const win = (guessedEagle && result === 'орёл') || (!guessedEagle && result === 'решка');
    
    if (win) user.stats.casinoWins++; else user.stats.casinoLosses++;
    
    const winnings = win ? bet * 2 : 0;
    user.money += winnings;
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'casino_bets', 1);
    db.saveAll();
    
    return {
      text: `🪙 МОНЕТКА\n━━━━━━━━━━━━━━━━━━━━\n${emoji} Выпало: ${result.toUpperCase()}\n\n${win ? '🎉 ПОБЕДА! x2' : '❌ Проигрыш!'}\n\n💰 Ставка: ${formatMoney(bet)}\n💵 Выигрыш: ${formatMoney(winnings)}\n💰 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.casino
    };
  },
  
  // ==================== МИНИ-ИГРЫ ====================
  games: async (ctx) => {
    return {
      text: `🎮 МИНИ-ИГРЫ\n━━━━━━━━━━━━━━━━━━━━\n\n📈 трейд [вверх/вниз] [ставка]\n   Угадай направление курса\n\n🎲 кубик [1-6] [ставка]\n   Угадай число на кубике\n\n🥛 стаканчик [1-3] [ставка]\n   Найди шарик под стаканом\n\n⚔️ дуэль [ID] [ставка]\n   Сразись с другим игроком\n\n💡 Минимальная ставка: 100$`,
      keyboard: keyboards.tg.games
    };
  },
  
  trade: async (ctx, direction, amountStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (!direction) {
      const btcRate = db.getCurrentBtcPrice();
      return {
        text: `📈 ТРЕЙДИНГ\n━━━━━━━━━━━━━━━━━━━━\n₿ Курс BTC: ${formatMoney(btcRate)}\n\n📊 Угадайте куда пойдёт курс!\n\n📌 трейд вверх [ставка]\n📌 трейд вниз [ставка]\n\n💡 Выигрыш: x1.9`,
        keyboard: keyboards.tg.games
      };
    }
    
    const validDirs = ['вверх', 'up', 'вниз', 'down'];
    if (!validDirs.includes(direction.toLowerCase())) {
      return { text: '❌ Укажите: вверх или вниз', keyboard: keyboards.tg.games };
    }
    
    const cd = checkCooldown(user.cooldowns.trade, config.game.cooldowns.trade);
    if (!cd.ready) return { text: `⏰ Подождите: ${formatTime(cd.remaining)}`, keyboard: keyboards.tg.games };
    
    const bet = parseAmount(amountStr, user.money);
    if (!bet || bet < 100) return { text: '❌ Минимум 100$!', keyboard: keyboards.tg.games };
    if (user.money < bet) return { text: '❌ Недостаточно денег!', keyboard: keyboards.tg.games };
    
    user.money -= bet;
    user.cooldowns.trade = Date.now();
    
    const userUp = ['вверх', 'up'].includes(direction.toLowerCase());
    const actualUp = Math.random() < 0.5;
    const win = userUp === actualUp;
    
    if (win) {
      user.stats.tradesWon++;
      const winnings = Math.floor(bet * 1.9);
      user.money += winnings;
      user.stats.totalEarned += winnings - bet;
    } else {
      user.stats.tradesLost++;
    }
    
    db.saveAll();
    
    const arrow = actualUp ? '📈 ВВЕРХ' : '📉 ВНИЗ';
    const winnings = win ? Math.floor(bet * 1.9) : 0;
    
    return {
      text: `📊 ТРЕЙД\n━━━━━━━━━━━━━━━━━━━━\nКурс пошёл: ${arrow}\n\n${win ? '🎉 УГАДАЛИ! x1.9' : '❌ Не угадали!'}\n\n💰 Ставка: ${formatMoney(bet)}\n💵 Выигрыш: ${formatMoney(winnings)}\n💰 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.games
    };
  },
  
  gameDice: async (ctx, guessStr, amountStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (!guessStr) {
      return {
        text: `🎲 КУБИК\n━━━━━━━━━━━━━━━━━━━━\nУгадайте число от 1 до 6!\n\n📌 кубик [число] [ставка]\nПример: кубик 3 1000\n\n💡 Выигрыш: x5`,
        keyboard: keyboards.tg.games
      };
    }
    
    const guess = parseInt(guessStr);
    const bet = parseAmount(amountStr, user.money);
    
    if (!guess || guess < 1 || guess > 6) return { text: '❌ Число от 1 до 6!', keyboard: keyboards.tg.games };
    if (!bet || bet < 100) return { text: '❌ Минимум 100$!', keyboard: keyboards.tg.games };
    if (user.money < bet) return { text: '❌ Недостаточно!', keyboard: keyboards.tg.games };
    
    const cd = checkCooldown(user.cooldowns.dice, config.game.cooldowns.dice);
    if (!cd.ready) return { text: `⏰ Подождите: ${formatTime(cd.remaining)}`, keyboard: keyboards.tg.games };
    
    user.money -= bet;
    user.cooldowns.dice = Date.now();
    
    const dice = random(1, 6);
    const win = dice === guess;
    const winnings = win ? bet * 5 : 0;
    
    if (win) user.money += winnings;
    db.saveAll();
    
    return {
      text: `🎲 КУБИК\n━━━━━━━━━━━━━━━━━━━━\n🎯 Ваше: ${guess}\n🎲 Выпало: ${dice}\n\n${win ? '🎉 УГАДАЛИ! x5' : '❌ Мимо!'}\n\n💵 Выигрыш: ${formatMoney(winnings)}\n💰 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.games
    };
  },
  
  gameCup: async (ctx, guessStr, amountStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (!guessStr) {
      return {
        text: `🥛 СТАКАНЧИКИ\n━━━━━━━━━━━━━━━━━━━━\nПод каким стаканом шарик?\n\n🥛 🥛 🥛\n 1   2   3\n\n📌 стаканчик [1-3] [ставка]\n\n💡 Выигрыш: x2.5`,
        keyboard: keyboards.tg.games
      };
    }
    
    const guess = parseInt(guessStr);
    const bet = parseAmount(amountStr, user.money);
    
    if (!guess || guess < 1 || guess > 3) return { text: '❌ Выберите 1, 2 или 3!', keyboard: keyboards.tg.games };
    if (!bet || bet < 100) return { text: '❌ Минимум 100$!', keyboard: keyboards.tg.games };
    if (user.money < bet) return { text: '❌ Недостаточно!', keyboard: keyboards.tg.games };
    
    const cd = checkCooldown(user.cooldowns.cup, config.game.cooldowns.cup);
    if (!cd.ready) return { text: `⏰ Подождите: ${formatTime(cd.remaining)}`, keyboard: keyboards.tg.games };
    
    user.money -= bet;
    user.cooldowns.cup = Date.now();
    
    const ball = random(1, 3);
    const win = ball === guess;
    const winnings = win ? Math.floor(bet * 2.5) : 0;
    
    const cups = ['🥛', '🥛', '🥛'];
    cups[ball - 1] = '🔵';
    
    if (win) user.money += winnings;
    db.saveAll();
    
    return {
      text: `🥛 СТАКАНЧИКИ\n━━━━━━━━━━━━━━━━━━━━\n${cups[0]} ${cups[1]} ${cups[2]}\n 1   2   3\n\n🎯 Ваш выбор: ${guess}\n🔵 Шарик под: ${ball}\n\n${win ? '🎉 УГАДАЛИ! x2.5' : '❌ Мимо!'}\n\n💵 Выигрыш: ${formatMoney(winnings)}\n💰 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.games
    };
  },
  
  // ==================== ГОНКИ ====================
  race: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (!user.currentCar) {
      return { text: `🏁 ГОНКИ\n━━━━━━━━━━━━━━━━━━━━\n❌ Нет машины!\n\n📌 машина список\n📌 машина купить [номер]`, keyboard: keyboards.tg.race };
    }
    
    const cdTime = config.game.cooldowns.race * getCooldownMultiplier(user, config);
    const cd = checkCooldown(user.cooldowns.race, cdTime);
    if (!cd.ready) return { text: `⏰ Подождите: ${formatTime(cd.remaining)}`, keyboard: keyboards.tg.race };
    
    if (user.energy < config.game.energyCosts.race) {
      return { text: `❌ Нужно ${config.game.energyCosts.race}⚡!`, keyboard: keyboards.tg.race };
    }
    
    const car = config.cars.find(c => c.id === user.currentCar);
    const speed = car.speed * (1 + user.tuning * 0.05);
    
    const opponent = randomElement(config.cars);
    const opponentSpeed = opponent.speed * (0.8 + Math.random() * 0.4);
    
    user.energy -= config.game.energyCosts.race;
    user.cooldowns.race = Date.now();
    
    const win = speed > opponentSpeed;
    let cups = win ? random(1, 3) : 0;
    let prize = win ? random(5000, 15000) : 0;
    const exp = win ? random(20, 50) : 10;
    
    prize = Math.floor(prize * getIncomeMultiplier(user, config));
    
    if (win) {
      user.money += prize;
      user.cups += cups;
      user.stats.raceWins++;
      user.stats.totalEarned += prize;
      db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'race_wins', 1);
    } else {
      user.stats.raceLosses++;
    }
    
    db.addExp(user, exp);
    db.saveAll();
    
    return {
      text: `🏁 ГОНКА\n━━━━━━━━━━━━━━━━━━━━\n🚗 Вы: ${car.name} (${Math.floor(speed)} км/ч)\n🚙 Соперник: ${opponent.name} (${Math.floor(opponentSpeed)} км/ч)\n\n${win ? '🎉 ПОБЕДА!' : '❌ Поражение!'}\n\n💰 Приз: ${formatMoney(prize)}\n🏆 Кубки: +${cups}\n⭐ Опыт: +${exp}\n\n💰 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.race
    };
  },
  
  // ==================== ДОБЫЧА ====================
  mine: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const cd = checkCooldown(user.cooldowns.mining, config.game.cooldowns.mining);
    if (!cd.ready) return { text: `⏰ Подождите: ${formatTime(cd.remaining)}`, keyboard: keyboards.tg.start };
    
    user.cooldowns.mining = Date.now();
    
    const availableOres = config.ores.filter(o => user.pickaxeLevel >= o.minLevel);
    const ore = randomElement(availableOres);
    const count = random(1, 3 + user.pickaxeLevel);
    
    if (!user.ores) user.ores = {};
    user.ores[ore.id] = (user.ores[ore.id] || 0) + count;
    user.stats.oreMined += count;
    
    const exp = random(5, 15);
    db.addExp(user, exp);
    db.saveAll();
    
    return {
      text: `⛏️ ШАХТА\n━━━━━━━━━━━━━━━━━━━━\nВы добыли: ${ore.name} x${count}\n⭐ Опыт: +${exp}\n\n📌 продать руду — продать всё`,
      keyboard: keyboards.tg.main
    };
  },
  
  fish: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const cd = checkCooldown(user.cooldowns.fishing, config.game.cooldowns.fishing);
    if (!cd.ready) return { text: `⏰ Подождите: ${formatTime(cd.remaining)}`, keyboard: keyboards.tg.start };
    
    user.cooldowns.fishing = Date.now();
    
    const fish = randomElement(config.fishes);
    const count = random(1, 2 + user.rodLevel);
    
    if (!user.fish) user.fish = {};
    user.fish[fish.id] = (user.fish[fish.id] || 0) + count;
    user.stats.fishCaught += count;
    
    const exp = random(5, 20);
    db.addExp(user, exp);
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'fish', count);
    db.saveAll();
    
    return {
      text: `🎣 РЫБАЛКА\n━━━━━━━━━━━━━━━━━━━━\nВы поймали: ${fish.name} x${count}\n⭐ Опыт: +${exp}\n\n📌 продать рыбу — продать всё`,
      keyboard: keyboards.tg.main
    };
  },
  
  hunt: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const cd = checkCooldown(user.cooldowns.hunting, config.game.cooldowns.hunting);
    if (!cd.ready) return { text: `⏰ Подождите: ${formatTime(cd.remaining)}`, keyboard: keyboards.tg.start };
    
    if (user.energy < config.game.energyCosts.hunting) {
      return { text: `❌ Нужно ${config.game.energyCosts.hunting}⚡!`, keyboard: keyboards.tg.main };
    }
    
    user.energy -= config.game.energyCosts.hunting;
    user.cooldowns.hunting = Date.now();
    
    const animal = randomElement(config.animals);
    
    if (!user.trophies) user.trophies = {};
    user.trophies[animal.id] = (user.trophies[animal.id] || 0) + 1;
    user.stats.huntingSuccess++;
    
    const exp = random(15, 40);
    db.addExp(user, exp);
    db.saveAll();
    
    return {
      text: `🏹 ОХОТА\n━━━━━━━━━━━━━━━━━━━━\nВы добыли: ${animal.name}\n⭐ Опыт: +${exp}\n\n📌 продать трофеи — продать всё`,
      keyboard: keyboards.tg.main
    };
  },
  
  sellOres: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (!user.ores || Object.keys(user.ores).length === 0) {
      return { text: '❌ Нет руды для продажи!', keyboard: keyboards.tg.main };
    }
    
    let total = 0;
    Object.entries(user.ores).forEach(([id, count]) => {
      const ore = config.ores.find(o => o.id === parseInt(id));
      if (ore) total += ore.price * count;
    });
    
    user.ores = {};
    user.money += total;
    user.stats.totalEarned += total;
    db.saveAll();
    
    return { text: `✅ Продано руды на ${formatMoney(total)}`, keyboard: keyboards.tg.main };
  },
  
  sellFish: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (!user.fish || Object.keys(user.fish).length === 0) {
      return { text: '❌ Нет рыбы для продажи!', keyboard: keyboards.tg.main };
    }
    
    let total = 0;
    Object.entries(user.fish).forEach(([id, count]) => {
      const fish = config.fishes.find(f => f.id === parseInt(id));
      if (fish) total += fish.price * count;
    });
    
    user.fish = {};
    user.money += total;
    user.stats.totalEarned += total;
    db.saveAll();
    
    return { text: `✅ Продано рыбы на ${formatMoney(total)}`, keyboard: keyboards.tg.main };
  },
  
  sellTrophies: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (!user.trophies || Object.keys(user.trophies).length === 0) {
      return { text: '❌ Нет трофеев!', keyboard: keyboards.tg.main };
    }
    
    let total = 0;
    Object.entries(user.trophies).forEach(([id, count]) => {
      const animal = config.animals.find(a => a.id === parseInt(id));
      if (animal) total += animal.price * count;
    });
    
    user.trophies = {};
    user.money += total;
    user.stats.totalEarned += total;
    db.saveAll();
    
    return { text: `✅ Продано трофеев на ${formatMoney(total)}`, keyboard: keyboards.tg.main };
  },
  
  // ==================== ДУЭЛЬ ====================
  duel: async (ctx, targetId, amountStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (!targetId || !amountStr) {
      return { text: `⚔️ ДУЭЛЬ\n━━━━━━━━━━━━━━━━━━━━\n📌 дуэль [ID] [ставка]\nПример: дуэль #5 1000\n\n💡 Выигравший забирает обе ставки!`, keyboard: keyboards.tg.games };
    }
    
    const id = parseInt(String(targetId).replace('#', ''));
    const target = db.getUserById(id);
    
    if (!target) return { text: '❌ Игрок не найден!', keyboard: keyboards.tg.games };
    if (target.uid === user.uid) return { text: '❌ Нельзя с собой!', keyboard: keyboards.tg.games };
    
    const bet = parseAmount(amountStr, user.money);
    if (!bet || bet < 100) return { text: '❌ Минимум 100$!', keyboard: keyboards.tg.games };
    if (user.money < bet) return { text: '❌ Недостаточно денег!', keyboard: keyboards.tg.games };
    if (target.money < bet) return { text: '❌ У соперника недостаточно!', keyboard: keyboards.tg.games };
    
    if (user.energy < config.game.energyCosts.duel) {
      return { text: `❌ Нужно ${config.game.energyCosts.duel}⚡!`, keyboard: keyboards.tg.games };
    }
    
    user.money -= bet;
    target.money -= bet;
    user.energy -= config.game.energyCosts.duel;
    
    const win = Math.random() < 0.5;
    const prize = bet * 2;
    
    if (win) {
      user.money += prize;
      user.stats.duelWins++;
      target.stats.duelLosses++;
    } else {
      target.money += prize;
      user.stats.duelLosses++;
      target.stats.duelWins++;
    }
    
    db.saveAll();
    
    return {
      text: `⚔️ ДУЭЛЬ\n━━━━━━━━━━━━━━━━━━━━\n👤 Вы vs ${target.name}\n💰 Ставка: ${formatMoney(bet)}\n\n${win ? '🎉 ВЫ ПОБЕДИЛИ!' : `❌ Победил ${target.name}!`}\n\n💵 ${win ? `+${formatMoney(prize)}` : `-${formatMoney(bet)}`}\n💰 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.games
    };
  }
};
