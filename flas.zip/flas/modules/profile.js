// ⚡ FLASH BOT v2.0 — МОДУЛЬ ПРОФИЛЯ
const db = require('../utils/database');
const keyboards = require('../utils/keyboards');
const config = require('../config');
const { formatMoney, formatNumber, levelFromExp, progressBar } = require('../utils/helpers');

module.exports = {
  profile: async (ctx, targetId = null) => {
    let user, isSelf = true;
    
    if (targetId) {
      const id = parseInt(String(targetId).replace('#', ''));
      user = db.getUserById(id);
      isSelf = false;
    } else {
      user = db.getUserByPlatform(ctx.platform, ctx.userId);
    }
    
    if (!user) return { text: '❌ Игрок не найден!', keyboard: keyboards.tg.main };
    
    const lvl = levelFromExp(user.exp);
    const expBar = progressBar(lvl.currentExp, lvl.nextExp, 10);
    
    let privText = '❌ Нет';
    if (user.privilege && user.privilegeExpires > Date.now()) {
      const days = Math.ceil((user.privilegeExpires - Date.now()) / 86400000);
      privText = `${user.privilege} (${days} дн.)`;
    }
    
    const jobText = user.job ? config.jobs.find(j => j.id === user.job)?.name : '❌ Безработный';
    const carText = user.currentCar ? config.cars.find(c => c.id === user.currentCar)?.name : '❌ Нет';
    const clanText = user.clanId ? db.clans[user.clanId]?.name : '❌ Нет';
    
    return {
      text: `👤 ПРОФИЛЬ${isSelf ? '' : ` — ${user.name}`}\n━━━━━━━━━━━━━━━━━━━━\n🆔 ID: #${user.id}\n📝 Ник: ${user.name}\n👑 Привилегия: ${privText}\n\n📊 Уровень: ${lvl.level}\n${expBar} ${lvl.currentExp}/${lvl.nextExp}\n\n💰 ${formatMoney(user.money)} | 🏦 ${formatMoney(user.bank)}\n₿ ${user.bitcoin.toFixed(6)} | 💎 ${user.diamonds} | 🏆 ${user.cups}\n\n💼 ${jobText}\n🚗 ${carText} | 🔧 Тюнинг: ${user.tuning}/20\n🏛️ ${clanText}\n🏠 ${user.house > 0 ? config.houses[user.house - 1]?.name : '❌ Нет'}\n⚡ ${user.energy}/${config.game.maxEnergy}\n\n📅 В игре с: ${new Date(user.registered).toLocaleDateString()}`,
      keyboard: isSelf ? keyboards.tg.profile : keyboards.tg.back('back_main')
    };
  },
  
  stats: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const s = user.stats;
    return {
      text: `📊 СТАТИСТИКА\n━━━━━━━━━━━━━━━━━━━━\n💰 Заработано: ${formatMoney(s.totalEarned)}\n📨 Сообщений: ${formatNumber(s.messagesCount)}\n\n🏁 Гонки: ${s.raceWins}W / ${s.raceLosses}L\n⚔️ Босс: ${s.bossAttacks} атак, ${s.bossKills} убийств\n💼 Работа: ${s.workShifts} смен\n🏢 Бизнес: ${s.businessCollects} сборов\n\n🎰 Казино: ${s.casinoBets} ставок\n✅ ${s.casinoWins} / ❌ ${s.casinoLosses}\n\n⛏️ Руды: ${formatNumber(s.oreMined)}\n🎣 Рыбы: ${s.fishCaught}\n🏹 Охота: ${s.huntingSuccess}\n\n⚔️ Дуэли: ${s.duelWins}W / ${s.duelLosses}L\n📈 Трейды: ${s.tradesWon}W / ${s.tradesLost}L`,
      keyboard: keyboards.tg.profile
    };
  },
  
  achievements: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    let text = `🏆 ДОСТИЖЕНИЯ (${user.achievements.length}/${config.achievements.length})\n━━━━━━━━━━━━━━━━━━━━`;
    
    config.achievements.forEach(a => {
      const done = user.achievements.includes(a.id);
      text += `\n${done ? '✅' : '⬜'} ${a.name}\n   ${a.desc}`;
      if (!done) text += `\n   💰 ${formatMoney(a.reward.money)}`;
    });
    
    return { text, keyboard: keyboards.tg.profile };
  },
  
  inventory: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (!user.inventory || user.inventory.length === 0) {
      return { text: '📦 ИНВЕНТАРЬ\n━━━━━━━━━━━━━━━━━━━━\n🗑️ Пусто\n\n💡 Предметы можно получить из кейсов и событий.', keyboard: keyboards.tg.profile };
    }
    
    let text = `📦 ИНВЕНТАРЬ (${user.inventory.length})\n━━━━━━━━━━━━━━━━━━━━`;
    user.inventory.forEach((item, i) => {
      text += `\n${i + 1}. ${item.name} x${item.count || 1}`;
    });
    
    return { text, keyboard: keyboards.tg.profile };
  },
  
  level: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const lvl = levelFromExp(user.exp);
    const bar = progressBar(lvl.currentExp, lvl.nextExp, 20);
    
    return {
      text: `📈 УРОВЕНЬ\n━━━━━━━━━━━━━━━━━━━━\n🎖️ Текущий: ${lvl.level}\n\n${bar}\n${lvl.currentExp} / ${lvl.nextExp} XP\n\n💡 До следующего: ${lvl.nextExp - lvl.currentExp} XP\n\n📌 Как получить опыт:\n• Работа: +10-50 XP\n• Босс: +50-200 XP\n• Квесты: +50-500 XP\n• Гонки: +20-100 XP`,
      keyboard: keyboards.tg.profile
    };
  },
  
  energy: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    db.regenerateEnergy(user);
    const bar = progressBar(user.energy, config.game.maxEnergy, 20);
    
    let timeText = '';
    if (user.energy < config.game.maxEnergy) {
      const needed = config.game.maxEnergy - user.energy;
      const mins = needed * config.game.energyRegenMinutes;
      timeText = `\n⏰ До полного: ${mins} мин.`;
    }
    
    return {
      text: `⚡ ЭНЕРГИЯ\n━━━━━━━━━━━━━━━━━━━━\n${bar}\n${user.energy} / ${config.game.maxEnergy}${timeText}\n\n📌 Восстановление:\n+1⚡ каждые ${config.game.energyRegenMinutes} минут\n\n💡 Расход энергии:\n• Гонка: 5⚡\n• Босс: 3⚡\n• Дуэль: 8⚡\n• Ограбление: 15⚡`,
      keyboard: keyboards.tg.profile
    };
  },
  
  nick: async (ctx, newNick) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (!newNick || newNick.length < 2 || newNick.length > 20) {
      return { text: '❌ Ник должен быть от 2 до 20 символов!', keyboard: keyboards.tg.profile };
    }
    
    const cost = 5000;
    if (user.money < cost) {
      return { text: `❌ Недостаточно денег! Нужно ${formatMoney(cost)}`, keyboard: keyboards.tg.profile };
    }
    
    const oldNick = user.name;
    user.name = newNick;
    user.money -= cost;
    db.saveAll();
    
    return {
      text: `✅ НИК ИЗМЕНЁН\n━━━━━━━━━━━━━━━━━━━━\n📝 Было: ${oldNick}\n📝 Стало: ${newNick}\n💰 Списано: ${formatMoney(cost)}`,
      keyboard: keyboards.tg.profile
    };
  },
  
  referral: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const refLink = ctx.platform === 'telegram' 
      ? `https://t.me/${config.telegram.botUsername}?start=ref_${user.id}`
      : `https://vk.com/club${config.vk.groupId}?ref=${user.id}`;
    
    return {
      text: `🎁 РЕФЕРАЛЬНАЯ ПРОГРАММА\n━━━━━━━━━━━━━━━━━━━━\n👥 Рефералов: ${user.referrals.length}\n💰 Заработано: ${formatMoney(user.referralEarnings)}\n\n🔗 Ваша ссылка:\n${refLink}\n\n📌 За каждого друга:\n• +5,000$ вам\n• +2,000$ другу\n• 10% от его заработка!`,
      keyboard: keyboards.tg.profile
    };
  }
};
