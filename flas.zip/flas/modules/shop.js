// ⚡ FLASH BOT v2.0 — МОДУЛЬ МАГАЗИНА
const db = require('../utils/database');
const keyboards = require('../utils/keyboards');
const config = require('../config');
const { formatMoney, formatNumber, random, parseAmount } = require('../utils/helpers');

module.exports = {
  shop: async (ctx) => {
    return {
      text: `🏪 МАГАЗИН\n━━━━━━━━━━━━━━━━━━━━\n📌 машина список — машины\n📌 бизнес список — бизнесы\n📌 ферма список — фермы\n📌 принтер список — принтеры\n📌 питомец список — питомцы\n📌 дом список — дома\n📌 телефон список — телефоны\n📌 яхта список — яхты\n📌 самолёт список — самолёты\n📌 кейс список — кейсы`,
      keyboard: keyboards.tg.shop
    };
  },
  
  // ==================== МАШИНЫ ====================
  cars: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (user.cars.length === 0) {
      return { text: `🚗 МАШИНЫ\n━━━━━━━━━━━━━━━━━━━━\n❌ Нет машин!\n\n📌 машина список\n📌 машина купить [номер]`, keyboard: keyboards.tg.race };
    }
    
    let text = `🚗 ВАШИ МАШИНЫ\n━━━━━━━━━━━━━━━━━━━━`;
    user.cars.forEach(carId => {
      const car = config.cars.find(c => c.id === carId);
      const current = user.currentCar === carId ? '✅' : '';
      text += `\n${car.name} (${car.speed} км/ч) ${current}`;
    });
    
    text += `\n\n🔧 Тюнинг: ${user.tuning}/20\n📌 машина выбрать [номер]`;
    return { text, keyboard: keyboards.tg.race };
  },
  
  carList: async (ctx) => {
    let text = `🚗 АВТОСАЛОН\n━━━━━━━━━━━━━━━━━━━━`;
    config.cars.forEach(car => {
      text += `\n${car.id}. ${car.name}\n   💰 ${formatMoney(car.price)} | 🏎️ ${car.speed} км/ч`;
    });
    text += `\n\n📌 машина купить [номер]`;
    return { text, keyboard: keyboards.tg.shop };
  },
  
  carBuy: async (ctx, carId) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const car = config.cars.find(c => c.id === parseInt(carId));
    if (!car) return { text: '❌ Машина не найдена!', keyboard: keyboards.tg.shop };
    if (user.cars.includes(car.id)) return { text: '❌ Уже есть!', keyboard: keyboards.tg.shop };
    if (user.money < car.price) return { text: `❌ Нужно ${formatMoney(car.price)}`, keyboard: keyboards.tg.shop };
    
    user.money -= car.price;
    user.cars.push(car.id);
    if (!user.currentCar) user.currentCar = car.id;
    
    const path = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'car');
    let pathText = path ? `\n\n🎉 ПУТЬ НОВИЧКА!\n+${formatMoney(path.reward.money)}` : '';
    
    db.saveAll();
    
    return {
      text: `✅ КУПЛЕНО!\n━━━━━━━━━━━━━━━━━━━━\n🚗 ${car.name}\n🏎️ ${car.speed} км/ч${pathText}`,
      keyboard: keyboards.tg.shop
    };
  },
  
  carSelect: async (ctx, carId) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const id = parseInt(carId);
    if (!user.cars.includes(id)) return { text: '❌ У вас нет такой машины!', keyboard: keyboards.tg.race };
    
    user.currentCar = id;
    db.saveAll();
    
    const car = config.cars.find(c => c.id === id);
    return { text: `✅ Выбрана: ${car.name}`, keyboard: keyboards.tg.race };
  },
  
  carSell: async (ctx, carId) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const id = parseInt(carId);
    const idx = user.cars.indexOf(id);
    if (idx === -1) return { text: '❌ У вас нет такой машины!', keyboard: keyboards.tg.race };
    
    const car = config.cars.find(c => c.id === id);
    const sellPrice = Math.floor(car.price * 0.5);
    
    user.cars.splice(idx, 1);
    user.money += sellPrice;
    if (user.currentCar === id) user.currentCar = user.cars[0] || null;
    db.saveAll();
    
    return { text: `✅ Продано: ${car.name}\n💰 +${formatMoney(sellPrice)}`, keyboard: keyboards.tg.race };
  },
  
  tuning: async (ctx, countStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (!user.currentCar) return { text: '❌ Сначала купите машину!', keyboard: keyboards.tg.race };
    if (user.tuning >= 20) return { text: '❌ Максимальный тюнинг!', keyboard: keyboards.tg.race };
    
    const count = parseInt(countStr) || 1;
    const price = 10000 * count;
    
    if (user.money < price) return { text: `❌ Нужно ${formatMoney(price)}`, keyboard: keyboards.tg.race };
    if (user.tuning + count > 20) return { text: '❌ Превышен максимум!', keyboard: keyboards.tg.race };
    
    user.money -= price;
    user.tuning += count;
    db.saveAll();
    
    return {
      text: `✅ ТЮНИНГ +${count}\n🔧 Теперь: ${user.tuning}/20\n💰 Потрачено: ${formatMoney(price)}`,
      keyboard: keyboards.tg.race
    };
  },
  
  // ==================== ПИТОМЦЫ ====================
  pets: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (user.pets.length === 0) {
      return { text: `🐾 ПИТОМЦЫ\n━━━━━━━━━━━━━━━━━━━━\n❌ Нет питомцев!\n\n📌 питомец список\n📌 питомец купить [номер]`, keyboard: keyboards.tg.main };
    }
    
    let text = `🐾 ПИТОМЦЫ\n━━━━━━━━━━━━━━━━━━━━`;
    user.pets.forEach(p => {
      const pet = config.pets.find(pt => pt.id === p.id);
      text += `\n${pet.name} (Бонус: +${pet.bonus}%)`;
    });
    
    return { text, keyboard: keyboards.tg.main };
  },
  
  petList: async (ctx) => {
    let text = `🐾 ПИТОМЦЫ\n━━━━━━━━━━━━━━━━━━━━`;
    config.pets.forEach(pet => {
      text += `\n${pet.id}. ${pet.name}\n   💰 ${formatMoney(pet.price)} | 📈 +${pet.bonus}%`;
    });
    text += `\n\n📌 питомец купить [номер]`;
    return { text, keyboard: keyboards.tg.shop };
  },
  
  petBuy: async (ctx, petId) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const pet = config.pets.find(p => p.id === parseInt(petId));
    if (!pet) return { text: '❌ Питомец не найден!', keyboard: keyboards.tg.shop };
    if (user.pets.find(p => p.id === pet.id)) return { text: '❌ Уже есть!', keyboard: keyboards.tg.shop };
    if (user.money < pet.price) return { text: `❌ Нужно ${formatMoney(pet.price)}`, keyboard: keyboards.tg.shop };
    
    user.money -= pet.price;
    user.pets.push({ id: pet.id, happiness: 100, lastFeed: Date.now() });
    db.saveAll();
    
    return { text: `✅ Питомец ${pet.name} куплен!`, keyboard: keyboards.tg.main };
  },
  
  petFeed: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (user.pets.length === 0) return { text: '❌ Нет питомцев!', keyboard: keyboards.tg.main };
    
    let totalCost = 0;
    user.pets.forEach(p => {
      const pet = config.pets.find(pt => pt.id === p.id);
      totalCost += pet.feedCost;
      p.happiness = 100;
      p.lastFeed = Date.now();
    });
    
    if (user.money < totalCost) return { text: `❌ Нужно ${formatMoney(totalCost)}`, keyboard: keyboards.tg.main };
    
    user.money -= totalCost;
    db.saveAll();
    
    return { text: `✅ Питомцы накормлены!\n💰 Потрачено: ${formatMoney(totalCost)}`, keyboard: keyboards.tg.main };
  },
  
  // ==================== ДОМА ====================
  house: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (!user.house) {
      return { text: `🏠 ДОМ\n━━━━━━━━━━━━━━━━━━━━\n❌ Нет дома!\n\n📌 дом список\n📌 дом купить [номер]`, keyboard: keyboards.tg.main };
    }
    
    const house = config.houses[user.house - 1];
    return { text: `🏠 ДОМ\n━━━━━━━━━━━━━━━━━━━━\n${house.name}\n📦 Слотов: ${house.slots}`, keyboard: keyboards.tg.main };
  },
  
  houseList: async (ctx) => {
    let text = `🏠 ДОМА\n━━━━━━━━━━━━━━━━━━━━`;
    config.houses.forEach(h => {
      text += `\n${h.id}. ${h.name}\n   💰 ${formatMoney(h.price)} | 📦 ${h.slots} слотов`;
    });
    text += `\n\n📌 дом купить [номер]`;
    return { text, keyboard: keyboards.tg.shop };
  },
  
  houseBuy: async (ctx, houseId) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const house = config.houses.find(h => h.id === parseInt(houseId));
    if (!house) return { text: '❌ Дом не найден!', keyboard: keyboards.tg.shop };
    if (user.house >= house.id) return { text: '❌ У вас уже такой или лучше!', keyboard: keyboards.tg.shop };
    if (user.money < house.price) return { text: `❌ Нужно ${formatMoney(house.price)}`, keyboard: keyboards.tg.shop };
    
    user.money -= house.price;
    user.house = house.id;
    db.saveAll();
    
    return { text: `✅ ${house.name} куплен!`, keyboard: keyboards.tg.main };
  },
  
  // ==================== ТЕЛЕФОНЫ ====================
  phone: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (!user.phone) {
      return { text: `📱 ТЕЛЕФОН\n━━━━━━━━━━━━━━━━━━━━\n❌ Нет телефона!\n\n📌 телефон список\n📌 телефон купить [номер]`, keyboard: keyboards.tg.main };
    }
    
    const phone = config.phones[user.phone - 1];
    return { text: `📱 ТЕЛЕФОН\n━━━━━━━━━━━━━━━━━━━━\n${phone.name}`, keyboard: keyboards.tg.main };
  },
  
  phoneList: async (ctx) => {
    let text = `📱 ТЕЛЕФОНЫ\n━━━━━━━━━━━━━━━━━━━━`;
    config.phones.forEach(p => {
      text += `\n${p.id}. ${p.name}\n   💰 ${formatMoney(p.price)}`;
    });
    text += `\n\n📌 телефон купить [номер]`;
    return { text, keyboard: keyboards.tg.shop };
  },
  
  phoneBuy: async (ctx, phoneId) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const phone = config.phones.find(p => p.id === parseInt(phoneId));
    if (!phone) return { text: '❌ Телефон не найден!', keyboard: keyboards.tg.shop };
    if (user.money < phone.price) return { text: `❌ Нужно ${formatMoney(phone.price)}`, keyboard: keyboards.tg.shop };
    
    user.money -= phone.price;
    user.phone = phone.id;
    db.saveAll();
    
    return { text: `✅ ${phone.name} куплен!`, keyboard: keyboards.tg.main };
  },
  
  // ==================== ЯХТЫ, САМОЛЁТЫ, ВЕРТОЛЁТЫ ====================
  yacht: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    let text = `🛥️ ЯХТЫ\n━━━━━━━━━━━━━━━━━━━━`;
    if (user.yachts.length === 0) text += `\n❌ Нет яхт`;
    else user.yachts.forEach(y => {
      const yacht = config.yachts.find(yt => yt.id === y);
      text += `\n${yacht.name}`;
    });
    text += `\n\n📌 яхта купить [номер]`;
    return { text, keyboard: keyboards.tg.main };
  },
  
  yachtBuy: async (ctx, yachtId) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const yacht = config.yachts.find(y => y.id === parseInt(yachtId));
    if (!yacht) return { text: '❌ Яхта не найдена!', keyboard: keyboards.tg.main };
    if (user.yachts.includes(yacht.id)) return { text: '❌ Уже есть!', keyboard: keyboards.tg.main };
    if (user.money < yacht.price) return { text: `❌ Нужно ${formatMoney(yacht.price)}`, keyboard: keyboards.tg.main };
    
    user.money -= yacht.price;
    user.yachts.push(yacht.id);
    db.saveAll();
    
    return { text: `✅ ${yacht.name} куплена!`, keyboard: keyboards.tg.main };
  },
  
  plane: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    let text = `✈️ САМОЛЁТЫ\n━━━━━━━━━━━━━━━━━━━━`;
    config.planes.forEach(p => {
      const owned = user.planes.includes(p.id) ? '✅' : '';
      text += `\n${p.id}. ${p.name} ${owned}\n   💰 ${formatMoney(p.price)}`;
    });
    text += `\n\n📌 самолёт купить [номер]`;
    return { text, keyboard: keyboards.tg.main };
  },
  
  planeBuy: async (ctx, planeId) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const plane = config.planes.find(p => p.id === parseInt(planeId));
    if (!plane) return { text: '❌ Самолёт не найден!', keyboard: keyboards.tg.main };
    if (user.planes.includes(plane.id)) return { text: '❌ Уже есть!', keyboard: keyboards.tg.main };
    if (user.money < plane.price) return { text: `❌ Нужно ${formatMoney(plane.price)}`, keyboard: keyboards.tg.main };
    
    user.money -= plane.price;
    user.planes.push(plane.id);
    db.saveAll();
    
    return { text: `✅ ${plane.name} куплен!`, keyboard: keyboards.tg.main };
  },
  
  helicopter: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    let text = `🚁 ВЕРТОЛЁТЫ\n━━━━━━━━━━━━━━━━━━━━`;
    config.helicopters.forEach(h => {
      const owned = user.helicopters.includes(h.id) ? '✅' : '';
      text += `\n${h.id}. ${h.name} ${owned}\n   💰 ${formatMoney(h.price)}`;
    });
    text += `\n\n📌 вертолёт купить [номер]`;
    return { text, keyboard: keyboards.tg.main };
  },
  
  helicopterBuy: async (ctx, heliId) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const heli = config.helicopters.find(h => h.id === parseInt(heliId));
    if (!heli) return { text: '❌ Вертолёт не найден!', keyboard: keyboards.tg.main };
    if (user.helicopters.includes(heli.id)) return { text: '❌ Уже есть!', keyboard: keyboards.tg.main };
    if (user.money < heli.price) return { text: `❌ Нужно ${formatMoney(heli.price)}`, keyboard: keyboards.tg.main };
    
    user.money -= heli.price;
    user.helicopters.push(heli.id);
    db.saveAll();
    
    return { text: `✅ ${heli.name} куплен!`, keyboard: keyboards.tg.main };
  },
  
  // ==================== КЕЙСЫ ====================
  caseList: async (ctx) => {
    let text = `📦 КЕЙСЫ\n━━━━━━━━━━━━━━━━━━━━`;
    config.cases.forEach(c => {
      text += `\n${c.id}. ${c.name}\n   💰 ${formatMoney(c.price)} | 🎁 ${formatMoney(c.rewards[0])}-${formatMoney(c.rewards[c.rewards.length - 1])}`;
    });
    text += `\n\n📌 кейс открыть [номер]`;
    return { text, keyboard: keyboards.tg.shop };
  },
  
  caseOpen: async (ctx, caseId) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const caseItem = config.cases.find(c => c.id === parseInt(caseId));
    if (!caseItem) return { text: '❌ Кейс не найден!', keyboard: keyboards.tg.shop };
    if (user.money < caseItem.price) return { text: `❌ Нужно ${formatMoney(caseItem.price)}`, keyboard: keyboards.tg.shop };
    
    if (user.energy < config.game.energyCosts.caseOpen) {
      return { text: `❌ Нужно ${config.game.energyCosts.caseOpen}⚡!`, keyboard: keyboards.tg.shop };
    }
    
    user.money -= caseItem.price;
    user.energy -= config.game.energyCosts.caseOpen;
    
    const reward = caseItem.rewards[random(0, caseItem.rewards.length - 1)];
    user.money += reward;
    user.stats.totalEarned += reward;
    db.saveAll();
    
    const profit = reward - caseItem.price;
    const profitText = profit >= 0 ? `+${formatMoney(profit)}` : formatMoney(profit);
    
    return {
      text: `📦 КЕЙС ОТКРЫТ!\n━━━━━━━━━━━━━━━━━━━━\n${caseItem.name}\n\n🎁 Выпало: ${formatMoney(reward)}\n📊 Профит: ${profitText}\n\n💰 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.shop
    };
  }
};
