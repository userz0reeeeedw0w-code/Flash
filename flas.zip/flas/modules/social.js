// ⚡ FLASH BOT v2.0 — МОДУЛЬ СОЦИАЛЬНЫХ МЕХАНИК
const db = require('../utils/database');
const keyboards = require('../utils/keyboards');
const config = require('../config');
const { formatMoney, formatNumber, checkCooldown, formatTime, random, progressBar, levelFromExp, parseAmount } = require('../utils/helpers');

module.exports = {
  // ==================== БОСС ====================
  boss: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (!db.boss.active) {
      return {
        text: `⚔️ БОСС\n━━━━━━━━━━━━━━━━━━━━\n❌ Босс не активен!\n\n⏰ Боссы появляются каждые 6 часов.`,
        keyboard: keyboards.tg.boss
      };
    }
    
    const hpPercent = Math.floor((db.boss.hp / db.boss.maxHp) * 100);
    const hpBar = progressBar(db.boss.hp, db.boss.maxHp, 15);
    const myDamage = db.boss.attackers[`${ctx.platform}_${ctx.userId}`]?.damage || 0;
    
    return {
      text: `⚔️ БОСС — ${db.boss.name}\n━━━━━━━━━━━━━━━━━━━━\n📊 Уровень: ${db.boss.level}\n❤️ HP: ${formatNumber(db.boss.hp)}/${formatNumber(db.boss.maxHp)}\n${hpBar} ${hpPercent}%\n\n💰 Награда: ${formatMoney(db.boss.reward)}\n👥 Атакующих: ${Object.keys(db.boss.attackers).length}\n⚔️ Ваш урон: ${formatNumber(myDamage)}\n\n📌 Атака стоит 3⚡`,
      keyboard: keyboards.tg.boss
    };
  },
  
  bossAttack: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (!db.boss.active) return { text: '❌ Босс не активен!', keyboard: keyboards.tg.boss };
    
    const cd = checkCooldown(user.cooldowns.boss, config.game.cooldowns.boss);
    if (!cd.ready) return { text: `⏰ Подождите: ${formatTime(cd.remaining)}`, keyboard: keyboards.tg.boss };
    
    if (user.energy < config.game.energyCosts.boss) {
      return { text: `❌ Нужно ${config.game.energyCosts.boss}⚡!`, keyboard: keyboards.tg.boss };
    }
    
    const damage = random(100, 500) + levelFromExp(user.exp).level * 10;
    
    user.energy -= config.game.energyCosts.boss;
    user.cooldowns.boss = Date.now();
    user.stats.bossAttacks++;
    
    const exp = Math.floor(damage / 10);
    db.addExp(user, exp);
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'boss_attacks', 1);
    db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'boss_damage', damage);
    
    const result = db.attackBoss(`${ctx.platform}_${ctx.userId}`, damage);
    
    const path = db.checkBeginnerPath(`${ctx.platform}_${ctx.userId}`, 'boss');
    let pathText = path ? `\n\n🎉 ПУТЬ НОВИЧКА!\n+${formatMoney(path.reward.money)}` : '';
    
    if (result.killed) {
      let rewardsText = '\n🏆 ТОП-5 УРОНА:\n';
      result.rewards.slice(0, 5).forEach((r, i) => {
        rewardsText += `${i + 1}. ${r.name}: ${formatMoney(r.reward)}\n`;
      });
      
      return {
        text: `⚔️ БОСС ПОВЕРЖЕН!\n━━━━━━━━━━━━━━━━━━━━\n🎯 Урон: ${formatNumber(damage)}\n👑 Бонус убийцы: ${formatMoney(result.killerBonus)}\n${rewardsText}\n⭐ +${exp} XP${pathText}`,
        keyboard: keyboards.tg.boss
      };
    }
    
    return {
      text: `⚔️ АТАКА\n━━━━━━━━━━━━━━━━━━━━\n🎯 Урон: ${formatNumber(damage)}\n❤️ HP: ${formatNumber(result.hp)}/${formatNumber(db.boss.maxHp)}\n\n⚡ Энергия: ${user.energy}\n⭐ +${exp} XP${pathText}`,
      keyboard: keyboards.tg.boss
    };
  },
  
  bossTop: async (ctx) => {
    if (!db.boss.active) return { text: '❌ Босс не активен!', keyboard: keyboards.tg.boss };
    
    const attackers = Object.entries(db.boss.attackers)
      .sort((a, b) => b[1].damage - a[1].damage)
      .slice(0, 10);
    
    let text = `🏆 ТОП УРОНА\n━━━━━━━━━━━━━━━━━━━━\n${db.boss.name}\n\n`;
    
    const medals = ['🥇', '🥈', '🥉'];
    attackers.forEach(([key, data], i) => {
      const user = db.users[key];
      const medal = medals[i] || `${i + 1}.`;
      text += `${medal} ${user?.name || 'Unknown'}: ${formatNumber(data.damage)}\n`;
    });
    
    return { text, keyboard: keyboards.tg.boss };
  },
  
  // ==================== КЛАНЫ ====================
  clan: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (!user.clanId) {
      return {
        text: `🏛️ КЛАНЫ\n━━━━━━━━━━━━━━━━━━━━\n❌ Вы не в клане!\n\n📌 клан создать [название] — 100,000$\n📌 клан вступить [ID]\n📌 кланы — список`,
        keyboard: keyboards.tg.clan
      };
    }
    
    const clan = db.clans[user.clanId];
    if (!clan) {
      user.clanId = null;
      db.saveAll();
      return { text: '❌ Клан удалён!', keyboard: keyboards.tg.clan };
    }
    
    const isLeader = clan.leader === `${ctx.platform}_${ctx.userId}`;
    
    return {
      text: `🏛️ КЛАН — ${clan.name}\n━━━━━━━━━━━━━━━━━━━━\n📊 Уровень: ${clan.level}\n👥 Участников: ${clan.members.length}/50\n💰 Казна: ${formatMoney(clan.treasury)}\n👑 Лидер: ${isLeader ? 'ВЫ' : 'другой'}\n\n⚔️ ${clan.wars.wins}W / ${clan.wars.losses}L\n\n📌 клан пополнить [сумма]\n📌 клан состав\n📌 клан покинуть`,
      keyboard: keyboards.tg.clan
    };
  },
  
  clanCreate: async (ctx, name) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (user.clanId) return { text: '❌ Вы уже в клане!', keyboard: keyboards.tg.clan };
    
    if (!name || name.length < 2 || name.length > 20) {
      return { text: '❌ Название: 2-20 символов!', keyboard: keyboards.tg.clan };
    }
    
    if (user.money < 100000) {
      return { text: `❌ Нужно ${formatMoney(100000)}!`, keyboard: keyboards.tg.clan };
    }
    
    const clan = db.createClan(`${ctx.platform}_${ctx.userId}`, name);
    if (!clan) return { text: '❌ Ошибка создания!', keyboard: keyboards.tg.clan };
    
    return {
      text: `✅ КЛАН СОЗДАН!\n━━━━━━━━━━━━━━━━━━━━\n🏛️ ${clan.name}\n👑 Лидер: ВЫ\n💰 Потрачено: ${formatMoney(100000)}`,
      keyboard: keyboards.tg.clan
    };
  },
  
  clanJoin: async (ctx, clanId) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (user.clanId) return { text: '❌ Вы уже в клане!', keyboard: keyboards.tg.clan };
    
    const id = parseInt(clanId);
    if (!id || !db.clans[id]) return { text: '❌ Клан не найден!', keyboard: keyboards.tg.clan };
    
    const success = db.joinClan(`${ctx.platform}_${ctx.userId}`, id);
    if (!success) return { text: '❌ Не удалось вступить!', keyboard: keyboards.tg.clan };
    
    return { text: `✅ Вы вступили в клан ${db.clans[id].name}!`, keyboard: keyboards.tg.clan };
  },
  
  clanLeave: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    if (!user.clanId) return { text: '❌ Вы не в клане!', keyboard: keyboards.tg.clan };
    
    const success = db.leaveClan(`${ctx.platform}_${ctx.userId}`);
    if (!success) return { text: '❌ Лидер не может покинуть клан с участниками!', keyboard: keyboards.tg.clan };
    
    return { text: '✅ Вы покинули клан!', keyboard: keyboards.tg.clan };
  },
  
  clanDeposit: async (ctx, amountStr) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user || !user.clanId) return { text: '❌ Вы не в клане!', keyboard: keyboards.tg.clan };
    
    const amount = parseAmount(amountStr, user.money);
    if (!amount || amount < 100) return { text: '❌ Минимум 100$!', keyboard: keyboards.tg.clan };
    if (user.money < amount) return { text: '❌ Недостаточно денег!', keyboard: keyboards.tg.clan };
    
    user.money -= amount;
    db.clans[user.clanId].treasury += amount;
    db.saveAll();
    
    return {
      text: `✅ ПОПОЛНЕНО!\n💰 Внесено: ${formatMoney(amount)}\n🏦 В казне: ${formatMoney(db.clans[user.clanId].treasury)}`,
      keyboard: keyboards.tg.clan
    };
  },
  
  clanMembers: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user || !user.clanId) return { text: '❌ Вы не в клане!', keyboard: keyboards.tg.clan };
    
    const clan = db.clans[user.clanId];
    let text = `👥 СОСТАВ — ${clan.name}\n━━━━━━━━━━━━━━━━━━━━`;
    
    clan.members.forEach((key, i) => {
      const member = db.users[key];
      if (member) {
        const role = key === clan.leader ? '👑' : '👤';
        text += `\n${i + 1}. ${role} ${member.name} (#${member.id})`;
      }
    });
    
    return { text, keyboard: keyboards.tg.clan };
  },
  
  clansList: async (ctx) => {
    const clans = Object.values(db.clans).sort((a, b) => b.treasury - a.treasury).slice(0, 10);
    
    let text = `🏛️ ТОП КЛАНОВ\n━━━━━━━━━━━━━━━━━━━━`;
    
    if (clans.length === 0) {
      text += '\n🗑️ Кланов пока нет';
    } else {
      const medals = ['🥇', '🥈', '🥉'];
      clans.forEach((c, i) => {
        const medal = medals[i] || `${i + 1}.`;
        text += `\n${medal} ${c.name} [#${c.id}]\n   👥 ${c.members.length} | 💰 ${formatMoney(c.treasury)}`;
      });
    }
    
    text += `\n\n📌 клан вступить [ID]`;
    return { text, keyboard: keyboards.tg.clan };
  },
  
  // ==================== ТОПЫ ====================
  top: async (ctx) => {
    return {
      text: `📊 ТОПЫ\n━━━━━━━━━━━━━━━━━━━━\n📌 топ деньги — богачи\n📌 топ уровень — ветераны\n📌 топ кланы — кланы\n📌 топ рейтинг — рейтинг`,
      keyboard: keyboards.tg.tops
    };
  },
  
  topMoney: async (ctx) => {
    const users = Object.values(db.users)
      .sort((a, b) => (b.money + b.bank) - (a.money + a.bank))
      .slice(0, 10);
    
    let text = `💰 ТОП БОГАЧЕЙ\n━━━━━━━━━━━━━━━━━━━━`;
    const medals = ['🥇', '🥈', '🥉'];
    
    users.forEach((u, i) => {
      const medal = medals[i] || `${i + 1}.`;
      text += `\n${medal} ${u.name} — ${formatMoney(u.money + u.bank)}`;
    });
    
    return { text, keyboard: keyboards.tg.tops };
  },
  
  topLevel: async (ctx) => {
    const users = Object.values(db.users)
      .sort((a, b) => b.exp - a.exp)
      .slice(0, 10);
    
    let text = `📈 ТОП ПО УРОВНЮ\n━━━━━━━━━━━━━━━━━━━━`;
    const medals = ['🥇', '🥈', '🥉'];
    
    users.forEach((u, i) => {
      const medal = medals[i] || `${i + 1}.`;
      const lvl = levelFromExp(u.exp).level;
      text += `\n${medal} ${u.name} — ${lvl} ур.`;
    });
    
    return { text, keyboard: keyboards.tg.tops };
  },
  
  topClans: async (ctx) => {
    return module.exports.clansList(ctx);
  },
  
  topRating: async (ctx) => {
    const users = Object.values(db.users)
      .sort((a, b) => b.rating - a.rating)
      .slice(0, 10);
    
    let text = `⭐ ТОП ПО РЕЙТИНГУ\n━━━━━━━━━━━━━━━━━━━━`;
    const medals = ['🥇', '🥈', '🥉'];
    
    users.forEach((u, i) => {
      const medal = medals[i] || `${i + 1}.`;
      text += `\n${medal} ${u.name} — ⭐${u.rating}`;
    });
    
    return { text, keyboard: keyboards.tg.tops };
  },
  
  // ==================== ОГРАБЛЕНИЕ ====================
  rob: async (ctx, targetId) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    if (!targetId) return { text: '❌ ограбить [ID игрока]', keyboard: keyboards.tg.main };
    
    const id = parseInt(String(targetId).replace('#', ''));
    const target = db.getUserById(id);
    
    if (!target) return { text: '❌ Игрок не найден!', keyboard: keyboards.tg.main };
    if (target.uid === user.uid) return { text: '❌ Нельзя ограбить себя!', keyboard: keyboards.tg.main };
    
    const cd = checkCooldown(user.cooldowns.robbery, config.game.cooldowns.robbery);
    if (!cd.ready) return { text: `⏰ Подождите: ${formatTime(cd.remaining)}`, keyboard: keyboards.tg.main };
    
    if (user.energy < config.game.energyCosts.robbery) {
      return { text: `❌ Нужно ${config.game.energyCosts.robbery}⚡!`, keyboard: keyboards.tg.main };
    }
    
    if (target.robberyProtection && target.robberyProtectionExpires > Date.now()) {
      return { text: '❌ У игрока защита от ограблений!', keyboard: keyboards.tg.main };
    }
    
    if (target.money < 100) return { text: '❌ У игрока нет денег!', keyboard: keyboards.tg.main };
    
    user.energy -= config.game.energyCosts.robbery;
    user.cooldowns.robbery = Date.now();
    user.stats.robberies++;
    
    const success = Math.random() < 0.4; // 40% шанс
    
    if (success) {
      const stolen = Math.floor(target.money * (0.05 + Math.random() * 0.1)); // 5-15%
      user.money += stolen;
      target.money -= stolen;
      user.stats.robberiesSuccess++;
      user.stats.totalEarned += stolen;
      
      db.updateQuestProgress(`${ctx.platform}_${ctx.userId}`, 'robberies', 1);
      db.saveAll();
      
      return {
        text: `🔫 ОГРАБЛЕНИЕ\n━━━━━━━━━━━━━━━━━━━━\n✅ УСПЕХ!\n\n👤 Жертва: ${target.name}\n💰 Украдено: ${formatMoney(stolen)}\n\n💵 Баланс: ${formatMoney(user.money)}`,
        keyboard: keyboards.tg.main
      };
    }
    
    // Провал — штраф
    const fine = Math.floor(user.money * 0.1);
    user.money -= fine;
    db.saveAll();
    
    return {
      text: `🔫 ОГРАБЛЕНИЕ\n━━━━━━━━━━━━━━━━━━━━\n❌ ПРОВАЛ!\n\nВас поймали!\n💰 Штраф: ${formatMoney(fine)}\n\n💵 Баланс: ${formatMoney(user.money)}`,
      keyboard: keyboards.tg.main
    };
  },
  
  crime: async (ctx) => {
    const user = db.getUserByPlatform(ctx.platform, ctx.userId);
    if (!user) return { text: '❌ Вы не зарегистрированы!', keyboard: keyboards.tg.start };
    
    const cd = checkCooldown(user.cooldowns.crime, config.game.cooldowns.crime);
    if (!cd.ready) return { text: `⏰ Подождите: ${formatTime(cd.remaining)}`, keyboard: keyboards.tg.main };
    
    user.cooldowns.crime = Date.now();
    
    const success = Math.random() < 0.5;
    
    if (success) {
      const reward = random(1000, 5000);
      user.money += reward;
      user.stats.totalEarned += reward;
      db.saveAll();
      
      return {
        text: `🔫 ПРЕСТУПЛЕНИЕ\n━━━━━━━━━━━━━━━━━━━━\n✅ Успешно!\n💰 Награбили: ${formatMoney(reward)}`,
        keyboard: keyboards.tg.main
      };
    }
    
    const fine = random(500, 2000);
    user.money = Math.max(0, user.money - fine);
    db.saveAll();
    
    return {
      text: `🔫 ПРЕСТУПЛЕНИЕ\n━━━━━━━━━━━━━━━━━━━━\n❌ Вас поймали!\n💰 Штраф: ${formatMoney(fine)}`,
      keyboard: keyboards.tg.main
    };
  }
};
