// ⚡ FLASH BOT v2.0 — VK ПЛАТФОРМА (ИСПРАВЛЕННАЯ)
const { VK, Keyboard } = require('vk-io');
const config = require('../config');
const { handleMessage } = require('../handler');
const db = require('../utils/database');
const keyboards = require('../utils/keyboards');

class VKPlatform {
  constructor() {
    if (!config.vk.token) {
      console.log('⚠️ VK: токен не указан');
      return;
    }
    
    this.vk = new VK({ token: config.vk.token });
    this.groupId = config.vk.groupId;
    this.setupHandlers();
    this.startPolling();
  }
  
  setupHandlers() {
    // Обработка новых сообщений
    this.vk.updates.on('message_new', async (ctx) => {
      try {
        // Игнорируем сообщения от групп (отрицательные ID)
        if (ctx.senderId < 0) return;
        if (!ctx.text) return;
        
        const isChat = ctx.peerType === 'chat';
        let commandText = ctx.text;
        
        // В беседах требуем упоминание бота
        if (isChat) {
          const groupMention = `[club${this.groupId}|`;
          const groupMention2 = `@club${this.groupId}`;
          const groupMention3 = `@public${this.groupId}`;
          
          let hasMention = false;
          
          if (ctx.text.includes(groupMention)) {
            // Формат [club123|Название]
            commandText = ctx.text.replace(/\[club\d+\|[^\]]*\]/g, '').trim();
            hasMention = true;
          } else if (ctx.text.toLowerCase().includes(groupMention2.toLowerCase())) {
            commandText = ctx.text.replace(new RegExp(groupMention2, 'gi'), '').trim();
            hasMention = true;
          } else if (ctx.text.toLowerCase().includes(groupMention3.toLowerCase())) {
            commandText = ctx.text.replace(new RegExp(groupMention3, 'gi'), '').trim();
            hasMention = true;
          } else if (ctx.text.toLowerCase().startsWith('флеш ') || ctx.text.toLowerCase().startsWith('flash ')) {
            commandText = ctx.text.substring(ctx.text.indexOf(' ') + 1).trim();
            hasMention = true;
          }
          
          // Если нет упоминания — игнорируем
          if (!hasMention) return;
        }
        
        // Если команда пустая после очистки
        if (!commandText.trim()) {
          commandText = 'старт';
        }
        
        const context = {
          platform: 'vk',
          userId: ctx.senderId,
          userName: await this.getUserName(ctx.senderId),
          peerId: ctx.peerId,
          isPrivate: !isChat,
          text: commandText,
          isChat: isChat
        };
        
        const response = await handleMessage(context);
        if (response) {
          await this.sendResponse(ctx, context, response);
        }
      } catch (e) {
        console.error('VK message error:', e);
      }
    });
    
    // Обработка callback кнопок (только в ЛС)
    this.vk.updates.on('message_event', async (ctx) => {
      try {
        if (ctx.userId < 0) return;
        
        const payload = ctx.eventPayload;
        if (!payload?.action) return;
        
        const context = {
          platform: 'vk',
          userId: ctx.userId,
          userName: await this.getUserName(ctx.userId),
          peerId: ctx.peerId,
          isPrivate: true,
          callbackData: payload.action,
          isChat: false
        };
        
        const response = await handleMessage(context);
        
        // Отвечаем на callback
        await ctx.answer({ type: 'show_snackbar', text: '✅' });
        
        if (response) {
          await this.sendResponse(ctx, context, response);
        }
      } catch (e) {
        console.error('VK callback error:', e);
      }
    });
  }
  
  async startPolling() {
    try {
      await this.vk.updates.start();
      console.log(`✅ VK бот запущен (группа: ${this.groupId})`);
    } catch (e) {
      console.error('VK polling error:', e.message);
    }
  }
  
  async getUserName(userId) {
    try {
      const [user] = await this.vk.api.users.get({ user_ids: [userId] });
      return `${user.first_name} ${user.last_name}`;
    } catch (e) {
      return 'Пользователь';
    }
  }
  
  // Конвертация TG клавиатуры в VK inline
  buildInlineKeyboard(tgKb) {
    if (!tgKb?.inline_keyboard) return null;
    
    const kb = Keyboard.builder().inline();
    
    tgKb.inline_keyboard.forEach((row, rowIdx) => {
      row.forEach(btn => {
        kb.callbackButton({
          label: btn.text.substring(0, 40),
          payload: { action: btn.callback_data }
        });
      });
      if (rowIdx < tgKb.inline_keyboard.length - 1) {
        kb.row();
      }
    });
    
    return kb;
  }
  
  // Обычная reply клавиатура для VK
  buildReplyKeyboard() {
    return Keyboard.builder()
      .textButton({ label: '👤 Профиль', color: 'primary' })
      .textButton({ label: '💰 Баланс', color: 'primary' })
      .textButton({ label: '🏪 Магазин', color: 'primary' })
      .row()
      .textButton({ label: '⚔️ Босс', color: 'secondary' })
      .textButton({ label: '🏁 Гонка', color: 'secondary' })
      .textButton({ label: '💼 Работа', color: 'secondary' })
      .row()
      .textButton({ label: '🏛️ Клан', color: 'secondary' })
      .textButton({ label: '🎰 Казино', color: 'secondary' })
      .textButton({ label: '🎁 Бонус', color: 'positive' })
      .row()
      .textButton({ label: '📊 Топ', color: 'secondary' })
      .textButton({ label: '❓ Помощь', color: 'secondary' })
      .textButton({ label: '📍 Путь', color: 'secondary' });
  }
  
  // Получение текста кнопок для беседы
  getButtonHints(keyboard) {
    if (!keyboard?.inline_keyboard) return [];
    
    const hints = [];
    keyboard.inline_keyboard.forEach(row => {
      const rowText = row.map(btn => btn.text).join(' | ');
      hints.push(rowText);
    });
    return hints;
  }
  
  async sendResponse(ctx, context, response) {
    try {
      // Формируем текст ответа
      let text = response.text;
      
      // В беседах добавляем упоминание пользователя
      if (context.isChat) {
        text = `@id${context.userId} (${context.userName}), ${text}`;
        
        // Добавляем подсказки по кнопкам, так как inline не работает в беседах
        if (response.keyboard?.inline_keyboard) {
          const hints = this.getButtonHints(response.keyboard);
          if (hints.length > 0) {
            text += '\n\n📌 Напишите Flash и команду:\n';
            hints.forEach(hint => {
              text += `   ${hint}\n`;
            });
          }
        }
        
        // Отправляем без клавиатуры в беседу
        await ctx.send(text);
      } else {
        // В ЛС используем inline кнопки
        const options = {};
        
        if (response.keyboard) {
          options.keyboard = this.buildInlineKeyboard(response.keyboard);
        }
        
        if (response.replyKeyboard) {
          options.keyboard = this.buildReplyKeyboard();
        }
        
        if (response.removeKeyboard) {
          options.keyboard = Keyboard.builder();
        }
        
        await ctx.send(text, options);
      }
      
      // Обрабатываем broadcast
      if (response.broadcast) {
        await this.broadcast(response.broadcast);
      }
    } catch (e) {
      console.error('VK send error:', e.message);
    }
  }
  
  async broadcast(text) {
    const users = Object.entries(db.users)
      .filter(([k]) => k.startsWith('vk_'))
      .map(([k]) => parseInt(k.replace('vk_', '')));
    
    let sent = 0;
    for (const id of users) {
      try {
        await this.vk.api.messages.send({
          user_id: id,
          message: text,
          random_id: Math.floor(Math.random() * 1e9)
        });
        sent++;
        await new Promise(r => setTimeout(r, 100));
      } catch (e) {}
    }
    console.log(`📢 VK Broadcast: ${sent}/${users.length}`);
  }
}

module.exports = VKPlatform;
