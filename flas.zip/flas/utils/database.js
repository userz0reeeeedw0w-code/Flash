// ⚡ FLASH BOT v2.0 — БАЗА ДАННЫХ
const { loadJSON, saveJSON, generateUID, levelFromExp, getDateKey, getWeekKey, random, randomElement } = require('./helpers');
const config = require('../config');

class Database {
  constructor() {
    this.users = loadJSON('users.json') || {};
    this.clans = loadJSON('clans.json') || {};
    this.families = loadJSON('families.json') || {};
    this.boss = loadJSON('boss.json') || { active: false };
    this.events = loadJSON('events.json') || { active: [], history: [] };
    this.promoCodes = loadJSON('promoCodes.json') || {};
    this.bonds = loadJSON('bonds.json') || {};
    this.newspaper = loadJSON('newspaper.json') || [];
    this.posts = loadJSON('posts.json') || [];
    this.duels = loadJSON('duels.json') || {};
    this.trades = loadJSON('trades.json') || {};
    this.lottery = loadJSON('lottery.json') || { pool: 0, tickets: [], lastDraw: 0 };
    
    this.nextUserId = this._getNextUserId();
    this.nextPostId = this.posts.length + 1;
    this.nextClanId = this._getNextClanId();
    
    // Авто-сохранение каждые 30 секунд
    setInterval(() => this.saveAll(), 30000);
    
    console.log(`📊 БД: ${Object.keys(this.users).length} игроков, ${Object.keys(this.clans).length} кланов`);
  }
  
  _getNextUserId() {
    let maxId = 0;
    Object.values(this.users).forEach(u => {
      if (u.id && u.id > maxId) maxId = u.id;
    });
    return maxId + 1;
  }
  
  _getNextClanId() {
    let maxId = 0;
    Object.values(this.clans).forEach(c => {
      if (c.id && c.id > maxId) maxId = c.id;
    });
    return maxId + 1;
  }
  
  saveAll() {
    saveJSON('users.json', this.users);
    saveJSON('clans.json', this.clans);
    saveJSON('families.json', this.families);
    saveJSON('boss.json', this.boss);
    saveJSON('events.json', this.events);
    saveJSON('promoCodes.json', this.promoCodes);
    saveJSON('bonds.json', this.bonds);
    saveJSON('newspaper.json', this.newspaper);
    saveJSON('posts.json', this.posts);
    saveJSON('duels.json', this.duels);
    saveJSON('trades.json', this.trades);
    saveJSON('lottery.json', this.lottery);
  }
  
  // ==================== ПОЛЬЗОВАТЕЛИ ====================
  
  getUserKey(platform, platformId) {
    return `${platform}_${platformId}`;
  }
  
  getUserByPlatform(platform, platformId) {
    // Игнорируем отрицательные ID (группы VK)
    if (platform === 'vk' && platformId < 0) return null;
    
    const key = this.getUserKey(platform, platformId);
    let user = this.users[key];
    
    // Ищем по platforms
    if (!user) {
      user = Object.values(this.users).find(u => 
        u.platforms && u.platforms[platform] === platformId
      );
    }
    
    if (user) {
      this.regenerateEnergy(user);
      user.lastActive = Date.now();
    }
    
    return user || null;
  }
  
  getUserByUID(uid) {
    return Object.values(this.users).find(u => u.uid === uid) || null;
  }
  
  getUserById(id) {
    id = parseInt(id);
    return Object.values(this.users).find(u => u.id === id) || null;
  }
  
  findUserKey(user) {
    return Object.keys(this.users).find(k => this.users[k].uid === user.uid);
  }
  
  createUser(platform, platformId, name) {
    // Игнорируем отрицательные ID (группы VK)
    if (platform === 'vk' && platformId < 0) return null;
    
    const key = this.getUserKey(platform, platformId);
    if (this.users[key]) return this.users[key];
    
    const uid = generateUID();
    const id = this.nextUserId++;
    
    this.users[key] = {
      uid, id, name,
      platforms: { [platform]: platformId },
      registered: Date.now(),
      lastActive: Date.now(),
      
      // Финансы
      money: config.game.startMoney,
      bank: 0,
      bankLimit: 100000,
      bitcoin: 0,
      rubles: 0,
      diamonds: 0,
      cups: 0,
      rating: 0,
      
      // Опыт и энергия
      exp: 0,
      energy: config.game.maxEnergy,
      lastEnergyRegen: Date.now(),
      
      // Работа
      job: null,
      jobStage: 0,
      workStreak: 0,
      
      // Имущество
      businesses: [],
      cars: [],
      currentCar: null,
      tuning: 0,
      farms: [],
      printers: [],
      yachts: [],
      planes: [],
      helicopters: [],
      
      // Добыча
      pickaxeLevel: 1,
      mineLevel: 0,
      ores: {},
      rodLevel: 1,
      fish: {},
      trophies: {},
      
      // Социальное
      clanId: null,
      familyId: null,
      spouse: null,
      children: 0,
      
      // Недвижимость
      house: 0,
      furniture: [],
      pets: [],
      
      // Телефон
      phone: 0,
      contacts: [],
      subscribers: [],
      subscriptions: [],
      
      // Хобби
      hobby: null,
      hobbyLevel: 0,
      
      // Привилегия
      privilege: null,
      privilegeExpires: null,
      
      // Путь новичка
      beginnerStage: 1,
      beginnerCompleted: false,
      
      // Квесты
      dailyQuests: {},
      weeklyQuests: {},
      dailyQuestsDate: null,
      weeklyQuestsDate: null,
      
      // Достижения
      achievements: [],
      
      // Инвентарь
      inventory: [],
      
      // Кулдауны
      cooldowns: {},
      
      // Защита
      robberyProtection: false,
      robberyProtectionExpires: null,
      
      // Статистика
      stats: {
        totalEarned: 0,
        raceWins: 0,
        raceLosses: 0,
        bossAttacks: 0,
        bossKills: 0,
        bossDamage: 0,
        fishCaught: 0,
        oreMined: 0,
        robberies: 0,
        robberiesSuccess: 0,
        casinoBets: 0,
        casinoWins: 0,
        casinoLosses: 0,
        workShifts: 0,
        businessCollects: 0,
        duelWins: 0,
        duelLosses: 0,
        huntingSuccess: 0,
        tradesWon: 0,
        tradesLost: 0,
        messagesCount: 0
      },
      
      // Настройки
      settings: {
        keyboard: false,
        notifications: true,
        nick: null,
        nickEnabled: true
      },
      
      // Рефералы
      referrer: null,
      referrals: [],
      referralEarnings: 0,
      
      // Кредит
      credit: null,
      
      // Бан
      banned: false,
      banReason: null,
      
      // Уведомления
      notifications: [],
      
      // Трейдинг
      lastTradeDirection: null,
      
      // Лотерея
      lotteryTickets: 0
    };
    
    // Первое достижение
    this.giveAchievement(key, 1);
    this.saveAll();
    
    console.log(`✅ Новый игрок: ${name} (#${id})`);
    return this.users[key];
  }
  
  updateUser(platform, platformId, updates) {
    const user = this.getUserByPlatform(platform, platformId);
    if (!user) return null;
    
    Object.entries(updates).forEach(([key, value]) => {
      if (key.includes('.')) {
        const parts = key.split('.');
        let obj = user;
        for (let i = 0; i < parts.length - 1; i++) {
          if (!obj[parts[i]]) obj[parts[i]] = {};
          obj = obj[parts[i]];
        }
        obj[parts[parts.length - 1]] = value;
      } else {
        user[key] = value;
      }
    });
    
    this.saveAll();
    return user;
  }
  
  // ==================== ПРИВЯЗКА ====================
  
  createBondCode(platform, platformId) {
    const user = this.getUserByPlatform(platform, platformId);
    if (!user) return null;
    
    // Удаляем старые коды этого пользователя
    Object.keys(this.bonds).forEach(code => {
      if (this.bonds[code].uid === user.uid) delete this.bonds[code];
    });
    
    const code = Math.random().toString(36).substring(2, 8).toUpperCase();
    this.bonds[code] = {
      uid: user.uid,
      platform,
      platformId,
      created: Date.now(),
      expires: Date.now() + config.game.bondCodeExpireMinutes * 60 * 1000
    };
    
    this.saveAll();
    return code;
  }
  
  useBondCode(code, newPlatform, newPlatformId) {
    code = code.toUpperCase();
    const bond = this.bonds[code];
    
    if (!bond) return { success: false, error: 'Код не найден' };
    if (Date.now() > bond.expires) {
      delete this.bonds[code];
      this.saveAll();
      return { success: false, error: 'Код истёк' };
    }
    
    const originalKey = `${bond.platform}_${bond.platformId}`;
    const user = this.users[originalKey];
    if (!user) return { success: false, error: 'Аккаунт не найден' };
    
    const newKey = `${newPlatform}_${newPlatformId}`;
    if (this.users[newKey]) return { success: false, error: 'У вас уже есть аккаунт на этой платформе' };
    
    // Привязываем
    user.platforms[newPlatform] = newPlatformId;
    this.users[newKey] = user;
    
    delete this.bonds[code];
    this.saveAll();
    
    return { success: true, user };
  }
  
  // ==================== ЭНЕРГИЯ ====================
  
  regenerateEnergy(user) {
    const now = Date.now();
    const elapsed = (now - (user.lastEnergyRegen || now)) / 1000 / 60;
    const regenAmount = Math.floor(elapsed / config.game.energyRegenMinutes);
    
    if (regenAmount > 0 && user.energy < config.game.maxEnergy) {
      user.energy = Math.min(config.game.maxEnergy, user.energy + regenAmount);
      user.lastEnergyRegen = now;
    }
    return user.energy;
  }
  
  // ==================== ОПЫТ ====================
  
  addExp(user, amount) {
    const oldLevel = levelFromExp(user.exp).level;
    user.exp += amount;
    const newInfo = levelFromExp(user.exp);
    return { leveledUp: newInfo.level > oldLevel, newLevel: newInfo.level, exp: amount };
  }
  
  // ==================== ДОСТИЖЕНИЯ ====================
  
  giveAchievement(userKey, achievementId) {
    const user = this.users[userKey];
    if (!user || user.achievements.includes(achievementId)) return null;
    
    const achievement = config.achievements.find(a => a.id === achievementId);
    if (!achievement) return null;
    
    user.achievements.push(achievementId);
    if (achievement.reward.money) user.money += achievement.reward.money;
    if (achievement.reward.exp) this.addExp(user, achievement.reward.exp);
    if (achievement.reward.diamonds) user.diamonds += achievement.reward.diamonds;
    if (achievement.reward.cups) user.cups += achievement.reward.cups;
    
    return achievement;
  }
  
  checkAchievements(userKey) {
    const user = this.users[userKey];
    if (!user) return [];
    
    const newAchievements = [];
    const checks = [
      { id: 2, check: () => (user.money + user.bank) >= 1000000 },
      { id: 3, check: () => user.stats.raceWins >= 100 },
      { id: 4, check: () => user.stats.bossDamage >= 1000000 },
      { id: 5, check: () => user.businesses.length >= 5 },
      { id: 6, check: () => user.stats.oreMined >= 10000 },
      { id: 7, check: () => user.stats.fishCaught >= 500 },
      { id: 8, check: () => levelFromExp(user.exp).level >= 50 },
      { id: 9, check: () => user.diamonds >= 100 },
      { id: 10, check: () => user.clanId !== null }
    ];
    
    checks.forEach(({ id, check }) => {
      if (!user.achievements.includes(id) && check()) {
        const a = this.giveAchievement(userKey, id);
        if (a) newAchievements.push(a);
      }
    });
    
    if (newAchievements.length > 0) this.saveAll();
    return newAchievements;
  }
  
  // ==================== ПУТЬ НОВИЧКА ====================
  
  checkBeginnerPath(userKey, action) {
    const user = this.users[userKey];
    if (!user || user.beginnerCompleted) return null;
    
    const stage = config.beginnerPath.find(s => s.stage === user.beginnerStage);
    if (!stage || stage.action !== action) return null;
    
    if (action === 'rich' && (user.money + user.bank) < 100000) return null;
    
    if (stage.reward.money) user.money += stage.reward.money;
    if (stage.reward.exp) this.addExp(user, stage.reward.exp);
    if (stage.reward.diamonds) user.diamonds += stage.reward.diamonds;
    
    user.beginnerStage++;
    if (user.beginnerStage > config.beginnerPath.length) {
      user.beginnerCompleted = true;
    }
    
    this.saveAll();
    return stage;
  }
  
  // ==================== КВЕСТЫ ====================
  
  initDailyQuests(user) {
    const today = getDateKey();
    if (user.dailyQuestsDate !== today) {
      user.dailyQuestsDate = today;
      user.dailyQuests = {};
      config.dailyQuests.forEach(q => {
        user.dailyQuests[q.id] = { progress: 0, completed: false, claimed: false };
      });
    }
  }
  
  initWeeklyQuests(user) {
    const week = getWeekKey();
    if (user.weeklyQuestsDate !== week) {
      user.weeklyQuestsDate = week;
      user.weeklyQuests = {};
      config.weeklyQuests.forEach(q => {
        user.weeklyQuests[q.id] = { progress: 0, completed: false, claimed: false };
      });
    }
  }
  
  updateQuestProgress(userKey, type, amount = 1) {
    const user = this.users[userKey];
    if (!user) return [];
    
    this.initDailyQuests(user);
    this.initWeeklyQuests(user);
    
    const completedQuests = [];
    
    const updateQuests = (quests, questConfigs) => {
      questConfigs.filter(q => q.type === type).forEach(quest => {
        const progress = quests[quest.id];
        if (progress && !progress.completed) {
          progress.progress += amount;
          if (progress.progress >= quest.target) {
            progress.completed = true;
            completedQuests.push(quest);
          }
        }
      });
    };
    
    updateQuests(user.dailyQuests, config.dailyQuests);
    updateQuests(user.weeklyQuests, config.weeklyQuests);
    
    this.saveAll();
    return completedQuests;
  }
  
  claimQuest(userKey, questId, isDaily = true) {
    const user = this.users[userKey];
    if (!user) return null;
    
    const quests = isDaily ? user.dailyQuests : user.weeklyQuests;
    const questConfigs = isDaily ? config.dailyQuests : config.weeklyQuests;
    
    const progress = quests[questId];
    const quest = questConfigs.find(q => q.id === questId);
    
    if (!progress || !quest || !progress.completed || progress.claimed) return null;
    
    progress.claimed = true;
    
    if (quest.reward.money) user.money += quest.reward.money;
    if (quest.reward.exp) this.addExp(user, quest.reward.exp);
    if (quest.reward.diamonds) user.diamonds += quest.reward.diamonds;
    if (quest.reward.cups) user.cups += quest.reward.cups;
    
    this.saveAll();
    return quest;
  }
  
  // ==================== БОСС ====================
  
  spawnBoss() {
    const bossTemplate = randomElement(config.bosses);
    const hp = random(bossTemplate.minHp, bossTemplate.maxHp);
    const level = random(1, 10);
    
    this.boss = {
      active: true,
      name: bossTemplate.name,
      level,
      hp,
      maxHp: hp,
      reward: Math.floor(bossTemplate.reward * (1 + level * 0.2)),
      attackers: {},
      spawnTime: Date.now()
    };
    
    this.saveAll();
    return this.boss;
  }
  
  attackBoss(userKey, damage) {
    if (!this.boss.active) return { killed: false, hp: 0 };
    
    if (!this.boss.attackers[userKey]) {
      this.boss.attackers[userKey] = { damage: 0, attacks: 0 };
    }
    
    this.boss.attackers[userKey].damage += damage;
    this.boss.attackers[userKey].attacks++;
    this.boss.hp -= damage;
    
    if (this.boss.hp <= 0) {
      // Босс убит
      const rewards = this.distributeBossRewards(userKey);
      this.boss.active = false;
      this.saveAll();
      return { killed: true, hp: 0, rewards, killerBonus: Math.floor(this.boss.reward * 0.2) };
    }
    
    this.saveAll();
    return { killed: false, hp: this.boss.hp };
  }
  
  distributeBossRewards(killerKey) {
    const totalDamage = Object.values(this.boss.attackers).reduce((sum, a) => sum + a.damage, 0);
    const rewards = [];
    
    Object.entries(this.boss.attackers)
      .sort((a, b) => b[1].damage - a[1].damage)
      .forEach(([key, data]) => {
        const user = this.users[key];
        if (!user) return;
        
        const share = data.damage / totalDamage;
        const reward = Math.floor(this.boss.reward * share);
        const exp = Math.floor(data.damage / 10);
        
        user.money += reward;
        this.addExp(user, exp);
        user.stats.bossDamage += data.damage;
        
        if (key === killerKey) {
          user.money += Math.floor(this.boss.reward * 0.2); // Бонус убийцы
          user.stats.bossKills++;
        }
        
        rewards.push({ key, name: user.name, damage: data.damage, reward });
      });
    
    return rewards;
  }
  
  // ==================== КЛАНЫ ====================
  
  createClan(ownerKey, name) {
    const user = this.users[ownerKey];
    if (!user || user.money < 100000) return null;
    
    const id = this.nextClanId++;
    user.money -= 100000;
    
    this.clans[id] = {
      id,
      name,
      leader: ownerKey,
      members: [ownerKey],
      treasury: 0,
      level: 1,
      exp: 0,
      wars: { wins: 0, losses: 0 },
      created: Date.now()
    };
    
    user.clanId = id;
    this.saveAll();
    
    return this.clans[id];
  }
  
  joinClan(userKey, clanId) {
    const user = this.users[userKey];
    const clan = this.clans[clanId];
    
    if (!user || !clan || user.clanId) return false;
    if (clan.members.length >= 50) return false;
    
    clan.members.push(userKey);
    user.clanId = clanId;
    this.saveAll();
    
    return true;
  }
  
  leaveClan(userKey) {
    const user = this.users[userKey];
    if (!user || !user.clanId) return false;
    
    const clan = this.clans[user.clanId];
    if (!clan) {
      user.clanId = null;
      this.saveAll();
      return true;
    }
    
    // Лидер не может покинуть
    if (clan.leader === userKey && clan.members.length > 1) return false;
    
    clan.members = clan.members.filter(m => m !== userKey);
    
    // Если это последний участник — удаляем клан
    if (clan.members.length === 0) {
      delete this.clans[user.clanId];
    }
    
    user.clanId = null;
    this.saveAll();
    return true;
  }
  
  // ==================== ПРОМОКОДЫ ====================
  
  createPromoCode(code, rewards, limit = 100) {
    this.promoCodes[code.toUpperCase()] = {
      rewards,
      limit,
      used: 0,
      users: [],
      created: Date.now()
    };
    this.saveAll();
    return true;
  }
  
  usePromoCode(userKey, code) {
    code = code.toUpperCase();
    const promo = this.promoCodes[code];
    const user = this.users[userKey];
    
    if (!promo) return { success: false, error: 'Промокод не найден' };
    if (!user) return { success: false, error: 'Пользователь не найден' };
    if (promo.users.includes(userKey)) return { success: false, error: 'Вы уже использовали этот промокод' };
    if (promo.used >= promo.limit) return { success: false, error: 'Промокод исчерпан' };
    
    promo.users.push(userKey);
    promo.used++;
    
    if (promo.rewards.money) user.money += promo.rewards.money;
    if (promo.rewards.exp) this.addExp(user, promo.rewards.exp);
    if (promo.rewards.diamonds) user.diamonds += promo.rewards.diamonds;
    
    this.saveAll();
    return { success: true, reward: promo.rewards };
  }
  
  // ==================== СОБЫТИЯ ====================
  
  startEvent(eventTemplate) {
    const event = {
      ...eventTemplate,
      startTime: Date.now(),
      endTime: Date.now() + eventTemplate.duration * 1000
    };
    
    this.events.active.push(event);
    this.saveAll();
    return event;
  }
  
  getActiveEvents() {
    const now = Date.now();
    this.events.active = this.events.active.filter(e => e.endTime > now);
    return this.events.active;
  }
  
  hasEventBonus(type) {
    return this.getActiveEvents().some(e => e.type === type);
  }
  
  getEventMultiplier(type) {
    const event = this.getActiveEvents().find(e => e.type === type);
    return event ? event.multiplier || 1 : 1;
  }
  
  // ==================== ТРЕЙДИНГ ====================
  
  getCurrentBtcPrice() {
    // Базовая цена + случайное отклонение
    const basePrice = 50000;
    const variance = 10000;
    return basePrice + random(-variance, variance);
  }
  
  getTradeDirection() {
    // 50/50 шанс
    return Math.random() < 0.5 ? 'up' : 'down';
  }
}

// Экспорт синглтона
module.exports = new Database();
