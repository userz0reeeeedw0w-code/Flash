// ⚡ FLASH BOT v2.0 — КЛАВИАТУРЫ
module.exports = {
  // ==================== TELEGRAM INLINE ====================
  tg: {
    // Стартовое меню
    start: {
      inline_keyboard: [
        [{ text: '✅ СОЗДАТЬ АККАУНТ', callback_data: 'auth_create' }],
        [{ text: '🔗 ПРИВЯЗАТЬ СУЩЕСТВУЮЩИЙ', callback_data: 'auth_bind' }]
      ]
    },
    
    // Главное меню
    main: {
      inline_keyboard: [
        [{ text: '👤 Профиль', callback_data: 'cmd_profile' }, { text: '💰 Баланс', callback_data: 'cmd_balance' }],
        [{ text: '🏪 Магазин', callback_data: 'cmd_shop' }, { text: '💼 Работа', callback_data: 'cmd_job' }],
        [{ text: '🎰 Казино', callback_data: 'cmd_casino' }, { text: '🏁 Гонки', callback_data: 'cmd_race' }],
        [{ text: '⚔️ Босс', callback_data: 'cmd_boss' }, { text: '🏛️ Клан', callback_data: 'cmd_clan' }],
        [{ text: '🎮 Игры', callback_data: 'cmd_games' }, { text: '❓ Помощь', callback_data: 'cmd_help' }]
      ]
    },
    
    // Привязка
    bind: {
      inline_keyboard: [
        [{ text: '🔄 НОВЫЙ КОД', callback_data: 'bind_newcode' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Профиль
    profile: {
      inline_keyboard: [
        [{ text: '📊 Статистика', callback_data: 'cmd_stats' }, { text: '🏆 Достижения', callback_data: 'cmd_achievements' }],
        [{ text: '📦 Инвентарь', callback_data: 'cmd_inventory' }, { text: '🎁 Рефералы', callback_data: 'cmd_referral' }],
        [{ text: '⚙️ Настройки', callback_data: 'cmd_settings' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Баланс
    balance: {
      inline_keyboard: [
        [{ text: '🏦 Банк', callback_data: 'cmd_bank' }, { text: '💱 Обмен', callback_data: 'cmd_exchange' }],
        [{ text: '💸 Перевести', callback_data: 'transfer_start' }, { text: '💎 Донат', callback_data: 'cmd_donate' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Банк
    bank: {
      inline_keyboard: [
        [{ text: '💰 Положить всё', callback_data: 'bank_dep_all' }, { text: '💸 Снять всё', callback_data: 'bank_with_all' }],
        [{ text: '📈 Лимит+', callback_data: 'bank_limit' }, { text: '💳 Кредит', callback_data: 'bank_credit' }],
        [{ text: '🔙 НАЗАД', callback_data: 'cmd_balance' }]
      ]
    },
    
    // Магазин
    shop: {
      inline_keyboard: [
        [{ text: '🚗 Машины', callback_data: 'shop_cars' }, { text: '🏢 Бизнесы', callback_data: 'shop_biz' }],
        [{ text: '🌾 Фермы', callback_data: 'shop_farms' }, { text: '🖨️ Принтеры', callback_data: 'shop_printers' }],
        [{ text: '📱 Телефоны', callback_data: 'shop_phones' }, { text: '🏠 Дома', callback_data: 'shop_houses' }],
        [{ text: '🐾 Питомцы', callback_data: 'shop_pets' }, { text: '📦 Кейсы', callback_data: 'shop_cases' }],
        [{ text: '🛥️ Яхты', callback_data: 'shop_yachts' }, { text: '✈️ Самолёты', callback_data: 'shop_planes' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Работа
    job: {
      inline_keyboard: [
        [{ text: '💼 РАБОТАТЬ', callback_data: 'do_work' }],
        [{ text: '📋 Список работ', callback_data: 'job_list' }, { text: '📊 Инфо', callback_data: 'job_info' }],
        [{ text: '🚪 Уволиться', callback_data: 'job_quit' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Бизнес
    business: {
      inline_keyboard: [
        [{ text: '💰 СОБРАТЬ ВСЕ', callback_data: 'biz_collect_all' }],
        [{ text: '📋 Мои бизнесы', callback_data: 'biz_my' }, { text: '🛒 Купить', callback_data: 'shop_biz' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Фермы
    farms: {
      inline_keyboard: [
        [{ text: '₿ СОБРАТЬ ВСЕ', callback_data: 'farm_collect_all' }],
        [{ text: '📋 Мои фермы', callback_data: 'farm_my' }, { text: '🛒 Купить', callback_data: 'shop_farms' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Принтеры
    printers: {
      inline_keyboard: [
        [{ text: '💰 СОБРАТЬ ВСЕ', callback_data: 'printer_collect_all' }],
        [{ text: '📋 Мои принтеры', callback_data: 'printer_my' }, { text: '🛒 Купить', callback_data: 'shop_printers' }],
        [{ text: '⛽ Заправить', callback_data: 'printer_fuel_all' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Казино
    casino: {
      inline_keyboard: [
        [{ text: '🎰 Слоты', callback_data: 'casino_slots' }, { text: '🎯 Рулетка', callback_data: 'casino_roulette' }],
        [{ text: '🎲 Кости', callback_data: 'casino_dice' }, { text: '🪙 Монетка', callback_data: 'casino_coin' }],
        [{ text: '📊 Статистика', callback_data: 'casino_stats' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Гонки
    race: {
      inline_keyboard: [
        [{ text: '🏁 ГОНКА', callback_data: 'do_race' }],
        [{ text: '🚗 Мои машины', callback_data: 'cmd_cars' }, { text: '🔧 Тюнинг', callback_data: 'cmd_tuning' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Босс
    boss: {
      inline_keyboard: [
        [{ text: '⚔️ АТАКОВАТЬ', callback_data: 'boss_attack' }],
        [{ text: '📊 Статистика', callback_data: 'boss_stats' }, { text: '🏆 Топ урона', callback_data: 'boss_top' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Клан
    clan: {
      inline_keyboard: [
        [{ text: '👥 Состав', callback_data: 'clan_members' }, { text: '💰 Казна', callback_data: 'clan_treasury' }],
        [{ text: '⚔️ Война', callback_data: 'clan_war' }, { text: '🚪 Покинуть', callback_data: 'clan_leave' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Игры
    games: {
      inline_keyboard: [
        [{ text: '📈 Трейд', callback_data: 'game_trade' }, { text: '🎲 Кубик', callback_data: 'game_dice' }],
        [{ text: '🥛 Стаканчики', callback_data: 'game_cup' }, { text: '🪙 Монетка', callback_data: 'game_coin' }],
        [{ text: '⚔️ Дуэль', callback_data: 'game_duel' }, { text: '🏟️ Арена', callback_data: 'game_arena' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Топы
    tops: {
      inline_keyboard: [
        [{ text: '💰 Деньги', callback_data: 'top_money' }, { text: '📈 Уровень', callback_data: 'top_level' }],
        [{ text: '🏢 Бизнес', callback_data: 'top_business' }, { text: '🏛️ Кланы', callback_data: 'top_clans' }],
        [{ text: '⭐ Рейтинг', callback_data: 'top_rating' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Помощь
    help: {
      inline_keyboard: [
        [{ text: '📋 Команды', callback_data: 'help_commands' }, { text: '🎮 Игры', callback_data: 'help_games' }],
        [{ text: '💰 Экономика', callback_data: 'help_economy' }, { text: '🎁 Рефералы', callback_data: 'help_ref' }],
        [{ text: '📜 Правила', callback_data: 'help_rules' }, { text: 'ℹ️ Инфо', callback_data: 'help_info' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Квесты
    quests: {
      inline_keyboard: [
        [{ text: '📅 Ежедневные', callback_data: 'quests_daily' }, { text: '📆 Недельные', callback_data: 'quests_weekly' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Настройки
    settings: {
      inline_keyboard: [
        [{ text: '⌨️ Клавиатура', callback_data: 'settings_keyboard' }],
        [{ text: '🔔 Уведомления', callback_data: 'settings_notif' }],
        [{ text: '🔙 НАЗАД', callback_data: 'back_main' }]
      ]
    },
    
    // Функция для кнопки "Назад"
    back: (target) => ({
      inline_keyboard: [[{ text: '🔙 НАЗАД', callback_data: target }]]
    }),
    
    // Ставки казино
    casinoBet: (game) => ({
      inline_keyboard: [
        [{ text: '100$', callback_data: `${game}_100` }, { text: '1K$', callback_data: `${game}_1000` }, { text: '10K$', callback_data: `${game}_10000` }],
        [{ text: '50K$', callback_data: `${game}_50000` }, { text: '100K$', callback_data: `${game}_100000` }, { text: 'ВСЕ', callback_data: `${game}_all` }],
        [{ text: '🔙 НАЗАД', callback_data: 'cmd_casino' }]
      ]
    })
  },
  
  // ==================== TELEGRAM REPLY ====================
  tgReply: {
    keyboard: [
      [{ text: '👤 Профиль' }, { text: '💰 Баланс' }, { text: '🏪 Магазин' }],
      [{ text: '⚔️ Босс' }, { text: '🏁 Гонка' }, { text: '💼 Работа' }],
      [{ text: '🏛️ Клан' }, { text: '🎰 Казино' }, { text: '🎁 Бонус' }],
      [{ text: '📊 Топ' }, { text: '❓ Помощь' }, { text: '📍 Путь' }]
    ],
    resize_keyboard: true
  },
  
  tgRemove: {
    remove_keyboard: true
  },
  
  // ==================== VK ====================
  // VK кнопки генерируются динамически в platforms/vk.js
  
  // Текстовые подсказки для беседы VK
  vkChatHints: {
    main: [
      '👤 профиль | 💰 баланс | 🏪 магазин',
      '⚔️ босс | 🏁 гонка | 💼 работа',
      '🏛️ клан | 🎰 казино | 🎁 бонус',
      '📊 топ | ❓ помощь | 📍 путь'
    ]
  }
};
