// PM2 Ecosystem Configuration
module.exports = {
  apps: [{
    name: 'flash-bot',
    script: 'index.js',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '500M',
    env: {
      NODE_ENV: 'development'
    },
    env_production: {
      NODE_ENV: 'production'
    },
    error_file: './logs/errors.log',
    out_file: './logs/commands.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss',
    merge_logs: true,
    kill_timeout: 5000,
    restart_delay: 1000,
    exp_backoff_restart_delay: 100
  }]
};
