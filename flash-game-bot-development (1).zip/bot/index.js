/**
 * ⚡ FLASH BOT — Игровой бот для Telegram и VK
 * Версия: 1.0.0
 * Node.js + JSON + ПОЛЛИНГ
 */

require('dotenv').config();

const db = require('./src/core/database/db.service');
const logger = require('./src/core/logger');
const cache = require('./src/core/cache');
const scheduler = require('./src/core/scheduler');
const telegramBot = require('./src/core/platforms/telegram/bot');
const vkBot = require('./src/core/platforms/vk/bot');
const telegramHandlers = require('./src/core/platforms/telegram/handlers');
const vkHandlers = require('./src/core/platforms/vk/handlers');
const { getCommand } = require('./src/config/aliases');
const { isBanned, needsCaptcha } = require('./src/core/utils/validator');
const { messages } = require('./src/config/messages');
const { getPlayerIdentifier } = require('./src/core/utils/formatter');

// Импортируем модули
const authModule = require('./src/modules/auth');
const profileModule = require('./src/modules/profile');
const economyModule = require('./src/modules/economy');
const businessModule = require('./src/modules/business');
const gamesModule = require('./src/modules/games');
const socialModule = require('./src/modules/social');
const contentModule = require('./src/modules/content');
const adminModule = require('./src/modules/admin');

// Объединяем все команды
const allCommands = {
  ...authModule.commands,
  ...profileModule.commands,
  ...economyModule.commands,
  ...businessModule.commands,
  ...gamesModule.commands,
  ...socialModule.commands,
  ...contentModule.commands,
  ...adminModule.commands
};

/**
 * Главный обработчик сообщений
 */
async function handleMessage(context) {
  try {
    const { platform, userId, text } = context;
    
    // Логируем активность
    cache.setOnline(platform, userId);
    
    // Парсим команду
    const handlers = platform === 'telegram' ? telegramHandlers : vkHandlers;
    const parsed = handlers.parseCommand(text);
    
    if (!parsed) {
      // Не команда - проверяем капчу
      const user = db.getUser(platform, userId);
      if (user && user.captchaPending) {
        // Может это ответ на капчу?
        return await adminModule.commands.captchaAnswer(context, user, text.split(/\s+/));
      }
      return null;
    }
    
    const { command, args } = parsed;
    
    // Получаем пользователя
    let user = db.getUser(platform, userId);
    
    // Автоматическая регистрация при старте
    if (!user && command !== 'start') {
      // Пользователь не зарегистрирован
      const identifier = handlers.getUserIdentifier(context, null);
      return { text: messages.errors.notRegistered(identifier), keyboard: 'main' };
    }
    
    // Проверка бана
    if (user && isBanned(user)) {
      const identifier = getPlayerIdentifier(user, platform);
      return { text: messages.errors.banned(identifier, user.banReason || 'Не указана'), keyboard: 'main' };
    }
    
    // Проверка капчи
    if (user && needsCaptcha(user) && command !== 'captchaAnswer') {
      const identifier = getPlayerIdentifier(user, platform);
      if (user.captchaBlockedUntil && Date.now() < user.captchaBlockedUntil) {
        return { text: messages.errors.captchaBlocked(identifier, user.captchaBlockedUntil - Date.now()), keyboard: 'main' };
      }
      return { text: messages.errors.captchaRequired(identifier), keyboard: 'main' };
    }
    
    // Обновляем время активности
    if (user) {
      const playTime = (user.playTime || 0) + Math.min(60000, Date.now() - (user.lastActivity || Date.now()));
      db.updateUser(platform, userId, { playTime });
    }
    
    // Логируем команду
    logger.command(userId, platform, command, args);
    db.logCommand(command, userId);
    
    // Выполняем команду
    const handler = allCommands[command];
    
    if (!handler) {
      logger.warn(`Unknown command: ${command}`);
      return null;
    }
    
    const result = await handler(context, user, args);
    
    // Обновляем путь новичка
    if (user && result) {
      updateNewbiePath(user, command);
    }
    
    return result;
  } catch (error) {
    logger.error('Message handler error:', { error: error.message, stack: error.stack });
    db.logError(error, { context });
    return {
      text: `❌ Произошла ошибка. Попробуйте позже.`,
      keyboard: 'main'
    };
  }
}

/**
 * Обработчик callback-кнопок
 */
async function handleCallback(context) {
  try {
    const { platform, userId, callbackData } = context;
    
    // Получаем пользователя
    const user = db.getUser(platform, userId);
    
    if (!user) {
      return { text: '❌ Сначала зарегистрируйтесь: напишите "старт"', edit: true };
    }
    
    // Парсим callback
    const [action, ...params] = callbackData.split('_');
    
    // Обрабатываем основные callback-и
    switch (action) {
      case 'profile':
        if (params[0] === 'stats') {
          return await profileModule.commands.stats(context, user, []);
        }
        if (params[0] === 'achievements') {
          return await profileModule.commands.achievements(context, user, []);
        }
        if (params[0] === 'referrals') {
          return await socialModule.commands.referral(context, user, []);
        }
        break;
        
      case 'boss':
        if (params[0] === 'attack') {
          return await socialModule.commands.bossAttack(context, user, []);
        }
        if (params[0] === 'weapon') {
          return await socialModule.commands.bossAttack(context, user, [params[1]]);
        }
        break;
        
      case 'clan':
        if (params[0] === 'members') {
          return await socialModule.commands.clanMembers(context, user, []);
        }
        if (params[0] === 'treasury') {
          return await socialModule.commands.clanTreasury(context, user, []);
        }
        if (params[0] === 'attack') {
          return await socialModule.commands.clanAttack(context, user, []);
        }
        if (params[0] === 'repair') {
          return await socialModule.commands.clanRepair(context, user, []);
        }
        if (params[0] === 'shop') {
          return { text: '🏪 Магазин клана в разработке...', edit: true };
        }
        break;
        
      case 'casino':
        if (params[0] === 'slots') {
          return await gamesModule.commands.casinoSlots(context, user, ['1000']);
        }
        if (params[0] === 'dice') {
          return await gamesModule.commands.casinoDice(context, user, ['1000']);
        }
        if (params[0] === 'cards') {
          return await gamesModule.commands.casinoCards(context, user, []);
        }
        if (params[0] === 'blackjack') {
          return await gamesModule.commands.casinoBlackjack(context, user, []);
        }
        if (params[0] === 'stats') {
          return await gamesModule.commands.casinoStats(context, user, []);
        }
        break;
        
      case 'shop':
        if (params[0] === 'cars') {
          return await gamesModule.commands.carList(context, user, []);
        }
        if (params[0] === 'businesses') {
          return await businessModule.commands.businessList(context, user, []);
        }
        if (params[0] === 'farms') {
          return await businessModule.commands.farms(context, user, []);
        }
        if (params[0] === 'printers') {
          return await businessModule.commands.printer(context, user, []);
        }
        if (params[0] === 'cases') {
          return await gamesModule.commands.caseList(context, user, []);
        }
        if (params[0] === 'pets') {
          return await socialModule.commands.petList(context, user, []);
        }
        break;
        
      case 'bank':
        if (params[0] === 'deposit') {
          return { text: '💡 Введите: банк положить [сумма]', edit: true };
        }
        if (params[0] === 'withdraw') {
          return { text: '💡 Введите: банк снять [сумма]', edit: true };
        }
        if (params[0] === 'credit') {
          return await economyModule.commands.bankCreditInfo(context, user, []);
        }
        if (params[0] === 'invest') {
          return await economyModule.commands.investments(context, user, []);
        }
        break;
        
      case 'quest':
        if (params[0] === 'daily') {
          return await contentModule.commands.questDaily(context, user, []);
        }
        if (params[0] === 'weekly') {
          return await contentModule.commands.questWeekly(context, user, []);
        }
        if (params[0] === 'newbie') {
          return await contentModule.commands.newbiePath(context, user, []);
        }
        if (params[0] === 'rewards') {
          return await contentModule.commands.questRewards(context, user, []);
        }
        break;
        
      case 'back':
        if (params[0] === 'main') {
          return await profileModule.commands.profile(context, user, []);
        }
        break;
        
      case 'confirm':
        // Обработка подтверждений
        const pending = cache.getPendingAction(user.uid);
        if (pending) {
          cache.clearPendingAction(user.uid);
          if (params[0] === 'yes') {
            // Выполнить действие
            return { text: '✅ Подтверждено!', edit: true };
          } else {
            return { text: '❌ Отменено!', edit: true };
          }
        }
        break;
        
      case 'noop':
        // Ничего не делаем
        return null;
    }
    
    return null;
  } catch (error) {
    logger.error('Callback handler error:', { error: error.message });
    return { text: '❌ Ошибка обработки', edit: true };
  }
}

/**
 * Обновление пути новичка
 */
function updateNewbiePath(user, command) {
  if (!user.newbiePath) return;
  
  const path = [...user.newbiePath];
  let updated = false;
  
  path.forEach((task, i) => {
    if (!task.completed && task.command === command) {
      path[i].completed = true;
      updated = true;
    }
  });
  
  if (updated) {
    const allCompleted = path.every(t => t.completed);
    const updates = { newbiePath: path };
    
    // Награда за полное прохождение
    if (allCompleted && !user.newbiePathCompleted) {
      updates.money = (user.money || 0) + 50000;
      updates.newbiePathCompleted = true;
    }
    
    db.updateUser(user.platform, user.platformId, updates);
  }
}

/**
 * Инициализация бота
 */
async function init() {
  console.log('⚡ FLASH BOT — Запуск...');
  console.log('━'.repeat(40));
  
  try {
    // Инициализация базы данных
    await db.init();
    console.log('✅ База данных инициализирована');
    
    // Инициализация планировщика
    scheduler.init();
    console.log('✅ Планировщик запущен');
    
    // Инициализация Telegram бота
    const telegramStarted = await telegramBot.init(handleMessage, handleCallback);
    if (telegramStarted) {
      console.log('✅ Telegram бот запущен (поллинг)');
    } else {
      console.log('⚠️ Telegram бот не запущен');
    }
    
    // Инициализация VK бота
    const vkStarted = await vkBot.init(handleMessage, handleCallback);
    if (vkStarted) {
      console.log('✅ VK бот запущен (поллинг)');
    } else {
      console.log('⚠️ VK бот не запущен');
    }
    
    console.log('━'.repeat(40));
    console.log('⚡ FLASH BOT — Готов к работе!');
    console.log(`📊 Команд: ${Object.keys(allCommands).length}`);
    console.log(`👥 Игроков: ${Object.keys(db.getUsers()).length}`);
    console.log('━'.repeat(40));
    
  } catch (error) {
    console.error('❌ Ошибка инициализации:', error);
    process.exit(1);
  }
}

/**
 * Graceful shutdown
 */
async function shutdown() {
  console.log('\n⚡ FLASH BOT — Остановка...');
  
  try {
    // Останавливаем ботов
    telegramBot.stop();
    vkBot.stop();
    
    // Останавливаем планировщик
    scheduler.stop();
    
    // Сохраняем данные
    await db.close();
    
    console.log('✅ Бот остановлен корректно');
    process.exit(0);
  } catch (error) {
    console.error('❌ Ошибка при остановке:', error);
    process.exit(1);
  }
}

// Обработка сигналов завершения
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

// Обработка необработанных ошибок
process.on('uncaughtException', (error) => {
  logger.error('Uncaught Exception:', { error: error.message, stack: error.stack });
  console.error('❌ Uncaught Exception:', error);
});

process.on('unhandledRejection', (reason, promise) => {
  logger.error('Unhandled Rejection:', { reason });
  console.error('❌ Unhandled Rejection:', reason);
});

// Запуск
init();
