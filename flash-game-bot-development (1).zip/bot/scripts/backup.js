/**
 * FLASH BOT - Backup Script
 * Запускается по cron для создания бэкапов
 */

require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });

const BackupService = require('../src/core/database/backup.service');

async function main() {
  console.log('[Backup] Starting backup...');
  
  try {
    const result = await BackupService.createBackup();
    console.log(`[Backup] Success: ${result}`);
    process.exit(0);
  } catch (error) {
    console.error('[Backup] Failed:', error.message);
    process.exit(1);
  }
}

main();
