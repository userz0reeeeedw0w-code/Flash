/**
 * FLASH BOT - Health Check Script
 */

const fs = require('fs');
const path = require('path');

function checkHealth() {
  const checks = [];
  
  // Проверка наличия .env
  const envPath = path.join(__dirname, '..', '.env');
  checks.push({
    name: 'Environment file',
    passed: fs.existsSync(envPath),
    message: fs.existsSync(envPath) ? 'OK' : 'Missing .env file'
  });
  
  // Проверка директории данных
  const dataDir = path.join(__dirname, '..', 'src', 'data');
  checks.push({
    name: 'Data directory',
    passed: fs.existsSync(dataDir),
    message: fs.existsSync(dataDir) ? 'OK' : 'Missing data directory'
  });
  
  // Проверка users.json
  const usersPath = path.join(dataDir, 'users.json');
  checks.push({
    name: 'Users database',
    passed: fs.existsSync(usersPath),
    message: fs.existsSync(usersPath) ? 'OK' : 'Missing users.json'
  });
  
  // Проверка логов
  const logsDir = path.join(__dirname, '..', 'logs');
  checks.push({
    name: 'Logs directory',
    passed: fs.existsSync(logsDir),
    message: fs.existsSync(logsDir) ? 'OK' : 'Missing logs directory'
  });
  
  // Вывод результатов
  console.log('━'.repeat(40));
  console.log('⚡ FLASH BOT - Health Check');
  console.log('━'.repeat(40));
  
  let allPassed = true;
  checks.forEach(check => {
    const status = check.passed ? '✅' : '❌';
    console.log(`${status} ${check.name}: ${check.message}`);
    if (!check.passed) allPassed = false;
  });
  
  console.log('━'.repeat(40));
  console.log(allPassed ? '✅ All checks passed!' : '❌ Some checks failed!');
  
  process.exit(allPassed ? 0 : 1);
}

checkHealth();
