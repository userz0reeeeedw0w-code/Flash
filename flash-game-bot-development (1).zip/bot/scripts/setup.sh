#!/bin/bash

# FLASH BOT - Setup Script
# Для Ubuntu 20.04/22.04

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "⚡ FLASH BOT - Setup"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Проверка Node.js
if ! command -v node &> /dev/null; then
    echo "📦 Installing Node.js..."
    curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
    sudo apt-get install -y nodejs
fi

echo "✅ Node.js version: $(node -v)"
echo "✅ npm version: $(npm -v)"

# Создание директорий
echo "📁 Creating directories..."
mkdir -p src/data
mkdir -p src/data/backups
mkdir -p logs

# Установка зависимостей
echo "📦 Installing dependencies..."
npm install

# Создание .env если не существует
if [ ! -f .env ]; then
    echo "📝 Creating .env file..."
    cp .env.example .env 2>/dev/null || echo "⚠️ No .env.example found"
fi

# Проверка здоровья
echo "🔍 Running health check..."
node scripts/health-check.js

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ Setup complete!"
echo ""
echo "To start the bot:"
echo "  npm start"
echo ""
echo "Or with PM2:"
echo "  pm2 start ecosystem.config.js"
echo ""
echo "Or with systemd:"
echo "  sudo cp flash-bot.service /etc/systemd/system/"
echo "  sudo systemctl enable flash-bot"
echo "  sudo systemctl start flash-bot"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
