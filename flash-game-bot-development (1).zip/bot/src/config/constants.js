/**
 * FLASH BOT - Константы
 */

// Платформы
const PLATFORMS = {
  TELEGRAM: 'telegram',
  VK: 'vk'
};

// Роли в клане
const CLAN_ROLES = {
  LEADER: 'leader',
  VICE_LEADER: 'vice_leader',
  MEMBER: 'member',
  NEWBIE: 'newbie'
};

const CLAN_ROLE_NAMES = {
  [CLAN_ROLES.LEADER]: '👑 Лидер',
  [CLAN_ROLES.VICE_LEADER]: '⚔️ Вице-лидер',
  [CLAN_ROLES.MEMBER]: '🛡️ Член',
  [CLAN_ROLES.NEWBIE]: '🆕 Новичок'
};

// Типы привилегий
const PRIVILEGE_TYPES = {
  NONE: 'none',
  VIP: 'vip',
  PREMIUM: 'premium',
  LEGEND: 'legend',
  ULTIMATE: 'ultimate'
};

// Машины
const CARS = [
  { id: 1, name: 'Обычная', price: 0, currency: 'money', speed: 30, acceleration: 20, handling: 40 },
  { id: 2, name: 'Спортивная', price: 500000, currency: 'money', speed: 60, acceleration: 50, handling: 55 },
  { id: 3, name: 'Гоночная', price: 2000000, currency: 'money', speed: 80, acceleration: 75, handling: 70 },
  { id: 4, name: 'Танк', price: 5000, currency: 'rubles', speed: 100, acceleration: 90, handling: 85 },
  { id: 5, name: 'Турбо', price: 10000, currency: 'rubles', speed: 120, acceleration: 110, handling: 95 },
  { id: 6, name: 'Электро', price: 25000, currency: 'rubles', speed: 140, acceleration: 130, handling: 105 },
  { id: 7, name: 'Космическая', price: 50000, currency: 'rubles', speed: 180, acceleration: 160, handling: 130 },
  { id: 8, name: 'Легендарная', price: 100000, currency: 'rubles', speed: 200, acceleration: 180, handling: 150 },
  { id: 9, name: 'Босс', price: 200000, currency: 'rubles', speed: 250, acceleration: 220, handling: 180 },
  { id: 10, name: 'Финальная', price: 500000, currency: 'rubles', speed: 300, acceleration: 280, handling: 230 },
  { id: 11, name: 'Мотоцикл', price: 100000, currency: 'money', speed: 50, acceleration: 70, handling: 60 },
  { id: 12, name: 'Спортмото', price: 300000, currency: 'money', speed: 70, acceleration: 90, handling: 65 },
  { id: 13, name: 'Квадроцикл', price: 400000, currency: 'money', speed: 45, acceleration: 55, handling: 80 },
  { id: 14, name: 'Дрон', price: 3000, currency: 'rubles', speed: 90, acceleration: 100, handling: 110 },
  { id: 15, name: 'Вертолёт', price: 15000, currency: 'rubles', speed: 130, acceleration: 120, handling: 100 },
  { id: 16, name: 'Яхта', price: 30000, currency: 'rubles', speed: 60, acceleration: 40, handling: 120 },
  { id: 17, name: 'Космолёт', price: 75000, currency: 'rubles', speed: 220, acceleration: 200, handling: 170 },
  { id: 18, name: 'МегаКосмолёт', price: 150000, currency: 'rubles', speed: 270, acceleration: 250, handling: 200 },
  { id: 19, name: 'Бронемашина', price: 250000, currency: 'rubles', speed: 150, acceleration: 140, handling: 160 },
  { id: 20, name: 'Танк-Мега', price: 400000, currency: 'rubles', speed: 180, acceleration: 170, handling: 190 }
];

// Бизнесы
const BUSINESSES = [
  { id: 1, name: 'Ларёк', price: 10000, income: 500 },
  { id: 2, name: 'Магазин', price: 50000, income: 2000 },
  { id: 3, name: 'Кафе', price: 100000, income: 4000 },
  { id: 4, name: 'Ресторан', price: 200000, income: 7000 },
  { id: 5, name: 'Автомойка', price: 150000, income: 5500 },
  { id: 6, name: 'Заправка', price: 300000, income: 10000 },
  { id: 7, name: 'Автосалон', price: 500000, income: 15000 },
  { id: 8, name: 'Гостиница', price: 750000, income: 22000 },
  { id: 9, name: 'Торговый центр', price: 1000000, income: 35000 },
  { id: 10, name: 'Бизнес-центр', price: 2000000, income: 50000 }
];

// Фермы (BTC)
const FARMS = [
  { id: 1, name: 'Маленькая ферма', price: 50000, btcPerHour: 0.1 },
  { id: 2, name: 'Средняя ферма', price: 150000, btcPerHour: 0.5 },
  { id: 3, name: 'Большая ферма', price: 500000, btcPerHour: 1.0 },
  { id: 4, name: 'Мега-ферма', price: 1000000, btcPerHour: 2.5 },
  { id: 5, name: 'Ультра-ферма', price: 2000000, btcPerHour: 5.0 }
];

// Принтеры
const PRINTERS = [
  { id: 1, name: 'Простой принтер', price: 100000, incomePerHour: 500 },
  { id: 2, name: 'Продвинутый принтер', price: 300000, incomePerHour: 2000 },
  { id: 3, name: 'Мега-принтер', price: 700000, incomePerHour: 5000 },
  { id: 4, name: 'Ультра-принтер', price: 1000000, incomePerHour: 10000 }
];

// Работы
const JOBS = [
  { id: 1, name: 'Стажёр', minLevel: 1, minIncome: 1000, maxIncome: 2000 },
  { id: 2, name: 'Сотрудник', minLevel: 5, minIncome: 2000, maxIncome: 4000 },
  { id: 3, name: 'Старший сотрудник', minLevel: 10, minIncome: 3500, maxIncome: 6000 },
  { id: 4, name: 'Менеджер', minLevel: 20, minIncome: 5000, maxIncome: 8000 },
  { id: 5, name: 'Директор', minLevel: 35, minIncome: 7000, maxIncome: 10000 }
];

// Теги
const TAGS = [
  { id: 1, name: 'Новичок', minLevel: 1 },
  { id: 2, name: 'Игрок', minLevel: 5 },
  { id: 3, name: 'Опытный', minLevel: 15 },
  { id: 4, name: 'Профи', minLevel: 30 },
  { id: 5, name: 'Мастер', minLevel: 50 },
  { id: 6, name: 'Магнат', minLevel: 70 },
  { id: 7, name: 'Легенда', minLevel: 90 },
  { id: 8, name: 'Бог', minLevel: 100 }
];

// Кейсы
const CASES = [
  { id: 1, name: 'Обычный кейс', price: 5000, currency: 'money', rewards: [
    { type: 'money', min: 1000, max: 10000, chance: 50 },
    { type: 'experience', min: 50, max: 200, chance: 30 },
    { type: 'diamonds', min: 1, max: 3, chance: 15 },
    { type: 'car', carId: 2, chance: 5 }
  ]},
  { id: 2, name: 'Редкий кейс', price: 25000, currency: 'money', rewards: [
    { type: 'money', min: 10000, max: 50000, chance: 40 },
    { type: 'experience', min: 200, max: 500, chance: 25 },
    { type: 'diamonds', min: 3, max: 10, chance: 20 },
    { type: 'car', carId: 3, chance: 10 },
    { type: 'business', businessId: 1, chance: 5 }
  ]},
  { id: 3, name: 'Легендарный кейс', price: 100000, currency: 'money', rewards: [
    { type: 'money', min: 50000, max: 200000, chance: 30 },
    { type: 'experience', min: 500, max: 1500, chance: 20 },
    { type: 'diamonds', min: 10, max: 30, chance: 25 },
    { type: 'rubles', min: 100, max: 1000, chance: 15 },
    { type: 'car', carId: 5, chance: 8 },
    { type: 'privilege', privilegeType: 'vip', days: 7, chance: 2 }
  ]},
  { id: 4, name: 'VIP кейс', price: 1000, currency: 'rubles', rewards: [
    { type: 'money', min: 100000, max: 500000, chance: 25 },
    { type: 'rubles', min: 500, max: 2000, chance: 30 },
    { type: 'diamonds', min: 20, max: 50, chance: 20 },
    { type: 'car', carId: 7, chance: 15 },
    { type: 'privilege', privilegeType: 'premium', days: 7, chance: 10 }
  ]}
];

// Рыба
const FISH = [
  { id: 1, name: 'Карась', price: 100, chance: 30 },
  { id: 2, name: 'Окунь', price: 200, chance: 25 },
  { id: 3, name: 'Щука', price: 500, chance: 20 },
  { id: 4, name: 'Сом', price: 1000, chance: 12 },
  { id: 5, name: 'Осётр', price: 2500, chance: 8 },
  { id: 6, name: 'Золотая рыбка', price: 5000, chance: 5 }
];

// Руда
const ORES = [
  { id: 1, name: 'Камень', price: 10, chance: 35 },
  { id: 2, name: 'Уголь', price: 50, chance: 25 },
  { id: 3, name: 'Железо', price: 100, chance: 18 },
  { id: 4, name: 'Медь', price: 200, chance: 10 },
  { id: 5, name: 'Серебро', price: 500, chance: 7 },
  { id: 6, name: 'Золото', price: 1000, chance: 4 },
  { id: 7, name: 'Алмаз', price: 2500, chance: 1 }
];

// Питомцы
const PETS = [
  { id: 1, name: 'Кот', price: 10000, bonusType: 'luck', bonusValue: 5 },
  { id: 2, name: 'Собака', price: 15000, bonusType: 'strength', bonusValue: 5 },
  { id: 3, name: 'Попугай', price: 20000, bonusType: 'charisma', bonusValue: 5 },
  { id: 4, name: 'Хомяк', price: 8000, bonusType: 'intellect', bonusValue: 3 },
  { id: 5, name: 'Змея', price: 30000, bonusType: 'luck', bonusValue: 10 },
  { id: 6, name: 'Дракон', price: 100000, bonusType: 'all', bonusValue: 15 }
];

// Хобби
const HOBBIES = [
  { id: 1, name: 'Рисование', skill: 'creativity', bonusType: 'charisma' },
  { id: 2, name: 'Музыка', skill: 'music', bonusType: 'charisma' },
  { id: 3, name: 'Спорт', skill: 'fitness', bonusType: 'strength' },
  { id: 4, name: 'Чтение', skill: 'knowledge', bonusType: 'intellect' },
  { id: 5, name: 'Программирование', skill: 'coding', bonusType: 'intellect' },
  { id: 6, name: 'Азартные игры', skill: 'gambling', bonusType: 'luck' }
];

// Типы капчи
const CAPTCHA_TYPES = {
  MATH: 'math',
  LOGIC: 'logic',
  TEXT: 'text',
  SEQUENCE: 'sequence',
  WORD: 'word',
  BOT: 'bot'
};

// Капчи
const CAPTCHA_QUESTIONS = [
  // Математические
  { type: CAPTCHA_TYPES.MATH, question: 'Сколько будет 7 + 3?', answer: '10' },
  { type: CAPTCHA_TYPES.MATH, question: '15 * 2 = ?', answer: '30' },
  { type: CAPTCHA_TYPES.MATH, question: '100 / 5 = ?', answer: '20' },
  { type: CAPTCHA_TYPES.MATH, question: '9 * 9 = ?', answer: '81' },
  { type: CAPTCHA_TYPES.MATH, question: '25 + 17 = ?', answer: '42' },
  { type: CAPTCHA_TYPES.MATH, question: '144 / 12 = ?', answer: '12' },
  { type: CAPTCHA_TYPES.MATH, question: '8 * 7 = ?', answer: '56' },
  { type: CAPTCHA_TYPES.MATH, question: '99 - 45 = ?', answer: '54' },
  
  // Логические
  { type: CAPTCHA_TYPES.LOGIC, question: 'Сколько месяцев в году имеют 28 дней?', answer: 'все', alternatives: ['12', 'все 12'] },
  { type: CAPTCHA_TYPES.LOGIC, question: 'У Маши было 5 яблок. 3 она съела. Сколько осталось?', answer: '2' },
  { type: CAPTCHA_TYPES.LOGIC, question: 'Сколько будет 2+2*2?', answer: '6' },
  { type: CAPTCHA_TYPES.LOGIC, question: 'В комнате 4 угла. В каждом углу сидит кошка. Сколько кошек?', answer: '4' },
  
  // Текстовые
  { type: CAPTCHA_TYPES.TEXT, question: 'В каком городе находится Эйфелева башня?', answer: 'париж', alternatives: ['paris'] },
  { type: CAPTCHA_TYPES.TEXT, question: 'Какого цвета небо в ясный день?', answer: 'голубое', alternatives: ['синее', 'голубой', 'синий'] },
  { type: CAPTCHA_TYPES.TEXT, question: 'Сколько дней в неделе?', answer: '7', alternatives: ['семь'] },
  { type: CAPTCHA_TYPES.TEXT, question: 'Как называется столица России?', answer: 'москва', alternatives: ['moscow'] },
  { type: CAPTCHA_TYPES.TEXT, question: 'Какая планета третья от Солнца?', answer: 'земля', alternatives: ['earth'] },
  
  // Последовательности
  { type: CAPTCHA_TYPES.SEQUENCE, question: 'Продолжите: 1, 2, 3, 4, 5, ...', answer: '6' },
  { type: CAPTCHA_TYPES.SEQUENCE, question: 'Продолжите: 2, 4, 6, 8, 10, ...', answer: '12' },
  { type: CAPTCHA_TYPES.SEQUENCE, question: 'Продолжите: 1, 1, 2, 3, 5, ...', answer: '8' },
  
  // Словесные
  { type: CAPTCHA_TYPES.WORD, question: 'Напишите слово "капча" наоборот', answer: 'ачпак' },
  { type: CAPTCHA_TYPES.WORD, question: 'Сколько букв в слове "телеграм"?', answer: '8' },
  { type: CAPTCHA_TYPES.WORD, question: 'Сколько гласных в слове "компьютер"?', answer: '3' },
  
  // О боте
  { type: CAPTCHA_TYPES.BOT, question: 'Какую команду нужно ввести, чтобы посмотреть профиль?', answer: 'профиль' },
  { type: CAPTCHA_TYPES.BOT, question: 'Какая валюта основная в игре?', answer: 'доллар', alternatives: ['$', 'доллары'] },
  { type: CAPTCHA_TYPES.BOT, question: 'Как называется этот бот?', answer: 'flash', alternatives: ['флэш', 'флеш'] }
];

// Эмодзи для сообщений
const EMOJI = {
  profile: '👤',
  money: '💵',
  rubles: '₽',
  bitcoin: '₿',
  diamonds: '💎',
  cups: '🏆',
  coins: '🪙',
  energy: '🔥',
  experience: '⭐',
  level: '📈',
  clan: '🏛️',
  boss: '🐉',
  car: '🚗',
  business: '🏢',
  farm: '🌾',
  printer: '🖨️',
  mining: '⛏️',
  fishing: '🎣',
  hunting: '🏹',
  casino: '🎰',
  race: '🏁',
  duel: '⚔️',
  family: '💍',
  pet: '🐾',
  home: '🏠',
  phone: '📱',
  quest: '📜',
  event: '🎉',
  bonus: '🎁',
  referral: '🔗',
  settings: '⚙️',
  help: '❓',
  success: '✅',
  error: '❌',
  warning: '⚠️',
  info: 'ℹ️',
  time: '⏳',
  date: '📅',
  stats: '📊',
  top: '🏅',
  bank: '🏦',
  transfer: '💸',
  work: '💼',
  shop: '🏪',
  case: '📦',
  achievement: '🏆',
  newbie: '🆕',
  vip: '🟡',
  premium: '🟣',
  legend: '🔴',
  ultimate: '⚫'
};

module.exports = {
  PLATFORMS,
  CLAN_ROLES,
  CLAN_ROLE_NAMES,
  PRIVILEGE_TYPES,
  CARS,
  BUSINESSES,
  FARMS,
  PRINTERS,
  JOBS,
  TAGS,
  CASES,
  FISH,
  ORES,
  PETS,
  HOBBIES,
  CAPTCHA_TYPES,
  CAPTCHA_QUESTIONS,
  EMOJI
};
