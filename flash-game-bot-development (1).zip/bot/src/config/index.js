/**
 * FLASH BOT - Главный конфигурационный файл
 */

require('dotenv').config();

const config = {
  // Telegram настройки
  telegram: {
    token: process.env.TELEGRAM_TOKEN,
    adminId: parseInt(process.env.TELEGRAM_ADMIN_ID) || 7151740962,
    group: process.env.TELEGRAM_GROUP || '@gamebotflash_bot',
    polling: {
      interval: 300,
      autoStart: true,
      params: {
        timeout: 10
      }
    }
  },

  // VK настройки
  vk: {
    token: process.env.VK_TOKEN,
    adminId: parseInt(process.env.VK_ADMIN_ID) || 211314690,
    groupId: parseInt(process.env.VK_GROUP_ID) || 237124814,
    apiVersion: '5.154',
    pollingGroupId: parseInt(process.env.VK_GROUP_ID) || 237124814
  },

  // Общие настройки
  app: {
    env: process.env.NODE_ENV || 'development',
    logLevel: process.env.LOG_LEVEL || 'info',
    dataDir: process.env.DATA_DIR || './src/data',
    backupInterval: parseInt(process.env.BACKUP_INTERVAL) || 3600000, // 1 час
    maxBackups: 168 // 7 дней * 24 часа
  },

  // Стартовые значения для новых игроков
  starter: {
    money: 5000,
    rubles: 0,
    bitcoin: 0,
    diamonds: 0,
    cups: 0,
    coins: 0,
    energy: 100,
    maxEnergy: 100,
    experience: 0,
    level: 1,
    strength: 10,
    intellect: 10,
    charisma: 10,
    luck: 10
  },

  // Лимиты
  limits: {
    daily: {
      work: 12,
      fishing: 20,
      mining: 50,
      casino: 50,
      boss: 50,
      business: 48,
      farm: 96,
      printer: 144,
      robbery: 5,
      duel: 10,
      hunting: 10,
      cases: 20,
      puzzles: 10
    },
    maxBusinesses: 5,
    maxFarms: 3,
    maxPrinters: 2,
    maxInvestments: 1,
    maxReferrals: 100,
    maxClanMembers: 50,
    maxFamilyChildren: 5
  },

  // Кулдауны (в минутах)
  cooldowns: {
    work: 5,
    business: 10,
    mining: 3,
    boss: 2,
    casino: 0,
    bonus: 1440, // 24 часа
    hourlyBonus: 180, // 3 часа
    robbery: 30,
    fishing: 10,
    race: 5,
    clanAttack: 60,
    farm: 15,
    printer: 10,
    hunting: 20,
    duel: 15,
    arena: 30,
    tournament: 60,
    clanRepair: 120,
    puzzle: 60,
    walk: 15,
    date: 120,
    training: 30,
    study: 60,
    performance: 90,
    negotiation: 20,
    building: 45,
    petFeed: 360,
    phoneGame: 10,
    reading: 180,
    politics: 60
  },

  // Расход энергии
  energyCost: {
    race: 5,
    boss: 3,
    work: 10,
    mining: 5,
    fishing: 8,
    casino: 1,
    robbery: 15,
    business: 2,
    farm: 3,
    printer: 2,
    clanAttack: 10,
    case: 1,
    hunting: 6,
    duel: 8,
    arena: 12,
    tournament: 15,
    clanRepair: 5,
    puzzle: 2,
    walk: 3,
    date: 10,
    training: 5,
    study: 8,
    performance: 7,
    negotiation: 4,
    building: 6,
    petFeed: 1,
    phoneGame: 2,
    reading: 3,
    politics: 5
  },

  // Восстановление энергии
  energyRestore: {
    perMinute: 1,
    maxFree: 100
  },

  // Налоги
  taxes: {
    dailyPercent: 5,
    minDaily: 500,
    maxDaily: 50000,
    newbieDays: 7 // Без налогов первые 7 дней
  },

  // Банк
  bank: {
    interestRate: 0.5, // 0.5% в день
    maxDeposit: 10000000,
    creditRate: 10, // 10% в месяц
    maxCredit: 100000,
    creditDays: 30
  },

  // Инвестиции
  investments: {
    minAmount: 10000,
    maxAmount: 1000000,
    monthlyReturn: { min: 5, max: 15 },
    riskPercent: 20
  },

  // Опыт и уровни
  experience: {
    perLevel: 1000, // Базовый опыт на уровень
    multiplier: 1.5, // Множитель роста
    maxLevel: 100
  },

  // Привилегии
  privileges: {
    vip: {
      name: 'VIP',
      price: 10000, // рублей
      incomeMultiplier: 2,
      expMultiplier: 1.5,
      bonusEnergy: 20,
      color: '🟡'
    },
    premium: {
      name: 'PREMIUM',
      price: 25000,
      incomeMultiplier: 3,
      expMultiplier: 2,
      bonusEnergy: 30,
      color: '🟣'
    },
    legend: {
      name: 'LEGEND',
      price: 50000,
      incomeMultiplier: 5,
      expMultiplier: 3,
      bonusEnergy: 50,
      color: '🔴'
    },
    ultimate: {
      name: 'ULTIMATE',
      price: 100000,
      incomeMultiplier: 10,
      expMultiplier: 5,
      bonusEnergy: 100,
      color: '⚫'
    }
  },

  // Казино множители
  casinoMultipliers: [
    { value: 0.25, chance: 35 },
    { value: 0.5, chance: 25 },
    { value: 1, chance: 20 },
    { value: 2, chance: 12 },
    { value: 3, chance: 5 },
    { value: 5, chance: 2 },
    { value: 10, chance: 1 }
  ],

  // Анти-фарм система
  antiFarm: {
    dimming: {
      first5: 1.0,   // 100%
      next5: 0.75,   // 75%
      next5_2: 0.5,  // 50%
      rest: 0.25     // 25%
    },
    fatigue: {
      low20: 0.5,    // -50% при энергии < 20%
      low10: 0.1,    // -90% при энергии < 10%
      zero: 0        // Невозможно при 0%
    },
    overLimit: {
      x1: 0.5,       // -50% при превышении лимита
      x2: 0.1,       // -90% при двойном превышении
      x3: 0          // Блокировка при тройном
    }
  },

  // Босс
  boss: {
    spawnInterval: 21600000, // 6 часов
    baseHp: 5000,
    baseReward: 50000,
    levelMultiplier: 1.2
  },

  // Клан
  clan: {
    createCost: 100000,
    minNameLength: 3,
    maxNameLength: 20,
    healthRestoreInterval: 43200000 // 12 часов
  },

  // Рефералы
  referral: {
    bonus: 5000,
    percent: 10 // 10% от дохода реферала
  },

  // Ежедневный бонус (стрик)
  dailyBonus: {
    day1: 1000,
    day2: 1500,
    day3: 2000,
    day4: 2500,
    day5: 3000,
    day6: 4000,
    day7: 5000,
    day7Diamond: 1
  },

  // Часовой бонус
  hourlyBonus: {
    money: 500,
    exp: 10
  },

  // Капча
  captcha: {
    timeLimit: 60, // секунд
    maxAttempts: 3,
    blockTime: 300, // 5 минут
    verifyBonus: 100
  }
};

module.exports = config;
