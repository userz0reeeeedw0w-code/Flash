/**
 * FLASH BOT - Клавиатуры
 */

const { EMOJI } = require('./constants');

// Статичная клавиатура (основная)
const mainKeyboard = {
  telegram: {
    keyboard: [
      [`${EMOJI.profile} Профиль`, `${EMOJI.money} Баланс`, `${EMOJI.shop} Магазин`],
      [`${EMOJI.boss} Босс`, `${EMOJI.race} Гонка`, `${EMOJI.work} Работа`],
      [`${EMOJI.clan} Клан`, `${EMOJI.casino} Казино`, `${EMOJI.bonus} Бонус`],
      [`${EMOJI.top} Топ`, `${EMOJI.help} Помощь`, `${EMOJI.newbie} Путь новичка`]
    ],
    resize_keyboard: true,
    one_time_keyboard: false
  },
  vk: [
    [
      { action: { type: 'text', label: `${EMOJI.profile} Профиль` }, color: 'primary' },
      { action: { type: 'text', label: `${EMOJI.money} Баланс` }, color: 'primary' },
      { action: { type: 'text', label: `${EMOJI.shop} Магазин` }, color: 'primary' }
    ],
    [
      { action: { type: 'text', label: `${EMOJI.boss} Босс` }, color: 'secondary' },
      { action: { type: 'text', label: `${EMOJI.race} Гонка` }, color: 'secondary' },
      { action: { type: 'text', label: `${EMOJI.work} Работа` }, color: 'secondary' }
    ],
    [
      { action: { type: 'text', label: `${EMOJI.clan} Клан` }, color: 'secondary' },
      { action: { type: 'text', label: `${EMOJI.casino} Казино` }, color: 'secondary' },
      { action: { type: 'text', label: `${EMOJI.bonus} Бонус` }, color: 'positive' }
    ],
    [
      { action: { type: 'text', label: `${EMOJI.top} Топ` }, color: 'secondary' },
      { action: { type: 'text', label: `${EMOJI.help} Помощь` }, color: 'secondary' },
      { action: { type: 'text', label: `${EMOJI.newbie} Путь новичка` }, color: 'secondary' }
    ]
  ]
};

// Убрать клавиатуру
const removeKeyboard = {
  telegram: { remove_keyboard: true },
  vk: null
};

// Inline кнопки профиля
const profileButtons = {
  telegram: {
    inline_keyboard: [
      [
        { text: '📊 Статистика', callback_data: 'profile_stats' },
        { text: '🏆 Достижения', callback_data: 'profile_achievements' }
      ],
      [
        { text: '🎁 Рефералы', callback_data: 'profile_referrals' },
        { text: '🔙 Назад', callback_data: 'back_main' }
      ]
    ]
  },
  vk: [
    [
      { action: { type: 'callback', label: '📊 Статистика', payload: JSON.stringify({ cmd: 'profile_stats' }) } },
      { action: { type: 'callback', label: '🏆 Достижения', payload: JSON.stringify({ cmd: 'profile_achievements' }) } }
    ],
    [
      { action: { type: 'callback', label: '🎁 Рефералы', payload: JSON.stringify({ cmd: 'profile_referrals' }) } },
      { action: { type: 'callback', label: '🔙 Назад', payload: JSON.stringify({ cmd: 'back_main' }) } }
    ]
  ]
};

// Inline кнопки босса
const bossButtons = {
  telegram: {
    inline_keyboard: [
      [{ text: '🗡️ АТАКОВАТЬ', callback_data: 'boss_attack' }]
    ]
  },
  vk: [
    [{ action: { type: 'callback', label: '🗡️ АТАКОВАТЬ', payload: JSON.stringify({ cmd: 'boss_attack' }) }, color: 'negative' }]
  ]
};

// Inline кнопки атаки босса (выбор оружия)
const bossAttackButtons = {
  telegram: {
    inline_keyboard: [
      [
        { text: '🗡️ МЕЧ', callback_data: 'boss_weapon_sword' },
        { text: '🏹 ЛУК', callback_data: 'boss_weapon_bow' },
        { text: '🛡️ ЩИТ', callback_data: 'boss_weapon_shield' }
      ]
    ]
  },
  vk: [
    [
      { action: { type: 'callback', label: '🗡️ МЕЧ', payload: JSON.stringify({ cmd: 'boss_weapon_sword' }) }, color: 'positive' },
      { action: { type: 'callback', label: '🏹 ЛУК', payload: JSON.stringify({ cmd: 'boss_weapon_bow' }) }, color: 'secondary' },
      { action: { type: 'callback', label: '🛡️ ЩИТ', payload: JSON.stringify({ cmd: 'boss_weapon_shield' }) }, color: 'secondary' }
    ]
  ]
};

// Inline кнопки клана
const clanButtons = {
  telegram: {
    inline_keyboard: [
      [
        { text: '👥 Состав', callback_data: 'clan_members' },
        { text: '💰 Казна', callback_data: 'clan_treasury' }
      ],
      [
        { text: '⚔️ Атака', callback_data: 'clan_attack' },
        { text: '🔧 Починка', callback_data: 'clan_repair' }
      ],
      [
        { text: '🏪 Магазин', callback_data: 'clan_shop' },
        { text: '🔙 Назад', callback_data: 'back_main' }
      ]
    ]
  },
  vk: [
    [
      { action: { type: 'callback', label: '👥 Состав', payload: JSON.stringify({ cmd: 'clan_members' }) } },
      { action: { type: 'callback', label: '💰 Казна', payload: JSON.stringify({ cmd: 'clan_treasury' }) } }
    ],
    [
      { action: { type: 'callback', label: '⚔️ Атака', payload: JSON.stringify({ cmd: 'clan_attack' }) }, color: 'negative' },
      { action: { type: 'callback', label: '🔧 Починка', payload: JSON.stringify({ cmd: 'clan_repair' }) } }
    ],
    [
      { action: { type: 'callback', label: '🏪 Магазин', payload: JSON.stringify({ cmd: 'clan_shop' }) } },
      { action: { type: 'callback', label: '🔙 Назад', payload: JSON.stringify({ cmd: 'back_main' }) } }
    ]
  ]
};

// Inline кнопки казино
const casinoButtons = {
  telegram: {
    inline_keyboard: [
      [
        { text: '🎰 Слоты', callback_data: 'casino_slots' },
        { text: '🎲 Кости', callback_data: 'casino_dice' }
      ],
      [
        { text: '🃏 Карты', callback_data: 'casino_cards' },
        { text: '♠️ Блэкджек', callback_data: 'casino_blackjack' }
      ],
      [
        { text: '📊 Статистика', callback_data: 'casino_stats' },
        { text: '🔙 Назад', callback_data: 'back_main' }
      ]
    ]
  },
  vk: [
    [
      { action: { type: 'callback', label: '🎰 Слоты', payload: JSON.stringify({ cmd: 'casino_slots' }) } },
      { action: { type: 'callback', label: '🎲 Кости', payload: JSON.stringify({ cmd: 'casino_dice' }) } }
    ],
    [
      { action: { type: 'callback', label: '🃏 Карты', payload: JSON.stringify({ cmd: 'casino_cards' }) } },
      { action: { type: 'callback', label: '♠️ Блэкджек', payload: JSON.stringify({ cmd: 'casino_blackjack' }) } }
    ],
    [
      { action: { type: 'callback', label: '📊 Статистика', payload: JSON.stringify({ cmd: 'casino_stats' }) } },
      { action: { type: 'callback', label: '🔙 Назад', payload: JSON.stringify({ cmd: 'back_main' }) } }
    ]
  ]
};

// Inline кнопки магазина
const shopButtons = {
  telegram: {
    inline_keyboard: [
      [
        { text: '🚗 Машины', callback_data: 'shop_cars' },
        { text: '🏢 Бизнесы', callback_data: 'shop_businesses' }
      ],
      [
        { text: '🌾 Фермы', callback_data: 'shop_farms' },
        { text: '🖨️ Принтеры', callback_data: 'shop_printers' }
      ],
      [
        { text: '📦 Кейсы', callback_data: 'shop_cases' },
        { text: '🐾 Питомцы', callback_data: 'shop_pets' }
      ],
      [{ text: '🔙 Назад', callback_data: 'back_main' }]
    ]
  },
  vk: [
    [
      { action: { type: 'callback', label: '🚗 Машины', payload: JSON.stringify({ cmd: 'shop_cars' }) } },
      { action: { type: 'callback', label: '🏢 Бизнесы', payload: JSON.stringify({ cmd: 'shop_businesses' }) } }
    ],
    [
      { action: { type: 'callback', label: '🌾 Фермы', payload: JSON.stringify({ cmd: 'shop_farms' }) } },
      { action: { type: 'callback', label: '🖨️ Принтеры', payload: JSON.stringify({ cmd: 'shop_printers' }) } }
    ],
    [
      { action: { type: 'callback', label: '📦 Кейсы', payload: JSON.stringify({ cmd: 'shop_cases' }) } },
      { action: { type: 'callback', label: '🐾 Питомцы', payload: JSON.stringify({ cmd: 'shop_pets' }) } }
    ],
    [{ action: { type: 'callback', label: '🔙 Назад', payload: JSON.stringify({ cmd: 'back_main' }) } }]
  ]
};

// Inline кнопки банка
const bankButtons = {
  telegram: {
    inline_keyboard: [
      [
        { text: '📥 Положить', callback_data: 'bank_deposit' },
        { text: '📤 Снять', callback_data: 'bank_withdraw' }
      ],
      [
        { text: '💳 Кредит', callback_data: 'bank_credit' },
        { text: '📊 Инвестиции', callback_data: 'bank_invest' }
      ],
      [{ text: '🔙 Назад', callback_data: 'back_main' }]
    ]
  },
  vk: [
    [
      { action: { type: 'callback', label: '📥 Положить', payload: JSON.stringify({ cmd: 'bank_deposit' }) } },
      { action: { type: 'callback', label: '📤 Снять', payload: JSON.stringify({ cmd: 'bank_withdraw' }) } }
    ],
    [
      { action: { type: 'callback', label: '💳 Кредит', payload: JSON.stringify({ cmd: 'bank_credit' }) } },
      { action: { type: 'callback', label: '📊 Инвестиции', payload: JSON.stringify({ cmd: 'bank_invest' }) } }
    ],
    [{ action: { type: 'callback', label: '🔙 Назад', payload: JSON.stringify({ cmd: 'back_main' }) } }]
  ]
};

// Inline кнопки квестов
const questButtons = {
  telegram: {
    inline_keyboard: [
      [
        { text: '📋 Ежедневные', callback_data: 'quest_daily' },
        { text: '📅 Недельные', callback_data: 'quest_weekly' }
      ],
      [
        { text: '📍 Путь новичка', callback_data: 'quest_newbie' },
        { text: '🏆 Награды', callback_data: 'quest_rewards' }
      ],
      [{ text: '🔙 Назад', callback_data: 'back_main' }]
    ]
  },
  vk: [
    [
      { action: { type: 'callback', label: '📋 Ежедневные', payload: JSON.stringify({ cmd: 'quest_daily' }) } },
      { action: { type: 'callback', label: '📅 Недельные', payload: JSON.stringify({ cmd: 'quest_weekly' }) } }
    ],
    [
      { action: { type: 'callback', label: '📍 Путь новичка', payload: JSON.stringify({ cmd: 'quest_newbie' }) } },
      { action: { type: 'callback', label: '🏆 Награды', payload: JSON.stringify({ cmd: 'quest_rewards' }) } }
    ],
    [{ action: { type: 'callback', label: '🔙 Назад', payload: JSON.stringify({ cmd: 'back_main' }) } }]
  ]
};

// Inline кнопки подтверждения
const confirmButtons = {
  telegram: {
    inline_keyboard: [
      [
        { text: '✅ Да', callback_data: 'confirm_yes' },
        { text: '❌ Нет', callback_data: 'confirm_no' }
      ]
    ]
  },
  vk: [
    [
      { action: { type: 'callback', label: '✅ Да', payload: JSON.stringify({ cmd: 'confirm_yes' }) }, color: 'positive' },
      { action: { type: 'callback', label: '❌ Нет', payload: JSON.stringify({ cmd: 'confirm_no' }) }, color: 'negative' }
    ]
  ]
};

// Inline кнопки пагинации
function paginationButtons(currentPage, totalPages, prefix) {
  const buttons = [];
  
  if (currentPage > 1) {
    buttons.push({ text: '◀️ Назад', callback_data: `${prefix}_page_${currentPage - 1}` });
  }
  
  buttons.push({ text: `${currentPage}/${totalPages}`, callback_data: 'noop' });
  
  if (currentPage < totalPages) {
    buttons.push({ text: 'Вперёд ▶️', callback_data: `${prefix}_page_${currentPage + 1}` });
  }
  
  return {
    telegram: { inline_keyboard: [buttons] },
    vk: [buttons.map(btn => ({
      action: { type: 'callback', label: btn.text, payload: JSON.stringify({ cmd: btn.callback_data }) }
    }))]
  };
}

module.exports = {
  mainKeyboard,
  removeKeyboard,
  profileButtons,
  bossButtons,
  bossAttackButtons,
  clanButtons,
  casinoButtons,
  shopButtons,
  bankButtons,
  questButtons,
  confirmButtons,
  paginationButtons
};
