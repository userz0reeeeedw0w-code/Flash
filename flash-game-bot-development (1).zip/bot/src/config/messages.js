/**
 * FLASH BOT - Шаблоны сообщений
 */

const { EMOJI } = require('./constants');

// Разделитель
const SEPARATOR = '━━━━━━━━━━━━━━━━━━━━';

// Шаблоны сообщений
const messages = {
  // Приветствие при регистрации
  welcome: (identifier, uid) => `
${identifier} ${EMOJI.success} ДОБРО ПОЖАЛОВАТЬ В FLASH!
${SEPARATOR}
🆔 Ваш UID: #${uid}
💰 Стартовый капитал: 5,000$
🔥 Энергия: 100/100

📜 Используйте команду "помощь" для списка команд.
📍 Команда "путь новичка" поможет освоиться.

Удачной игры! ⚡
`,

  // Профиль игрока
  profile: (identifier, user, platform) => {
    const privilegeEmoji = user.privilege !== 'none' ? EMOJI[user.privilege] || '' : '';
    const privilegeName = user.privilege !== 'none' ? user.privilege.toUpperCase() : '';
    
    let text = `
${identifier} ${EMOJI.profile} ПРОФИЛЬ ИГРОКА
${SEPARATOR}
🆔 UID: #${user.uid} | 📱 Платформа: ${platform === 'vk' ? 'VK' : 'Telegram'}
👤 Ник: ${user.nickname} | 🏷️ Тег: [${user.tag}]
📅 Регистрация: ${formatDate(user.registeredAt)}
⏳ В игре: ${formatDuration(user.playTime)}
${SEPARATOR}
📊 СТАТИСТИКА
${SEPARATOR}
📈 Уровень: ${user.level} (${EMOJI.experience} ${formatNumber(user.experience)}/${formatNumber(getExpForLevel(user.level + 1))})
🏆 Рейтинг: #${user.rating || '—'}
💪 Сила: ${user.strength} | 🧠 Интеллект: ${user.intellect}
🎭 Харизма: ${user.charisma} | 🍀 Удача: ${user.luck}
${EMOJI.energy} Энергия: ${user.energy}/${user.maxEnergy}
${SEPARATOR}
${EMOJI.money} БАЛАНС
${SEPARATOR}
💵 Доллар: ${formatNumber(user.money)}$
${EMOJI.rubles} Рубли: ${formatNumber(user.rubles)}₽
${EMOJI.bitcoin} Биткоин: ${user.bitcoin.toFixed(4)}₿
${EMOJI.diamonds} Алмазы: ${user.diamonds}💎
${EMOJI.cups} Кубки: ${user.cups}🏆
${EMOJI.coins} Монеты: ${user.coins}🪙`;

    // Семья
    if (user.familyId) {
      text += `
${SEPARATOR}
${EMOJI.family} СЕМЬЯ
${SEPARATOR}
💍 В браке с: ${user.spouseIdentifier || 'Неизвестно'} (UID: #${user.spouseUid || '—'})`;
    }

    // Машины
    if (user.cars && user.cars.length > 0) {
      text += `
${SEPARATOR}
${EMOJI.car} МАШИНЫ (${user.cars.length})
${SEPARATOR}`;
      user.cars.slice(0, 3).forEach(car => {
        const active = car.id === user.activeCar ? '✅ ' : '• ';
        text += `\n${active}${car.name} - Ур.${car.tuning || 0} (скорость: ${car.speed})`;
      });
      if (user.cars.length > 3) {
        text += `\n...и ещё ${user.cars.length - 3}`;
      }
    }

    // Бизнесы
    if (user.businesses && user.businesses.length > 0) {
      text += `
${SEPARATOR}
${EMOJI.business} БИЗНЕСЫ (${user.businesses.length})
${SEPARATOR}`;
      user.businesses.forEach((biz, i) => {
        text += `\n• #${i + 1} ${biz.name} - Ур.${biz.level} (${formatNumber(biz.income)}$/час)`;
      });
    }

    // Клан
    if (user.clanId) {
      text += `
${SEPARATOR}
${EMOJI.clan} КЛАН: ${user.clanName || 'Неизвестно'} (ID: #${user.clanId}) | ${user.clanRole || 'Член'}`;
    }

    // Привилегия
    if (user.privilege !== 'none') {
      text += `
${SEPARATOR}
👑 ПРИВИЛЕГИИ: ${privilegeEmoji} ${privilegeName} (до ${formatDate(user.privilegeExpires)})`;
    }

    // Достижения
    text += `
${SEPARATOR}
${EMOJI.achievement} ДОСТИЖЕНИЯ (${user.achievementsCount || 0}/50)
${SEPARATOR}
${EMOJI.referral} РЕФЕРАЛЬНАЯ ССЫЛКА: ${user.referralCode} | ${user.referralsCount || 0} игроков | ${formatNumber(user.referralEarnings || 0)}$
${SEPARATOR}
📅 Последняя активность: ${formatDate(user.lastActivity)}
`;

    return text;
  },

  // Баланс
  balance: (identifier, user) => `
${identifier} ${EMOJI.money} ВАШ БАЛАНС
${SEPARATOR}
💵 Наличные: ${formatNumber(user.money)}$
${EMOJI.bank} В банке: ${formatNumber(user.bankBalance || 0)}$
${SEPARATOR}
${EMOJI.rubles} Рубли: ${formatNumber(user.rubles)}₽
${EMOJI.bitcoin} Биткоин: ${user.bitcoin.toFixed(4)}₿
${EMOJI.diamonds} Алмазы: ${user.diamonds}💎
${EMOJI.cups} Кубки: ${user.cups}🏆
${EMOJI.coins} Монеты: ${user.coins}🪙
${SEPARATOR}
💰 Всего: ${formatNumber(calculateNetWorth(user))}$
`,

  // Перевод
  transfer: (identifier, fromUser, toUser, amount) => `
${identifier} ${EMOJI.transfer} ПЕРЕВОД
${SEPARATOR}
Отправитель: ${fromUser.identifier} (UID: #${fromUser.uid})
Получатель: ${toUser.identifier} (UID: #${toUser.uid})
💰 Сумма: ${formatNumber(amount)}$
${EMOJI.success} Перевод выполнен успешно!
`,

  // Босс
  boss: (identifier, boss) => `
${identifier} ${EMOJI.boss} БОСС: ${boss.name}
${SEPARATOR}
❤️ HP: ${formatNumber(boss.currentHp)}/${formatNumber(boss.maxHp)} (${Math.round(boss.currentHp / boss.maxHp * 100)}%)
⚔️ Уровень: ${boss.level}
💰 Награда: ${formatNumber(boss.reward)}$
${SEPARATOR}
⏳ Появился: ${formatDuration(Date.now() - boss.spawnedAt)} назад
👥 Участников: ${boss.participants?.length || 0}
`,

  // Атака босса
  bossAttack: (identifier, damage, weapon, isCorrect) => `
${identifier} ${EMOJI.boss} АТАКА БОССА
${SEPARATOR}
${isCorrect ? '✅ Правильный выбор!' : '❌ Неправильный выбор!'}
⚔️ Оружие: ${weapon}
💥 Урон: ${formatNumber(damage)}
`,

  // Клан
  clan: (identifier, clan) => `
${identifier} ${EMOJI.clan} КЛАН: ${clan.name}
${SEPARATOR}
🆔 ID: #${clan.uid}
👑 Лидер: ${clan.leaderIdentifier} (UID: #${clan.leaderUid})
👥 Участников: ${clan.members?.length || 0}/${50}
${SEPARATOR}
💪 Сила: ${formatNumber(clan.power)}
❤️ Здоровье: ${formatNumber(clan.health)}/${formatNumber(clan.maxHealth)}
💰 Казна: ${formatNumber(clan.treasury)}$
⭐ Опыт: ${formatNumber(clan.experience)}
${SEPARATOR}
🏆 Побед: ${clan.wins || 0} | 💀 Поражений: ${clan.losses || 0}
📅 Создан: ${formatDate(clan.createdAt)}
`,

  // Казино
  casino: (identifier, bet, multiplier, win) => `
${identifier} ${EMOJI.casino} КАЗИНО
${SEPARATOR}
🎰 Ставка: ${formatNumber(bet)}$
🎲 Множитель: x${multiplier}
${win >= bet ? EMOJI.success : EMOJI.error} Результат: ${win >= bet ? '+' : ''}${formatNumber(win - bet)}$
💰 Итого: ${formatNumber(win)}$
`,

  // Работа
  work: (identifier, job, income, exp) => `
${identifier} ${EMOJI.work} РАБОТА
${SEPARATOR}
💼 Должность: ${job.name}
💰 Заработано: ${formatNumber(income)}$
⭐ Опыт: +${exp}
`,

  // Гонка
  race: (identifier, car, opponent, result, prize) => `
${identifier} ${EMOJI.race} ГОНКА
${SEPARATOR}
🚗 Ваша машина: ${car.name} (скорость: ${car.speed})
🚙 Соперник: ${opponent.car.name} (скорость: ${opponent.car.speed})
${SEPARATOR}
${result === 'win' ? `${EMOJI.success} Победа! +${formatNumber(prize)}$` : 
  result === 'lose' ? `${EMOJI.error} Поражение! -${formatNumber(prize)}$` :
  `⚡ Ничья! Ставки возвращены`}
`,

  // Бонус
  bonus: (identifier, amount, streak, exp) => `
${identifier} ${EMOJI.bonus} ЕЖЕДНЕВНЫЙ БОНУС
${SEPARATOR}
🔥 Стрик: ${streak} дней
💰 Награда: ${formatNumber(amount)}$
⭐ Опыт: +${exp}
${streak === 7 ? '\n💎 Бонус за 7 дней: +1 алмаз!' : ''}
`,

  // Капча
  captcha: (identifier, question) => `
${identifier} ⚠️ ПРОВЕРКА БЕЗОПАСНОСТИ
${SEPARATOR}
Для продолжения ответьте на вопрос:

❓ ${question}

⏱️ Время на ответ: 60 секунд
💡 Введите ответ текстом
`,

  // Ошибки
  errors: {
    notRegistered: (identifier) => `${identifier} ${EMOJI.error} Вы не зарегистрированы!\nВведите "старт" для регистрации.`,
    notEnoughMoney: (identifier) => `${identifier} ${EMOJI.error} Недостаточно средств!`,
    notEnoughEnergy: (identifier) => `${identifier} ${EMOJI.error} Недостаточно энергии!`,
    cooldown: (identifier, remaining) => `${identifier} ${EMOJI.time} Подождите ${formatDuration(remaining)}`,
    playerNotFound: (identifier) => `${identifier} ${EMOJI.error} Игрок не найден!`,
    invalidAmount: (identifier) => `${identifier} ${EMOJI.error} Неверная сумма!`,
    limitReached: (identifier, action) => `${identifier} ${EMOJI.error} Достигнут дневной лимит для "${action}"!`,
    banned: (identifier, reason) => `${identifier} ${EMOJI.error} Вы заблокированы!\nПричина: ${reason}`,
    adminOnly: (identifier) => `${identifier} ${EMOJI.error} Команда доступна только администраторам!`,
    clanRequired: (identifier) => `${identifier} ${EMOJI.error} Вы не состоите в клане!`,
    alreadyInClan: (identifier) => `${identifier} ${EMOJI.error} Вы уже состоите в клане!`,
    noBoss: (identifier) => `${identifier} ${EMOJI.error} Босс сейчас не активен!`,
    noCar: (identifier) => `${identifier} ${EMOJI.error} У вас нет машины для гонок!`,
    selfTransfer: (identifier) => `${identifier} ${EMOJI.error} Нельзя переводить самому себе!`,
    minTransfer: (identifier, min) => `${identifier} ${EMOJI.error} Минимальная сумма перевода: ${formatNumber(min)}$`,
    captchaRequired: (identifier) => `${identifier} ${EMOJI.warning} Требуется пройти проверку!`,
    captchaWrong: (identifier, attempts) => `${identifier} ${EMOJI.error} Неверный ответ! Осталось попыток: ${attempts}`,
    captchaBlocked: (identifier, time) => `${identifier} ${EMOJI.error} Слишком много ошибок! Подождите ${formatDuration(time)}`
  },

  // Помощь
  help: (identifier) => `
${identifier} ${EMOJI.help} ПОМОЩЬ
${SEPARATOR}
📋 ОСНОВНЫЕ КОМАНДЫ:
• профиль — ваш профиль
• баланс — ваш баланс
• работать — заработать деньги
• бизнес — управление бизнесами
• магазин — магазин покупок
${SEPARATOR}
🎮 ИГРЫ:
• казино [сумма] — игра в казино
• гонка — гоночные соревнования
• рыбалка — ловля рыбы
• копать — добыча руды
${SEPARATOR}
👥 СОЦИАЛЬНЫЕ:
• клан — информация о клане
• босс — атака на босса
• перевод [игрок] [сумма] — перевод денег
${SEPARATOR}
🎁 БОНУСЫ:
• бонус — ежедневный бонус
• квесты — список заданий
• промокод [код] — активация кода
${SEPARATOR}
📍 Команда "путь новичка" для новичков!
📜 Все команды без / и !
`,

  // Путь новичка
  newbiePath: (identifier, progress) => `
${identifier} ${EMOJI.newbie} ПУТЬ НОВИЧКА
${SEPARATOR}
Выполняйте задания и получайте награды!

${progress.map((task, i) => 
  `${task.completed ? '✅' : '⬜'} ${i + 1}. ${task.name}${task.completed ? ` — ${EMOJI.success}` : ''}`
).join('\n')}
${SEPARATOR}
📊 Прогресс: ${progress.filter(t => t.completed).length}/${progress.length}
💰 Награда за полное прохождение: 50,000$
`
};

// Вспомогательные функции
function formatNumber(num) {
  if (num === null || num === undefined) return '0';
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

function formatDate(timestamp) {
  if (!timestamp) return 'Неизвестно';
  const date = new Date(timestamp);
  return date.toLocaleDateString('ru-RU', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

function formatDuration(ms) {
  if (!ms || ms < 0) return '0 сек';
  
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (days > 0) return `${days} дн. ${hours % 24} ч.`;
  if (hours > 0) return `${hours} ч. ${minutes % 60} мин.`;
  if (minutes > 0) return `${minutes} мин. ${seconds % 60} сек.`;
  return `${seconds} сек.`;
}

function getExpForLevel(level) {
  return Math.floor(1000 * Math.pow(1.5, level - 1));
}

function calculateNetWorth(user) {
  let total = user.money || 0;
  total += user.bankBalance || 0;
  total += (user.bitcoin || 0) * 100000; // Примерный курс
  return total;
}

module.exports = {
  messages,
  formatNumber,
  formatDate,
  formatDuration,
  getExpForLevel,
  calculateNetWorth,
  SEPARATOR
};
