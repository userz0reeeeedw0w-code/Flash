/**
 * FLASH BOT - Cache Service (In-Memory)
 */

class CacheService {
  constructor() {
    this.cache = new Map();
    this.ttl = new Map();
  }

  // Установить значение с TTL (в миллисекундах)
  set(key, value, ttlMs = 0) {
    this.cache.set(key, value);
    
    if (ttlMs > 0) {
      // Удаляем предыдущий таймер если есть
      if (this.ttl.has(key)) {
        clearTimeout(this.ttl.get(key));
      }
      
      // Устанавливаем новый таймер
      const timer = setTimeout(() => {
        this.delete(key);
      }, ttlMs);
      
      this.ttl.set(key, timer);
    }
  }

  // Получить значение
  get(key) {
    return this.cache.get(key);
  }

  // Проверить наличие
  has(key) {
    return this.cache.has(key);
  }

  // Удалить значение
  delete(key) {
    if (this.ttl.has(key)) {
      clearTimeout(this.ttl.get(key));
      this.ttl.delete(key);
    }
    return this.cache.delete(key);
  }

  // Очистить весь кэш
  clear() {
    for (const timer of this.ttl.values()) {
      clearTimeout(timer);
    }
    this.ttl.clear();
    this.cache.clear();
  }

  // Получить размер кэша
  size() {
    return this.cache.size;
  }

  // Получить все ключи
  keys() {
    return Array.from(this.cache.keys());
  }

  // Получить или установить
  getOrSet(key, factory, ttlMs = 0) {
    if (this.has(key)) {
      return this.get(key);
    }
    const value = typeof factory === 'function' ? factory() : factory;
    this.set(key, value, ttlMs);
    return value;
  }

  // ===== Специфичные методы для бота =====

  // Кэш онлайн пользователей
  setOnline(platform, platformId) {
    const key = `online_${platform}_${platformId}`;
    this.set(key, Date.now(), 5 * 60 * 1000); // 5 минут
  }

  isOnline(platform, platformId) {
    const key = `online_${platform}_${platformId}`;
    return this.has(key);
  }

  getOnlineUsers() {
    const onlineKeys = this.keys().filter(k => k.startsWith('online_'));
    return onlineKeys.map(k => {
      const [, platform, platformId] = k.split('_');
      return { platform, platformId };
    });
  }

  // Кэш кулдаунов
  setCooldown(uid, action, durationMs) {
    const key = `cooldown_${uid}_${action}`;
    this.set(key, Date.now() + durationMs, durationMs);
  }

  getCooldown(uid, action) {
    const key = `cooldown_${uid}_${action}`;
    const expires = this.get(key);
    if (!expires) return 0;
    const remaining = expires - Date.now();
    return remaining > 0 ? remaining : 0;
  }

  hasCooldown(uid, action) {
    return this.getCooldown(uid, action) > 0;
  }

  // Кэш капчи
  setCaptcha(uid, question, answer) {
    const key = `captcha_${uid}`;
    this.set(key, { question, answer, createdAt: Date.now() }, 60 * 1000); // 60 секунд
  }

  getCaptcha(uid) {
    const key = `captcha_${uid}`;
    return this.get(key);
  }

  clearCaptcha(uid) {
    const key = `captcha_${uid}`;
    this.delete(key);
  }

  // Кэш ожидающих подтверждений
  setPendingAction(uid, action, data) {
    const key = `pending_${uid}`;
    this.set(key, { action, data, createdAt: Date.now() }, 60 * 1000); // 60 секунд
  }

  getPendingAction(uid) {
    const key = `pending_${uid}`;
    return this.get(key);
  }

  clearPendingAction(uid) {
    const key = `pending_${uid}`;
    this.delete(key);
  }

  // Кэш топов (обновляется каждые 5 минут)
  setTop(type, data) {
    const key = `top_${type}`;
    this.set(key, data, 5 * 60 * 1000); // 5 минут
  }

  getTop(type) {
    const key = `top_${type}`;
    return this.get(key);
  }
}

module.exports = new CacheService();
