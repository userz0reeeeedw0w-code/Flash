/**
 * FLASH BOT - Cache Index
 */

const CacheService = require('./cache.service');

module.exports = CacheService;
