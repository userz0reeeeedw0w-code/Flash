/**
 * FLASH BOT - Backup Service
 */

const fs = require('fs');
const path = require('path');
const config = require('../../config');

class BackupService {
  constructor() {
    this.dataDir = config.app.dataDir;
    this.backupDir = path.join(this.dataDir, 'backups');
    this.maxBackups = config.app.maxBackups;
  }

  // Создать бэкап
  async createBackup() {
    try {
      // Убеждаемся, что директория существует
      if (!fs.existsSync(this.backupDir)) {
        fs.mkdirSync(this.backupDir, { recursive: true });
      }

      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backupName = `backup_${timestamp}`;
      const backupPath = path.join(this.backupDir, backupName);

      // Создаём директорию для бэкапа
      fs.mkdirSync(backupPath);

      // Копируем все JSON файлы
      const files = fs.readdirSync(this.dataDir).filter(f => f.endsWith('.json'));
      
      for (const file of files) {
        const src = path.join(this.dataDir, file);
        const dest = path.join(backupPath, file);
        fs.copyFileSync(src, dest);
      }

      console.log(`[Backup] Created backup: ${backupName}`);

      // Удаляем старые бэкапы
      await this.cleanOldBackups();

      return backupName;
    } catch (error) {
      console.error('[Backup] Error creating backup:', error);
      throw error;
    }
  }

  // Восстановить из бэкапа
  async restoreBackup(backupName) {
    try {
      const backupPath = path.join(this.backupDir, backupName);

      if (!fs.existsSync(backupPath)) {
        throw new Error(`Backup not found: ${backupName}`);
      }

      // Копируем файлы из бэкапа
      const files = fs.readdirSync(backupPath).filter(f => f.endsWith('.json'));
      
      for (const file of files) {
        const src = path.join(backupPath, file);
        const dest = path.join(this.dataDir, file);
        fs.copyFileSync(src, dest);
      }

      console.log(`[Backup] Restored backup: ${backupName}`);
      return true;
    } catch (error) {
      console.error('[Backup] Error restoring backup:', error);
      throw error;
    }
  }

  // Получить список бэкапов
  getBackupList() {
    try {
      if (!fs.existsSync(this.backupDir)) {
        return [];
      }

      const backups = fs.readdirSync(this.backupDir)
        .filter(f => f.startsWith('backup_'))
        .map(name => {
          const backupPath = path.join(this.backupDir, name);
          const stats = fs.statSync(backupPath);
          return {
            name,
            createdAt: stats.mtime,
            size: this.getDirectorySize(backupPath)
          };
        })
        .sort((a, b) => b.createdAt - a.createdAt);

      return backups;
    } catch (error) {
      console.error('[Backup] Error getting backup list:', error);
      return [];
    }
  }

  // Удалить старые бэкапы
  async cleanOldBackups() {
    try {
      const backups = this.getBackupList();
      
      if (backups.length <= this.maxBackups) {
        return;
      }

      // Удаляем самые старые бэкапы
      const toDelete = backups.slice(this.maxBackups);
      
      for (const backup of toDelete) {
        const backupPath = path.join(this.backupDir, backup.name);
        this.deleteDirectory(backupPath);
        console.log(`[Backup] Deleted old backup: ${backup.name}`);
      }
    } catch (error) {
      console.error('[Backup] Error cleaning old backups:', error);
    }
  }

  // Получить размер директории
  getDirectorySize(dirPath) {
    let size = 0;
    const files = fs.readdirSync(dirPath);
    
    for (const file of files) {
      const filePath = path.join(dirPath, file);
      const stats = fs.statSync(filePath);
      
      if (stats.isDirectory()) {
        size += this.getDirectorySize(filePath);
      } else {
        size += stats.size;
      }
    }
    
    return size;
  }

  // Удалить директорию рекурсивно
  deleteDirectory(dirPath) {
    if (fs.existsSync(dirPath)) {
      fs.readdirSync(dirPath).forEach(file => {
        const curPath = path.join(dirPath, file);
        if (fs.lstatSync(curPath).isDirectory()) {
          this.deleteDirectory(curPath);
        } else {
          fs.unlinkSync(curPath);
        }
      });
      fs.rmdirSync(dirPath);
    }
  }

  // Автобэкап (запускается по расписанию)
  async autoBackup() {
    try {
      const backupName = await this.createBackup();
      return { success: true, backupName };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }
}

module.exports = new BackupService();
