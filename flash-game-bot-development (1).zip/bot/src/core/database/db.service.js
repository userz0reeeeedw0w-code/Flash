/**
 * FLASH BOT - Database Service (JSON)
 */

const fs = require('fs');
const path = require('path');
const config = require('../../config');

class DBService {
  constructor() {
    this.dataDir = config.app.dataDir;
    this.cache = {};
    this.saveQueue = new Set();
    this.saveInterval = null;
    this.initialized = false;
  }

  // Инициализация базы данных
  async init() {
    if (this.initialized) return;

    // Создаем директории
    const dirs = [
      this.dataDir,
      path.join(this.dataDir, 'backups')
    ];

    for (const dir of dirs) {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    }

    // Инициализируем файлы данных
    const files = {
      'users.json': {},
      'clans.json': {},
      'shop.json': this.getDefaultShop(),
      'config.json': this.getDefaultConfig(),
      'promocodes.json': {},
      'quests.json': this.getDefaultQuests(),
      'events.json': {},
      'achievements.json': this.getDefaultAchievements(),
      'mailings.json': [],
      'boss.json': null,
      'stats.json': { commands: {}, errors: [], transactions: [] },
      'linkCodes.json': {}
    };

    for (const [filename, defaultData] of Object.entries(files)) {
      const filepath = path.join(this.dataDir, filename);
      if (!fs.existsSync(filepath)) {
        fs.writeFileSync(filepath, JSON.stringify(defaultData, null, 2));
      }
      // Загружаем в кэш
      this.cache[filename] = this.loadFile(filename);
    }

    // Запускаем автосохранение каждые 30 секунд
    this.saveInterval = setInterval(() => this.saveAll(), 30000);

    this.initialized = true;
    console.log('[DB] Database initialized');
  }

  // Загрузка файла
  loadFile(filename) {
    try {
      const filepath = path.join(this.dataDir, filename);
      if (!fs.existsSync(filepath)) return null;
      const data = fs.readFileSync(filepath, 'utf8');
      return JSON.parse(data);
    } catch (error) {
      console.error(`[DB] Error loading ${filename}:`, error);
      return null;
    }
  }

  // Сохранение файла
  saveFile(filename) {
    try {
      const filepath = path.join(this.dataDir, filename);
      const data = this.cache[filename];
      if (data !== undefined) {
        fs.writeFileSync(filepath, JSON.stringify(data, null, 2));
      }
    } catch (error) {
      console.error(`[DB] Error saving ${filename}:`, error);
    }
  }

  // Добавить в очередь сохранения
  queueSave(filename) {
    this.saveQueue.add(filename);
  }

  // Сохранить все файлы из очереди
  saveAll() {
    for (const filename of this.saveQueue) {
      this.saveFile(filename);
    }
    this.saveQueue.clear();
  }

  // Принудительное сохранение всего
  forceSaveAll() {
    for (const filename of Object.keys(this.cache)) {
      this.saveFile(filename);
    }
  }

  // ===== USERS =====
  
  getUsers() {
    return this.cache['users.json'] || {};
  }

  getUser(platform, platformId) {
    const users = this.getUsers();
    const key = `${platform}_${platformId}`;
    return users[key] || null;
  }

  getUserByUid(uid) {
    const users = this.getUsers();
    return Object.values(users).find(u => u.uid === uid) || null;
  }

  getUserByIdentifier(identifier) {
    const users = this.getUsers();
    // @id123456789 (VK) или @username (Telegram)
    if (identifier.startsWith('@id')) {
      const vkId = identifier.slice(3);
      return Object.values(users).find(u => u.vkId === vkId) || null;
    } else if (identifier.startsWith('@')) {
      const tgUsername = identifier.slice(1).toLowerCase();
      return Object.values(users).find(u => 
        u.telegramUsername && u.telegramUsername.toLowerCase() === tgUsername
      ) || null;
    }
    return null;
  }

  createUser(platform, platformId, data) {
    const users = this.getUsers();
    const key = `${platform}_${platformId}`;
    
    // Генерируем UID
    const maxUid = Math.max(0, ...Object.values(users).map(u => u.uid || 0));
    const uid = maxUid + 1;
    
    // Генерируем реферальный код
    const referralCode = this.generateReferralCode();
    
    const user = {
      uid,
      platform,
      platformId,
      // Идентификаторы
      vkId: platform === 'vk' ? platformId : null,
      telegramId: platform === 'telegram' ? platformId : null,
      telegramUsername: data.username || null,
      // Основные данные
      nickname: data.nickname || `Игрок${uid}`,
      tag: 'Новичок',
      // Валюты
      money: config.starter.money,
      rubles: config.starter.rubles,
      bitcoin: config.starter.bitcoin,
      diamonds: config.starter.diamonds,
      cups: config.starter.cups,
      coins: config.starter.coins,
      // Банк
      bankBalance: 0,
      bankLimit: 100000,
      credit: 0,
      creditDate: null,
      // Статы
      level: config.starter.level,
      experience: config.starter.experience,
      energy: config.starter.energy,
      maxEnergy: config.starter.maxEnergy,
      strength: config.starter.strength,
      intellect: config.starter.intellect,
      charisma: config.starter.charisma,
      luck: config.starter.luck,
      // Привилегии
      privilege: 'none',
      privilegeExpires: null,
      // Имущество
      cars: [{ id: 1, name: 'Обычная', speed: 30, acceleration: 20, handling: 40, tuning: 0, fuel: 100, condition: 100 }],
      activeCar: 1,
      businesses: [],
      farms: [],
      printers: [],
      // Работа
      job: null,
      jobLevel: 0,
      jobExperience: 0,
      lastWorkTime: null,
      // Майнинг
      pickaxeLevel: 1,
      shaftLevel: 1,
      ores: {},
      lastMiningTime: null,
      // Рыбалка
      rodLevel: 1,
      fish: {},
      lastFishingTime: null,
      // Клан
      clanId: null,
      clanRole: null,
      // Семья
      familyId: null,
      spouseUid: null,
      spouseIdentifier: null,
      children: [],
      // Питомец
      pet: null,
      // Дом
      home: null,
      // Инвентарь
      inventory: [],
      // Достижения
      achievements: [],
      achievementsCount: 0,
      // Рефералы
      referralCode,
      referredBy: null,
      referrals: [],
      referralsCount: 0,
      referralEarnings: 0,
      // Статистика
      rating: null,
      playTime: 0,
      totalEarned: 0,
      totalSpent: 0,
      gamesPlayed: 0,
      gamesWon: 0,
      bossKills: 0,
      // Кулдауны
      cooldowns: {},
      // Лимиты (дневные)
      dailyLimits: {},
      dailyLimitsReset: null,
      // Квесты
      dailyQuests: [],
      weeklyQuests: [],
      newbiePath: this.getNewbiePath(),
      // Бонусы
      lastBonusTime: null,
      bonusStreak: 0,
      lastHourlyBonus: null,
      // Капча
      captchaPending: null,
      captchaAttempts: 0,
      captchaBlockedUntil: null,
      // Настройки
      keyboardEnabled: true,
      notifications: true,
      // Привязка
      linkedAccounts: [],
      // Метаданные
      registeredAt: Date.now(),
      lastActivity: Date.now(),
      isBanned: false,
      banReason: null,
      isMuted: false,
      muteUntil: null,
      ...data
    };

    users[key] = user;
    this.cache['users.json'] = users;
    this.queueSave('users.json');
    
    return user;
  }

  updateUser(platform, platformId, updates) {
    const users = this.getUsers();
    const key = `${platform}_${platformId}`;
    
    if (!users[key]) return null;
    
    users[key] = { ...users[key], ...updates, lastActivity: Date.now() };
    this.cache['users.json'] = users;
    this.queueSave('users.json');
    
    return users[key];
  }

  updateUserByUid(uid, updates) {
    const user = this.getUserByUid(uid);
    if (!user) return null;
    return this.updateUser(user.platform, user.platformId, updates);
  }

  // ===== CLANS =====

  getClans() {
    return this.cache['clans.json'] || {};
  }

  getClan(clanUid) {
    const clans = this.getClans();
    return clans[clanUid] || null;
  }

  getClanByName(name) {
    const clans = this.getClans();
    return Object.values(clans).find(c => c.name.toLowerCase() === name.toLowerCase()) || null;
  }

  createClan(leaderUid, leaderIdentifier, name) {
    const clans = this.getClans();
    const maxUid = Math.max(0, ...Object.keys(clans).map(Number));
    const uid = maxUid + 1;
    
    const clan = {
      uid,
      name,
      leaderUid,
      leaderIdentifier,
      members: [{ uid: leaderUid, identifier: leaderIdentifier, role: 'leader', joinedAt: Date.now() }],
      power: 100,
      health: 1000,
      maxHealth: 1000,
      treasury: 0,
      experience: 0,
      level: 1,
      wins: 0,
      losses: 0,
      upgrades: {},
      createdAt: Date.now()
    };

    clans[uid] = clan;
    this.cache['clans.json'] = clans;
    this.queueSave('clans.json');
    
    return clan;
  }

  updateClan(clanUid, updates) {
    const clans = this.getClans();
    if (!clans[clanUid]) return null;
    
    clans[clanUid] = { ...clans[clanUid], ...updates };
    this.cache['clans.json'] = clans;
    this.queueSave('clans.json');
    
    return clans[clanUid];
  }

  deleteClan(clanUid) {
    const clans = this.getClans();
    delete clans[clanUid];
    this.cache['clans.json'] = clans;
    this.queueSave('clans.json');
  }

  // ===== BOSS =====

  getBoss() {
    return this.cache['boss.json'];
  }

  setBoss(boss) {
    this.cache['boss.json'] = boss;
    this.queueSave('boss.json');
  }

  // ===== PROMOCODES =====

  getPromocodes() {
    return this.cache['promocodes.json'] || {};
  }

  getPromocode(code) {
    const promocodes = this.getPromocodes();
    return promocodes[code.toUpperCase()] || null;
  }

  createPromocode(code, data) {
    const promocodes = this.getPromocodes();
    const upperCode = code.toUpperCase();
    
    promocodes[upperCode] = {
      code: upperCode,
      ...data,
      usedBy: [],
      usedCount: 0,
      createdAt: Date.now()
    };
    
    this.cache['promocodes.json'] = promocodes;
    this.queueSave('promocodes.json');
    
    return promocodes[upperCode];
  }

  updatePromocode(code, updates) {
    const promocodes = this.getPromocodes();
    const upperCode = code.toUpperCase();
    
    if (!promocodes[upperCode]) return null;
    
    promocodes[upperCode] = { ...promocodes[upperCode], ...updates };
    this.cache['promocodes.json'] = promocodes;
    this.queueSave('promocodes.json');
    
    return promocodes[upperCode];
  }

  deletePromocode(code) {
    const promocodes = this.getPromocodes();
    delete promocodes[code.toUpperCase()];
    this.cache['promocodes.json'] = promocodes;
    this.queueSave('promocodes.json');
  }

  // ===== LINK CODES =====

  getLinkCodes() {
    return this.cache['linkCodes.json'] || {};
  }

  createLinkCode(uid, code) {
    const codes = this.getLinkCodes();
    codes[code] = {
      uid,
      code,
      createdAt: Date.now(),
      expiresAt: Date.now() + 5 * 60 * 1000 // 5 минут
    };
    this.cache['linkCodes.json'] = codes;
    this.queueSave('linkCodes.json');
    return codes[code];
  }

  getLinkCode(code) {
    const codes = this.getLinkCodes();
    const linkCode = codes[code];
    if (!linkCode) return null;
    if (Date.now() > linkCode.expiresAt) {
      delete codes[code];
      this.cache['linkCodes.json'] = codes;
      this.queueSave('linkCodes.json');
      return null;
    }
    return linkCode;
  }

  deleteLinkCode(code) {
    const codes = this.getLinkCodes();
    delete codes[code];
    this.cache['linkCodes.json'] = codes;
    this.queueSave('linkCodes.json');
  }

  // ===== CONFIG =====

  getConfig() {
    return this.cache['config.json'] || this.getDefaultConfig();
  }

  updateConfig(updates) {
    const cfg = this.getConfig();
    this.cache['config.json'] = { ...cfg, ...updates };
    this.queueSave('config.json');
    return this.cache['config.json'];
  }

  // ===== STATS =====

  getStats() {
    return this.cache['stats.json'] || { commands: {}, errors: [], transactions: [] };
  }

  logCommand(command, userId) {
    const stats = this.getStats();
    stats.commands[command] = (stats.commands[command] || 0) + 1;
    this.cache['stats.json'] = stats;
    this.queueSave('stats.json');
  }

  logError(error, context) {
    const stats = this.getStats();
    stats.errors.push({
      error: error.message || error,
      stack: error.stack,
      context,
      timestamp: Date.now()
    });
    // Храним только последние 1000 ошибок
    if (stats.errors.length > 1000) {
      stats.errors = stats.errors.slice(-1000);
    }
    this.cache['stats.json'] = stats;
    this.queueSave('stats.json');
  }

  logTransaction(fromUid, toUid, amount, type) {
    const stats = this.getStats();
    stats.transactions.push({
      fromUid,
      toUid,
      amount,
      type,
      timestamp: Date.now()
    });
    // Храним только последние 10000 транзакций
    if (stats.transactions.length > 10000) {
      stats.transactions = stats.transactions.slice(-10000);
    }
    this.cache['stats.json'] = stats;
    this.queueSave('stats.json');
  }

  // ===== EVENTS =====

  getEvents() {
    return this.cache['events.json'] || {};
  }

  setEvents(events) {
    this.cache['events.json'] = events;
    this.queueSave('events.json');
  }

  // ===== MAILINGS =====

  getMailings() {
    return this.cache['mailings.json'] || [];
  }

  addMailing(mailing) {
    const mailings = this.getMailings();
    mailings.push({
      id: Date.now(),
      ...mailing,
      createdAt: Date.now(),
      status: 'pending'
    });
    this.cache['mailings.json'] = mailings;
    this.queueSave('mailings.json');
    return mailings[mailings.length - 1];
  }

  updateMailing(id, updates) {
    const mailings = this.getMailings();
    const index = mailings.findIndex(m => m.id === id);
    if (index === -1) return null;
    mailings[index] = { ...mailings[index], ...updates };
    this.cache['mailings.json'] = mailings;
    this.queueSave('mailings.json');
    return mailings[index];
  }

  // ===== HELPERS =====

  generateReferralCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 6; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  }

  getDefaultShop() {
    return {
      cars: require('../../config/constants').CARS,
      businesses: require('../../config/constants').BUSINESSES,
      farms: require('../../config/constants').FARMS,
      printers: require('../../config/constants').PRINTERS,
      pets: require('../../config/constants').PETS,
      cases: require('../../config/constants').CASES
    };
  }

  getDefaultConfig() {
    return {
      btcRate: 100000,
      lastBtcUpdate: Date.now(),
      maintenanceMode: false,
      registrationEnabled: true,
      globalMultiplier: 1,
      eventMultiplier: 1
    };
  }

  getDefaultQuests() {
    return {
      daily: [
        { id: 1, name: 'Заработать 10,000$', type: 'earn', target: 10000, reward: { money: 2000, exp: 50 } },
        { id: 2, name: 'Выиграть 3 гонки', type: 'race_wins', target: 3, reward: { money: 5000, exp: 100, cups: 5 } },
        { id: 3, name: 'Атаковать босса 5 раз', type: 'boss_attacks', target: 5, reward: { money: 3000, exp: 75 } },
        { id: 4, name: 'Поймать 10 рыб', type: 'fishing', target: 10, reward: { money: 2000, exp: 50 } },
        { id: 5, name: 'Ограбить 2 игроков', type: 'robbery', target: 2, reward: { money: 4000, exp: 100 } },
        { id: 6, name: 'Собрать бизнес 3 раза', type: 'business_collect', target: 3, reward: { money: 3000, exp: 75 } },
        { id: 7, name: 'Сделать 5 ставок в казино', type: 'casino', target: 5, reward: { money: 2000, exp: 50 } },
        { id: 8, name: 'Поработать 2 смены', type: 'work', target: 2, reward: { money: 3000, exp: 75 } }
      ],
      weekly: [
        { id: 101, name: 'Заработать 100,000$', type: 'earn', target: 100000, reward: { money: 20000, exp: 500, diamonds: 5 } },
        { id: 102, name: 'Выиграть 20 гонок', type: 'race_wins', target: 20, reward: { money: 30000, exp: 750, diamonds: 10 } },
        { id: 103, name: 'Убить 10 боссов', type: 'boss_kills', target: 10, reward: { money: 25000, exp: 600, diamonds: 5 } },
        { id: 104, name: 'Накопать 1000 руды', type: 'mining', target: 1000, reward: { money: 15000, exp: 400, diamonds: 3 } },
        { id: 105, name: 'Поймать 50 рыб', type: 'fishing_total', target: 50, reward: { money: 15000, exp: 400, diamonds: 3 } }
      ]
    };
  }

  getDefaultAchievements() {
    return [
      { id: 1, name: 'Первые шаги', description: 'Зарегистрироваться в игре', reward: { money: 5000 } },
      { id: 2, name: 'Богач', description: 'Накопить 100,000$', reward: { money: 10000, diamonds: 1 } },
      { id: 3, name: 'Миллионер', description: 'Накопить 1,000,000$', reward: { money: 50000, diamonds: 5 } },
      { id: 4, name: 'Гонщик', description: 'Выиграть 10 гонок', reward: { money: 5000, cups: 10 } },
      { id: 5, name: 'Чемпион', description: 'Выиграть 100 гонок', reward: { money: 25000, cups: 50 } },
      { id: 6, name: 'Убийца боссов', description: 'Убить 10 боссов', reward: { money: 15000, diamonds: 3 } },
      { id: 7, name: 'Бизнесмен', description: 'Купить 5 бизнесов', reward: { money: 20000 } },
      { id: 8, name: 'Рыбак', description: 'Поймать 100 рыб', reward: { money: 10000 } },
      { id: 9, name: 'Шахтёр', description: 'Накопать 5000 руды', reward: { money: 15000 } },
      { id: 10, name: 'Социальный', description: 'Вступить в клан', reward: { money: 5000 } }
    ];
  }

  getNewbiePath() {
    return [
      { id: 1, name: 'Введите команду "профиль"', command: 'profile', completed: false },
      { id: 2, name: 'Получите ежедневный бонус', command: 'bonus', completed: false },
      { id: 3, name: 'Поработайте 1 раз', command: 'work', completed: false },
      { id: 4, name: 'Сыграйте в казино', command: 'casino', completed: false },
      { id: 5, name: 'Атакуйте босса', command: 'bossAttack', completed: false },
      { id: 6, name: 'Проведите гонку', command: 'race', completed: false },
      { id: 7, name: 'Купите бизнес', command: 'businessBuy', completed: false },
      { id: 8, name: 'Вступите в клан', command: 'clanJoin', completed: false }
    ];
  }

  // Закрытие базы данных
  async close() {
    if (this.saveInterval) {
      clearInterval(this.saveInterval);
    }
    this.forceSaveAll();
    console.log('[DB] Database closed');
  }
}

module.exports = new DBService();
