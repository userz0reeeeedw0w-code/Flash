/**
 * FLASH BOT - Database Index
 */

const DBService = require('./db.service');
const BackupService = require('./backup.service');

module.exports = {
  DBService,
  BackupService
};
