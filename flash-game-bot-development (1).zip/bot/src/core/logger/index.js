/**
 * FLASH BOT - Logger Index
 */

const LoggerService = require('./logger.service');

module.exports = LoggerService;
