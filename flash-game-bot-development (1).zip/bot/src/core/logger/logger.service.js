/**
 * FLASH BOT - Logger Service
 */

const fs = require('fs');
const path = require('path');
const config = require('../../config');

class LoggerService {
  constructor() {
    this.logsDir = path.join(process.cwd(), 'logs');
    this.ensureLogsDir();
  }

  ensureLogsDir() {
    if (!fs.existsSync(this.logsDir)) {
      fs.mkdirSync(this.logsDir, { recursive: true });
    }
  }

  getTimestamp() {
    return new Date().toISOString();
  }

  formatMessage(level, message, meta = {}) {
    const timestamp = this.getTimestamp();
    const metaStr = Object.keys(meta).length > 0 ? ` ${JSON.stringify(meta)}` : '';
    return `[${timestamp}] [${level.toUpperCase()}] ${message}${metaStr}`;
  }

  writeToFile(filename, message) {
    const filepath = path.join(this.logsDir, filename);
    fs.appendFileSync(filepath, message + '\n');
  }

  info(message, meta = {}) {
    const formatted = this.formatMessage('info', message, meta);
    console.log(formatted);
  }

  warn(message, meta = {}) {
    const formatted = this.formatMessage('warn', message, meta);
    console.warn(formatted);
  }

  error(message, meta = {}) {
    const formatted = this.formatMessage('error', message, meta);
    console.error(formatted);
    this.writeToFile('errors.log', formatted);
  }

  debug(message, meta = {}) {
    if (config.app.env === 'development' || config.app.logLevel === 'debug') {
      const formatted = this.formatMessage('debug', message, meta);
      console.log(formatted);
    }
  }

  command(userId, platform, command, args = []) {
    const message = `User ${userId} (${platform}) executed: ${command} ${args.join(' ')}`;
    const formatted = this.formatMessage('command', message);
    console.log(formatted);
    this.writeToFile('commands.log', formatted);
  }

  transaction(fromUid, toUid, amount, type) {
    const message = `Transaction: ${type} | From: #${fromUid} | To: #${toUid} | Amount: ${amount}`;
    const formatted = this.formatMessage('transaction', message);
    this.writeToFile('transactions.log', formatted);
  }

  // Получить последние логи
  getRecentLogs(filename, lines = 50) {
    try {
      const filepath = path.join(this.logsDir, filename);
      if (!fs.existsSync(filepath)) return [];
      
      const content = fs.readFileSync(filepath, 'utf8');
      const allLines = content.split('\n').filter(l => l.trim());
      return allLines.slice(-lines);
    } catch (error) {
      return [];
    }
  }

  // Очистить логи
  clearLogs(filename) {
    const filepath = path.join(this.logsDir, filename);
    if (fs.existsSync(filepath)) {
      fs.writeFileSync(filepath, '');
    }
  }
}

module.exports = new LoggerService();
