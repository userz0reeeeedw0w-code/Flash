/**
 * FLASH BOT - Telegram Bot
 */

const TelegramBot = require('node-telegram-bot-api');
const config = require('../../../config');
const logger = require('../../logger');
const db = require('../../database/db.service');
const { mainKeyboard, removeKeyboard } = require('../../../config/keyboards');

class TelegramBotService {
  constructor() {
    this.bot = null;
    this.messageHandler = null;
    this.callbackHandler = null;
  }

  // Инициализация бота
  async init(messageHandler, callbackHandler) {
    try {
      this.messageHandler = messageHandler;
      this.callbackHandler = callbackHandler;

      // Создаём бота в режиме поллинга
      this.bot = new TelegramBot(config.telegram.token, {
        polling: config.telegram.polling
      });

      // Обработчик текстовых сообщений
      this.bot.on('message', async (msg) => {
        try {
          await this.handleMessage(msg);
        } catch (error) {
          logger.error('[Telegram] Message handler error:', { error: error.message, stack: error.stack });
        }
      });

      // Обработчик callback_query (inline кнопки)
      this.bot.on('callback_query', async (query) => {
        try {
          await this.handleCallback(query);
        } catch (error) {
          logger.error('[Telegram] Callback handler error:', { error: error.message, stack: error.stack });
        }
      });

      // Обработчик ошибок поллинга
      this.bot.on('polling_error', (error) => {
        logger.error('[Telegram] Polling error:', { error: error.message });
      });

      logger.info('[Telegram] Bot initialized and polling started');
      return true;
    } catch (error) {
      logger.error('[Telegram] Failed to initialize bot:', { error: error.message });
      return false;
    }
  }

  // Обработка сообщения
  async handleMessage(msg) {
    // Игнорируем сообщения без текста
    if (!msg.text) return;
    
    // Формируем контекст
    const context = {
      platform: 'telegram',
      chatId: msg.chat.id,
      userId: msg.from.id.toString(),
      username: msg.from.username || null,
      firstName: msg.from.first_name || '',
      lastName: msg.from.last_name || '',
      text: msg.text,
      messageId: msg.message_id,
      replyTo: msg.reply_to_message || null,
      isGroup: msg.chat.type !== 'private',
      raw: msg
    };

    // Передаём обработчику
    if (this.messageHandler) {
      const result = await this.messageHandler(context);
      if (result) {
        await this.sendResponse(context, result);
      }
    }
  }

  // Обработка callback
  async handleCallback(query) {
    const context = {
      platform: 'telegram',
      chatId: query.message.chat.id,
      userId: query.from.id.toString(),
      username: query.from.username || null,
      callbackData: query.data,
      messageId: query.message.message_id,
      raw: query
    };

    // Отвечаем на callback чтобы убрать "часики"
    await this.bot.answerCallbackQuery(query.id);

    // Передаём обработчику
    if (this.callbackHandler) {
      const result = await this.callbackHandler(context);
      if (result) {
        if (result.edit) {
          await this.editMessage(context, result);
        } else {
          await this.sendResponse(context, result);
        }
      }
    }
  }

  // Отправка ответа
  async sendResponse(context, response) {
    try {
      const options = {};

      // Клавиатура
      if (response.keyboard) {
        if (response.keyboard === 'main') {
          const user = db.getUser('telegram', context.userId);
          if (user && user.keyboardEnabled !== false) {
            options.reply_markup = mainKeyboard.telegram;
          }
        } else if (response.keyboard === 'remove') {
          options.reply_markup = removeKeyboard.telegram;
        } else if (response.keyboard.telegram) {
          options.reply_markup = response.keyboard.telegram;
        } else {
          options.reply_markup = response.keyboard;
        }
      }

      // Inline кнопки
      if (response.buttons) {
        if (response.buttons.telegram) {
          options.reply_markup = response.buttons.telegram;
        } else {
          options.reply_markup = response.buttons;
        }
      }

      // Парсинг HTML/Markdown
      if (response.parseMode) {
        options.parse_mode = response.parseMode;
      }

      // Отправляем сообщение
      await this.bot.sendMessage(context.chatId, response.text, options);
    } catch (error) {
      logger.error('[Telegram] Send response error:', { error: error.message });
    }
  }

  // Редактирование сообщения
  async editMessage(context, response) {
    try {
      const options = {
        chat_id: context.chatId,
        message_id: context.messageId
      };

      if (response.buttons) {
        if (response.buttons.telegram) {
          options.reply_markup = response.buttons.telegram;
        } else {
          options.reply_markup = response.buttons;
        }
      }

      await this.bot.editMessageText(response.text, options);
    } catch (error) {
      // Игнорируем ошибку "message is not modified"
      if (!error.message.includes('not modified')) {
        logger.error('[Telegram] Edit message error:', { error: error.message });
      }
    }
  }

  // Отправка сообщения напрямую
  async sendMessage(chatId, text, options = {}) {
    try {
      return await this.bot.sendMessage(chatId, text, options);
    } catch (error) {
      logger.error('[Telegram] Direct send error:', { error: error.message });
      return null;
    }
  }

  // Отправка сообщения пользователю по UID
  async sendToUser(user, text, options = {}) {
    if (user.telegramId) {
      return await this.sendMessage(user.telegramId, text, options);
    }
    return null;
  }

  // Массовая рассылка
  async broadcast(users, text, options = {}) {
    let sent = 0;
    let failed = 0;

    for (const user of users) {
      if (user.telegramId) {
        try {
          await this.sendMessage(user.telegramId, text, options);
          sent++;
          // Небольшая задержка чтобы не превысить лимиты
          await new Promise(resolve => setTimeout(resolve, 50));
        } catch (error) {
          failed++;
        }
      }
    }

    return { sent, failed };
  }

  // Остановка бота
  stop() {
    if (this.bot) {
      this.bot.stopPolling();
      logger.info('[Telegram] Bot stopped');
    }
  }
}

module.exports = new TelegramBotService();
