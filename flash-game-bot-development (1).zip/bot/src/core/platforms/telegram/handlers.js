/**
 * FLASH BOT - Telegram Handlers
 */

const { getCommand } = require('../../../config/aliases');
const { getPlayerIdentifier } = require('../../utils/formatter');

// Парсинг текста команды
function parseCommand(text) {
  if (!text) return null;
  
  const trimmed = text.trim();
  
  // Пропускаем команды с / или !
  if (trimmed.startsWith('/') || trimmed.startsWith('!')) {
    return null;
  }
  
  return getCommand(trimmed);
}

// Получение идентификатора пользователя для сообщений
function getUserIdentifier(context, user) {
  if (user) {
    if (user.telegramUsername) {
      return `@${user.telegramUsername}`;
    }
    return `@user${user.telegramId || context.userId}`;
  }
  
  if (context.username) {
    return `@${context.username}`;
  }
  
  return `@user${context.userId}`;
}

// Получение данных о пользователе из контекста
function extractUserData(context) {
  return {
    platform: 'telegram',
    platformId: context.userId,
    username: context.username,
    firstName: context.firstName,
    lastName: context.lastName,
    nickname: context.firstName || `Игрок`
  };
}

// Парсинг reply (ответа на сообщение)
function parseReplyTo(context) {
  if (!context.replyTo || !context.replyTo.from) {
    return null;
  }
  
  return {
    platform: 'telegram',
    platformId: context.replyTo.from.id.toString(),
    username: context.replyTo.from.username || null
  };
}

module.exports = {
  parseCommand,
  getUserIdentifier,
  extractUserData,
  parseReplyTo
};
