/**
 * FLASH BOT - VK Bot
 */

const { VK, Keyboard } = require('vk-io');
const config = require('../../../config');
const logger = require('../../logger');
const db = require('../../database/db.service');
const { mainKeyboard, removeKeyboard } = require('../../../config/keyboards');

class VKBotService {
  constructor() {
    this.vk = null;
    this.messageHandler = null;
    this.callbackHandler = null;
  }

  // Инициализация бота
  async init(messageHandler, callbackHandler) {
    try {
      this.messageHandler = messageHandler;
      this.callbackHandler = callbackHandler;

      // Создаём экземпляр VK
      this.vk = new VK({
        token: config.vk.token,
        apiVersion: config.vk.apiVersion
      });

      // Обработчик сообщений
      this.vk.updates.on('message_new', async (context) => {
        try {
          await this.handleMessage(context);
        } catch (error) {
          logger.error('[VK] Message handler error:', { error: error.message, stack: error.stack });
        }
      });

      // Обработчик callback (inline кнопки)
      this.vk.updates.on('message_event', async (context) => {
        try {
          await this.handleCallback(context);
        } catch (error) {
          logger.error('[VK] Callback handler error:', { error: error.message, stack: error.stack });
        }
      });

      // Запускаем поллинг
      await this.vk.updates.start();

      logger.info('[VK] Bot initialized and polling started');
      return true;
    } catch (error) {
      logger.error('[VK] Failed to initialize bot:', { error: error.message });
      return false;
    }
  }

  // Обработка сообщения
  async handleMessage(ctx) {
    // Игнорируем исходящие сообщения
    if (ctx.isOutbox) return;
    
    // Игнорируем сообщения без текста
    if (!ctx.text) return;

    // Формируем контекст
    const context = {
      platform: 'vk',
      chatId: ctx.peerId,
      userId: ctx.senderId.toString(),
      text: ctx.text,
      messageId: ctx.conversationMessageId,
      replyTo: ctx.replyMessage || null,
      isGroup: ctx.isChat,
      raw: ctx
    };

    // Передаём обработчику
    if (this.messageHandler) {
      const result = await this.messageHandler(context);
      if (result) {
        await this.sendResponse(context, result);
      }
    }
  }

  // Обработка callback
  async handleCallback(ctx) {
    const payload = ctx.eventPayload;
    
    const context = {
      platform: 'vk',
      chatId: ctx.peerId,
      userId: ctx.userId.toString(),
      callbackData: payload.cmd || payload.command || '',
      eventId: ctx.eventId,
      raw: ctx
    };

    // Отправляем пустой ответ чтобы VK не показывал ошибку
    await ctx.answer({});

    // Передаём обработчику
    if (this.callbackHandler) {
      const result = await this.callbackHandler(context);
      if (result) {
        await this.sendResponse(context, result);
      }
    }
  }

  // Создание клавиатуры VK
  createKeyboard(buttons, inline = false) {
    if (!buttons || buttons.length === 0) return null;
    
    const keyboard = Keyboard.builder();
    
    if (inline) {
      keyboard.inline();
    }
    
    for (const row of buttons) {
      for (const button of row) {
        const action = button.action;
        
        if (action.type === 'text') {
          keyboard.textButton({
            label: action.label,
            payload: action.payload ? JSON.parse(action.payload) : {},
            color: this.getVKColor(button.color)
          });
        } else if (action.type === 'callback') {
          keyboard.callbackButton({
            label: action.label,
            payload: action.payload ? JSON.parse(action.payload) : {}
          });
        }
      }
      keyboard.row();
    }
    
    return keyboard;
  }

  // Преобразование цвета
  getVKColor(color) {
    const colors = {
      'primary': Keyboard.PRIMARY_COLOR,
      'secondary': Keyboard.SECONDARY_COLOR,
      'positive': Keyboard.POSITIVE_COLOR,
      'negative': Keyboard.NEGATIVE_COLOR
    };
    return colors[color] || Keyboard.SECONDARY_COLOR;
  }

  // Отправка ответа
  async sendResponse(context, response) {
    try {
      const params = {
        peer_id: context.chatId,
        message: response.text,
        random_id: Math.floor(Math.random() * 1000000000)
      };

      // Клавиатура
      if (response.keyboard) {
        if (response.keyboard === 'main') {
          const user = db.getUser('vk', context.userId);
          if (user && user.keyboardEnabled !== false) {
            params.keyboard = this.createKeyboard(mainKeyboard.vk);
          }
        } else if (response.keyboard === 'remove') {
          params.keyboard = Keyboard.builder().oneTime();
        } else if (response.keyboard.vk) {
          params.keyboard = this.createKeyboard(response.keyboard.vk);
        }
      }

      // Inline кнопки
      if (response.buttons) {
        if (response.buttons.vk) {
          params.keyboard = this.createKeyboard(response.buttons.vk, true);
        }
      }

      await this.vk.api.messages.send(params);
    } catch (error) {
      logger.error('[VK] Send response error:', { error: error.message });
    }
  }

  // Отправка сообщения напрямую
  async sendMessage(peerId, text, options = {}) {
    try {
      const params = {
        peer_id: peerId,
        message: text,
        random_id: Math.floor(Math.random() * 1000000000),
        ...options
      };
      
      return await this.vk.api.messages.send(params);
    } catch (error) {
      logger.error('[VK] Direct send error:', { error: error.message });
      return null;
    }
  }

  // Отправка сообщения пользователю по UID
  async sendToUser(user, text, options = {}) {
    if (user.vkId) {
      return await this.sendMessage(parseInt(user.vkId), text, options);
    }
    return null;
  }

  // Массовая рассылка
  async broadcast(users, text, options = {}) {
    let sent = 0;
    let failed = 0;

    // VK позволяет отправлять до 100 сообщений за раз
    const vkUsers = users.filter(u => u.vkId);
    const chunks = [];
    for (let i = 0; i < vkUsers.length; i += 100) {
      chunks.push(vkUsers.slice(i, i + 100));
    }

    for (const chunk of chunks) {
      try {
        const userIds = chunk.map(u => parseInt(u.vkId));
        
        // Отправляем каждому по отдельности (для надёжности)
        for (const userId of userIds) {
          try {
            await this.sendMessage(userId, text, options);
            sent++;
            await new Promise(resolve => setTimeout(resolve, 50));
          } catch (e) {
            failed++;
          }
        }
      } catch (error) {
        failed += chunk.length;
      }
    }

    return { sent, failed };
  }

  // Получение информации о пользователе VK
  async getUserInfo(userId) {
    try {
      const [user] = await this.vk.api.users.get({
        user_ids: userId,
        fields: 'screen_name'
      });
      return user;
    } catch (error) {
      logger.error('[VK] Get user info error:', { error: error.message });
      return null;
    }
  }

  // Резолв домена VK
  async resolveScreenName(screenName) {
    try {
      const result = await this.vk.api.utils.resolveScreenName({
        screen_name: screenName
      });
      
      if (result && result.type === 'user') {
        return result.object_id;
      }
      return null;
    } catch (error) {
      logger.error('[VK] Resolve screen name error:', { error: error.message });
      return null;
    }
  }

  // Остановка бота
  stop() {
    if (this.vk) {
      this.vk.updates.stop();
      logger.info('[VK] Bot stopped');
    }
  }
}

module.exports = new VKBotService();
