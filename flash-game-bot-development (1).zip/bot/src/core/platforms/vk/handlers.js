/**
 * FLASH BOT - VK Handlers
 */

const { getCommand } = require('../../../config/aliases');

// Парсинг текста команды
function parseCommand(text) {
  if (!text) return null;
  
  const trimmed = text.trim();
  
  // Пропускаем команды с / или !
  if (trimmed.startsWith('/') || trimmed.startsWith('!')) {
    return null;
  }
  
  return getCommand(trimmed);
}

// Получение идентификатора пользователя для сообщений
function getUserIdentifier(context, user) {
  if (user && user.vkId) {
    return `@id${user.vkId}`;
  }
  return `@id${context.userId}`;
}

// Получение данных о пользователе из контекста
function extractUserData(context) {
  return {
    platform: 'vk',
    platformId: context.userId,
    nickname: `Игрок`
  };
}

// Парсинг reply (ответа на сообщение)
function parseReplyTo(context) {
  if (!context.replyTo) {
    return null;
  }
  
  // В VK reply_message содержит from_id
  const fromId = context.replyTo.from_id || context.replyTo.senderId;
  
  if (!fromId) return null;
  
  return {
    platform: 'vk',
    platformId: fromId.toString()
  };
}

module.exports = {
  parseCommand,
  getUserIdentifier,
  extractUserData,
  parseReplyTo
};
