/**
 * FLASH BOT - Scheduler Index
 */

const SchedulerService = require('./scheduler.service');

module.exports = SchedulerService;
