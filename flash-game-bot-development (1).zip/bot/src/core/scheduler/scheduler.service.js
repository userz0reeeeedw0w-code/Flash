/**
 * FLASH BOT - Scheduler Service
 * Автоматические задачи и события
 */

const cron = require('node-cron');
const config = require('../../config');
const db = require('../database/db.service');
const backup = require('../database/backup.service');
const logger = require('../logger');
const cache = require('../cache');

class SchedulerService {
  constructor() {
    this.jobs = [];
    this.bossTimeout = null;
    this.sendMessage = null; // Будет установлено при инициализации
  }

  // Инициализация планировщика
  init(sendMessageFn) {
    this.sendMessage = sendMessageFn;
    
    // Восстановление энергии - каждую минуту
    this.addJob('* * * * *', 'energy-restore', this.restoreEnergy.bind(this));
    
    // Бэкап - каждый час
    this.addJob('0 * * * *', 'backup', this.runBackup.bind(this));
    
    // Сброс дневных лимитов - в 00:00
    this.addJob('0 0 * * *', 'daily-reset', this.dailyReset.bind(this));
    
    // Сброс недельных квестов - в понедельник 00:00
    this.addJob('0 0 * * 1', 'weekly-reset', this.weeklyReset.bind(this));
    
    // Обновление курса BTC - каждые 6 часов
    this.addJob('0 */6 * * *', 'btc-rate', this.updateBtcRate.bind(this));
    
    // Проверка босса - каждые 5 минут
    this.addJob('*/5 * * * *', 'boss-check', this.checkBoss.bind(this));
    
    // Обновление топов - каждые 5 минут
    this.addJob('*/5 * * * *', 'tops-update', this.updateTops.bind(this));
    
    // Восстановление здоровья кланов - каждые 12 часов
    this.addJob('0 */12 * * *', 'clan-health', this.restoreClanHealth.bind(this));
    
    // Проверка истечения привилегий - каждый час
    this.addJob('0 * * * *', 'privilege-check', this.checkPrivileges.bind(this));
    
    // Начисление процентов банка - в 00:00
    this.addJob('0 0 * * *', 'bank-interest', this.processBankInterest.bind(this));
    
    // Начисление налогов - в 00:00
    this.addJob('0 0 * * *', 'taxes', this.processTaxes.bind(this));
    
    // Генерация газеты - каждые 6 часов
    this.addJob('0 */6 * * *', 'newspaper', this.generateNewspaper.bind(this));
    
    // Очистка старых данных - каждый день в 03:00
    this.addJob('0 3 * * *', 'cleanup', this.cleanup.bind(this));

    logger.info('[Scheduler] Initialized with jobs:', { count: this.jobs.length });
  }

  // Добавить задачу
  addJob(cronExpression, name, handler) {
    const job = cron.schedule(cronExpression, async () => {
      try {
        logger.debug(`[Scheduler] Running job: ${name}`);
        await handler();
      } catch (error) {
        logger.error(`[Scheduler] Job ${name} failed:`, { error: error.message });
      }
    });
    
    this.jobs.push({ name, job });
  }

  // Остановить все задачи
  stop() {
    for (const { job, name } of this.jobs) {
      job.stop();
      logger.debug(`[Scheduler] Stopped job: ${name}`);
    }
    
    if (this.bossTimeout) {
      clearTimeout(this.bossTimeout);
    }
    
    logger.info('[Scheduler] All jobs stopped');
  }

  // ===== ЗАДАЧИ =====

  // Восстановление энергии
  async restoreEnergy() {
    const users = db.getUsers();
    let updated = 0;
    
    for (const key of Object.keys(users)) {
      const user = users[key];
      if (user.energy < user.maxEnergy) {
        const newEnergy = Math.min(user.maxEnergy, user.energy + config.energyRestore.perMinute);
        if (newEnergy !== user.energy) {
          db.updateUser(user.platform, user.platformId, { energy: newEnergy });
          updated++;
        }
      }
    }
    
    if (updated > 0) {
      logger.debug(`[Scheduler] Restored energy for ${updated} users`);
    }
  }

  // Бэкап
  async runBackup() {
    const result = await backup.autoBackup();
    if (result.success) {
      logger.info(`[Scheduler] Backup created: ${result.backupName}`);
    } else {
      logger.error('[Scheduler] Backup failed:', { error: result.error });
    }
  }

  // Сброс дневных лимитов и квестов
  async dailyReset() {
    const users = db.getUsers();
    
    for (const key of Object.keys(users)) {
      const user = users[key];
      
      // Сброс лимитов
      const updates = {
        dailyLimits: {},
        dailyLimitsReset: Date.now()
      };
      
      // Генерация новых ежедневных квестов
      const questsData = db.loadFile('quests.json') || db.getDefaultQuests();
      updates.dailyQuests = questsData.daily.map(q => ({
        ...q,
        progress: 0,
        completed: false,
        claimed: false
      }));
      
      db.updateUser(user.platform, user.platformId, updates);
    }
    
    logger.info('[Scheduler] Daily reset completed');
  }

  // Сброс недельных квестов
  async weeklyReset() {
    const users = db.getUsers();
    const questsData = db.loadFile('quests.json') || db.getDefaultQuests();
    
    for (const key of Object.keys(users)) {
      const user = users[key];
      
      const weeklyQuests = questsData.weekly.map(q => ({
        ...q,
        progress: 0,
        completed: false,
        claimed: false
      }));
      
      db.updateUser(user.platform, user.platformId, { weeklyQuests });
    }
    
    logger.info('[Scheduler] Weekly reset completed');
  }

  // Обновление курса BTC
  async updateBtcRate() {
    // Случайный курс от 50,000 до 150,000
    const newRate = Math.floor(50000 + Math.random() * 100000);
    
    db.updateConfig({
      btcRate: newRate,
      lastBtcUpdate: Date.now()
    });
    
    logger.info(`[Scheduler] BTC rate updated: $${newRate}`);
  }

  // Проверка босса
  async checkBoss() {
    const boss = db.getBoss();
    
    if (!boss) {
      // Спавн нового босса
      await this.spawnBoss();
    } else if (boss.currentHp <= 0) {
      // Босс убит - распределяем награды
      await this.distributeBossRewards(boss);
      // Планируем следующего босса
      this.scheduleBossSpawn();
    }
  }

  // Спавн босса
  async spawnBoss() {
    const bossNames = [
      'Тёмный Дракон', 'Ледяной Голем', 'Огненный Феникс',
      'Теневой Демон', 'Древний Титан', 'Кристальный Змей'
    ];
    
    const name = bossNames[Math.floor(Math.random() * bossNames.length)];
    const level = Math.floor(1 + Math.random() * 50);
    const hp = config.boss.baseHp * Math.pow(config.boss.levelMultiplier, level - 1);
    const reward = config.boss.baseReward * Math.pow(config.boss.levelMultiplier, level - 1);
    
    const boss = {
      name,
      level,
      maxHp: Math.floor(hp),
      currentHp: Math.floor(hp),
      reward: Math.floor(reward),
      participants: [],
      spawnedAt: Date.now(),
      active: true
    };
    
    db.setBoss(boss);
    logger.info(`[Scheduler] Boss spawned: ${name} (Lv.${level})`);
    
    // TODO: Уведомить игроков о появлении босса
  }

  // Планировка спавна босса
  scheduleBossSpawn() {
    if (this.bossTimeout) {
      clearTimeout(this.bossTimeout);
    }
    
    this.bossTimeout = setTimeout(async () => {
      await this.spawnBoss();
    }, config.boss.spawnInterval);
  }

  // Распределение наград босса
  async distributeBossRewards(boss) {
    if (!boss.participants || boss.participants.length === 0) {
      db.setBoss(null);
      this.scheduleBossSpawn();
      return;
    }
    
    // Сортируем по урону
    const sorted = boss.participants.sort((a, b) => b.damage - a.damage);
    const totalDamage = sorted.reduce((sum, p) => sum + p.damage, 0);
    
    for (let i = 0; i < sorted.length; i++) {
      const participant = sorted[i];
      const user = db.getUserByUid(participant.uid);
      
      if (!user) continue;
      
      // Базовая награда пропорционально урону
      let reward = Math.floor(boss.reward * (participant.damage / totalDamage));
      
      // Бонус для топ-3
      if (i === 0) reward += Math.floor(boss.reward * 0.2);
      else if (i === 1) reward += Math.floor(boss.reward * 0.1);
      else if (i === 2) reward += Math.floor(boss.reward * 0.05);
      
      // Обновляем пользователя
      db.updateUserByUid(participant.uid, {
        money: user.money + reward,
        bossKills: (user.bossKills || 0) + 1
      });
      
      logger.info(`[Boss] Reward: UID #${participant.uid} got ${reward}$`);
    }
    
    db.setBoss(null);
    this.scheduleBossSpawn();
    
    logger.info('[Scheduler] Boss rewards distributed');
  }

  // Обновление топов
  async updateTops() {
    const users = Object.values(db.getUsers());
    
    // Топ по деньгам
    const topMoney = users
      .sort((a, b) => (b.money + (b.bankBalance || 0)) - (a.money + (a.bankBalance || 0)))
      .slice(0, 100)
      .map((u, i) => ({ rank: i + 1, uid: u.uid, nickname: u.nickname, value: u.money + (u.bankBalance || 0) }));
    cache.setTop('money', topMoney);
    
    // Топ по уровню
    const topLevel = users
      .sort((a, b) => b.level - a.level || b.experience - a.experience)
      .slice(0, 100)
      .map((u, i) => ({ rank: i + 1, uid: u.uid, nickname: u.nickname, value: u.level }));
    cache.setTop('level', topLevel);
    
    // Топ по бизнесам
    const topBusiness = users
      .filter(u => u.businesses && u.businesses.length > 0)
      .sort((a, b) => {
        const incomeA = a.businesses.reduce((sum, biz) => sum + biz.income, 0);
        const incomeB = b.businesses.reduce((sum, biz) => sum + biz.income, 0);
        return incomeB - incomeA;
      })
      .slice(0, 100)
      .map((u, i) => ({
        rank: i + 1,
        uid: u.uid,
        nickname: u.nickname,
        value: u.businesses.reduce((sum, biz) => sum + biz.income, 0)
      }));
    cache.setTop('business', topBusiness);
    
    // Обновляем рейтинг пользователей
    for (let i = 0; i < topMoney.length; i++) {
      db.updateUserByUid(topMoney[i].uid, { rating: i + 1 });
    }
    
    logger.debug('[Scheduler] Tops updated');
  }

  // Восстановление здоровья кланов
  async restoreClanHealth() {
    const clans = db.getClans();
    
    for (const clanUid of Object.keys(clans)) {
      const clan = clans[clanUid];
      if (clan.health < clan.maxHealth) {
        const newHealth = Math.min(clan.maxHealth, clan.health + Math.floor(clan.maxHealth * 0.1));
        db.updateClan(clanUid, { health: newHealth });
      }
    }
    
    logger.info('[Scheduler] Clan health restored');
  }

  // Проверка истечения привилегий
  async checkPrivileges() {
    const users = db.getUsers();
    const now = Date.now();
    
    for (const key of Object.keys(users)) {
      const user = users[key];
      if (user.privilege !== 'none' && user.privilegeExpires && user.privilegeExpires < now) {
        db.updateUser(user.platform, user.platformId, {
          privilege: 'none',
          privilegeExpires: null
        });
        logger.info(`[Scheduler] Privilege expired for UID #${user.uid}`);
      }
    }
  }

  // Начисление процентов банка
  async processBankInterest() {
    const users = db.getUsers();
    
    for (const key of Object.keys(users)) {
      const user = users[key];
      if (user.bankBalance > 0) {
        const interest = Math.floor(user.bankBalance * (config.bank.interestRate / 100));
        if (interest > 0) {
          db.updateUser(user.platform, user.platformId, {
            bankBalance: user.bankBalance + interest
          });
        }
      }
    }
    
    logger.info('[Scheduler] Bank interest processed');
  }

  // Начисление налогов
  async processTaxes() {
    const users = db.getUsers();
    const now = Date.now();
    
    for (const key of Object.keys(users)) {
      const user = users[key];
      
      // Пропускаем новичков
      const daysSinceRegistration = (now - user.registeredAt) / (24 * 60 * 60 * 1000);
      if (daysSinceRegistration < config.taxes.newbieDays) continue;
      
      // Рассчитываем налог
      const totalWealth = user.money + (user.bankBalance || 0);
      let tax = Math.floor(totalWealth * (config.taxes.dailyPercent / 100));
      tax = Math.max(config.taxes.minDaily, Math.min(config.taxes.maxDaily, tax));
      
      // Снимаем налог (сначала с наличных, потом с банка)
      if (user.money >= tax) {
        db.updateUser(user.platform, user.platformId, {
          money: user.money - tax
        });
      } else {
        const fromBank = tax - user.money;
        db.updateUser(user.platform, user.platformId, {
          money: 0,
          bankBalance: Math.max(0, (user.bankBalance || 0) - fromBank)
        });
      }
    }
    
    logger.info('[Scheduler] Taxes processed');
  }

  // Генерация газеты
  async generateNewspaper() {
    // TODO: Генерация новостей на основе событий в игре
    logger.debug('[Scheduler] Newspaper generated');
  }

  // Очистка старых данных
  async cleanup() {
    const stats = db.getStats();
    
    // Удаляем старые ошибки (старше 7 дней)
    const weekAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
    stats.errors = stats.errors.filter(e => e.timestamp > weekAgo);
    
    // Удаляем старые транзакции (старше 30 дней)
    const monthAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
    stats.transactions = stats.transactions.filter(t => t.timestamp > monthAgo);
    
    db.cache['stats.json'] = stats;
    db.queueSave('stats.json');
    
    // Удаляем истёкшие коды привязки
    const codes = db.getLinkCodes();
    const now = Date.now();
    for (const code of Object.keys(codes)) {
      if (codes[code].expiresAt < now) {
        delete codes[code];
      }
    }
    db.cache['linkCodes.json'] = codes;
    db.queueSave('linkCodes.json');
    
    logger.info('[Scheduler] Cleanup completed');
  }
}

module.exports = new SchedulerService();
