/**
 * FLASH BOT - Crypto Utils
 */

const crypto = require('crypto');

// Генерация случайного числа в диапазоне
function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Генерация случайного ID
function generateId(length = 8) {
  return crypto.randomBytes(length).toString('hex');
}

// Генерация кода привязки (6 цифр)
function generateLinkCode() {
  return String(randomInt(100000, 999999));
}

// Генерация реферального кода
function generateReferralCode() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

// Генерация промокода
function generatePromocode(length = 8) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = '';
  for (let i = 0; i < length; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

// Хэширование строки
function hash(str) {
  return crypto.createHash('sha256').update(str).digest('hex');
}

// Выбор случайного элемента из массива
function randomChoice(array) {
  return array[Math.floor(Math.random() * array.length)];
}

// Выбор элемента с учётом вероятностей
function weightedRandom(items) {
  // items = [{ value: 'a', chance: 50 }, { value: 'b', chance: 30 }, ...]
  const totalChance = items.reduce((sum, item) => sum + (item.chance || 0), 0);
  let random = Math.random() * totalChance;
  
  for (const item of items) {
    random -= item.chance || 0;
    if (random <= 0) {
      return item;
    }
  }
  
  return items[items.length - 1];
}

// Перемешивание массива
function shuffle(array) {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

// Проверка вероятности (0-100)
function checkChance(percent) {
  return Math.random() * 100 < percent;
}

module.exports = {
  randomInt,
  generateId,
  generateLinkCode,
  generateReferralCode,
  generatePromocode,
  hash,
  randomChoice,
  weightedRandom,
  shuffle,
  checkChance
};
