/**
 * FLASH BOT - Formatter Utils
 */

// Форматирование числа с разделителями
function formatNumber(num) {
  if (num === null || num === undefined) return '0';
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// Форматирование даты
function formatDate(timestamp) {
  if (!timestamp) return 'Неизвестно';
  const date = new Date(timestamp);
  return date.toLocaleDateString('ru-RU', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

// Форматирование длительности
function formatDuration(ms) {
  if (!ms || ms < 0) return '0 сек';
  
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (days > 0) return `${days} дн. ${hours % 24} ч.`;
  if (hours > 0) return `${hours} ч. ${minutes % 60} мин.`;
  if (minutes > 0) return `${minutes} мин. ${seconds % 60} сек.`;
  return `${seconds} сек.`;
}

// Форматирование кулдауна
function formatCooldown(ms) {
  if (!ms || ms <= 0) return null;
  
  const seconds = Math.ceil(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  
  if (hours > 0) return `${hours}:${String(minutes % 60).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
  if (minutes > 0) return `${minutes}:${String(seconds % 60).padStart(2, '0')}`;
  return `${seconds} сек`;
}

// Получить идентификатор игрока для сообщения
function getPlayerIdentifier(user, platform) {
  if (platform === 'vk') {
    return `@id${user.vkId || user.platformId}`;
  } else {
    if (user.telegramUsername) {
      return `@${user.telegramUsername}`;
    }
    return `@user${user.telegramId || user.platformId}`;
  }
}

// Прогресс-бар
function progressBar(current, max, length = 10) {
  const filled = Math.round((current / max) * length);
  const empty = length - filled;
  return '█'.repeat(filled) + '░'.repeat(empty);
}

// Форматирование процента
function formatPercent(value, decimals = 1) {
  return `${(value * 100).toFixed(decimals)}%`;
}

// Парсинг суммы из текста
function parseAmount(text) {
  if (!text) return null;
  
  // Убираем пробелы и запятые
  let cleaned = text.replace(/[\s,]/g, '').toLowerCase();
  
  // Проверяем на "всё" или "все"
  if (cleaned === 'всё' || cleaned === 'все' || cleaned === 'all') {
    return 'all';
  }
  
  // Проверяем на суффиксы
  let multiplier = 1;
  if (cleaned.endsWith('к') || cleaned.endsWith('k')) {
    multiplier = 1000;
    cleaned = cleaned.slice(0, -1);
  } else if (cleaned.endsWith('м') || cleaned.endsWith('m')) {
    multiplier = 1000000;
    cleaned = cleaned.slice(0, -1);
  } else if (cleaned.endsWith('кк') || cleaned.endsWith('kk')) {
    multiplier = 1000000;
    cleaned = cleaned.slice(0, -2);
  }
  
  const num = parseFloat(cleaned);
  if (isNaN(num)) return null;
  
  return Math.floor(num * multiplier);
}

// Получить тег по уровню
function getTagByLevel(level) {
  if (level >= 100) return 'Бог';
  if (level >= 90) return 'Легенда';
  if (level >= 70) return 'Магнат';
  if (level >= 50) return 'Мастер';
  if (level >= 30) return 'Профи';
  if (level >= 15) return 'Опытный';
  if (level >= 5) return 'Игрок';
  return 'Новичок';
}

// Получить опыт для уровня
function getExpForLevel(level) {
  return Math.floor(1000 * Math.pow(1.5, level - 1));
}

// Рассчитать уровень по опыту
function getLevelByExp(totalExp) {
  let level = 1;
  let expNeeded = 1000;
  let expSum = 0;
  
  while (expSum + expNeeded <= totalExp && level < 100) {
    expSum += expNeeded;
    level++;
    expNeeded = Math.floor(1000 * Math.pow(1.5, level - 1));
  }
  
  return { level, currentExp: totalExp - expSum, nextLevelExp: expNeeded };
}

// Сокращение большого числа
function shortNumber(num) {
  if (num >= 1000000000) return `${(num / 1000000000).toFixed(1)}B`;
  if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
  if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
  return num.toString();
}

module.exports = {
  formatNumber,
  formatDate,
  formatDuration,
  formatCooldown,
  getPlayerIdentifier,
  progressBar,
  formatPercent,
  parseAmount,
  getTagByLevel,
  getExpForLevel,
  getLevelByExp,
  shortNumber
};
