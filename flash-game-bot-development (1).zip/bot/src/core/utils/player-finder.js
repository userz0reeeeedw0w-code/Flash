/**
 * FLASH BOT - Player Finder
 * Поиск игроков по различным идентификаторам
 */

const db = require('../database/db.service');
const smartSearch = require('./smart-search');

class PlayerFinder {
  /**
   * Найти игрока по различным способам
   * @param {Object} options - Параметры поиска
   * @param {string} options.query - Поисковый запрос
   * @param {Object} options.replyTo - Данные ответа на сообщение
   * @param {string} options.platform - Платформа
   * @returns {Object|null} - Найденный пользователь
   */
  find(options) {
    const { query, replyTo, platform } = options;
    
    // 1. Поиск по ответу на сообщение (высший приоритет)
    if (replyTo) {
      const fromReply = this.findFromReply(replyTo, platform);
      if (fromReply) return fromReply;
    }
    
    // 2. Поиск по запросу
    if (query) {
      return smartSearch.smartSearch(query);
    }
    
    return null;
  }

  /**
   * Найти игрока из ответа на сообщение
   */
  findFromReply(replyTo, platform) {
    if (!replyTo) return null;
    
    // Для Telegram
    if (platform === 'telegram' && replyTo.from) {
      const tgId = replyTo.from.id.toString();
      return db.getUser('telegram', tgId);
    }
    
    // Для VK
    if (platform === 'vk' && replyTo.from_id) {
      const vkId = replyTo.from_id.toString();
      return db.getUser('vk', vkId);
    }
    
    return null;
  }

  /**
   * Найти игрока по UID
   */
  findByUid(uid) {
    return db.getUserByUid(parseInt(uid));
  }

  /**
   * Найти игрока по платформе и ID
   */
  findByPlatformId(platform, platformId) {
    return db.getUser(platform, platformId);
  }

  /**
   * Найти игрока по VK ID (@id123456789)
   */
  findByVkId(vkId) {
    // Убираем @id если есть
    const cleanId = vkId.replace(/^@?id/i, '');
    return smartSearch.findByVkId(cleanId);
  }

  /**
   * Найти игрока по Telegram username (@username)
   */
  findByTelegramUsername(username) {
    // Убираем @ если есть
    const cleanUsername = username.replace(/^@/, '');
    return smartSearch.findByTelegramUsername(cleanUsername);
  }

  /**
   * Найти игрока по ссылке VK
   */
  findByVkLink(link) {
    const match = link.match(/vk\.com\/(?:id)?(\d+)/i);
    if (match) {
      return smartSearch.findByVkId(match[1]);
    }
    return null;
  }

  /**
   * Найти игрока по ссылке Telegram
   */
  findByTelegramLink(link) {
    const match = link.match(/t\.me\/([\w]+)/i);
    if (match) {
      return smartSearch.findByTelegramUsername(match[1]);
    }
    return null;
  }

  /**
   * Парсинг игрока из текста команды
   * Возвращает найденного игрока и оставшиеся аргументы
   */
  parseFromCommand(args, context) {
    if (!args || args.length === 0) {
      return { player: null, remainingArgs: args };
    }

    // Проверяем первый аргумент
    const firstArg = args[0];
    
    // UID (просто число)
    if (/^\d+$/.test(firstArg)) {
      const player = this.findByUid(firstArg);
      return {
        player,
        remainingArgs: args.slice(1)
      };
    }
    
    // @id123456789 (VK)
    if (/^@id\d+$/i.test(firstArg)) {
      const player = this.findByVkId(firstArg);
      return {
        player,
        remainingArgs: args.slice(1)
      };
    }
    
    // @username (Telegram)
    if (/^@[\w]+$/i.test(firstArg) && !firstArg.toLowerCase().startsWith('@id')) {
      const player = this.findByTelegramUsername(firstArg);
      return {
        player,
        remainingArgs: args.slice(1)
      };
    }
    
    // Ссылка VK
    if (firstArg.includes('vk.com')) {
      const player = this.findByVkLink(firstArg);
      return {
        player,
        remainingArgs: args.slice(1)
      };
    }
    
    // Ссылка Telegram
    if (firstArg.includes('t.me')) {
      const player = this.findByTelegramLink(firstArg);
      return {
        player,
        remainingArgs: args.slice(1)
      };
    }
    
    // Не найдено по идентификатору
    return { player: null, remainingArgs: args };
  }

  /**
   * Валидация что найден нужный игрок
   */
  validate(player, options = {}) {
    if (!player) {
      return { valid: false, error: 'Игрок не найден' };
    }
    
    if (options.notSelf && options.currentUser && player.uid === options.currentUser.uid) {
      return { valid: false, error: 'Нельзя указать себя' };
    }
    
    if (options.notBanned && player.isBanned) {
      return { valid: false, error: 'Игрок заблокирован' };
    }
    
    if (options.minLevel && player.level < options.minLevel) {
      return { valid: false, error: `Требуется минимум ${options.minLevel} уровень` };
    }
    
    return { valid: true };
  }
}

module.exports = new PlayerFinder();
