/**
 * FLASH BOT - Smart Search Utils
 */

const db = require('../database/db.service');

/**
 * Умный поиск игрока
 * Приоритет:
 * 1. UID (число)
 * 2. VK ID (@id123456789)
 * 3. Telegram username (@username)
 * 4. Ссылка VK (vk.com/id123)
 * 5. Ссылка Telegram (t.me/username)
 */
function smartSearch(query) {
  if (!query) return null;
  
  const trimmed = query.trim();
  
  // 1. UID (просто число)
  if (/^\d+$/.test(trimmed)) {
    const uid = parseInt(trimmed);
    return db.getUserByUid(uid);
  }
  
  // 2. VK ID (@id123456789)
  if (/^@id\d+$/i.test(trimmed)) {
    const vkId = trimmed.slice(3);
    return findByVkId(vkId);
  }
  
  // 3. Telegram username (@username)
  if (/^@[\w]+$/i.test(trimmed) && !trimmed.toLowerCase().startsWith('@id')) {
    const username = trimmed.slice(1);
    return findByTelegramUsername(username);
  }
  
  // 4. Ссылка VK (vk.com/id123 или vk.com/username)
  const vkMatch = trimmed.match(/vk\.com\/(?:id)?(\d+)/i);
  if (vkMatch) {
    return findByVkId(vkMatch[1]);
  }
  
  // 5. Ссылка Telegram (t.me/username)
  const tgMatch = trimmed.match(/t\.me\/([\w]+)/i);
  if (tgMatch) {
    return findByTelegramUsername(tgMatch[1]);
  }
  
  // 6. Попытка найти по VK домену
  const vkDomainMatch = trimmed.match(/vk\.com\/([\w]+)/i);
  if (vkDomainMatch && !/^\d+$/.test(vkDomainMatch[1])) {
    // Это домен, нужно резолвить через VK API
    // Пока просто ищем в базе
    const users = db.getUsers();
    const found = Object.values(users).find(u => 
      u.vkDomain && u.vkDomain.toLowerCase() === vkDomainMatch[1].toLowerCase()
    );
    return found || null;
  }
  
  return null;
}

// Поиск по VK ID
function findByVkId(vkId) {
  const users = db.getUsers();
  return Object.values(users).find(u => 
    u.vkId === vkId || u.platformId === vkId
  ) || null;
}

// Поиск по Telegram username
function findByTelegramUsername(username) {
  const users = db.getUsers();
  return Object.values(users).find(u => 
    u.telegramUsername && u.telegramUsername.toLowerCase() === username.toLowerCase()
  ) || null;
}

// Поиск по любому идентификатору
function findByIdentifier(identifier) {
  if (!identifier) return null;
  
  // Убираем @ если есть
  const cleaned = identifier.startsWith('@') ? identifier : '@' + identifier;
  
  return smartSearch(cleaned);
}

// Получить идентификатор для отображения
function getDisplayIdentifier(user, platform) {
  if (platform === 'vk' || user.platform === 'vk') {
    return `@id${user.vkId || user.platformId}`;
  } else {
    if (user.telegramUsername) {
      return `@${user.telegramUsername}`;
    }
    return `@user${user.telegramId || user.platformId}`;
  }
}

// Парсинг игрока из аргументов команды
function parsePlayerFromArgs(args, fromUser) {
  if (!args || args.length === 0) return null;
  
  const firstArg = args[0];
  
  // UID
  if (/^\d+$/.test(firstArg)) {
    return {
      user: db.getUserByUid(parseInt(firstArg)),
      consumedArgs: 1
    };
  }
  
  // @id или @username
  if (firstArg.startsWith('@')) {
    const user = smartSearch(firstArg);
    return {
      user,
      consumedArgs: 1
    };
  }
  
  // Ссылка
  if (firstArg.includes('vk.com') || firstArg.includes('t.me')) {
    const user = smartSearch(firstArg);
    return {
      user,
      consumedArgs: 1
    };
  }
  
  return null;
}

module.exports = {
  smartSearch,
  findByVkId,
  findByTelegramUsername,
  findByIdentifier,
  getDisplayIdentifier,
  parsePlayerFromArgs
};
