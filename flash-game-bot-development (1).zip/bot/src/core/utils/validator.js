/**
 * FLASH BOT - Validator Utils
 */

const config = require('../../config');

// Проверка достаточности денег
function hasEnoughMoney(user, amount) {
  return user.money >= amount;
}

// Проверка достаточности энергии
function hasEnoughEnergy(user, amount) {
  return user.energy >= amount;
}

// Проверка кулдауна
function isOnCooldown(user, action) {
  const cooldowns = user.cooldowns || {};
  const lastTime = cooldowns[action];
  
  if (!lastTime) return { onCooldown: false, remaining: 0 };
  
  const cooldownMs = (config.cooldowns[action] || 0) * 60 * 1000;
  const elapsed = Date.now() - lastTime;
  
  if (elapsed < cooldownMs) {
    return { onCooldown: true, remaining: cooldownMs - elapsed };
  }
  
  return { onCooldown: false, remaining: 0 };
}

// Проверка дневного лимита
function checkDailyLimit(user, action) {
  const limits = user.dailyLimits || {};
  const maxLimit = config.limits.daily[action] || Infinity;
  const currentCount = limits[action] || 0;
  
  return {
    canDo: currentCount < maxLimit,
    current: currentCount,
    max: maxLimit,
    remaining: Math.max(0, maxLimit - currentCount)
  };
}

// Проверка бана
function isBanned(user) {
  return user.isBanned === true;
}

// Проверка мута
function isMuted(user) {
  if (!user.isMuted) return false;
  if (user.muteUntil && Date.now() > user.muteUntil) {
    return false;
  }
  return true;
}

// Проверка админа
function isAdmin(user, platform) {
  if (platform === 'telegram') {
    return user.telegramId === config.telegram.adminId.toString() || 
           user.platformId === config.telegram.adminId.toString();
  } else if (platform === 'vk') {
    return user.vkId === config.vk.adminId.toString() || 
           user.platformId === config.vk.adminId.toString();
  }
  return false;
}

// Проверка привилегии
function hasPrivilege(user, minPrivilege) {
  const privileges = ['none', 'vip', 'premium', 'legend', 'ultimate'];
  const userIndex = privileges.indexOf(user.privilege || 'none');
  const minIndex = privileges.indexOf(minPrivilege);
  return userIndex >= minIndex;
}

// Проверка уровня
function hasMinLevel(user, minLevel) {
  return user.level >= minLevel;
}

// Проверка членства в клане
function isInClan(user) {
  return user.clanId !== null && user.clanId !== undefined;
}

// Проверка роли в клане
function hasClanRole(user, roles) {
  if (!isInClan(user)) return false;
  if (!Array.isArray(roles)) roles = [roles];
  return roles.includes(user.clanRole);
}

// Проверка капчи
function needsCaptcha(user) {
  if (user.captchaPending) return true;
  if (user.captchaBlockedUntil && Date.now() < user.captchaBlockedUntil) {
    return true;
  }
  return false;
}

// Валидация никнейма
function isValidNickname(nickname) {
  if (!nickname || typeof nickname !== 'string') return false;
  if (nickname.length < 2 || nickname.length > 20) return false;
  // Разрешаем буквы, цифры, пробелы, подчёркивания
  return /^[\wа-яА-ЯёЁ\s]+$/.test(nickname);
}

// Валидация названия клана
function isValidClanName(name) {
  if (!name || typeof name !== 'string') return false;
  if (name.length < 3 || name.length > 20) return false;
  return /^[\wа-яА-ЯёЁ\s]+$/.test(name);
}

// Валидация суммы
function isValidAmount(amount, min = 1, max = Infinity) {
  if (typeof amount !== 'number' || isNaN(amount)) return false;
  if (!Number.isInteger(amount)) return false;
  return amount >= min && amount <= max;
}

// Расчёт модификатора дохода (анти-фарм)
function calculateIncomeModifier(user, action) {
  let modifier = 1;
  
  // Проверка привилегий
  if (user.privilege && config.privileges[user.privilege]) {
    modifier *= config.privileges[user.privilege].incomeMultiplier || 1;
  }
  
  // Проверка энергии (усталость)
  const energyPercent = user.energy / user.maxEnergy;
  if (energyPercent < 0.1) {
    modifier *= config.antiFarm.fatigue.low10;
  } else if (energyPercent < 0.2) {
    modifier *= config.antiFarm.fatigue.low20;
  }
  
  // Проверка лимитов (димминг)
  const dailyCount = (user.dailyLimits || {})[action] || 0;
  const baseLimit = config.limits.daily[action] || 10;
  
  if (dailyCount < 5) {
    modifier *= config.antiFarm.dimming.first5;
  } else if (dailyCount < 10) {
    modifier *= config.antiFarm.dimming.next5;
  } else if (dailyCount < 15) {
    modifier *= config.antiFarm.dimming.next5_2;
  } else {
    modifier *= config.antiFarm.dimming.rest;
  }
  
  // Проверка превышения лимита
  if (dailyCount >= baseLimit * 3) {
    modifier = 0; // Блокировка
  } else if (dailyCount >= baseLimit * 2) {
    modifier *= config.antiFarm.overLimit.x2;
  } else if (dailyCount >= baseLimit) {
    modifier *= config.antiFarm.overLimit.x1;
  }
  
  return modifier;
}

module.exports = {
  hasEnoughMoney,
  hasEnoughEnergy,
  isOnCooldown,
  checkDailyLimit,
  isBanned,
  isMuted,
  isAdmin,
  hasPrivilege,
  hasMinLevel,
  isInClan,
  hasClanRole,
  needsCaptcha,
  isValidNickname,
  isValidClanName,
  isValidAmount,
  calculateIncomeModifier
};
