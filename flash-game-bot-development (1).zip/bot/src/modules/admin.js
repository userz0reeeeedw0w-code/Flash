/**
 * FLASH BOT - Admin Module
 * Команды: рассылка, выдать, бан, статистика, логи, капча, промокоды и т.д.
 */

const db = require('../core/database/db.service');
const config = require('../config');
const logger = require('../core/logger');
const { messages } = require('../config/messages');
const { formatNumber, formatDate, getPlayerIdentifier, parseAmount } = require('../core/utils/formatter');
const { isAdmin } = require('../core/utils/validator');
const { generatePromocode, randomChoice } = require('../core/utils/crypto');
const playerFinder = require('../core/utils/player-finder');
const { EMOJI, CAPTCHA_QUESTIONS } = require('../config/constants');

const SEPARATOR = '━━━━━━━━━━━━━━━━━━━━';

class AdminModule {
  constructor() {
    this.commands = {
      'broadcast': this.broadcast.bind(this),
      'give': this.give.bind(this),
      'giveRubles': this.giveRubles.bind(this),
      'giveBitcoin': this.giveBitcoin.bind(this),
      'giveDiamonds': this.giveDiamonds.bind(this),
      'giveExp': this.giveExp.bind(this),
      'giveLevel': this.giveLevel.bind(this),
      'givePrivilege': this.givePrivilege.bind(this),
      'giveCar': this.giveCar.bind(this),
      'ban': this.ban.bind(this),
      'unban': this.unban.bind(this),
      'mute': this.mute.bind(this),
      'unmute': this.unmute.bind(this),
      'kick': this.kick.bind(this),
      'bossCreate': this.bossCreate.bind(this),
      'bossEnd': this.bossEnd.bind(this),
      'eventCreate': this.eventCreate.bind(this),
      'eventEnd': this.eventEnd.bind(this),
      'promocodeCreate': this.promocodeCreate.bind(this),
      'promocodeDelete': this.promocodeDelete.bind(this),
      'setBtcRate': this.setBtcRate.bind(this),
      'updateRate': this.updateRate.bind(this),
      'captcha': this.captcha.bind(this),
      'captchaAnswer': this.captchaAnswer.bind(this),
      'captchaStatus': this.captchaStatus.bind(this),
      'captchaReset': this.captchaReset.bind(this),
      'statistics': this.statistics.bind(this),
      'statsUsers': this.statsUsers.bind(this),
      'statsActive': this.statsActive.bind(this),
      'statsCommands': this.statsCommands.bind(this),
      'logs': this.logs.bind(this),
      'logsErrors': this.logsErrors.bind(this),
      'logsCommands': this.logsCommands.bind(this),
      'logsTransactions': this.logsTransactions.bind(this),
      'logsClear': this.logsClear.bind(this),
      'status': this.status.bind(this),
      'restart': this.restart.bind(this),
      'stop': this.stop.bind(this),
      'keyboardOn': this.keyboardOn.bind(this),
      'keyboardOff': this.keyboardOff.bind(this),
      'keyboardStatus': this.keyboardStatus.bind(this),
      'broadcastGroup': this.broadcastGroup.bind(this),
      'broadcastLevel': this.broadcastLevel.bind(this),
      'broadcastOnline': this.broadcastOnline.bind(this),
      'broadcastClan': this.broadcastClan.bind(this),
      'broadcastStats': this.broadcastStats.bind(this)
    };
  }

  // Проверка админа
  checkAdmin(user, context) {
    return isAdmin(user, context.platform);
  }

  // Рассылка
  async broadcast(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    if (args.length === 0) {
      return {
        text: `${identifier} 📢 РАССЫЛКА
${SEPARATOR}
📝 Использование: рассылка [текст]

💡 Типы рассылок:
• рассылка [текст] — всем
• рассылка группа [группа] [текст]
• рассылка уровень [уровень] [текст]
• рассылка онлайн [текст]
• рассылка клан [UID] [текст]`,
        keyboard: 'main'
      };
    }

    const text = args.join(' ');
    const users = Object.values(db.getUsers());

    // Добавляем рассылку в очередь
    const mailing = db.addMailing({
      type: 'all',
      text,
      targetCount: users.length,
      sentCount: 0,
      failedCount: 0,
      createdBy: user.uid
    });

    return {
      text: `${identifier} ${EMOJI.success} Рассылка создана!
${SEPARATOR}
📝 ID: ${mailing.id}
👥 Получателей: ${users.length}
📊 Статус: В очереди`,
      keyboard: 'main'
    };
  }

  // Выдать деньги
  async give(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    if (args.length < 2) {
      return {
        text: `${identifier} 💰 ВЫДАЧА
${SEPARATOR}
📝 Использование: выдать [UID] [сумма]
💡 Пример: выдать 1 10000`,
        keyboard: 'main'
      };
    }

    const targetUid = parseInt(args[0]);
    const amount = parseAmount(args[1]);

    if (!amount || amount < 1) {
      return { text: `${identifier} ${EMOJI.error} Неверная сумма!`, keyboard: 'main' };
    }

    const targetUser = db.getUserByUid(targetUid);
    
    if (!targetUser) {
      return { text: messages.errors.playerNotFound(identifier), keyboard: 'main' };
    }

    db.updateUserByUid(targetUid, {
      money: targetUser.money + amount
    });

    const targetIdentifier = getPlayerIdentifier(targetUser, targetUser.platform);

    logger.info(`[Admin] ${identifier} gave ${amount}$ to ${targetIdentifier}`);

    return {
      text: `${identifier} ${EMOJI.success} Выдано!
${SEPARATOR}
👤 Получатель: ${targetIdentifier} (UID: #${targetUid})
💰 Сумма: ${formatNumber(amount)}$`,
      keyboard: 'main'
    };
  }

  // Выдать рубли
  async giveRubles(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    if (args.length < 2) {
      return { text: `${identifier} ${EMOJI.error} Использование: выдать рубли [UID] [сумма]`, keyboard: 'main' };
    }

    const targetUid = parseInt(args[0]);
    const amount = parseAmount(args[1]);

    const targetUser = db.getUserByUid(targetUid);
    
    if (!targetUser) {
      return { text: messages.errors.playerNotFound(identifier), keyboard: 'main' };
    }

    db.updateUserByUid(targetUid, {
      rubles: targetUser.rubles + amount
    });

    return {
      text: `${identifier} ${EMOJI.success} Выдано ${formatNumber(amount)}₽ игроку UID #${targetUid}`,
      keyboard: 'main'
    };
  }

  // Выдать биткоин
  async giveBitcoin(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    if (args.length < 2) {
      return { text: `${identifier} ${EMOJI.error} Использование: выдать биткоин [UID] [количество]`, keyboard: 'main' };
    }

    const targetUid = parseInt(args[0]);
    const amount = parseFloat(args[1]);

    const targetUser = db.getUserByUid(targetUid);
    
    if (!targetUser) {
      return { text: messages.errors.playerNotFound(identifier), keyboard: 'main' };
    }

    db.updateUserByUid(targetUid, {
      bitcoin: targetUser.bitcoin + amount
    });

    return {
      text: `${identifier} ${EMOJI.success} Выдано ${amount}₿ игроку UID #${targetUid}`,
      keyboard: 'main'
    };
  }

  // Выдать алмазы
  async giveDiamonds(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    if (args.length < 2) {
      return { text: `${identifier} ${EMOJI.error} Использование: выдать алмазы [UID] [количество]`, keyboard: 'main' };
    }

    const targetUid = parseInt(args[0]);
    const amount = parseInt(args[1]);

    const targetUser = db.getUserByUid(targetUid);
    
    if (!targetUser) {
      return { text: messages.errors.playerNotFound(identifier), keyboard: 'main' };
    }

    db.updateUserByUid(targetUid, {
      diamonds: targetUser.diamonds + amount
    });

    return {
      text: `${identifier} ${EMOJI.success} Выдано ${amount}💎 игроку UID #${targetUid}`,
      keyboard: 'main'
    };
  }

  // Выдать опыт
  async giveExp(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    if (args.length < 2) {
      return { text: `${identifier} ${EMOJI.error} Использование: выдать опыт [UID] [количество]`, keyboard: 'main' };
    }

    const targetUid = parseInt(args[0]);
    const amount = parseInt(args[1]);

    const targetUser = db.getUserByUid(targetUid);
    
    if (!targetUser) {
      return { text: messages.errors.playerNotFound(identifier), keyboard: 'main' };
    }

    db.updateUserByUid(targetUid, {
      experience: targetUser.experience + amount
    });

    return {
      text: `${identifier} ${EMOJI.success} Выдано ${amount}⭐ опыта игроку UID #${targetUid}`,
      keyboard: 'main'
    };
  }

  // Выдать уровень
  async giveLevel(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    if (args.length < 2) {
      return { text: `${identifier} ${EMOJI.error} Использование: выдать уровень [UID] [уровень]`, keyboard: 'main' };
    }

    const targetUid = parseInt(args[0]);
    const level = parseInt(args[1]);

    const targetUser = db.getUserByUid(targetUid);
    
    if (!targetUser) {
      return { text: messages.errors.playerNotFound(identifier), keyboard: 'main' };
    }

    db.updateUserByUid(targetUid, {
      level: level
    });

    return {
      text: `${identifier} ${EMOJI.success} Установлен ${level} уровень игроку UID #${targetUid}`,
      keyboard: 'main'
    };
  }

  // Выдать привилегию
  async givePrivilege(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    if (args.length < 3) {
      return {
        text: `${identifier} ${EMOJI.error} Использование: выдать привилегию [UID] [тип] [дней]
💡 Типы: vip, premium, legend, ultimate`,
        keyboard: 'main'
      };
    }

    const targetUid = parseInt(args[0]);
    const privType = args[1].toLowerCase();
    const days = parseInt(args[2]);

    if (!['vip', 'premium', 'legend', 'ultimate'].includes(privType)) {
      return { text: `${identifier} ${EMOJI.error} Неверный тип привилегии!`, keyboard: 'main' };
    }

    const targetUser = db.getUserByUid(targetUid);
    
    if (!targetUser) {
      return { text: messages.errors.playerNotFound(identifier), keyboard: 'main' };
    }

    const expiresAt = Date.now() + days * 24 * 60 * 60 * 1000;

    db.updateUserByUid(targetUid, {
      privilege: privType,
      privilegeExpires: expiresAt
    });

    return {
      text: `${identifier} ${EMOJI.success} Выдана привилегия ${privType.toUpperCase()} на ${days} дней игроку UID #${targetUid}`,
      keyboard: 'main'
    };
  }

  // Выдать машину
  async giveCar(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    return {
      text: `${identifier} 🚗 ВЫДАЧА МАШИНЫ
${SEPARATOR}
🔧 Функция в разработке...`,
      keyboard: 'main'
    };
  }

  // Бан
  async ban(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    if (args.length < 1) {
      return { text: `${identifier} ${EMOJI.error} Использование: бан [UID] [причина]`, keyboard: 'main' };
    }

    const targetUid = parseInt(args[0]);
    const reason = args.slice(1).join(' ') || 'Не указана';

    const targetUser = db.getUserByUid(targetUid);
    
    if (!targetUser) {
      return { text: messages.errors.playerNotFound(identifier), keyboard: 'main' };
    }

    db.updateUserByUid(targetUid, {
      isBanned: true,
      banReason: reason
    });

    logger.info(`[Admin] ${identifier} banned UID #${targetUid}: ${reason}`);

    return {
      text: `${identifier} ${EMOJI.success} Игрок заблокирован!
${SEPARATOR}
🆔 UID: #${targetUid}
📝 Причина: ${reason}`,
      keyboard: 'main'
    };
  }

  // Разбан
  async unban(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    if (args.length < 1) {
      return { text: `${identifier} ${EMOJI.error} Использование: разбан [UID]`, keyboard: 'main' };
    }

    const targetUid = parseInt(args[0]);
    const targetUser = db.getUserByUid(targetUid);
    
    if (!targetUser) {
      return { text: messages.errors.playerNotFound(identifier), keyboard: 'main' };
    }

    db.updateUserByUid(targetUid, {
      isBanned: false,
      banReason: null
    });

    return {
      text: `${identifier} ${EMOJI.success} Игрок разблокирован! UID: #${targetUid}`,
      keyboard: 'main'
    };
  }

  // Мут
  async mute(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    if (args.length < 2) {
      return { text: `${identifier} ${EMOJI.error} Использование: мут [UID] [минут]`, keyboard: 'main' };
    }

    const targetUid = parseInt(args[0]);
    const minutes = parseInt(args[1]);

    const targetUser = db.getUserByUid(targetUid);
    
    if (!targetUser) {
      return { text: messages.errors.playerNotFound(identifier), keyboard: 'main' };
    }

    const muteUntil = Date.now() + minutes * 60 * 1000;

    db.updateUserByUid(targetUid, {
      isMuted: true,
      muteUntil
    });

    return {
      text: `${identifier} ${EMOJI.success} Мут выдан на ${minutes} минут! UID: #${targetUid}`,
      keyboard: 'main'
    };
  }

  // Размут
  async unmute(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    if (args.length < 1) {
      return { text: `${identifier} ${EMOJI.error} Использование: размут [UID]`, keyboard: 'main' };
    }

    const targetUid = parseInt(args[0]);
    const targetUser = db.getUserByUid(targetUid);
    
    if (!targetUser) {
      return { text: messages.errors.playerNotFound(identifier), keyboard: 'main' };
    }

    db.updateUserByUid(targetUid, {
      isMuted: false,
      muteUntil: null
    });

    return {
      text: `${identifier} ${EMOJI.success} Мут снят! UID: #${targetUid}`,
      keyboard: 'main'
    };
  }

  // Кик
  async kick(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    return {
      text: `${identifier} 👢 КИК
${SEPARATOR}
ℹ️ Для кика из клана используйте: клан удалить [UID]`,
      keyboard: 'main'
    };
  }

  // Создание босса
  async bossCreate(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    if (args.length < 3) {
      return {
        text: `${identifier} ${EMOJI.error} Использование: босс создать [название] [HP] [награда]
💡 Пример: босс создать Дракон 10000 50000`,
        keyboard: 'main'
      };
    }

    const name = args[0];
    const hp = parseInt(args[1]);
    const reward = parseInt(args[2]);

    const boss = {
      name,
      level: 1,
      maxHp: hp,
      currentHp: hp,
      reward,
      participants: [],
      spawnedAt: Date.now(),
      active: true
    };

    db.setBoss(boss);

    return {
      text: `${identifier} ${EMOJI.success} Босс создан!
${SEPARATOR}
${EMOJI.boss} ${name}
❤️ HP: ${formatNumber(hp)}
💰 Награда: ${formatNumber(reward)}$`,
      keyboard: 'main'
    };
  }

  // Завершение босса
  async bossEnd(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    db.setBoss(null);

    return {
      text: `${identifier} ${EMOJI.success} Босс удалён!`,
      keyboard: 'main'
    };
  }

  // Создание события
  async eventCreate(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    return {
      text: `${identifier} ${EMOJI.event} СОЗДАНИЕ СОБЫТИЯ
${SEPARATOR}
🔧 Функция в разработке...`,
      keyboard: 'main'
    };
  }

  // Завершение события
  async eventEnd(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    return {
      text: `${identifier} ${EMOJI.event} ЗАВЕРШЕНИЕ СОБЫТИЯ
${SEPARATOR}
🔧 Функция в разработке...`,
      keyboard: 'main'
    };
  }

  // Создание промокода
  async promocodeCreate(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    if (args.length < 3) {
      return {
        text: `${identifier} ${EMOJI.error} Использование: промокод создать [код] [тип] [значение] [лимит]
💡 Типы: money, rubles, diamonds, experience
💡 Пример: промокод создать NEWYEAR money 10000 100`,
        keyboard: 'main'
      };
    }

    let code = args[0].toUpperCase();
    const rewardType = args[1].toLowerCase();
    const rewardValue = parseInt(args[2]);
    const limit = args[3] ? parseInt(args[3]) : null;

    if (code === 'RANDOM') {
      code = generatePromocode();
    }

    if (!['money', 'rubles', 'diamonds', 'experience'].includes(rewardType)) {
      return { text: `${identifier} ${EMOJI.error} Неверный тип награды!`, keyboard: 'main' };
    }

    const existingPromo = db.getPromocode(code);
    if (existingPromo) {
      return { text: `${identifier} ${EMOJI.error} Промокод уже существует!`, keyboard: 'main' };
    }

    db.createPromocode(code, {
      rewardType,
      rewardValue,
      limit,
      createdBy: user.uid
    });

    return {
      text: `${identifier} ${EMOJI.success} Промокод создан!
${SEPARATOR}
🎟️ Код: ${code}
🎁 Награда: ${rewardType} — ${rewardValue}
📊 Лимит: ${limit || 'Без лимита'}`,
      keyboard: 'main'
    };
  }

  // Удаление промокода
  async promocodeDelete(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    if (args.length < 1) {
      return { text: `${identifier} ${EMOJI.error} Укажите код промокода!`, keyboard: 'main' };
    }

    const code = args[0].toUpperCase();
    const promo = db.getPromocode(code);

    if (!promo) {
      return { text: `${identifier} ${EMOJI.error} Промокод не найден!`, keyboard: 'main' };
    }

    db.deletePromocode(code);

    return {
      text: `${identifier} ${EMOJI.success} Промокод ${code} удалён!`,
      keyboard: 'main'
    };
  }

  // Установка курса BTC
  async setBtcRate(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    if (args.length < 1) {
      return { text: `${identifier} ${EMOJI.error} Укажите курс!`, keyboard: 'main' };
    }

    const rate = parseInt(args[0]);

    db.updateConfig({
      btcRate: rate,
      lastBtcUpdate: Date.now()
    });

    return {
      text: `${identifier} ${EMOJI.success} Курс BTC установлен: ${formatNumber(rate)}$`,
      keyboard: 'main'
    };
  }

  // Обновление курса
  async updateRate(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    const newRate = Math.floor(50000 + Math.random() * 100000);

    db.updateConfig({
      btcRate: newRate,
      lastBtcUpdate: Date.now()
    });

    return {
      text: `${identifier} ${EMOJI.success} Курс BTC обновлён: ${formatNumber(newRate)}$`,
      keyboard: 'main'
    };
  }

  // Капча - отправить
  async captcha(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    // Если у пользователя уже есть капча
    if (user.captchaPending) {
      return {
        text: `${identifier} ⚠️ У вас уже есть активная капча!
${SEPARATOR}
❓ ${user.captchaPending.question}
💡 Ответьте: капча ответ [ответ]`,
        keyboard: 'main'
      };
    }

    // Выбираем случайный вопрос
    const captcha = randomChoice(CAPTCHA_QUESTIONS);

    db.updateUser(context.platform, context.userId, {
      captchaPending: {
        question: captcha.question,
        answer: captcha.answer,
        alternatives: captcha.alternatives || [],
        createdAt: Date.now()
      },
      captchaAttempts: 0
    });

    return {
      text: messages.captcha(identifier, captcha.question),
      keyboard: 'main'
    };
  }

  // Ответ на капчу
  async captchaAnswer(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (!user.captchaPending) {
      return { text: `${identifier} ${EMOJI.info} У вас нет активной капчи.`, keyboard: 'main' };
    }

    if (args.length === 0) {
      return { text: `${identifier} ${EMOJI.error} Введите ответ!`, keyboard: 'main' };
    }

    const answer = args.join(' ').toLowerCase().trim();
    const correct = user.captchaPending.answer.toLowerCase();
    const alternatives = (user.captchaPending.alternatives || []).map(a => a.toLowerCase());

    const isCorrect = answer === correct || alternatives.includes(answer);

    if (isCorrect) {
      db.updateUser(context.platform, context.userId, {
        captchaPending: null,
        captchaAttempts: 0,
        money: user.money + config.captcha.verifyBonus
      });

      return {
        text: `${identifier} ${EMOJI.success} Капча пройдена!
${SEPARATOR}
🎁 Бонус: +${config.captcha.verifyBonus}$`,
        keyboard: 'main'
      };
    }

    // Неправильный ответ
    const attempts = (user.captchaAttempts || 0) + 1;

    if (attempts >= config.captcha.maxAttempts) {
      // Блокировка
      db.updateUser(context.platform, context.userId, {
        captchaPending: null,
        captchaAttempts: 0,
        captchaBlockedUntil: Date.now() + config.captcha.blockTime * 1000
      });

      return { text: messages.errors.captchaBlocked(identifier, config.captcha.blockTime * 1000), keyboard: 'main' };
    }

    db.updateUser(context.platform, context.userId, {
      captchaAttempts: attempts
    });

    return { text: messages.errors.captchaWrong(identifier, config.captcha.maxAttempts - attempts), keyboard: 'main' };
  }

  // Статус капчи
  async captchaStatus(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (user.captchaBlockedUntil && Date.now() < user.captchaBlockedUntil) {
      return {
        text: `${identifier} 🔒 Вы временно заблокированы!
⏳ Осталось: ${formatDate(user.captchaBlockedUntil)}`,
        keyboard: 'main'
      };
    }

    if (user.captchaPending) {
      return {
        text: `${identifier} ⚠️ Активная капча
${SEPARATOR}
❓ ${user.captchaPending.question}
📊 Попыток: ${user.captchaAttempts || 0}/${config.captcha.maxAttempts}`,
        keyboard: 'main'
      };
    }

    return { text: `${identifier} ${EMOJI.success} Капча не требуется.`, keyboard: 'main' };
  }

  // Сброс капчи (админ)
  async captchaReset(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    if (args.length < 1) {
      return { text: `${identifier} ${EMOJI.error} Укажите UID игрока!`, keyboard: 'main' };
    }

    const targetUid = parseInt(args[0]);
    const targetUser = db.getUserByUid(targetUid);
    
    if (!targetUser) {
      return { text: messages.errors.playerNotFound(identifier), keyboard: 'main' };
    }

    db.updateUserByUid(targetUid, {
      captchaPending: null,
      captchaAttempts: 0,
      captchaBlockedUntil: null
    });

    return {
      text: `${identifier} ${EMOJI.success} Капча сброшена для UID #${targetUid}`,
      keyboard: 'main'
    };
  }

  // Статистика
  async statistics(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    const users = db.getUsers();
    const clans = db.getClans();
    const stats = db.getStats();

    const totalUsers = Object.keys(users).length;
    const totalClans = Object.keys(clans).length;
    const totalCommands = Object.values(stats.commands || {}).reduce((a, b) => a + b, 0);

    return {
      text: `${identifier} 📊 СТАТИСТИКА БОТА
${SEPARATOR}
👥 Игроков: ${totalUsers}
🏛️ Кланов: ${totalClans}
📝 Команд выполнено: ${formatNumber(totalCommands)}
❌ Ошибок: ${(stats.errors || []).length}
💰 Транзакций: ${(stats.transactions || []).length}
${SEPARATOR}
💡 Подробнее: статистика пользователи`,
      keyboard: 'main'
    };
  }

  // Статистика пользователей
  async statsUsers(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    const users = Object.values(db.getUsers());
    const today = new Date().setHours(0, 0, 0, 0);
    const weekAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;

    const registeredToday = users.filter(u => u.registeredAt >= today).length;
    const activeWeek = users.filter(u => u.lastActivity >= weekAgo).length;
    const vipUsers = users.filter(u => u.privilege !== 'none').length;

    return {
      text: `${identifier} 👥 СТАТИСТИКА ПОЛЬЗОВАТЕЛЕЙ
${SEPARATOR}
📊 Всего: ${users.length}
🆕 Сегодня: ${registeredToday}
📈 Активных (неделя): ${activeWeek}
👑 С привилегиями: ${vipUsers}`,
      keyboard: 'main'
    };
  }

  // Статистика активных
  async statsActive(context, user, args) {
    return await this.statsUsers(context, user, args);
  }

  // Статистика команд
  async statsCommands(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    const stats = db.getStats();
    const commands = stats.commands || {};

    const sorted = Object.entries(commands)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10);

    let text = `${identifier} 📝 ТОП КОМАНД
${SEPARATOR}`;

    sorted.forEach(([cmd, count], i) => {
      text += `\n${i + 1}. ${cmd} — ${formatNumber(count)}`;
    });

    return { text, keyboard: 'main' };
  }

  // Логи
  async logs(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    return {
      text: `${identifier} 📋 ЛОГИ
${SEPARATOR}
💡 Команды:
• логи ошибки — последние ошибки
• логи команды — последние команды
• логи транзакции — последние транзакции
• логи очистить — очистка логов`,
      keyboard: 'main'
    };
  }

  // Логи ошибок
  async logsErrors(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    const logs = logger.getRecentLogs('errors.log', 10);

    let text = `${identifier} ❌ ПОСЛЕДНИЕ ОШИБКИ
${SEPARATOR}`;

    if (logs.length === 0) {
      text += '\n📭 Ошибок нет!';
    } else {
      logs.forEach(log => {
        text += `\n${log.slice(0, 100)}...`;
      });
    }

    return { text, keyboard: 'main' };
  }

  // Логи команд
  async logsCommands(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    const logs = logger.getRecentLogs('commands.log', 10);

    let text = `${identifier} 📝 ПОСЛЕДНИЕ КОМАНДЫ
${SEPARATOR}`;

    if (logs.length === 0) {
      text += '\n📭 Команд нет!';
    } else {
      logs.forEach(log => {
        text += `\n${log.slice(0, 80)}`;
      });
    }

    return { text, keyboard: 'main' };
  }

  // Логи транзакций
  async logsTransactions(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    const stats = db.getStats();
    const transactions = (stats.transactions || []).slice(-10);

    let text = `${identifier} 💰 ПОСЛЕДНИЕ ТРАНЗАКЦИИ
${SEPARATOR}`;

    if (transactions.length === 0) {
      text += '\n📭 Транзакций нет!';
    } else {
      transactions.reverse().forEach(t => {
        text += `\n#${t.fromUid} → #${t.toUid}: ${formatNumber(t.amount)}$`;
      });
    }

    return { text, keyboard: 'main' };
  }

  // Очистка логов
  async logsClear(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    logger.clearLogs('errors.log');
    logger.clearLogs('commands.log');

    return {
      text: `${identifier} ${EMOJI.success} Логи очищены!`,
      keyboard: 'main'
    };
  }

  // Статус бота
  async status(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    const uptime = process.uptime();
    const memory = process.memoryUsage();

    return {
      text: `${identifier} 🤖 СТАТУС БОТА
${SEPARATOR}
✅ Статус: Работает
⏱️ Аптайм: ${Math.floor(uptime / 3600)}ч ${Math.floor((uptime % 3600) / 60)}м
💾 RAM: ${Math.round(memory.heapUsed / 1024 / 1024)}MB
📅 Время сервера: ${new Date().toLocaleString('ru-RU')}`,
      keyboard: 'main'
    };
  }

  // Перезагрузка
  async restart(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    return {
      text: `${identifier} 🔄 ПЕРЕЗАГРУЗКА
${SEPARATOR}
⚠️ Используйте systemctl или pm2 для перезагрузки:
• sudo systemctl restart flash-bot
• pm2 restart flash-bot`,
      keyboard: 'main'
    };
  }

  // Остановка
  async stop(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    return {
      text: `${identifier} 🛑 ОСТАНОВКА
${SEPARATOR}
⚠️ Используйте systemctl или pm2:
• sudo systemctl stop flash-bot
• pm2 stop flash-bot`,
      keyboard: 'main'
    };
  }

  // Включение клавиатуры
  async keyboardOn(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    db.updateUser(context.platform, context.userId, {
      keyboardEnabled: true
    });

    return {
      text: `${identifier} ${EMOJI.success} Клавиатура включена!`,
      keyboard: 'main'
    };
  }

  // Выключение клавиатуры
  async keyboardOff(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    db.updateUser(context.platform, context.userId, {
      keyboardEnabled: false
    });

    return {
      text: `${identifier} ${EMOJI.success} Клавиатура выключена!`,
      keyboard: 'remove'
    };
  }

  // Статус клавиатуры
  async keyboardStatus(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    return {
      text: `${identifier} ⌨️ СТАТУС КЛАВИАТУРЫ
${SEPARATOR}
${user.keyboardEnabled !== false ? '✅ Включена' : '❌ Выключена'}
${SEPARATOR}
💡 Управление:
• клавиатура вкл
• клавиатура выкл`,
      keyboard: user.keyboardEnabled !== false ? 'main' : 'remove'
    };
  }

  // Рассылка по группе
  async broadcastGroup(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    return {
      text: `${identifier} 📢 РАССЫЛКА ПО ГРУППЕ
${SEPARATOR}
🔧 Функция в разработке...`,
      keyboard: 'main'
    };
  }

  // Рассылка по уровню
  async broadcastLevel(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    return {
      text: `${identifier} 📢 РАССЫЛКА ПО УРОВНЮ
${SEPARATOR}
🔧 Функция в разработке...`,
      keyboard: 'main'
    };
  }

  // Рассылка онлайн
  async broadcastOnline(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    return {
      text: `${identifier} 📢 РАССЫЛКА ОНЛАЙН
${SEPARATOR}
🔧 Функция в разработке...`,
      keyboard: 'main'
    };
  }

  // Рассылка по клану
  async broadcastClan(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    return {
      text: `${identifier} 📢 РАССЫЛКА ПО КЛАНУ
${SEPARATOR}
🔧 Функция в разработке...`,
      keyboard: 'main'
    };
  }

  // Статистика рассылок
  async broadcastStats(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !this.checkAdmin(user, context)) {
      return { text: messages.errors.adminOnly(identifier), keyboard: 'main' };
    }

    const mailings = db.getMailings();

    return {
      text: `${identifier} 📊 СТАТИСТИКА РАССЫЛОК
${SEPARATOR}
📨 Всего рассылок: ${mailings.length}
✅ Успешных: ${mailings.filter(m => m.status === 'completed').length}
⏳ В очереди: ${mailings.filter(m => m.status === 'pending').length}`,
      keyboard: 'main'
    };
  }
}

module.exports = new AdminModule();
