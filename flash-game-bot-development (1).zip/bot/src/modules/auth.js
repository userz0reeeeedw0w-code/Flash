/**
 * FLASH BOT - Auth Module
 * Команды: старт, привязать, код, привязка статус, привязка отвязать, помощь, инфо, правила, настройки, выход
 */

const db = require('../core/database/db.service');
const logger = require('../core/logger');
const { messages } = require('../config/messages');
const { formatNumber, formatDate, getPlayerIdentifier } = require('../core/utils/formatter');
const { generateLinkCode } = require('../core/utils/crypto');
const { mainKeyboard } = require('../config/keyboards');
const { EMOJI } = require('../config/constants');

const SEPARATOR = '━━━━━━━━━━━━━━━━━━━━';

class AuthModule {
  constructor() {
    this.commands = {
      'start': this.start.bind(this),
      'link': this.link.bind(this),
      'code': this.code.bind(this),
      'linkStatus': this.linkStatus.bind(this),
      'unlink': this.unlink.bind(this),
      'help': this.help.bind(this),
      'info': this.info.bind(this),
      'rules': this.rules.bind(this),
      'settings': this.settings.bind(this),
      'exit': this.exit.bind(this)
    };
  }

  // Регистрация/старт
  async start(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    
    // Уже зарегистрирован
    if (user) {
      return {
        text: `${identifier} ${EMOJI.info} Вы уже зарегистрированы!\n${SEPARATOR}\n🆔 Ваш UID: #${user.uid}\n📱 Платформа: ${context.platform === 'vk' ? 'VK' : 'Telegram'}\n\n📜 Используйте "помощь" для списка команд.`,
        keyboard: 'main'
      };
    }

    // Создаём нового пользователя
    const userData = {
      nickname: context.firstName || `Игрок`,
      username: context.username || null
    };

    // Проверяем реферальный код
    if (args.length > 0) {
      const refCode = args[0].toUpperCase();
      const referrer = this.findUserByReferralCode(refCode);
      if (referrer) {
        userData.referredBy = referrer.uid;
      }
    }

    const newUser = db.createUser(context.platform, context.userId, userData);
    
    // Начисляем бонус рефереру
    if (newUser.referredBy) {
      const referrer = db.getUserByUid(newUser.referredBy);
      if (referrer) {
        const refBonus = 5000;
        db.updateUserByUid(referrer.uid, {
          money: referrer.money + refBonus,
          referrals: [...(referrer.referrals || []), newUser.uid],
          referralsCount: (referrer.referralsCount || 0) + 1,
          referralEarnings: (referrer.referralEarnings || 0) + refBonus
        });
      }
    }

    logger.info(`[Auth] New user registered: UID #${newUser.uid}, platform: ${context.platform}`);

    return {
      text: messages.welcome(identifier, newUser.uid),
      keyboard: 'main'
    };
  }

  // Привязка аккаунта
  async link(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    // Генерируем код привязки
    const code = generateLinkCode();
    db.createLinkCode(user.uid, code);

    const otherPlatform = context.platform === 'vk' ? 'Telegram' : 'VK';

    return {
      text: `${identifier} 🔗 ПРИВЯЗКА АККАУНТА
${SEPARATOR}
Ваш код привязки: ${code}

📱 Отправьте этот код в боте на ${otherPlatform}:
код ${code}

⏱️ Код действителен 5 минут.

${EMOJI.warning} После привязки ваши аккаунты будут объединены!`,
      keyboard: 'main'
    };
  }

  // Ввод кода привязки
  async code(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    
    if (args.length === 0) {
      return {
        text: `${identifier} ${EMOJI.error} Укажите код привязки!\nПример: код 123456`,
        keyboard: 'main'
      };
    }

    const code = args[0];
    const linkCode = db.getLinkCode(code);

    if (!linkCode) {
      return {
        text: `${identifier} ${EMOJI.error} Неверный или истёкший код привязки!`,
        keyboard: 'main'
      };
    }

    const sourceUser = db.getUserByUid(linkCode.uid);
    
    if (!sourceUser) {
      return {
        text: `${identifier} ${EMOJI.error} Пользователь не найден!`,
        keyboard: 'main'
      };
    }

    // Проверяем что это другая платформа
    if (sourceUser.platform === context.platform) {
      return {
        text: `${identifier} ${EMOJI.error} Код создан на той же платформе!`,
        keyboard: 'main'
      };
    }

    // Если текущий пользователь не зарегистрирован
    if (!user) {
      // Добавляем данные текущей платформы к существующему аккаунту
      const updates = {};
      
      if (context.platform === 'telegram') {
        updates.telegramId = context.userId;
        updates.telegramUsername = context.username || null;
        updates.linkedAccounts = [...(sourceUser.linkedAccounts || []), {
          platform: 'telegram',
          platformId: context.userId,
          linkedAt: Date.now()
        }];
      } else {
        updates.vkId = context.userId;
        updates.linkedAccounts = [...(sourceUser.linkedAccounts || []), {
          platform: 'vk',
          platformId: context.userId,
          linkedAt: Date.now()
        }];
      }

      db.updateUserByUid(sourceUser.uid, updates);
      
      // Создаём алиас для новой платформы
      db.createUser(context.platform, context.userId, {
        ...sourceUser,
        ...updates,
        uid: sourceUser.uid // Сохраняем тот же UID
      });

      db.deleteLinkCode(code);

      logger.info(`[Auth] Account linked: UID #${sourceUser.uid}, added ${context.platform}`);

      return {
        text: `${identifier} ${EMOJI.success} АККАУНТ ПРИВЯЗАН!
${SEPARATOR}
🆔 Ваш UID: #${sourceUser.uid}
📱 Теперь доступен на обеих платформах!

💰 Баланс: ${formatNumber(sourceUser.money)}$
📈 Уровень: ${sourceUser.level}`,
        keyboard: 'main'
      };
    } else {
      // Оба аккаунта существуют - объединяем
      return {
        text: `${identifier} ${EMOJI.warning} У вас уже есть аккаунт на этой платформе!\n\nДля объединения аккаунтов обратитесь к администратору.`,
        keyboard: 'main'
      };
    }
  }

  // Статус привязки
  async linkStatus(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const linked = user.linkedAccounts || [];
    const hasTelegram = !!user.telegramId;
    const hasVk = !!user.vkId;

    let text = `${identifier} 🔗 СТАТУС ПРИВЯЗКИ
${SEPARATOR}
📱 Telegram: ${hasTelegram ? `✅ @${user.telegramUsername || user.telegramId}` : '❌ Не привязан'}
📱 VK: ${hasVk ? `✅ @id${user.vkId}` : '❌ Не привязан'}
${SEPARATOR}`;

    if (linked.length > 0) {
      text += `\n📋 История привязок:\n`;
      linked.forEach((l, i) => {
        text += `${i + 1}. ${l.platform} - ${formatDate(l.linkedAt)}\n`;
      });
    }

    if (!hasTelegram || !hasVk) {
      text += `\n💡 Для привязки используйте команду "привязать"`;
    }

    return { text, keyboard: 'main' };
  }

  // Отвязка аккаунта
  async unlink(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    // Проверяем что привязаны обе платформы
    if (!user.telegramId || !user.vkId) {
      return {
        text: `${identifier} ${EMOJI.error} У вас привязана только одна платформа!\nОтвязка невозможна.`,
        keyboard: 'main'
      };
    }

    return {
      text: `${identifier} ${EMOJI.warning} ОТВЯЗКА АККАУНТА
${SEPARATOR}
Для отвязки аккаунта обратитесь к администратору.

⚠️ При отвязке вы потеряете доступ к аккаунту с одной из платформ!`,
      keyboard: 'main'
    };
  }

  // Помощь
  async help(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    
    return {
      text: `${identifier} ${EMOJI.help} ПОМОЩЬ
${SEPARATOR}
📋 ОСНОВНЫЕ КОМАНДЫ:
• профиль — ваш профиль
• баланс — ваш баланс
• работать — заработать деньги
• бизнес — управление бизнесами
• магазин — магазин покупок
${SEPARATOR}
🎮 ИГРЫ:
• казино [сумма] — игра в казино
• гонка — гоночные соревнования
• рыбалка — ловля рыбы
• копать — добыча руды
${SEPARATOR}
👥 СОЦИАЛЬНЫЕ:
• клан — информация о клане
• босс — атака на босса
• перевод [игрок] [сумма] — перевод денег
${SEPARATOR}
🎁 БОНУСЫ:
• бонус — ежедневный бонус
• квесты — список заданий
• промокод [код] — активация кода
${SEPARATOR}
📍 ДОПОЛНИТЕЛЬНО:
• путь новичка — задания для новичков
• топ — рейтинги игроков
• достижения — ваши достижения
${SEPARATOR}
📜 Все команды без / и !
💡 Команды вводятся текстом`,
      keyboard: 'main'
    };
  }

  // Информация о боте
  async info(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    
    const users = db.getUsers();
    const totalUsers = Object.keys(users).length;
    const clans = db.getClans();
    const totalClans = Object.keys(clans).length;

    return {
      text: `${identifier} ℹ️ О БОТЕ FLASH
${SEPARATOR}
⚡ FLASH — Игровой бот 2026

📊 СТАТИСТИКА:
👥 Игроков: ${formatNumber(totalUsers)}
🏛️ Кланов: ${formatNumber(totalClans)}

🔗 ССЫЛКИ:
📱 Telegram: @gamebotflash_bot
📱 VK: vk.com/club237124814

👨‍💻 Разработчик: FLASH Team
📅 Версия: 1.0.0
${SEPARATOR}
⚡ Франшиза 2026`,
      keyboard: 'main'
    };
  }

  // Правила
  async rules(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    
    return {
      text: `${identifier} 📜 ПРАВИЛА ИГРЫ
${SEPARATOR}
1. ЗАПРЕЩЕНО:
❌ Использование багов/читов
❌ Мультиаккаунты для фарма
❌ Оскорбления игроков
❌ Реклама/спам
❌ Обман при сделках

2. ЭКОНОМИКА:
💰 Переводить можно только $
💰 Рубли — донатная валюта
💰 Курс BTC меняется

3. КЛАНЫ:
🏛️ Макс. 50 участников
🏛️ Войны между кланами
🏛️ Клановый опыт

4. НАКАЗАНИЯ:
⚠️ Предупреждение
⚠️ Мут 1-24 часа
⚠️ Бан на время
⚠️ Вечный бан

${SEPARATOR}
⚡ Играйте честно!`,
      keyboard: 'main'
    };
  }

  // Настройки
  async settings(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    return {
      text: `${identifier} ⚙️ НАСТРОЙКИ
${SEPARATOR}
⌨️ Клавиатура: ${user.keyboardEnabled !== false ? '✅ Включена' : '❌ Выключена'}
🔔 Уведомления: ${user.notifications !== false ? '✅ Включены' : '❌ Выключены'}
${SEPARATOR}
📝 КОМАНДЫ НАСТРОЕК:
• клавиатура вкл/выкл — управление клавиатурой
${SEPARATOR}
🔗 ПРИВЯЗКА:
📱 Telegram: ${user.telegramId ? '✅' : '❌'}
📱 VK: ${user.vkId ? '✅' : '❌'}

Для привязки: "привязать"`,
      keyboard: 'main'
    };
  }

  // Выход (просто информация)
  async exit(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    
    return {
      text: `${identifier} 👋 ДО СВИДАНИЯ!
${SEPARATOR}
Вы можете вернуться в любой момент.
Ваш прогресс сохранён.

💡 Напишите "старт" чтобы продолжить игру.`,
      keyboard: 'remove'
    };
  }

  // Поиск пользователя по реферальному коду
  findUserByReferralCode(code) {
    const users = db.getUsers();
    return Object.values(users).find(u => u.referralCode === code) || null;
  }
}

module.exports = new AuthModule();
