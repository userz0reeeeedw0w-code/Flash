/**
 * FLASH BOT - Business Module
 * Команды: бизнес, работа, фермы, принтеры, майнинг, магазин, донат
 */

const db = require('../core/database/db.service');
const config = require('../config');
const { messages } = require('../config/messages');
const { formatNumber, formatDate, formatDuration, getPlayerIdentifier, parseAmount, getExpForLevel } = require('../core/utils/formatter');
const { hasEnoughMoney, hasEnoughEnergy, isOnCooldown, checkDailyLimit, calculateIncomeModifier } = require('../core/utils/validator');
const { randomInt, weightedRandom } = require('../core/utils/crypto');
const { shopButtons } = require('../config/keyboards');
const { EMOJI, BUSINESSES, FARMS, PRINTERS, JOBS, ORES, CARS, CASES, PETS } = require('../config/constants');

const SEPARATOR = '━━━━━━━━━━━━━━━━━━━━';

class BusinessModule {
  constructor() {
    this.commands = {
      'business': this.business.bind(this),
      'businessList': this.businessList.bind(this),
      'businessBuy': this.businessBuy.bind(this),
      'businessInfo': this.businessInfo.bind(this),
      'businessCollect': this.businessCollect.bind(this),
      'businessUpgrade': this.businessUpgrade.bind(this),
      'businessSell': this.businessSell.bind(this),
      'job': this.job.bind(this),
      'jobList': this.jobList.bind(this),
      'work': this.work.bind(this),
      'jobQuit': this.jobQuit.bind(this),
      'jobInfo': this.jobInfo.bind(this),
      'farms': this.farms.bind(this),
      'farmBuy': this.farmBuy.bind(this),
      'farmInfo': this.farmInfo.bind(this),
      'farmCollect': this.farmCollect.bind(this),
      'farmUpgrade': this.farmUpgrade.bind(this),
      'printer': this.printer.bind(this),
      'printerBuy': this.printerBuy.bind(this),
      'printerCollect': this.printerCollect.bind(this),
      'printerRefuel': this.printerRefuel.bind(this),
      'mining': this.mining.bind(this),
      'mine': this.mine.bind(this),
      'pickaxe': this.pickaxe.bind(this),
      'pickaxeUpgrade': this.pickaxeUpgrade.bind(this),
      'oreSell': this.oreSell.bind(this),
      'shop': this.shop.bind(this),
      'shopBuy': this.shopBuy.bind(this),
      'donate': this.donate.bind(this),
      'donateBuy': this.donateBuy.bind(this),
      'vip': this.vip.bind(this),
      'premium': this.premium.bind(this),
      'legend': this.legend.bind(this),
      'ultimate': this.ultimate.bind(this)
    };
  }

  // Бизнес
  async business(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const businesses = user.businesses || [];

    if (businesses.length === 0) {
      return {
        text: `${identifier} ${EMOJI.business} БИЗНЕСЫ
${SEPARATOR}
📭 У вас нет бизнесов!

💡 Купите бизнес: бизнес купить [номер]
📋 Список бизнесов: бизнес список`,
        keyboard: 'main'
      };
    }

    let totalIncome = 0;
    let text = `${identifier} ${EMOJI.business} ВАШИ БИЗНЕСЫ (${businesses.length}/${config.limits.maxBusinesses})
${SEPARATOR}`;

    businesses.forEach((biz, i) => {
      const income = Math.floor(biz.income * (1 + biz.level * 0.2));
      totalIncome += income;
      const canCollect = !biz.lastCollect || (Date.now() - biz.lastCollect) > 30 * 60 * 1000;
      text += `\n${i + 1}. ${biz.name}
   📈 Ур.${biz.level} | 💰 ${formatNumber(income)}$/час
   ${canCollect ? '✅ Можно собрать' : `⏳ ${formatDuration(30 * 60 * 1000 - (Date.now() - biz.lastCollect))}`}`;
    });

    text += `\n${SEPARATOR}
💰 Общий доход: ${formatNumber(totalIncome)}$/час

📝 КОМАНДЫ:
• бизнес собрать [номер]
• бизнес улучшить [номер]
• бизнес продать [номер]`;

    return { text, keyboard: 'main' };
  }

  // Список бизнесов для покупки
  async businessList(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    
    let text = `${identifier} 🏪 МАГАЗИН БИЗНЕСОВ
${SEPARATOR}`;

    BUSINESSES.forEach(biz => {
      text += `\n${biz.id}. ${biz.name}
   💰 ${formatNumber(biz.price)}$ | 📈 ${formatNumber(biz.income)}$/час`;
    });

    text += `\n${SEPARATOR}
💡 Для покупки: бизнес купить [номер]`;

    return { text, keyboard: 'main' };
  }

  // Покупка бизнеса
  async businessBuy(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (args.length === 0) {
      return await this.businessList(context, user, args);
    }

    const bizId = parseInt(args[0]);
    const bizTemplate = BUSINESSES.find(b => b.id === bizId);

    if (!bizTemplate) {
      return { text: `${identifier} ${EMOJI.error} Бизнес не найден!`, keyboard: 'main' };
    }

    const currentBusinesses = user.businesses || [];
    
    if (currentBusinesses.length >= config.limits.maxBusinesses) {
      return { text: `${identifier} ${EMOJI.error} Достигнут лимит бизнесов (${config.limits.maxBusinesses})!`, keyboard: 'main' };
    }

    if (!hasEnoughMoney(user, bizTemplate.price)) {
      return { text: messages.errors.notEnoughMoney(identifier), keyboard: 'main' };
    }

    const newBusiness = {
      id: bizTemplate.id,
      name: bizTemplate.name,
      price: bizTemplate.price,
      income: bizTemplate.income,
      level: 1,
      lastCollect: null,
      purchasedAt: Date.now()
    };

    db.updateUser(context.platform, context.userId, {
      money: user.money - bizTemplate.price,
      businesses: [...currentBusinesses, newBusiness],
      totalSpent: (user.totalSpent || 0) + bizTemplate.price
    });

    return {
      text: `${identifier} ${EMOJI.success} Бизнес куплен!
${SEPARATOR}
🏢 ${bizTemplate.name}
💰 Потрачено: ${formatNumber(bizTemplate.price)}$
📈 Доход: ${formatNumber(bizTemplate.income)}$/час`,
      keyboard: 'main'
    };
  }

  // Сбор с бизнеса
  async businessCollect(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const businesses = user.businesses || [];
    
    if (businesses.length === 0) {
      return { text: `${identifier} ${EMOJI.error} У вас нет бизнесов!`, keyboard: 'main' };
    }

    // Проверка энергии
    if (!hasEnoughEnergy(user, config.energyCost.business)) {
      return { text: messages.errors.notEnoughEnergy(identifier), keyboard: 'main' };
    }

    // Если указан номер - собираем с конкретного
    if (args.length > 0) {
      const bizIndex = parseInt(args[0]) - 1;
      
      if (bizIndex < 0 || bizIndex >= businesses.length) {
        return { text: `${identifier} ${EMOJI.error} Бизнес не найден!`, keyboard: 'main' };
      }

      const biz = businesses[bizIndex];
      
      if (biz.lastCollect && (Date.now() - biz.lastCollect) < 30 * 60 * 1000) {
        const remaining = 30 * 60 * 1000 - (Date.now() - biz.lastCollect);
        return { text: messages.errors.cooldown(identifier, remaining), keyboard: 'main' };
      }

      const income = Math.floor(biz.income * (1 + biz.level * 0.2) * calculateIncomeModifier(user, 'business'));
      
      businesses[bizIndex].lastCollect = Date.now();
      
      db.updateUser(context.platform, context.userId, {
        money: user.money + income,
        energy: user.energy - config.energyCost.business,
        businesses,
        totalEarned: (user.totalEarned || 0) + income
      });

      return {
        text: `${identifier} ${EMOJI.success} Доход собран!
${SEPARATOR}
🏢 ${biz.name}
💰 Получено: ${formatNumber(income)}$`,
        keyboard: 'main'
      };
    }

    // Собираем со всех доступных
    let totalCollected = 0;
    let collectedCount = 0;

    businesses.forEach((biz, i) => {
      if (!biz.lastCollect || (Date.now() - biz.lastCollect) >= 30 * 60 * 1000) {
        const income = Math.floor(biz.income * (1 + biz.level * 0.2) * calculateIncomeModifier(user, 'business'));
        totalCollected += income;
        businesses[i].lastCollect = Date.now();
        collectedCount++;
      }
    });

    if (collectedCount === 0) {
      return { text: `${identifier} ${EMOJI.error} Нечего собирать! Подождите.`, keyboard: 'main' };
    }

    db.updateUser(context.platform, context.userId, {
      money: user.money + totalCollected,
      energy: user.energy - config.energyCost.business,
      businesses,
      totalEarned: (user.totalEarned || 0) + totalCollected
    });

    return {
      text: `${identifier} ${EMOJI.success} Доход собран!
${SEPARATOR}
🏢 Бизнесов: ${collectedCount}
💰 Получено: ${formatNumber(totalCollected)}$`,
      keyboard: 'main'
    };
  }

  // Улучшение бизнеса
  async businessUpgrade(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const businesses = user.businesses || [];
    
    if (args.length === 0 || businesses.length === 0) {
      return { text: `${identifier} ${EMOJI.error} Укажите номер бизнеса!\nПример: бизнес улучшить 1`, keyboard: 'main' };
    }

    const bizIndex = parseInt(args[0]) - 1;
    
    if (bizIndex < 0 || bizIndex >= businesses.length) {
      return { text: `${identifier} ${EMOJI.error} Бизнес не найден!`, keyboard: 'main' };
    }

    const biz = businesses[bizIndex];
    
    if (biz.level >= 10) {
      return { text: `${identifier} ${EMOJI.error} Бизнес уже максимального уровня!`, keyboard: 'main' };
    }

    const upgradeCost = Math.floor(biz.price * 0.5 * Math.pow(1.1, biz.level));
    
    if (!hasEnoughMoney(user, upgradeCost)) {
      return {
        text: `${identifier} ${EMOJI.error} Недостаточно средств!
${SEPARATOR}
💰 Стоимость улучшения: ${formatNumber(upgradeCost)}$`,
        keyboard: 'main'
      };
    }

    businesses[bizIndex].level += 1;
    const newIncome = Math.floor(biz.income * (1 + businesses[bizIndex].level * 0.2));

    db.updateUser(context.platform, context.userId, {
      money: user.money - upgradeCost,
      businesses
    });

    return {
      text: `${identifier} ${EMOJI.success} Бизнес улучшен!
${SEPARATOR}
🏢 ${biz.name}
📈 Новый уровень: ${businesses[bizIndex].level}
💰 Новый доход: ${formatNumber(newIncome)}$/час`,
      keyboard: 'main'
    };
  }

  // Продажа бизнеса
  async businessSell(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const businesses = user.businesses || [];
    
    if (args.length === 0 || businesses.length === 0) {
      return { text: `${identifier} ${EMOJI.error} Укажите номер бизнеса!\nПример: бизнес продать 1`, keyboard: 'main' };
    }

    const bizIndex = parseInt(args[0]) - 1;
    
    if (bizIndex < 0 || bizIndex >= businesses.length) {
      return { text: `${identifier} ${EMOJI.error} Бизнес не найден!`, keyboard: 'main' };
    }

    const biz = businesses[bizIndex];
    const sellPrice = Math.floor(biz.price * 0.5);

    businesses.splice(bizIndex, 1);

    db.updateUser(context.platform, context.userId, {
      money: user.money + sellPrice,
      businesses
    });

    return {
      text: `${identifier} ${EMOJI.success} Бизнес продан!
${SEPARATOR}
🏢 ${biz.name}
💰 Получено: ${formatNumber(sellPrice)}$`,
      keyboard: 'main'
    };
  }

  // Информация о бизнесе
  async businessInfo(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const businesses = user.businesses || [];
    
    if (args.length === 0 || businesses.length === 0) {
      return { text: `${identifier} ${EMOJI.error} Укажите номер бизнеса!`, keyboard: 'main' };
    }

    const bizIndex = parseInt(args[0]) - 1;
    
    if (bizIndex < 0 || bizIndex >= businesses.length) {
      return { text: `${identifier} ${EMOJI.error} Бизнес не найден!`, keyboard: 'main' };
    }

    const biz = businesses[bizIndex];
    const income = Math.floor(biz.income * (1 + biz.level * 0.2));
    const upgradeCost = Math.floor(biz.price * 0.5 * Math.pow(1.1, biz.level));
    const sellPrice = Math.floor(biz.price * 0.5);

    return {
      text: `${identifier} 🏢 ${biz.name}
${SEPARATOR}
📈 Уровень: ${biz.level}/10
💰 Доход: ${formatNumber(income)}$/час
📅 Куплен: ${formatDate(biz.purchasedAt)}
${SEPARATOR}
💎 Улучшение: ${formatNumber(upgradeCost)}$
💸 Продажа: ${formatNumber(sellPrice)}$`,
      keyboard: 'main'
    };
  }

  // Работа
  async job(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (!user.job) {
      return {
        text: `${identifier} ${EMOJI.work} РАБОТА
${SEPARATOR}
📭 Вы не трудоустроены!

💡 Список работ: работа список`,
        keyboard: 'main'
      };
    }

    const jobTemplate = JOBS.find(j => j.id === user.job);
    const cooldown = isOnCooldown(user, 'work');

    return {
      text: `${identifier} ${EMOJI.work} РАБОТА
${SEPARATOR}
💼 Должность: ${jobTemplate ? jobTemplate.name : 'Неизвестно'}
📊 Стаж: ${user.jobExperience || 0} смен
💰 Доход: ${formatNumber(jobTemplate ? jobTemplate.minIncome : 0)}-${formatNumber(jobTemplate ? jobTemplate.maxIncome : 0)}$
${SEPARATOR}
${cooldown.onCooldown ? `⏳ Следующая смена: ${formatDuration(cooldown.remaining)}` : '✅ Можно работать!'}

💡 Для работы: работать`,
      keyboard: 'main'
    };
  }

  // Список работ
  async jobList(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    const userLevel = user ? user.level : 1;
    
    let text = `${identifier} 💼 СПИСОК РАБОТ
${SEPARATOR}`;

    JOBS.forEach(job => {
      const available = userLevel >= job.minLevel;
      text += `\n${available ? '✅' : '❌'} ${job.id}. ${job.name}
   📊 Ур.${job.minLevel} | 💰 ${formatNumber(job.minIncome)}-${formatNumber(job.maxIncome)}$`;
    });

    text += `\n${SEPARATOR}
💡 Для устройства: работа [номер]`;

    return { text, keyboard: 'main' };
  }

  // Работать
  async work(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    // Автоустройство если нет работы
    if (!user.job) {
      const availableJob = JOBS.find(j => user.level >= j.minLevel);
      if (availableJob) {
        db.updateUser(context.platform, context.userId, { job: availableJob.id, jobExperience: 0 });
        user.job = availableJob.id;
      } else {
        return { text: `${identifier} ${EMOJI.error} Нет доступных работ для вашего уровня!`, keyboard: 'main' };
      }
    }

    // Проверка кулдауна
    const cooldown = isOnCooldown(user, 'work');
    if (cooldown.onCooldown) {
      return { text: messages.errors.cooldown(identifier, cooldown.remaining), keyboard: 'main' };
    }

    // Проверка энергии
    if (!hasEnoughEnergy(user, config.energyCost.work)) {
      return { text: messages.errors.notEnoughEnergy(identifier), keyboard: 'main' };
    }

    // Проверка лимита
    const limit = checkDailyLimit(user, 'work');
    if (!limit.canDo) {
      return { text: messages.errors.limitReached(identifier, 'работа'), keyboard: 'main' };
    }

    const jobTemplate = JOBS.find(j => j.id === user.job);
    const income = randomInt(jobTemplate.minIncome, jobTemplate.maxIncome);
    const expGain = randomInt(50, 100);
    const modifier = calculateIncomeModifier(user, 'work');
    const finalIncome = Math.floor(income * modifier);

    // Обновляем кулдаун и лимит
    const cooldowns = { ...(user.cooldowns || {}), work: Date.now() };
    const dailyLimits = { ...(user.dailyLimits || {}), work: (user.dailyLimits?.work || 0) + 1 };

    // Проверяем повышение уровня
    const newExp = user.experience + expGain;
    const expNeeded = getExpForLevel(user.level + 1);
    const levelUp = newExp >= expNeeded;

    db.updateUser(context.platform, context.userId, {
      money: user.money + finalIncome,
      experience: levelUp ? newExp - expNeeded : newExp,
      level: levelUp ? user.level + 1 : user.level,
      energy: user.energy - config.energyCost.work,
      jobExperience: (user.jobExperience || 0) + 1,
      cooldowns,
      dailyLimits,
      totalEarned: (user.totalEarned || 0) + finalIncome
    });

    let text = `${identifier} ${EMOJI.work} РАБОТА
${SEPARATOR}
💼 Должность: ${jobTemplate.name}
💰 Заработано: ${formatNumber(finalIncome)}$
⭐ Опыт: +${expGain}`;

    if (modifier < 1) {
      text += `\n⚠️ Штраф за усталость: ${Math.round((1 - modifier) * 100)}%`;
    }

    if (levelUp) {
      text += `\n${SEPARATOR}\n🎉 ПОВЫШЕНИЕ УРОВНЯ! Теперь вы ${user.level + 1} уровня!`;
    }

    return { text, keyboard: 'main' };
  }

  // Увольнение
  async jobQuit(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (!user.job) {
      return { text: `${identifier} ${EMOJI.error} Вы не трудоустроены!`, keyboard: 'main' };
    }

    const jobTemplate = JOBS.find(j => j.id === user.job);

    db.updateUser(context.platform, context.userId, {
      job: null,
      jobExperience: 0
    });

    return {
      text: `${identifier} ${EMOJI.success} Вы уволились!
${SEPARATOR}
💼 Бывшая должность: ${jobTemplate ? jobTemplate.name : 'Неизвестно'}`,
      keyboard: 'main'
    };
  }

  // Информация о работе
  async jobInfo(context, user, args) {
    return await this.job(context, user, args);
  }

  // Фермы
  async farms(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const farms = user.farms || [];

    if (farms.length === 0) {
      let text = `${identifier} ${EMOJI.farm} ФЕРМЫ
${SEPARATOR}
📭 У вас нет ферм!

🏪 МАГАЗИН ФЕРМ:`;
      
      FARMS.forEach(f => {
        text += `\n${f.id}. ${f.name} - ${formatNumber(f.price)}$ (${f.btcPerHour}₿/час)`;
      });
      
      text += `\n${SEPARATOR}\n💡 Покупка: фермы купить [номер]`;
      
      return { text, keyboard: 'main' };
    }

    let totalBtc = 0;
    let text = `${identifier} ${EMOJI.farm} ВАШИ ФЕРМЫ (${farms.length}/${config.limits.maxFarms})
${SEPARATOR}`;

    farms.forEach((farm, i) => {
      const btcIncome = farm.btcPerHour * (1 + (farm.level || 1) * 0.1);
      totalBtc += btcIncome;
      const canCollect = !farm.lastCollect || (Date.now() - farm.lastCollect) > 15 * 60 * 1000;
      text += `\n${i + 1}. ${farm.name}
   📈 Ур.${farm.level || 1} | ₿ ${btcIncome.toFixed(2)}/час
   ${canCollect ? '✅ Можно собрать' : `⏳ ${formatDuration(15 * 60 * 1000 - (Date.now() - farm.lastCollect))}`}`;
    });

    text += `\n${SEPARATOR}
₿ Общий доход: ${totalBtc.toFixed(2)}₿/час

💡 Сбор: ферма собрать [номер]`;

    return { text, keyboard: 'main' };
  }

  // Покупка фермы
  async farmBuy(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (args.length === 0) {
      return await this.farms(context, user, args);
    }

    const farmId = parseInt(args[0]);
    const farmTemplate = FARMS.find(f => f.id === farmId);

    if (!farmTemplate) {
      return { text: `${identifier} ${EMOJI.error} Ферма не найдена!`, keyboard: 'main' };
    }

    const currentFarms = user.farms || [];
    
    if (currentFarms.length >= config.limits.maxFarms) {
      return { text: `${identifier} ${EMOJI.error} Достигнут лимит ферм (${config.limits.maxFarms})!`, keyboard: 'main' };
    }

    if (!hasEnoughMoney(user, farmTemplate.price)) {
      return { text: messages.errors.notEnoughMoney(identifier), keyboard: 'main' };
    }

    const newFarm = {
      id: farmTemplate.id,
      name: farmTemplate.name,
      price: farmTemplate.price,
      btcPerHour: farmTemplate.btcPerHour,
      level: 1,
      lastCollect: null
    };

    db.updateUser(context.platform, context.userId, {
      money: user.money - farmTemplate.price,
      farms: [...currentFarms, newFarm]
    });

    return {
      text: `${identifier} ${EMOJI.success} Ферма куплена!
${SEPARATOR}
${EMOJI.farm} ${farmTemplate.name}
💰 Потрачено: ${formatNumber(farmTemplate.price)}$
₿ Доход: ${farmTemplate.btcPerHour}₿/час`,
      keyboard: 'main'
    };
  }

  // Информация о ферме
  async farmInfo(context, user, args) {
    return await this.farms(context, user, args);
  }

  // Сбор с фермы
  async farmCollect(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const farms = user.farms || [];
    
    if (farms.length === 0) {
      return { text: `${identifier} ${EMOJI.error} У вас нет ферм!`, keyboard: 'main' };
    }

    if (!hasEnoughEnergy(user, config.energyCost.farm)) {
      return { text: messages.errors.notEnoughEnergy(identifier), keyboard: 'main' };
    }

    let totalBtc = 0;
    let collectedCount = 0;

    farms.forEach((farm, i) => {
      if (!farm.lastCollect || (Date.now() - farm.lastCollect) >= 15 * 60 * 1000) {
        const btcIncome = farm.btcPerHour * (1 + (farm.level || 1) * 0.1) * 0.25; // 15 минут = 0.25 часа
        totalBtc += btcIncome;
        farms[i].lastCollect = Date.now();
        collectedCount++;
      }
    });

    if (collectedCount === 0) {
      return { text: `${identifier} ${EMOJI.error} Нечего собирать!`, keyboard: 'main' };
    }

    db.updateUser(context.platform, context.userId, {
      bitcoin: user.bitcoin + totalBtc,
      energy: user.energy - config.energyCost.farm,
      farms
    });

    return {
      text: `${identifier} ${EMOJI.success} BTC собран!
${SEPARATOR}
${EMOJI.farm} Ферм: ${collectedCount}
₿ Получено: ${totalBtc.toFixed(4)}₿`,
      keyboard: 'main'
    };
  }

  // Улучшение фермы
  async farmUpgrade(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    return {
      text: `${identifier} ${EMOJI.farm} УЛУЧШЕНИЕ ФЕРМЫ
${SEPARATOR}
🔧 Функция в разработке...`,
      keyboard: 'main'
    };
  }

  // Принтеры
  async printer(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const printers = user.printers || [];

    if (printers.length === 0) {
      let text = `${identifier} ${EMOJI.printer} ПРИНТЕРЫ
${SEPARATOR}
📭 У вас нет принтеров!

🏪 МАГАЗИН ПРИНТЕРОВ:`;
      
      PRINTERS.forEach(p => {
        text += `\n${p.id}. ${p.name} - ${formatNumber(p.price)}$ (${formatNumber(p.incomePerHour)}$/час)`;
      });
      
      text += `\n${SEPARATOR}\n💡 Покупка: принтер купить [номер]`;
      
      return { text, keyboard: 'main' };
    }

    let text = `${identifier} ${EMOJI.printer} ВАШИ ПРИНТЕРЫ (${printers.length}/${config.limits.maxPrinters})
${SEPARATOR}`;

    printers.forEach((printer, i) => {
      text += `\n${i + 1}. ${printer.name}
   💰 ${formatNumber(printer.incomePerHour)}$/час | ⛽ ${printer.fuel || 0}%`;
    });

    text += `\n${SEPARATOR}\n💡 Сбор: принтер собрать\n💡 Заправка: принтер заправить [номер]`;

    return { text, keyboard: 'main' };
  }

  // Покупка принтера
  async printerBuy(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (args.length === 0) {
      return await this.printer(context, user, args);
    }

    const printerId = parseInt(args[0]);
    const printerTemplate = PRINTERS.find(p => p.id === printerId);

    if (!printerTemplate) {
      return { text: `${identifier} ${EMOJI.error} Принтер не найден!`, keyboard: 'main' };
    }

    const currentPrinters = user.printers || [];
    
    if (currentPrinters.length >= config.limits.maxPrinters) {
      return { text: `${identifier} ${EMOJI.error} Достигнут лимит принтеров (${config.limits.maxPrinters})!`, keyboard: 'main' };
    }

    if (!hasEnoughMoney(user, printerTemplate.price)) {
      return { text: messages.errors.notEnoughMoney(identifier), keyboard: 'main' };
    }

    const newPrinter = {
      id: printerTemplate.id,
      name: printerTemplate.name,
      price: printerTemplate.price,
      incomePerHour: printerTemplate.incomePerHour,
      fuel: 100,
      lastCollect: null
    };

    db.updateUser(context.platform, context.userId, {
      money: user.money - printerTemplate.price,
      printers: [...currentPrinters, newPrinter]
    });

    return {
      text: `${identifier} ${EMOJI.success} Принтер куплен!
${SEPARATOR}
${EMOJI.printer} ${printerTemplate.name}
💰 Потрачено: ${formatNumber(printerTemplate.price)}$`,
      keyboard: 'main'
    };
  }

  // Сбор с принтера
  async printerCollect(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const printers = user.printers || [];
    
    if (printers.length === 0) {
      return { text: `${identifier} ${EMOJI.error} У вас нет принтеров!`, keyboard: 'main' };
    }

    let totalIncome = 0;
    let collectedCount = 0;

    printers.forEach((printer, i) => {
      if (printer.fuel > 0) {
        const income = Math.floor(printer.incomePerHour * 0.167); // ~10 минут
        totalIncome += income;
        printers[i].fuel = Math.max(0, printer.fuel - 1);
        collectedCount++;
      }
    });

    if (collectedCount === 0) {
      return { text: `${identifier} ${EMOJI.error} Нечего собирать или принтеры без топлива!`, keyboard: 'main' };
    }

    db.updateUser(context.platform, context.userId, {
      money: user.money + totalIncome,
      printers
    });

    return {
      text: `${identifier} ${EMOJI.success} Доход собран!
${SEPARATOR}
${EMOJI.printer} Принтеров: ${collectedCount}
💰 Получено: ${formatNumber(totalIncome)}$`,
      keyboard: 'main'
    };
  }

  // Заправка принтера
  async printerRefuel(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const printers = user.printers || [];
    
    if (printers.length === 0) {
      return { text: `${identifier} ${EMOJI.error} У вас нет принтеров!`, keyboard: 'main' };
    }

    const refuelCost = 1000; // за 10%

    if (!hasEnoughMoney(user, refuelCost)) {
      return { text: messages.errors.notEnoughMoney(identifier), keyboard: 'main' };
    }

    // Заправляем все принтеры на 10%
    printers.forEach((printer, i) => {
      printers[i].fuel = Math.min(100, printer.fuel + 10);
    });

    db.updateUser(context.platform, context.userId, {
      money: user.money - refuelCost,
      printers
    });

    return {
      text: `${identifier} ${EMOJI.success} Принтеры заправлены!
${SEPARATOR}
⛽ +10% топлива
💰 Потрачено: ${formatNumber(refuelCost)}$`,
      keyboard: 'main'
    };
  }

  // Майнинг
  async mining(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const ores = user.ores || {};
    let totalValue = 0;

    let text = `${identifier} ${EMOJI.mining} МАЙНИНГ
${SEPARATOR}
⛏️ Кирка: Ур.${user.pickaxeLevel || 1}
🏔️ Шахта: Ур.${user.shaftLevel || 1}
${SEPARATOR}
📦 ВАША РУДА:`;

    ORES.forEach(ore => {
      const amount = ores[ore.name] || 0;
      if (amount > 0) {
        text += `\n• ${ore.name}: ${amount} (${formatNumber(amount * ore.price)}$)`;
        totalValue += amount * ore.price;
      }
    });

    if (totalValue === 0) {
      text += '\n📭 Пусто!';
    }

    text += `\n${SEPARATOR}
💰 Общая стоимость: ${formatNumber(totalValue)}$

💡 Копать: копать
💡 Продать: руда продать`;

    return { text, keyboard: 'main' };
  }

  // Копать
  async mine(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const cooldown = isOnCooldown(user, 'mining');
    if (cooldown.onCooldown) {
      return { text: messages.errors.cooldown(identifier, cooldown.remaining), keyboard: 'main' };
    }

    if (!hasEnoughEnergy(user, config.energyCost.mining)) {
      return { text: messages.errors.notEnoughEnergy(identifier), keyboard: 'main' };
    }

    const limit = checkDailyLimit(user, 'mining');
    if (!limit.canDo) {
      return { text: messages.errors.limitReached(identifier, 'майнинг'), keyboard: 'main' };
    }

    // Выбираем случайную руду
    const ore = weightedRandom(ORES);
    const amount = randomInt(1, 5) * (user.pickaxeLevel || 1);
    
    const ores = { ...(user.ores || {}) };
    ores[ore.name] = (ores[ore.name] || 0) + amount;

    const cooldowns = { ...(user.cooldowns || {}), mining: Date.now() };
    const dailyLimits = { ...(user.dailyLimits || {}), mining: (user.dailyLimits?.mining || 0) + 1 };

    db.updateUser(context.platform, context.userId, {
      ores,
      energy: user.energy - config.energyCost.mining,
      cooldowns,
      dailyLimits
    });

    return {
      text: `${identifier} ${EMOJI.mining} КОПАНИЕ
${SEPARATOR}
⛏️ Вы накопали:
• ${ore.name} x${amount} (${formatNumber(amount * ore.price)}$)`,
      keyboard: 'main'
    };
  }

  // Кирка
  async pickaxe(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const level = user.pickaxeLevel || 1;
    const upgradeCost = 5000 * Math.pow(2, level - 1);

    return {
      text: `${identifier} ⛏️ КИРКА
${SEPARATOR}
📊 Текущий уровень: ${level}
💎 Улучшение: ${formatNumber(upgradeCost)}$
${SEPARATOR}
💡 Улучшить: кирка улучшить`,
      keyboard: 'main'
    };
  }

  // Улучшение кирки
  async pickaxeUpgrade(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const level = user.pickaxeLevel || 1;
    const upgradeCost = 5000 * Math.pow(2, level - 1);

    if (!hasEnoughMoney(user, upgradeCost)) {
      return { text: messages.errors.notEnoughMoney(identifier), keyboard: 'main' };
    }

    db.updateUser(context.platform, context.userId, {
      money: user.money - upgradeCost,
      pickaxeLevel: level + 1
    });

    return {
      text: `${identifier} ${EMOJI.success} Кирка улучшена!
${SEPARATOR}
⛏️ Новый уровень: ${level + 1}
💰 Потрачено: ${formatNumber(upgradeCost)}$`,
      keyboard: 'main'
    };
  }

  // Продажа руды
  async oreSell(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const ores = user.ores || {};
    let totalValue = 0;

    ORES.forEach(ore => {
      const amount = ores[ore.name] || 0;
      totalValue += amount * ore.price;
    });

    if (totalValue === 0) {
      return { text: `${identifier} ${EMOJI.error} У вас нет руды для продажи!`, keyboard: 'main' };
    }

    db.updateUser(context.platform, context.userId, {
      money: user.money + totalValue,
      ores: {},
      totalEarned: (user.totalEarned || 0) + totalValue
    });

    return {
      text: `${identifier} ${EMOJI.success} Руда продана!
${SEPARATOR}
💰 Получено: ${formatNumber(totalValue)}$`,
      keyboard: 'main'
    };
  }

  // Магазин
  async shop(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    
    return {
      text: `${identifier} ${EMOJI.shop} МАГАЗИН
${SEPARATOR}
📋 КАТЕГОРИИ:
• 🚗 Машины — машина список
• 🏢 Бизнесы — бизнес список
• 🌾 Фермы — фермы
• 🖨️ Принтеры — принтер
• 📦 Кейсы — кейс список
• 🐾 Питомцы — питомец список
${SEPARATOR}
💎 ДОНАТ — донат`,
      buttons: shopButtons,
      keyboard: 'main'
    };
  }

  // Покупка в магазине
  async shopBuy(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    return {
      text: `${identifier} ${EMOJI.shop} ПОКУПКА
${SEPARATOR}
💡 Укажите категорию:
• машина купить [номер]
• бизнес купить [номер]
• и т.д.`,
      keyboard: 'main'
    };
  }

  // Донат
  async donate(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    
    return {
      text: `${identifier} 💎 ДОНАТ-МАГАЗИН
${SEPARATOR}
👑 ПРИВИЛЕГИИ:
1. 🟡 VIP — 10,000₽/месяц
   • x2 доход, x1.5 опыт, +20 энергия

2. 🟣 PREMIUM — 25,000₽/месяц
   • x3 доход, x2 опыт, +30 энергия

3. 🔴 LEGEND — 50,000₽/месяц
   • x5 доход, x3 опыт, +50 энергия

4. ⚫ ULTIMATE — 100,000₽/месяц
   • x10 доход, x5 опыт, +100 энергия
${SEPARATOR}
💡 Покупка: вип / премиум / легенда / ультима`,
      keyboard: 'main'
    };
  }

  // Покупка доната
  async donateBuy(context, user, args) {
    return await this.donate(context, user, args);
  }

  // VIP
  async vip(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const price = config.privileges.vip.price;
    
    if (user.rubles < price) {
      return {
        text: `${identifier} ${EMOJI.error} Недостаточно рублей!
${SEPARATOR}
💰 Нужно: ${formatNumber(price)}₽
💵 У вас: ${formatNumber(user.rubles)}₽`,
        keyboard: 'main'
      };
    }

    const expiresAt = Date.now() + 30 * 24 * 60 * 60 * 1000; // 30 дней

    db.updateUser(context.platform, context.userId, {
      rubles: user.rubles - price,
      privilege: 'vip',
      privilegeExpires: expiresAt,
      maxEnergy: (user.maxEnergy || 100) + config.privileges.vip.bonusEnergy
    });

    return {
      text: `${identifier} ${EMOJI.success} VIP активирован!
${SEPARATOR}
🟡 Привилегия: VIP
📅 До: ${formatDate(expiresAt)}
${SEPARATOR}
✨ Бонусы:
• x2 к доходу
• x1.5 к опыту
• +20 максимальной энергии`,
      keyboard: 'main'
    };
  }

  // Premium
  async premium(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const price = config.privileges.premium.price;
    
    if (user.rubles < price) {
      return {
        text: `${identifier} ${EMOJI.error} Недостаточно рублей!
${SEPARATOR}
💰 Нужно: ${formatNumber(price)}₽
💵 У вас: ${formatNumber(user.rubles)}₽`,
        keyboard: 'main'
      };
    }

    const expiresAt = Date.now() + 30 * 24 * 60 * 60 * 1000;

    db.updateUser(context.platform, context.userId, {
      rubles: user.rubles - price,
      privilege: 'premium',
      privilegeExpires: expiresAt,
      maxEnergy: (user.maxEnergy || 100) + config.privileges.premium.bonusEnergy
    });

    return {
      text: `${identifier} ${EMOJI.success} PREMIUM активирован!
${SEPARATOR}
🟣 Привилегия: PREMIUM
📅 До: ${formatDate(expiresAt)}`,
      keyboard: 'main'
    };
  }

  // Legend
  async legend(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const price = config.privileges.legend.price;
    
    if (user.rubles < price) {
      return { text: `${identifier} ${EMOJI.error} Недостаточно рублей! Нужно: ${formatNumber(price)}₽`, keyboard: 'main' };
    }

    const expiresAt = Date.now() + 30 * 24 * 60 * 60 * 1000;

    db.updateUser(context.platform, context.userId, {
      rubles: user.rubles - price,
      privilege: 'legend',
      privilegeExpires: expiresAt,
      maxEnergy: (user.maxEnergy || 100) + config.privileges.legend.bonusEnergy
    });

    return {
      text: `${identifier} ${EMOJI.success} LEGEND активирован!
${SEPARATOR}
🔴 Привилегия: LEGEND
📅 До: ${formatDate(expiresAt)}`,
      keyboard: 'main'
    };
  }

  // Ultimate
  async ultimate(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const price = config.privileges.ultimate.price;
    
    if (user.rubles < price) {
      return { text: `${identifier} ${EMOJI.error} Недостаточно рублей! Нужно: ${formatNumber(price)}₽`, keyboard: 'main' };
    }

    const expiresAt = Date.now() + 30 * 24 * 60 * 60 * 1000;

    db.updateUser(context.platform, context.userId, {
      rubles: user.rubles - price,
      privilege: 'ultimate',
      privilegeExpires: expiresAt,
      maxEnergy: (user.maxEnergy || 100) + config.privileges.ultimate.bonusEnergy
    });

    return {
      text: `${identifier} ${EMOJI.success} ULTIMATE активирован!
${SEPARATOR}
⚫ Привилегия: ULTIMATE
📅 До: ${formatDate(expiresAt)}`,
      keyboard: 'main'
    };
  }
}

module.exports = new BusinessModule();
