/**
 * FLASH BOT - Content Module
 * Команды: квесты, события, бонусы, фортуна, промокоды, путь новичка
 */

const db = require('../core/database/db.service');
const config = require('../config');
const { messages } = require('../config/messages');
const { formatNumber, formatDate, formatDuration, getPlayerIdentifier } = require('../core/utils/formatter');
const { isOnCooldown } = require('../core/utils/validator');
const { randomInt, randomChoice } = require('../core/utils/crypto');
const { questButtons } = require('../config/keyboards');
const { EMOJI } = require('../config/constants');

const SEPARATOR = '━━━━━━━━━━━━━━━━━━━━';

class ContentModule {
  constructor() {
    this.commands = {
      'quests': this.quests.bind(this),
      'questList': this.questList.bind(this),
      'questTake': this.questTake.bind(this),
      'questComplete': this.questComplete.bind(this),
      'questInfo': this.questInfo.bind(this),
      'questDaily': this.questDaily.bind(this),
      'questWeekly': this.questWeekly.bind(this),
      'newbiePath': this.newbiePath.bind(this),
      'newbieStatus': this.newbieStatus.bind(this),
      'questRewards': this.questRewards.bind(this),
      'questProgress': this.questProgress.bind(this),
      'events': this.events.bind(this),
      'eventList': this.eventList.bind(this),
      'eventInfo': this.eventInfo.bind(this),
      'eventJoin': this.eventJoin.bind(this),
      'bonus': this.bonus.bind(this),
      'bonusDaily': this.bonusDaily.bind(this),
      'bonusHourly': this.bonusHourly.bind(this),
      'bonusStreak': this.bonusStreak.bind(this),
      'bonusStatus': this.bonusStatus.bind(this),
      'fortune': this.fortune.bind(this),
      'fortuneCheck': this.fortuneCheck.bind(this),
      'promocode': this.promocode.bind(this),
      'promocodeActivate': this.promocodeActivate.bind(this),
      'promocodeList': this.promocodeList.bind(this),
      'promocodeCreate': this.promocodeCreate.bind(this),
      'promocodeDelete': this.promocodeDelete.bind(this),
      'promocodeInfo': this.promocodeInfo.bind(this)
    };
  }

  // Квесты
  async quests(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    return {
      text: `${identifier} ${EMOJI.quest} КВЕСТЫ
${SEPARATOR}
📋 ТИПЫ КВЕСТОВ:
• квесты ежедневные — 8 квестов
• квесты недельные — 5 квестов
• путь новичка — для новичков
${SEPARATOR}
💡 Квесты обновляются автоматически!`,
      buttons: questButtons,
      keyboard: 'main'
    };
  }

  // Список квестов
  async questList(context, user, args) {
    return await this.quests(context, user, args);
  }

  // Взять квест
  async questTake(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    return {
      text: `${identifier} ${EMOJI.quest} ВЗЯТЬ КВЕСТ
${SEPARATOR}
ℹ️ Квесты назначаются автоматически!
Проверьте: квесты ежедневные`,
      keyboard: 'main'
    };
  }

  // Сдать квест
  async questComplete(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    return {
      text: `${identifier} ${EMOJI.quest} СДАТЬ КВЕСТ
${SEPARATOR}
ℹ️ Квесты засчитываются автоматически!`,
      keyboard: 'main'
    };
  }

  // Информация о квесте
  async questInfo(context, user, args) {
    return await this.quests(context, user, args);
  }

  // Ежедневные квесты
  async questDaily(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const dailyQuests = user.dailyQuests || [];

    if (dailyQuests.length === 0) {
      // Генерируем квесты если их нет
      const questsData = db.cache['quests.json'] || db.getDefaultQuests();
      const newQuests = questsData.daily.map(q => ({
        ...q,
        progress: 0,
        completed: false,
        claimed: false
      }));
      
      db.updateUser(context.platform, context.userId, { dailyQuests: newQuests });
      
      return await this.questDaily(context, { ...user, dailyQuests: newQuests }, args);
    }

    let text = `${identifier} 📋 ЕЖЕДНЕВНЫЕ КВЕСТЫ
${SEPARATOR}`;

    let completed = 0;
    dailyQuests.forEach((q, i) => {
      const status = q.claimed ? '🏆' : q.completed ? '✅' : '⬜';
      completed += q.completed ? 1 : 0;
      text += `\n${status} ${i + 1}. ${q.name}
   📊 ${q.progress || 0}/${q.target}`;
      if (q.reward.money) text += ` | 💰 ${formatNumber(q.reward.money)}$`;
    });

    text += `\n${SEPARATOR}
📊 Выполнено: ${completed}/${dailyQuests.length}
⏱️ Обновление в 00:00`;

    return { text, keyboard: 'main' };
  }

  // Недельные квесты
  async questWeekly(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const weeklyQuests = user.weeklyQuests || [];

    if (weeklyQuests.length === 0) {
      const questsData = db.cache['quests.json'] || db.getDefaultQuests();
      const newQuests = questsData.weekly.map(q => ({
        ...q,
        progress: 0,
        completed: false,
        claimed: false
      }));
      
      db.updateUser(context.platform, context.userId, { weeklyQuests: newQuests });
      
      return await this.questWeekly(context, { ...user, weeklyQuests: newQuests }, args);
    }

    let text = `${identifier} 📅 НЕДЕЛЬНЫЕ КВЕСТЫ
${SEPARATOR}`;

    let completed = 0;
    weeklyQuests.forEach((q, i) => {
      const status = q.claimed ? '🏆' : q.completed ? '✅' : '⬜';
      completed += q.completed ? 1 : 0;
      text += `\n${status} ${i + 1}. ${q.name}
   📊 ${q.progress || 0}/${q.target}`;
      if (q.reward.money) text += ` | 💰 ${formatNumber(q.reward.money)}$`;
      if (q.reward.diamonds) text += ` | 💎 ${q.reward.diamonds}`;
    });

    text += `\n${SEPARATOR}
📊 Выполнено: ${completed}/${weeklyQuests.length}
⏱️ Обновление в понедельник 00:00`;

    return { text, keyboard: 'main' };
  }

  // Путь новичка
  async newbiePath(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const path = user.newbiePath || db.getNewbiePath();

    let text = `${identifier} ${EMOJI.newbie} ПУТЬ НОВИЧКА
${SEPARATOR}
Выполняйте задания и получайте награды!

`;

    let completed = 0;
    path.forEach((task, i) => {
      const status = task.completed ? '✅' : '⬜';
      completed += task.completed ? 1 : 0;
      text += `${status} ${i + 1}. ${task.name}\n`;
    });

    text += `${SEPARATOR}
📊 Прогресс: ${completed}/${path.length}`;

    if (completed === path.length) {
      text += `\n🎉 ПУТЬ ЗАВЕРШЁН! Награда: 50,000$`;
    }

    return { text, keyboard: 'main' };
  }

  // Статус пути новичка
  async newbieStatus(context, user, args) {
    return await this.newbiePath(context, user, args);
  }

  // Награды за квесты
  async questRewards(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    return {
      text: `${identifier} 🏆 НАГРАДЫ ЗА КВЕСТЫ
${SEPARATOR}
📋 ЕЖЕДНЕВНЫЕ:
• 💰 1,000-5,000$ за квест
• ⭐ 50-100 опыта

📅 НЕДЕЛЬНЫЕ:
• 💰 15,000-30,000$ за квест
• ⭐ 400-750 опыта
• 💎 3-10 алмазов

📍 ПУТЬ НОВИЧКА:
• 💰 50,000$ за полное прохождение`,
      keyboard: 'main'
    };
  }

  // Прогресс квестов
  async questProgress(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const dailyQuests = user.dailyQuests || [];
    const weeklyQuests = user.weeklyQuests || [];
    const newbiePath = user.newbiePath || [];

    const dailyCompleted = dailyQuests.filter(q => q.completed).length;
    const weeklyCompleted = weeklyQuests.filter(q => q.completed).length;
    const newbieCompleted = newbiePath.filter(t => t.completed).length;

    return {
      text: `${identifier} 📊 ПРОГРЕСС КВЕСТОВ
${SEPARATOR}
📋 Ежедневные: ${dailyCompleted}/${dailyQuests.length}
📅 Недельные: ${weeklyCompleted}/${weeklyQuests.length}
📍 Путь новичка: ${newbieCompleted}/${newbiePath.length}`,
      keyboard: 'main'
    };
  }

  // События
  async events(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    
    const events = db.getEvents();
    const activeEvents = Object.values(events).filter(e => e.active && e.endTime > Date.now());

    if (activeEvents.length === 0) {
      return {
        text: `${identifier} ${EMOJI.event} СОБЫТИЯ
${SEPARATOR}
📭 Сейчас нет активных событий!

⏳ Ожидайте анонсов...`,
        keyboard: 'main'
      };
    }

    let text = `${identifier} ${EMOJI.event} АКТИВНЫЕ СОБЫТИЯ
${SEPARATOR}`;

    activeEvents.forEach(event => {
      text += `\n🎉 ${event.name}
   ⏳ До: ${formatDate(event.endTime)}
   📊 Участников: ${event.participants?.length || 0}`;
    });

    return { text, keyboard: 'main' };
  }

  // Список событий
  async eventList(context, user, args) {
    return await this.events(context, user, args);
  }

  // Информация о событии
  async eventInfo(context, user, args) {
    return await this.events(context, user, args);
  }

  // Участие в событии
  async eventJoin(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    return {
      text: `${identifier} ${EMOJI.event} УЧАСТИЕ В СОБЫТИИ
${SEPARATOR}
🔧 Функция в разработке...`,
      keyboard: 'main'
    };
  }

  // Бонус
  async bonus(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    // Проверяем ежедневный бонус
    const lastBonus = user.lastBonusTime || 0;
    const now = Date.now();
    const dayMs = 24 * 60 * 60 * 1000;
    const canClaimDaily = (now - lastBonus) >= dayMs;

    // Проверяем часовой бонус
    const lastHourly = user.lastHourlyBonus || 0;
    const hourlyMs = 3 * 60 * 60 * 1000;
    const canClaimHourly = (now - lastHourly) >= hourlyMs;

    if (!canClaimDaily && !canClaimHourly) {
      const dailyRemaining = dayMs - (now - lastBonus);
      const hourlyRemaining = hourlyMs - (now - lastHourly);

      return {
        text: `${identifier} ${EMOJI.bonus} БОНУСЫ
${SEPARATOR}
🎁 Ежедневный: ${formatDuration(dailyRemaining)}
⏰ Часовой: ${formatDuration(hourlyRemaining)}
🔥 Стрик: ${user.bonusStreak || 0} дней`,
        keyboard: 'main'
      };
    }

    // Если можно получить ежедневный
    if (canClaimDaily) {
      return await this.bonusDaily(context, user, args);
    }

    // Если можно получить часовой
    return await this.bonusHourly(context, user, args);
  }

  // Ежедневный бонус
  async bonusDaily(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const lastBonus = user.lastBonusTime || 0;
    const now = Date.now();
    const dayMs = 24 * 60 * 60 * 1000;
    const twoDaysMs = 2 * dayMs;

    if ((now - lastBonus) < dayMs) {
      const remaining = dayMs - (now - lastBonus);
      return {
        text: `${identifier} ${EMOJI.time} Ежедневный бонус доступен через ${formatDuration(remaining)}`,
        keyboard: 'main'
      };
    }

    // Проверяем стрик
    let streak = user.bonusStreak || 0;
    
    if ((now - lastBonus) > twoDaysMs) {
      streak = 0; // Сброс стрика
    }
    
    streak = Math.min(7, streak + 1);

    // Награда в зависимости от стрика
    const rewards = [1000, 1500, 2000, 2500, 3000, 4000, 5000];
    const reward = rewards[streak - 1] || 1000;
    const expReward = 50 * streak;

    const updates = {
      money: user.money + reward,
      experience: user.experience + expReward,
      lastBonusTime: now,
      bonusStreak: streak,
      coins: user.coins + streak
    };

    // Бонусный алмаз на 7 день
    if (streak === 7) {
      updates.diamonds = user.diamonds + 1;
    }

    db.updateUser(context.platform, context.userId, updates);

    let text = `${identifier} ${EMOJI.bonus} ЕЖЕДНЕВНЫЙ БОНУС
${SEPARATOR}
🔥 Стрик: ${streak} дней
💰 Награда: ${formatNumber(reward)}$
⭐ Опыт: +${expReward}
🪙 Монеты: +${streak}`;

    if (streak === 7) {
      text += `\n💎 Бонус за 7 дней: +1 алмаз!`;
    }

    text += `\n${SEPARATOR}\n💡 Заходите каждый день для увеличения стрика!`;

    return { text, keyboard: 'main' };
  }

  // Часовой бонус
  async bonusHourly(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const lastHourly = user.lastHourlyBonus || 0;
    const now = Date.now();
    const hourlyMs = 3 * 60 * 60 * 1000;

    if ((now - lastHourly) < hourlyMs) {
      const remaining = hourlyMs - (now - lastHourly);
      return {
        text: `${identifier} ${EMOJI.time} Часовой бонус доступен через ${formatDuration(remaining)}`,
        keyboard: 'main'
      };
    }

    const reward = config.hourlyBonus.money;
    const expReward = config.hourlyBonus.exp;

    db.updateUser(context.platform, context.userId, {
      money: user.money + reward,
      experience: user.experience + expReward,
      lastHourlyBonus: now
    });

    return {
      text: `${identifier} ⏰ ЧАСОВОЙ БОНУС
${SEPARATOR}
💰 Награда: ${formatNumber(reward)}$
⭐ Опыт: +${expReward}
${SEPARATOR}
💡 Следующий бонус через 3 часа!`,
      keyboard: 'main'
    };
  }

  // Информация о стрике
  async bonusStreak(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const rewards = [1000, 1500, 2000, 2500, 3000, 4000, 5000];

    let text = `${identifier} 🔥 СТРИК
${SEPARATOR}
📊 Текущий стрик: ${user.bonusStreak || 0} дней
${SEPARATOR}
💰 НАГРАДЫ:`;

    rewards.forEach((r, i) => {
      const day = i + 1;
      const current = (user.bonusStreak || 0) === day ? ' 👈' : '';
      const status = (user.bonusStreak || 0) >= day ? '✅' : '⬜';
      text += `\n${status} День ${day}: ${formatNumber(r)}$${day === 7 ? ' + 💎' : ''}${current}`;
    });

    return { text, keyboard: 'main' };
  }

  // Статус бонусов
  async bonusStatus(context, user, args) {
    return await this.bonus(context, user, args);
  }

  // Фортуна
  async fortune(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    return {
      text: `${identifier} 🔮 ФОРТУНА
${SEPARATOR}
Испытайте свою удачу!

💡 Узнать судьбу: фортуна узнать
⚠️ Доступно раз в день`,
      keyboard: 'main'
    };
  }

  // Проверить фортуну
  async fortuneCheck(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const cooldown = isOnCooldown(user, 'fortune');
    if (cooldown.onCooldown) {
      return { text: messages.errors.cooldown(identifier, cooldown.remaining), keyboard: 'main' };
    }

    const fortunes = [
      { text: '🌟 Удача на вашей стороне!', effect: 'bonus', value: 5000 },
      { text: '💰 Деньги любят вас сегодня!', effect: 'bonus', value: 3000 },
      { text: '⚡ Энергия переполняет вас!', effect: 'energy', value: 50 },
      { text: '📈 Опыт приходит легко!', effect: 'exp', value: 200 },
      { text: '😐 Обычный день...', effect: 'none', value: 0 },
      { text: '💸 Не лучший день для денег...', effect: 'penalty', value: -1000 },
      { text: '😰 Звёзды против вас...', effect: 'penalty', value: -2000 }
    ];

    const fortune = randomChoice(fortunes);

    const updates = {
      cooldowns: { ...(user.cooldowns || {}), fortune: Date.now() }
    };

    switch (fortune.effect) {
      case 'bonus':
        updates.money = user.money + fortune.value;
        break;
      case 'energy':
        updates.energy = Math.min(user.maxEnergy, user.energy + fortune.value);
        break;
      case 'exp':
        updates.experience = user.experience + fortune.value;
        break;
      case 'penalty':
        updates.money = Math.max(0, user.money + fortune.value);
        break;
    }

    db.updateUser(context.platform, context.userId, updates);

    let effectText = '';
    switch (fortune.effect) {
      case 'bonus':
        effectText = `💰 +${formatNumber(fortune.value)}$`;
        break;
      case 'energy':
        effectText = `⚡ +${fortune.value} энергии`;
        break;
      case 'exp':
        effectText = `⭐ +${fortune.value} опыта`;
        break;
      case 'penalty':
        effectText = `💸 ${formatNumber(fortune.value)}$`;
        break;
      default:
        effectText = 'Ничего особенного';
    }

    return {
      text: `${identifier} 🔮 ФОРТУНА
${SEPARATOR}
${fortune.text}
${SEPARATOR}
${effectText}`,
      keyboard: 'main'
    };
  }

  // Промокод
  async promocode(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (args.length === 0) {
      return {
        text: `${identifier} 🎟️ ПРОМОКОДЫ
${SEPARATOR}
💡 Активировать: промокод активировать [код]
📋 Информация: промокод инфо [код]`,
        keyboard: 'main'
      };
    }

    // Если указан код - активируем
    return await this.promocodeActivate(context, user, args);
  }

  // Активация промокода
  async promocodeActivate(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (args.length === 0) {
      return { text: `${identifier} ${EMOJI.error} Укажите промокод!`, keyboard: 'main' };
    }

    const code = args[0].toUpperCase();
    const promo = db.getPromocode(code);

    if (!promo) {
      return { text: `${identifier} ${EMOJI.error} Промокод не найден!`, keyboard: 'main' };
    }

    if (promo.usedBy?.includes(user.uid)) {
      return { text: `${identifier} ${EMOJI.error} Вы уже использовали этот промокод!`, keyboard: 'main' };
    }

    if (promo.limit && promo.usedCount >= promo.limit) {
      return { text: `${identifier} ${EMOJI.error} Промокод больше не действителен!`, keyboard: 'main' };
    }

    if (promo.expiresAt && Date.now() > promo.expiresAt) {
      return { text: `${identifier} ${EMOJI.error} Промокод истёк!`, keyboard: 'main' };
    }

    // Применяем награду
    const updates = {};
    let rewardText = '';

    switch (promo.rewardType) {
      case 'money':
        updates.money = user.money + promo.rewardValue;
        rewardText = `💰 ${formatNumber(promo.rewardValue)}$`;
        break;
      case 'rubles':
        updates.rubles = user.rubles + promo.rewardValue;
        rewardText = `₽ ${formatNumber(promo.rewardValue)}₽`;
        break;
      case 'diamonds':
        updates.diamonds = user.diamonds + promo.rewardValue;
        rewardText = `💎 ${promo.rewardValue} алмазов`;
        break;
      case 'experience':
        updates.experience = user.experience + promo.rewardValue;
        rewardText = `⭐ ${promo.rewardValue} опыта`;
        break;
      default:
        rewardText = '🎁 Сюрприз!';
    }

    db.updateUser(context.platform, context.userId, updates);

    // Обновляем промокод
    db.updatePromocode(code, {
      usedBy: [...(promo.usedBy || []), user.uid],
      usedCount: (promo.usedCount || 0) + 1
    });

    return {
      text: `${identifier} ${EMOJI.success} Промокод активирован!
${SEPARATOR}
🎟️ Код: ${code}
🎁 Награда: ${rewardText}`,
      keyboard: 'main'
    };
  }

  // Список промокодов (для себя)
  async promocodeList(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    return {
      text: `${identifier} 🎟️ ПРОМОКОДЫ
${SEPARATOR}
ℹ️ Промокоды публикуются в группе и новостях!`,
      keyboard: 'main'
    };
  }

  // Создание промокода (админ)
  async promocodeCreate(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    // Эта команда будет в admin модуле
    return {
      text: `${identifier} ${EMOJI.error} Используйте admin модуль для создания промокодов.`,
      keyboard: 'main'
    };
  }

  // Удаление промокода (админ)
  async promocodeDelete(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    return {
      text: `${identifier} ${EMOJI.error} Используйте admin модуль для удаления промокодов.`,
      keyboard: 'main'
    };
  }

  // Информация о промокоде
  async promocodeInfo(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (args.length === 0) {
      return { text: `${identifier} ${EMOJI.error} Укажите промокод!`, keyboard: 'main' };
    }

    const code = args[0].toUpperCase();
    const promo = db.getPromocode(code);

    if (!promo) {
      return { text: `${identifier} ${EMOJI.error} Промокод не найден!`, keyboard: 'main' };
    }

    return {
      text: `${identifier} 🎟️ ПРОМОКОД: ${code}
${SEPARATOR}
🎁 Награда: ${promo.rewardType} — ${promo.rewardValue}
📊 Использований: ${promo.usedCount || 0}${promo.limit ? `/${promo.limit}` : ''}
${promo.expiresAt ? `⏳ До: ${formatDate(promo.expiresAt)}` : ''}`,
      keyboard: 'main'
    };
  }
}

module.exports = new ContentModule();
