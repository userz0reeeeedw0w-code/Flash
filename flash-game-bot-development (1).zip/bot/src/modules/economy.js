/**
 * FLASH BOT - Economy Module
 * Команды: баланс, перевод, банк, инвестиции, налоги и т.д.
 */

const db = require('../core/database/db.service');
const config = require('../config');
const { messages } = require('../config/messages');
const { formatNumber, formatDate, formatDuration, getPlayerIdentifier, parseAmount } = require('../core/utils/formatter');
const { hasEnoughMoney, isValidAmount } = require('../core/utils/validator');
const playerFinder = require('../core/utils/player-finder');
const { bankButtons } = require('../config/keyboards');
const { EMOJI } = require('../config/constants');

const SEPARATOR = '━━━━━━━━━━━━━━━━━━━━';

class EconomyModule {
  constructor() {
    this.commands = {
      'balance': this.balance.bind(this),
      'transfer': this.transfer.bind(this),
      'transferHistory': this.transferHistory.bind(this),
      'transferTop': this.transferTop.bind(this),
      'bank': this.bank.bind(this),
      'bankDeposit': this.bankDeposit.bind(this),
      'bankWithdraw': this.bankWithdraw.bind(this),
      'bankInterest': this.bankInterest.bind(this),
      'bankLimit': this.bankLimit.bind(this),
      'bankIncrease': this.bankIncrease.bind(this),
      'bankDepositAccount': this.bankDepositAccount.bind(this),
      'bankDepositClose': this.bankDepositClose.bind(this),
      'bankCreditTake': this.bankCreditTake.bind(this),
      'bankCreditReturn': this.bankCreditReturn.bind(this),
      'bankCreditInfo': this.bankCreditInfo.bind(this),
      'investments': this.investments.bind(this),
      'investmentAdd': this.investmentAdd.bind(this),
      'investmentWithdraw': this.investmentWithdraw.bind(this),
      'investmentStats': this.investmentStats.bind(this),
      'exchange': this.exchange.bind(this),
      'rate': this.rate.bind(this),
      'taxes': this.taxes.bind(this),
      'debt': this.debt.bind(this),
      'networth': this.networth.bind(this),
      'transactions': this.transactions.bind(this)
    };
  }

  // Баланс
  async balance(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const gameConfig = db.getConfig();
    const btcValue = user.bitcoin * (gameConfig.btcRate || 100000);

    return {
      text: `${identifier} ${EMOJI.money} ВАШ БАЛАНС
${SEPARATOR}
💵 Наличные: ${formatNumber(user.money)}$
${EMOJI.bank} В банке: ${formatNumber(user.bankBalance || 0)}$
${SEPARATOR}
${EMOJI.rubles} Рубли: ${formatNumber(user.rubles)}₽
${EMOJI.bitcoin} Биткоин: ${user.bitcoin.toFixed(4)}₿ (~${formatNumber(Math.floor(btcValue))}$)
${EMOJI.diamonds} Алмазы: ${user.diamonds}💎
${EMOJI.cups} Кубки: ${user.cups}🏆
${EMOJI.coins} Монеты: ${user.coins}🪙
${SEPARATOR}
💰 Общее состояние: ~${formatNumber(Math.floor(user.money + (user.bankBalance || 0) + btcValue))}$`,
      keyboard: 'main'
    };
  }

  // Перевод
  async transfer(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (args.length < 2) {
      return {
        text: `${identifier} ${EMOJI.transfer} ПЕРЕВОД
${SEPARATOR}
📝 Использование:
перевод [игрок] [сумма]

💡 Способы указания игрока:
• UID: перевод 2 1000
• VK: перевод @id123456 1000
• TG: перевод @username 1000

⚠️ Переводить можно только $!`,
        keyboard: 'main'
      };
    }

    // Ищем получателя
    const { player: recipient, remainingArgs } = playerFinder.parseFromCommand(args, context);
    
    // Проверяем ответ на сообщение
    let finalRecipient = recipient;
    if (!finalRecipient && context.replyTo) {
      finalRecipient = playerFinder.findFromReply(context.replyTo, context.platform);
    }

    if (!finalRecipient) {
      return {
        text: `${identifier} ${EMOJI.error} Игрок не найден!
${SEPARATOR}
💡 Укажите игрока одним из способов:
• UID (число): перевод 2 1000
• VK ID: перевод @id123456 1000
• Telegram: перевод @username 1000
• Ответом на сообщение`,
        keyboard: 'main'
      };
    }

    // Проверяем что не себе
    if (finalRecipient.uid === user.uid) {
      return { text: messages.errors.selfTransfer(identifier), keyboard: 'main' };
    }

    // Получаем сумму
    const amountArg = remainingArgs.length > 0 ? remainingArgs[0] : args[args.length - 1];
    const amount = parseAmount(amountArg);

    if (amount === 'all') {
      // Перевести всё
      if (user.money < 1) {
        return { text: messages.errors.notEnoughMoney(identifier), keyboard: 'main' };
      }
      return await this.executeTransfer(context, user, finalRecipient, user.money, identifier);
    }

    if (!amount || amount < 1) {
      return { text: messages.errors.invalidAmount(identifier), keyboard: 'main' };
    }

    if (amount < 100) {
      return { text: messages.errors.minTransfer(identifier, 100), keyboard: 'main' };
    }

    if (!hasEnoughMoney(user, amount)) {
      return { text: messages.errors.notEnoughMoney(identifier), keyboard: 'main' };
    }

    return await this.executeTransfer(context, user, finalRecipient, amount, identifier);
  }

  async executeTransfer(context, user, recipient, amount, identifier) {
    // Выполняем перевод
    db.updateUser(context.platform, context.userId, {
      money: user.money - amount,
      totalSpent: (user.totalSpent || 0) + amount
    });

    db.updateUserByUid(recipient.uid, {
      money: recipient.money + amount,
      totalEarned: (recipient.totalEarned || 0) + amount
    });

    // Логируем транзакцию
    db.logTransaction(user.uid, recipient.uid, amount, 'transfer');

    const recipientIdentifier = getPlayerIdentifier(recipient, recipient.platform);

    return {
      text: `${identifier} ${EMOJI.transfer} ПЕРЕВОД
${SEPARATOR}
Отправитель: ${identifier} (UID: #${user.uid})
Получатель: ${recipientIdentifier} (UID: #${recipient.uid})
💰 Сумма: ${formatNumber(amount)}$
${EMOJI.success} Перевод выполнен успешно!
${SEPARATOR}
💵 Ваш остаток: ${formatNumber(user.money - amount)}$`,
      keyboard: 'main'
    };
  }

  // История переводов
  async transferHistory(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const stats = db.getStats();
    const transactions = stats.transactions || [];
    const myTransactions = transactions.filter(t => 
      t.fromUid === user.uid || t.toUid === user.uid
    ).slice(-10);

    if (myTransactions.length === 0) {
      return {
        text: `${identifier} ${EMOJI.transfer} ИСТОРИЯ ПЕРЕВОДОВ
${SEPARATOR}
📭 История переводов пуста.`,
        keyboard: 'main'
      };
    }

    let text = `${identifier} ${EMOJI.transfer} ИСТОРИЯ ПЕРЕВОДОВ
${SEPARATOR}`;

    myTransactions.reverse().forEach(t => {
      const isOutgoing = t.fromUid === user.uid;
      const otherUid = isOutgoing ? t.toUid : t.fromUid;
      const sign = isOutgoing ? '-' : '+';
      const emoji = isOutgoing ? '📤' : '📥';
      text += `\n${emoji} ${sign}${formatNumber(t.amount)}$ | UID #${otherUid} | ${formatDate(t.timestamp)}`;
    });

    return { text, keyboard: 'main' };
  }

  // Топ переводов
  async transferTop(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);

    return {
      text: `${identifier} ${EMOJI.transfer} ТОП ПЕРЕВОДОВ
${SEPARATOR}
📊 Функция в разработке...`,
      keyboard: 'main'
    };
  }

  // Банк
  async bank(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const credit = user.credit || 0;
    const creditDays = user.creditDate ? Math.ceil((Date.now() - user.creditDate) / (24 * 60 * 60 * 1000)) : 0;

    return {
      text: `${identifier} ${EMOJI.bank} БАНК
${SEPARATOR}
💵 На счету: ${formatNumber(user.bankBalance || 0)}$
📊 Лимит: ${formatNumber(user.bankLimit || 100000)}$
📈 Ставка: ${config.bank.interestRate}% в день
${SEPARATOR}
💳 КРЕДИТ:
• Долг: ${formatNumber(credit)}$
${credit > 0 ? `• Дней: ${creditDays} (макс. ${config.bank.creditDays})` : '• Нет активного кредита'}
• Ставка: ${config.bank.creditRate}% в месяц
• Макс. сумма: ${formatNumber(config.bank.maxCredit)}$
${SEPARATOR}
📝 КОМАНДЫ:
• банк положить [сумма]
• банк снять [сумма]
• банк кредит взять [сумма]
• банк кредит вернуть`,
      buttons: bankButtons,
      keyboard: 'main'
    };
  }

  // Положить в банк
  async bankDeposit(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (args.length === 0) {
      return {
        text: `${identifier} ${EMOJI.error} Укажите сумму!\nПример: банк положить 1000`,
        keyboard: 'main'
      };
    }

    const amount = parseAmount(args[0]);
    const maxDeposit = (user.bankLimit || 100000) - (user.bankBalance || 0);

    if (amount === 'all') {
      const depositAmount = Math.min(user.money, maxDeposit);
      if (depositAmount < 1) {
        return { text: `${identifier} ${EMOJI.error} Нечего класть или достигнут лимит!`, keyboard: 'main' };
      }
      return await this.executeDeposit(context, user, depositAmount, identifier);
    }

    if (!amount || amount < 1) {
      return { text: messages.errors.invalidAmount(identifier), keyboard: 'main' };
    }

    if (amount > maxDeposit) {
      return { text: `${identifier} ${EMOJI.error} Превышен лимит! Доступно: ${formatNumber(maxDeposit)}$`, keyboard: 'main' };
    }

    if (!hasEnoughMoney(user, amount)) {
      return { text: messages.errors.notEnoughMoney(identifier), keyboard: 'main' };
    }

    return await this.executeDeposit(context, user, amount, identifier);
  }

  async executeDeposit(context, user, amount, identifier) {
    db.updateUser(context.platform, context.userId, {
      money: user.money - amount,
      bankBalance: (user.bankBalance || 0) + amount
    });

    return {
      text: `${identifier} ${EMOJI.success} Вклад пополнен!
${SEPARATOR}
📥 Положено: ${formatNumber(amount)}$
${EMOJI.bank} На счету: ${formatNumber((user.bankBalance || 0) + amount)}$
💵 Наличные: ${formatNumber(user.money - amount)}$`,
      keyboard: 'main'
    };
  }

  // Снять из банка
  async bankWithdraw(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (args.length === 0) {
      return {
        text: `${identifier} ${EMOJI.error} Укажите сумму!\nПример: банк снять 1000`,
        keyboard: 'main'
      };
    }

    const amount = parseAmount(args[0]);
    const bankBalance = user.bankBalance || 0;

    if (amount === 'all') {
      if (bankBalance < 1) {
        return { text: `${identifier} ${EMOJI.error} На счету пусто!`, keyboard: 'main' };
      }
      return await this.executeWithdraw(context, user, bankBalance, identifier);
    }

    if (!amount || amount < 1) {
      return { text: messages.errors.invalidAmount(identifier), keyboard: 'main' };
    }

    if (amount > bankBalance) {
      return { text: `${identifier} ${EMOJI.error} Недостаточно на счету! Доступно: ${formatNumber(bankBalance)}$`, keyboard: 'main' };
    }

    return await this.executeWithdraw(context, user, amount, identifier);
  }

  async executeWithdraw(context, user, amount, identifier) {
    db.updateUser(context.platform, context.userId, {
      money: user.money + amount,
      bankBalance: (user.bankBalance || 0) - amount
    });

    return {
      text: `${identifier} ${EMOJI.success} Средства сняты!
${SEPARATOR}
📤 Снято: ${formatNumber(amount)}$
${EMOJI.bank} На счету: ${formatNumber((user.bankBalance || 0) - amount)}$
💵 Наличные: ${formatNumber(user.money + amount)}$`,
      keyboard: 'main'
    };
  }

  // Процентная ставка
  async bankInterest(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    
    return {
      text: `${identifier} 📈 БАНКОВСКИЕ ПРОЦЕНТЫ
${SEPARATOR}
💰 Вклады: +${config.bank.interestRate}% в день
💳 Кредиты: ${config.bank.creditRate}% в месяц
${SEPARATOR}
💡 Проценты начисляются в 00:00`,
      keyboard: 'main'
    };
  }

  // Лимит банка
  async bankLimit(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    return {
      text: `${identifier} 📊 ЛИМИТ БАНКА
${SEPARATOR}
📈 Текущий лимит: ${formatNumber(user.bankLimit || 100000)}$
💵 На счету: ${formatNumber(user.bankBalance || 0)}$
📉 Свободно: ${formatNumber((user.bankLimit || 100000) - (user.bankBalance || 0))}$
${SEPARATOR}
💡 Для увеличения лимита: банк увеличить`,
      keyboard: 'main'
    };
  }

  // Увеличение лимита
  async bankIncrease(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const currentLimit = user.bankLimit || 100000;
    const cost = Math.floor(currentLimit * 0.1); // 10% от текущего лимита
    const newLimit = currentLimit + 100000;

    if (!hasEnoughMoney(user, cost)) {
      return {
        text: `${identifier} ${EMOJI.error} Недостаточно средств!
${SEPARATOR}
💰 Стоимость увеличения: ${formatNumber(cost)}$
📈 Новый лимит: ${formatNumber(newLimit)}$`,
        keyboard: 'main'
      };
    }

    db.updateUser(context.platform, context.userId, {
      money: user.money - cost,
      bankLimit: newLimit
    });

    return {
      text: `${identifier} ${EMOJI.success} Лимит увеличен!
${SEPARATOR}
💰 Потрачено: ${formatNumber(cost)}$
📈 Новый лимит: ${formatNumber(newLimit)}$`,
      keyboard: 'main'
    };
  }

  // Депозитный счёт
  async bankDepositAccount(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    return {
      text: `${identifier} 📊 ДЕПОЗИТ
${SEPARATOR}
🔧 Функция в разработке...`,
      keyboard: 'main'
    };
  }

  // Закрыть депозит
  async bankDepositClose(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    return {
      text: `${identifier} 📊 ЗАКРЫТИЕ ДЕПОЗИТА
${SEPARATOR}
🔧 Функция в разработке...`,
      keyboard: 'main'
    };
  }

  // Взять кредит
  async bankCreditTake(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (user.credit && user.credit > 0) {
      return {
        text: `${identifier} ${EMOJI.error} У вас уже есть активный кредит!
${SEPARATOR}
💳 Долг: ${formatNumber(user.credit)}$
📝 Верните кредит: банк кредит вернуть`,
        keyboard: 'main'
      };
    }

    if (args.length === 0) {
      return {
        text: `${identifier} 💳 КРЕДИТ
${SEPARATOR}
📝 Использование: банк кредит взять [сумма]
💰 Максимум: ${formatNumber(config.bank.maxCredit)}$
📈 Ставка: ${config.bank.creditRate}% в месяц
⏱️ Срок: ${config.bank.creditDays} дней`,
        keyboard: 'main'
      };
    }

    const amount = parseAmount(args[0]);

    if (!amount || amount < 1000) {
      return { text: `${identifier} ${EMOJI.error} Минимальная сумма кредита: 1,000$`, keyboard: 'main' };
    }

    if (amount > config.bank.maxCredit) {
      return { text: `${identifier} ${EMOJI.error} Максимальная сумма кредита: ${formatNumber(config.bank.maxCredit)}$`, keyboard: 'main' };
    }

    db.updateUser(context.platform, context.userId, {
      money: user.money + amount,
      credit: amount,
      creditDate: Date.now()
    });

    return {
      text: `${identifier} ${EMOJI.success} Кредит получен!
${SEPARATOR}
💳 Сумма: ${formatNumber(amount)}$
📈 Ставка: ${config.bank.creditRate}% в месяц
⏱️ Срок: ${config.bank.creditDays} дней
${SEPARATOR}
⚠️ Верните вовремя, иначе штраф!`,
      keyboard: 'main'
    };
  }

  // Вернуть кредит
  async bankCreditReturn(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (!user.credit || user.credit <= 0) {
      return {
        text: `${identifier} ${EMOJI.info} У вас нет активного кредита.`,
        keyboard: 'main'
      };
    }

    // Рассчитываем проценты
    const days = Math.ceil((Date.now() - user.creditDate) / (24 * 60 * 60 * 1000));
    const interest = Math.floor(user.credit * (config.bank.creditRate / 100) * (days / 30));
    const totalDebt = user.credit + interest;

    if (!hasEnoughMoney(user, totalDebt)) {
      return {
        text: `${identifier} ${EMOJI.error} Недостаточно средств!
${SEPARATOR}
💳 Основной долг: ${formatNumber(user.credit)}$
📈 Проценты (${days} дн.): ${formatNumber(interest)}$
💰 Итого к оплате: ${formatNumber(totalDebt)}$
💵 У вас: ${formatNumber(user.money)}$`,
        keyboard: 'main'
      };
    }

    db.updateUser(context.platform, context.userId, {
      money: user.money - totalDebt,
      credit: 0,
      creditDate: null
    });

    return {
      text: `${identifier} ${EMOJI.success} Кредит погашен!
${SEPARATOR}
💳 Выплачено: ${formatNumber(totalDebt)}$
• Основной долг: ${formatNumber(user.credit)}$
• Проценты: ${formatNumber(interest)}$`,
      keyboard: 'main'
    };
  }

  // Информация о кредите
  async bankCreditInfo(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (!user.credit || user.credit <= 0) {
      return {
        text: `${identifier} ${EMOJI.info} У вас нет активного кредита.
${SEPARATOR}
💡 Взять кредит: банк кредит взять [сумма]`,
        keyboard: 'main'
      };
    }

    const days = Math.ceil((Date.now() - user.creditDate) / (24 * 60 * 60 * 1000));
    const interest = Math.floor(user.credit * (config.bank.creditRate / 100) * (days / 30));
    const daysLeft = config.bank.creditDays - days;

    return {
      text: `${identifier} 💳 ИНФОРМАЦИЯ О КРЕДИТЕ
${SEPARATOR}
💰 Основной долг: ${formatNumber(user.credit)}$
📈 Проценты: ${formatNumber(interest)}$
💵 Итого: ${formatNumber(user.credit + interest)}$
${SEPARATOR}
📅 Взят: ${formatDate(user.creditDate)}
⏱️ Прошло дней: ${days}
⏳ Осталось: ${daysLeft > 0 ? daysLeft : 0} дней
${daysLeft <= 0 ? '\n⚠️ СРОК ИСТЁК! Верните срочно!' : ''}`,
      keyboard: 'main'
    };
  }

  // Инвестиции
  async investments(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    return {
      text: `${identifier} 📊 ИНВЕСТИЦИИ
${SEPARATOR}
💰 Минимум: ${formatNumber(config.investments.minAmount)}$
💵 Максимум: ${formatNumber(config.investments.maxAmount)}$
📈 Доход: ${config.investments.monthlyReturn.min}-${config.investments.monthlyReturn.max}% в месяц
⚠️ Риск потери: ${config.investments.riskPercent}%
${SEPARATOR}
📝 КОМАНДЫ:
• инвестиции вложить [сумма]
• инвестиции вывести
• инвестиции статистика`,
      keyboard: 'main'
    };
  }

  // Вложить инвестиции
  async investmentAdd(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    return {
      text: `${identifier} 📊 ИНВЕСТИЦИИ
${SEPARATOR}
🔧 Функция в разработке...`,
      keyboard: 'main'
    };
  }

  // Вывести инвестиции
  async investmentWithdraw(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    return {
      text: `${identifier} 📊 ВЫВОД ИНВЕСТИЦИЙ
${SEPARATOR}
🔧 Функция в разработке...`,
      keyboard: 'main'
    };
  }

  // Статистика инвестиций
  async investmentStats(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    return {
      text: `${identifier} 📊 СТАТИСТИКА ИНВЕСТИЦИЙ
${SEPARATOR}
🔧 Функция в разработке...`,
      keyboard: 'main'
    };
  }

  // Обмен валют
  async exchange(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    const gameConfig = db.getConfig();
    
    return {
      text: `${identifier} 💱 ОБМЕН ВАЛЮТ
${SEPARATOR}
${EMOJI.bitcoin} BTC → $ : 1₿ = ${formatNumber(gameConfig.btcRate || 100000)}$
${SEPARATOR}
🔧 Обмен BTC в разработке...`,
      keyboard: 'main'
    };
  }

  // Курс
  async rate(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    const gameConfig = db.getConfig();
    
    return {
      text: `${identifier} 📈 КУРС ВАЛЮТ
${SEPARATOR}
${EMOJI.bitcoin} Биткоин: ${formatNumber(gameConfig.btcRate || 100000)}$
📅 Обновлён: ${formatDate(gameConfig.lastBtcUpdate)}
${SEPARATOR}
💡 Курс обновляется каждые 6 часов`,
      keyboard: 'main'
    };
  }

  // Налоги
  async taxes(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const daysSinceReg = Math.floor((Date.now() - user.registeredAt) / (24 * 60 * 60 * 1000));
    const isNewbie = daysSinceReg < config.taxes.newbieDays;

    const totalWealth = user.money + (user.bankBalance || 0);
    let estimatedTax = Math.floor(totalWealth * (config.taxes.dailyPercent / 100));
    estimatedTax = Math.max(config.taxes.minDaily, Math.min(config.taxes.maxDaily, estimatedTax));

    return {
      text: `${identifier} 💸 НАЛОГИ
${SEPARATOR}
📊 Ставка: ${config.taxes.dailyPercent}% от состояния
💰 Минимум: ${formatNumber(config.taxes.minDaily)}$/день
💵 Максимум: ${formatNumber(config.taxes.maxDaily)}$/день
${SEPARATOR}
📈 Ваше состояние: ${formatNumber(totalWealth)}$
💸 Ваш налог: ~${formatNumber(estimatedTax)}$/день
${isNewbie ? `\n🆕 Льгота новичка: ещё ${config.taxes.newbieDays - daysSinceReg} дней без налогов!` : ''}
${SEPARATOR}
💡 Налоги списываются в 00:00`,
      keyboard: 'main'
    };
  }

  // Долги
  async debt(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const credit = user.credit || 0;

    if (credit === 0) {
      return {
        text: `${identifier} ${EMOJI.success} У вас нет долгов!`,
        keyboard: 'main'
      };
    }

    return {
      text: `${identifier} 💳 ВАШИ ДОЛГИ
${SEPARATOR}
💳 Кредит: ${formatNumber(credit)}$
${SEPARATOR}
📝 Для погашения: банк кредит вернуть`,
      keyboard: 'main'
    };
  }

  // Состояние (net worth)
  async networth(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const gameConfig = db.getConfig();
    const btcValue = user.bitcoin * (gameConfig.btcRate || 100000);
    const cash = user.money;
    const bank = user.bankBalance || 0;
    const debt = user.credit || 0;

    // Стоимость имущества
    let propertyValue = 0;
    if (user.businesses) {
      user.businesses.forEach(biz => {
        propertyValue += biz.price || 0;
      });
    }
    if (user.cars) {
      user.cars.forEach(car => {
        propertyValue += car.price || 0;
      });
    }

    const total = cash + bank + btcValue + propertyValue - debt;

    return {
      text: `${identifier} 💰 СОСТОЯНИЕ
${SEPARATOR}
💵 Наличные: ${formatNumber(cash)}$
${EMOJI.bank} В банке: ${formatNumber(bank)}$
${EMOJI.bitcoin} Биткоин: ~${formatNumber(Math.floor(btcValue))}$
🏢 Имущество: ~${formatNumber(propertyValue)}$
${SEPARATOR}
💳 Долги: -${formatNumber(debt)}$
${SEPARATOR}
💎 ИТОГО: ${formatNumber(Math.floor(total))}$`,
      keyboard: 'main'
    };
  }

  // Транзакции
  async transactions(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    // Перенаправляем на историю переводов
    return await this.transferHistory(context, user, args);
  }
}

module.exports = new EconomyModule();
