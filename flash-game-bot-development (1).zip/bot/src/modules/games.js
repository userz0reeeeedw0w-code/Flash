/**
 * FLASH BOT - Games Module
 * Команды: казино, рыбалка, охота, грабеж, дуэль, арена, турнир, кейсы, машины, гонки, тюнинг
 */

const db = require('../core/database/db.service');
const config = require('../config');
const { messages } = require('../config/messages');
const { formatNumber, getPlayerIdentifier, parseAmount, getExpForLevel } = require('../core/utils/formatter');
const { hasEnoughMoney, hasEnoughEnergy, isOnCooldown, checkDailyLimit, calculateIncomeModifier } = require('../core/utils/validator');
const { randomInt, weightedRandom, checkChance, randomChoice } = require('../core/utils/crypto');
const playerFinder = require('../core/utils/player-finder');
const { casinoButtons } = require('../config/keyboards');
const { EMOJI, CARS, FISH, CASES } = require('../config/constants');

const SEPARATOR = '━━━━━━━━━━━━━━━━━━━━';

class GamesModule {
  constructor() {
    this.commands = {
      'casino': this.casino.bind(this),
      'casinoSlots': this.casinoSlots.bind(this),
      'casinoDice': this.casinoDice.bind(this),
      'casinoCards': this.casinoCards.bind(this),
      'casinoBlackjack': this.casinoBlackjack.bind(this),
      'casinoStats': this.casinoStats.bind(this),
      'casinoTop': this.casinoTop.bind(this),
      'fishing': this.fishing.bind(this),
      'fishSell': this.fishSell.bind(this),
      'hunting': this.hunting.bind(this),
      'robbery': this.robbery.bind(this),
      'robberyDefense': this.robberyDefense.bind(this),
      'duel': this.duel.bind(this),
      'duelAccept': this.duelAccept.bind(this),
      'duelDecline': this.duelDecline.bind(this),
      'duelStats': this.duelStats.bind(this),
      'arena': this.arena.bind(this),
      'tournament': this.tournament.bind(this),
      'case': this.case.bind(this),
      'caseList': this.caseList.bind(this),
      'caseOpen': this.caseOpen.bind(this),
      'car': this.car.bind(this),
      'carList': this.carList.bind(this),
      'carBuy': this.carBuy.bind(this),
      'carInfo': this.carInfo.bind(this),
      'carSelect': this.carSelect.bind(this),
      'carSell': this.carSell.bind(this),
      'carRepair': this.carRepair.bind(this),
      'tuning': this.tuning.bind(this),
      'tuningBuy': this.tuningBuy.bind(this),
      'race': this.race.bind(this),
      'raceStats': this.raceStats.bind(this),
      'raceTop': this.raceTop.bind(this)
    };
  }

  // Казино
  async casino(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (args.length === 0) {
      return {
        text: `${identifier} ${EMOJI.casino} КАЗИНО
${SEPARATOR}
🎰 Игры:
• казино [сумма] — быстрая ставка
• казино слоты — игровые автоматы
• казино кости — игра в кости
• казино карты — карточная игра
${SEPARATOR}
📊 Статистика: казино статистика
🏆 Топ: казино топ
${SEPARATOR}
💡 Множители: x0.25, x0.5, x1, x2, x3, x5, x10`,
        buttons: casinoButtons,
        keyboard: 'main'
      };
    }

    // Быстрая ставка
    const amount = parseAmount(args[0]);
    
    if (amount === 'all') {
      if (user.money < 100) {
        return { text: messages.errors.notEnoughMoney(identifier), keyboard: 'main' };
      }
      return await this.playSlots(context, user, user.money, identifier);
    }

    if (!amount || amount < 100) {
      return { text: `${identifier} ${EMOJI.error} Минимальная ставка: 100$`, keyboard: 'main' };
    }

    if (!hasEnoughMoney(user, amount)) {
      return { text: messages.errors.notEnoughMoney(identifier), keyboard: 'main' };
    }

    return await this.playSlots(context, user, amount, identifier);
  }

  // Слоты
  async casinoSlots(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const amount = args.length > 0 ? parseAmount(args[0]) : 1000;
    
    if (!amount || amount < 100) {
      return { text: `${identifier} ${EMOJI.error} Минимальная ставка: 100$`, keyboard: 'main' };
    }

    if (!hasEnoughMoney(user, amount)) {
      return { text: messages.errors.notEnoughMoney(identifier), keyboard: 'main' };
    }

    return await this.playSlots(context, user, amount, identifier);
  }

  async playSlots(context, user, amount, identifier) {
    // Проверка лимита
    const limit = checkDailyLimit(user, 'casino');
    if (!limit.canDo) {
      return { text: messages.errors.limitReached(identifier, 'казино'), keyboard: 'main' };
    }

    // Проверка энергии
    if (!hasEnoughEnergy(user, config.energyCost.casino)) {
      return { text: messages.errors.notEnoughEnergy(identifier), keyboard: 'main' };
    }

    // Выбираем множитель
    const result = weightedRandom(config.casinoMultipliers);
    const multiplier = result.value;
    const winAmount = Math.floor(amount * multiplier);
    const profit = winAmount - amount;

    // Генерируем символы слотов
    const symbols = ['🍒', '🍋', '🍊', '🍇', '💎', '7️⃣', '🎰'];
    let slots = [
      randomChoice(symbols),
      randomChoice(symbols),
      randomChoice(symbols)
    ];

    // Если выигрыш большой - делаем символы одинаковыми
    if (multiplier >= 5) {
      const winSymbol = multiplier >= 10 ? '7️⃣' : '💎';
      slots = [winSymbol, winSymbol, winSymbol];
    } else if (multiplier >= 2) {
      slots[0] = slots[1];
    }

    // Обновляем баланс и статистику
    const dailyLimits = { ...(user.dailyLimits || {}), casino: (user.dailyLimits?.casino || 0) + 1 };

    db.updateUser(context.platform, context.userId, {
      money: user.money + profit,
      energy: user.energy - config.energyCost.casino,
      gamesPlayed: (user.gamesPlayed || 0) + 1,
      gamesWon: profit > 0 ? (user.gamesWon || 0) + 1 : user.gamesWon || 0,
      dailyLimits,
      totalEarned: profit > 0 ? (user.totalEarned || 0) + profit : user.totalEarned || 0,
      totalSpent: profit < 0 ? (user.totalSpent || 0) - profit : user.totalSpent || 0
    });

    const resultEmoji = profit > 0 ? EMOJI.success : profit < 0 ? EMOJI.error : '🔄';
    const resultText = profit > 0 ? `Выигрыш: +${formatNumber(profit)}$` : 
                       profit < 0 ? `Проигрыш: ${formatNumber(profit)}$` : 
                       'Возврат ставки';

    return {
      text: `${identifier} ${EMOJI.casino} СЛОТЫ
${SEPARATOR}
┏━━━━━━━━━━━━━━━━━┓
┃   ${slots[0]}   ${slots[1]}   ${slots[2]}   ┃
┗━━━━━━━━━━━━━━━━━┛
${SEPARATOR}
🎲 Ставка: ${formatNumber(amount)}$
🎯 Множитель: x${multiplier}
${resultEmoji} ${resultText}
${SEPARATOR}
💰 Баланс: ${formatNumber(user.money + profit)}$`,
      keyboard: 'main'
    };
  }

  // Кости
  async casinoDice(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const amount = args.length > 0 ? parseAmount(args[0]) : 1000;
    
    if (!amount || amount < 100) {
      return { text: `${identifier} ${EMOJI.error} Минимальная ставка: 100$`, keyboard: 'main' };
    }

    if (!hasEnoughMoney(user, amount)) {
      return { text: messages.errors.notEnoughMoney(identifier), keyboard: 'main' };
    }

    const dice1 = randomInt(1, 6);
    const dice2 = randomInt(1, 6);
    const total = dice1 + dice2;

    let multiplier = 0;
    if (total === 12) multiplier = 5;
    else if (total === 11 || total === 2) multiplier = 3;
    else if (total >= 9) multiplier = 2;
    else if (total >= 7) multiplier = 1;
    else multiplier = 0;

    const winAmount = Math.floor(amount * multiplier);
    const profit = winAmount - amount;

    db.updateUser(context.platform, context.userId, {
      money: user.money + profit,
      gamesPlayed: (user.gamesPlayed || 0) + 1,
      gamesWon: profit > 0 ? (user.gamesWon || 0) + 1 : user.gamesWon || 0
    });

    const diceEmoji = ['', '⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];

    return {
      text: `${identifier} 🎲 КОСТИ
${SEPARATOR}
${diceEmoji[dice1]} + ${diceEmoji[dice2]} = ${total}
${SEPARATOR}
🎲 Ставка: ${formatNumber(amount)}$
🎯 Множитель: x${multiplier}
${profit >= 0 ? EMOJI.success : EMOJI.error} ${profit >= 0 ? '+' : ''}${formatNumber(profit)}$
${SEPARATOR}
💰 Баланс: ${formatNumber(user.money + profit)}$`,
      keyboard: 'main'
    };
  }

  // Карты
  async casinoCards(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    return {
      text: `${identifier} 🃏 КАРТЫ
${SEPARATOR}
🔧 Игра в разработке...`,
      keyboard: 'main'
    };
  }

  // Блэкджек
  async casinoBlackjack(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    return {
      text: `${identifier} ♠️ БЛЭКДЖЕК
${SEPARATOR}
🔧 Игра в разработке...`,
      keyboard: 'main'
    };
  }

  // Статистика казино
  async casinoStats(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const winRate = user.gamesPlayed > 0 ? Math.round((user.gamesWon || 0) / user.gamesPlayed * 100) : 0;

    return {
      text: `${identifier} 📊 СТАТИСТИКА КАЗИНО
${SEPARATOR}
🎮 Всего игр: ${user.gamesPlayed || 0}
🏆 Побед: ${user.gamesWon || 0}
📈 Процент побед: ${winRate}%
${SEPARATOR}
💰 Заработано: ${formatNumber(user.totalEarned || 0)}$
💸 Проиграно: ${formatNumber(user.totalSpent || 0)}$`,
      keyboard: 'main'
    };
  }

  // Топ казино
  async casinoTop(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    
    const users = Object.values(db.getUsers())
      .filter(u => u.gamesWon > 0)
      .sort((a, b) => (b.gamesWon || 0) - (a.gamesWon || 0))
      .slice(0, 10);

    let text = `${identifier} 🏆 ТОП КАЗИНО
${SEPARATOR}`;

    if (users.length === 0) {
      text += '\n📭 Пока никто не играл!';
    } else {
      users.forEach((u, i) => {
        const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i + 1}.`;
        text += `\n${medal} ${u.nickname} — ${u.gamesWon} побед`;
      });
    }

    return { text, keyboard: 'main' };
  }

  // Рыбалка
  async fishing(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const cooldown = isOnCooldown(user, 'fishing');
    if (cooldown.onCooldown) {
      return { text: messages.errors.cooldown(identifier, cooldown.remaining), keyboard: 'main' };
    }

    if (!hasEnoughEnergy(user, config.energyCost.fishing)) {
      return { text: messages.errors.notEnoughEnergy(identifier), keyboard: 'main' };
    }

    const limit = checkDailyLimit(user, 'fishing');
    if (!limit.canDo) {
      return { text: messages.errors.limitReached(identifier, 'рыбалка'), keyboard: 'main' };
    }

    // Ловим рыбу
    const fish = weightedRandom(FISH);
    const amount = randomInt(1, 3) * (user.rodLevel || 1);
    
    const userFish = { ...(user.fish || {}) };
    userFish[fish.name] = (userFish[fish.name] || 0) + amount;

    const cooldowns = { ...(user.cooldowns || {}), fishing: Date.now() };
    const dailyLimits = { ...(user.dailyLimits || {}), fishing: (user.dailyLimits?.fishing || 0) + 1 };

    db.updateUser(context.platform, context.userId, {
      fish: userFish,
      energy: user.energy - config.energyCost.fishing,
      cooldowns,
      dailyLimits
    });

    return {
      text: `${identifier} ${EMOJI.fishing} РЫБАЛКА
${SEPARATOR}
🎣 Вы поймали:
• ${fish.name} x${amount} (${formatNumber(amount * fish.price)}$)
${SEPARATOR}
💡 Продать: рыба продать`,
      keyboard: 'main'
    };
  }

  // Продажа рыбы
  async fishSell(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const fish = user.fish || {};
    let totalValue = 0;

    FISH.forEach(f => {
      const amount = fish[f.name] || 0;
      totalValue += amount * f.price;
    });

    if (totalValue === 0) {
      return { text: `${identifier} ${EMOJI.error} У вас нет рыбы для продажи!`, keyboard: 'main' };
    }

    db.updateUser(context.platform, context.userId, {
      money: user.money + totalValue,
      fish: {},
      totalEarned: (user.totalEarned || 0) + totalValue
    });

    return {
      text: `${identifier} ${EMOJI.success} Рыба продана!
${SEPARATOR}
💰 Получено: ${formatNumber(totalValue)}$`,
      keyboard: 'main'
    };
  }

  // Охота
  async hunting(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    return {
      text: `${identifier} ${EMOJI.hunting} ОХОТА
${SEPARATOR}
🔧 Функция в разработке...`,
      keyboard: 'main'
    };
  }

  // Грабёж
  async robbery(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const cooldown = isOnCooldown(user, 'robbery');
    if (cooldown.onCooldown) {
      return { text: messages.errors.cooldown(identifier, cooldown.remaining), keyboard: 'main' };
    }

    if (!hasEnoughEnergy(user, config.energyCost.robbery)) {
      return { text: messages.errors.notEnoughEnergy(identifier), keyboard: 'main' };
    }

    const limit = checkDailyLimit(user, 'robbery');
    if (!limit.canDo) {
      return { text: messages.errors.limitReached(identifier, 'грабёж'), keyboard: 'main' };
    }

    if (args.length === 0) {
      return {
        text: `${identifier} 🦹 ГРАБЁЖ
${SEPARATOR}
📝 Использование: грабеж [игрок]
💡 Укажите UID, @id или @username
${SEPARATOR}
⚠️ Шанс успеха зависит от силы!
❗ При неудаче вы заплатите штраф!`,
        keyboard: 'main'
      };
    }

    // Ищем жертву
    const { player: victim } = playerFinder.parseFromCommand(args, context);
    
    if (!victim) {
      return { text: messages.errors.playerNotFound(identifier), keyboard: 'main' };
    }

    if (victim.uid === user.uid) {
      return { text: `${identifier} ${EMOJI.error} Нельзя ограбить себя!`, keyboard: 'main' };
    }

    // Проверяем защиту
    if (victim.robberyDefense) {
      return { text: `${identifier} ${EMOJI.error} У игрока активна защита от грабежа!`, keyboard: 'main' };
    }

    // Шанс успеха (зависит от силы)
    const successChance = Math.min(70, 30 + (user.strength - victim.strength));
    const isSuccess = checkChance(successChance);

    const cooldowns = { ...(user.cooldowns || {}), robbery: Date.now() };
    const dailyLimits = { ...(user.dailyLimits || {}), robbery: (user.dailyLimits?.robbery || 0) + 1 };

    if (isSuccess) {
      // Грабим 5-15% от наличных жертвы
      const stolenPercent = randomInt(5, 15);
      const stolenAmount = Math.floor(victim.money * (stolenPercent / 100));

      if (stolenAmount < 100) {
        db.updateUser(context.platform, context.userId, {
          energy: user.energy - config.energyCost.robbery,
          cooldowns,
          dailyLimits
        });

        return {
          text: `${identifier} ${EMOJI.error} У жертвы слишком мало денег!`,
          keyboard: 'main'
        };
      }

      db.updateUser(context.platform, context.userId, {
        money: user.money + stolenAmount,
        energy: user.energy - config.energyCost.robbery,
        cooldowns,
        dailyLimits,
        totalEarned: (user.totalEarned || 0) + stolenAmount
      });

      db.updateUserByUid(victim.uid, {
        money: victim.money - stolenAmount
      });

      const victimIdentifier = getPlayerIdentifier(victim, victim.platform);

      return {
        text: `${identifier} ${EMOJI.success} УСПЕШНЫЙ ГРАБЁЖ!
${SEPARATOR}
🦹 Жертва: ${victimIdentifier}
💰 Украдено: ${formatNumber(stolenAmount)}$`,
        keyboard: 'main'
      };
    } else {
      // Неудача - штраф
      const fine = Math.min(user.money, 5000);

      db.updateUser(context.platform, context.userId, {
        money: user.money - fine,
        energy: user.energy - config.energyCost.robbery,
        cooldowns,
        dailyLimits
      });

      return {
        text: `${identifier} ${EMOJI.error} ГРАБЁЖ ПРОВАЛЕН!
${SEPARATOR}
👮 Вас поймали!
💸 Штраф: ${formatNumber(fine)}$`,
        keyboard: 'main'
      };
    }
  }

  // Защита от грабежа
  async robberyDefense(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const cost = 10000;

    if (user.robberyDefense) {
      return {
        text: `${identifier} 🛡️ ЗАЩИТА ОТ ГРАБЕЖА
${SEPARATOR}
✅ Защита активна!
💡 Отключить: грабеж защита выкл`,
        keyboard: 'main'
      };
    }

    if (!hasEnoughMoney(user, cost)) {
      return { text: `${identifier} ${EMOJI.error} Недостаточно средств! Нужно: ${formatNumber(cost)}$`, keyboard: 'main' };
    }

    db.updateUser(context.platform, context.userId, {
      money: user.money - cost,
      robberyDefense: true
    });

    return {
      text: `${identifier} ${EMOJI.success} Защита активирована!
${SEPARATOR}
🛡️ Вас теперь нельзя ограбить!
💰 Потрачено: ${formatNumber(cost)}$`,
      keyboard: 'main'
    };
  }

  // Дуэль
  async duel(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (args.length === 0) {
      return {
        text: `${identifier} ${EMOJI.duel} ДУЭЛЬ
${SEPARATOR}
📝 Использование: дуэль [игрок]
💡 Укажите UID, @id или @username
${SEPARATOR}
⚔️ Побеждает сильнейший!
🎁 Победитель получает награду!`,
        keyboard: 'main'
      };
    }

    return {
      text: `${identifier} ${EMOJI.duel} ДУЭЛЬ
${SEPARATOR}
🔧 Функция в разработке...`,
      keyboard: 'main'
    };
  }

  // Принять дуэль
  async duelAccept(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    return {
      text: `${identifier} ${EMOJI.duel} ПРИНЯТИЕ ДУЭЛИ
${SEPARATOR}
🔧 Функция в разработке...`,
      keyboard: 'main'
    };
  }

  // Отклонить дуэль
  async duelDecline(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    return {
      text: `${identifier} ${EMOJI.duel} ОТКЛОНЕНИЕ ДУЭЛИ
${SEPARATOR}
🔧 Функция в разработке...`,
      keyboard: 'main'
    };
  }

  // Статистика дуэлей
  async duelStats(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    return {
      text: `${identifier} 📊 СТАТИСТИКА ДУЭЛЕЙ
${SEPARATOR}
⚔️ Всего дуэлей: ${user.duelsPlayed || 0}
🏆 Побед: ${user.duelsWon || 0}
💀 Поражений: ${(user.duelsPlayed || 0) - (user.duelsWon || 0)}`,
      keyboard: 'main'
    };
  }

  // Арена
  async arena(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    return {
      text: `${identifier} 🏟️ АРЕНА
${SEPARATOR}
🔧 Функция в разработке...`,
      keyboard: 'main'
    };
  }

  // Турнир
  async tournament(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    return {
      text: `${identifier} 🏆 ТУРНИРЫ
${SEPARATOR}
🔧 Функция в разработке...`,
      keyboard: 'main'
    };
  }

  // Кейсы
  async case(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    return await this.caseList(context, user, args);
  }

  // Список кейсов
  async caseList(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    
    let text = `${identifier} ${EMOJI.case} КЕЙСЫ
${SEPARATOR}`;

    CASES.forEach(c => {
      const currency = c.currency === 'money' ? '$' : '₽';
      text += `\n${c.id}. ${c.name} — ${formatNumber(c.price)}${currency}`;
    });

    text += `\n${SEPARATOR}\n💡 Открыть: кейс открыть [номер]`;

    return { text, keyboard: 'main' };
  }

  // Открытие кейса
  async caseOpen(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (args.length === 0) {
      return await this.caseList(context, user, args);
    }

    const caseId = parseInt(args[0]);
    const caseTemplate = CASES.find(c => c.id === caseId);

    if (!caseTemplate) {
      return { text: `${identifier} ${EMOJI.error} Кейс не найден!`, keyboard: 'main' };
    }

    const currency = caseTemplate.currency === 'money' ? user.money : user.rubles;
    
    if (currency < caseTemplate.price) {
      return { text: messages.errors.notEnoughMoney(identifier), keyboard: 'main' };
    }

    // Выбираем награду
    const reward = weightedRandom(caseTemplate.rewards);
    let rewardText = '';
    const updates = {
      [caseTemplate.currency === 'money' ? 'money' : 'rubles']: currency - caseTemplate.price
    };

    switch (reward.type) {
      case 'money':
        const moneyAmount = randomInt(reward.min, reward.max);
        updates.money = (updates.money || user.money) + moneyAmount;
        rewardText = `💰 ${formatNumber(moneyAmount)}$`;
        break;
      case 'rubles':
        const rublesAmount = randomInt(reward.min, reward.max);
        updates.rubles = (updates.rubles || user.rubles) + rublesAmount;
        rewardText = `₽ ${formatNumber(rublesAmount)}₽`;
        break;
      case 'experience':
        const expAmount = randomInt(reward.min, reward.max);
        updates.experience = user.experience + expAmount;
        rewardText = `⭐ ${expAmount} опыта`;
        break;
      case 'diamonds':
        const diamondsAmount = randomInt(reward.min, reward.max);
        updates.diamonds = user.diamonds + diamondsAmount;
        rewardText = `💎 ${diamondsAmount} алмазов`;
        break;
      case 'car':
        const carTemplate = CARS.find(c => c.id === reward.carId);
        if (carTemplate) {
          const newCar = { ...carTemplate, tuning: 0, fuel: 100, condition: 100 };
          updates.cars = [...(user.cars || []), newCar];
          rewardText = `🚗 ${carTemplate.name}`;
        }
        break;
      default:
        rewardText = '🎁 Сюрприз!';
    }

    db.updateUser(context.platform, context.userId, updates);

    return {
      text: `${identifier} ${EMOJI.case} КЕЙС ОТКРЫТ!
${SEPARATOR}
📦 ${caseTemplate.name}
${SEPARATOR}
🎁 Награда: ${rewardText}`,
      keyboard: 'main'
    };
  }

  // Машины
  async car(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const cars = user.cars || [];

    if (cars.length === 0) {
      return {
        text: `${identifier} ${EMOJI.car} МАШИНЫ
${SEPARATOR}
📭 У вас нет машин!

💡 Купить: машина купить [номер]
📋 Список: машина список`,
        keyboard: 'main'
      };
    }

    let text = `${identifier} ${EMOJI.car} ВАШИ МАШИНЫ (${cars.length})
${SEPARATOR}`;

    cars.forEach((car, i) => {
      const active = car.id === user.activeCar ? '✅ ' : '• ';
      const totalSpeed = Math.round(car.speed * (1 + (car.tuning || 0) * 0.05));
      text += `\n${active}${i + 1}. ${car.name}
   📊 Скорость: ${totalSpeed} | Тюнинг: Ур.${car.tuning || 0}`;
    });

    text += `\n${SEPARATOR}\n💡 Выбрать: машина выбрать [номер]`;

    return { text, keyboard: 'main' };
  }

  // Список машин
  async carList(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    
    let text = `${identifier} 🏪 МАГАЗИН МАШИН
${SEPARATOR}`;

    CARS.forEach(car => {
      const currency = car.currency === 'money' ? '$' : '₽';
      text += `\n${car.id}. ${car.name}
   💰 ${formatNumber(car.price)}${currency} | 🏎️ ${car.speed}`;
    });

    text += `\n${SEPARATOR}\n💡 Купить: машина купить [номер]`;

    return { text, keyboard: 'main' };
  }

  // Покупка машины
  async carBuy(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (args.length === 0) {
      return await this.carList(context, user, args);
    }

    const carId = parseInt(args[0]);
    const carTemplate = CARS.find(c => c.id === carId);

    if (!carTemplate) {
      return { text: `${identifier} ${EMOJI.error} Машина не найдена!`, keyboard: 'main' };
    }

    // Проверяем что машины ещё нет
    const userCars = user.cars || [];
    if (userCars.find(c => c.id === carId)) {
      return { text: `${identifier} ${EMOJI.error} Эта машина у вас уже есть!`, keyboard: 'main' };
    }

    const currency = carTemplate.currency === 'money' ? user.money : user.rubles;
    
    if (currency < carTemplate.price) {
      return { text: messages.errors.notEnoughMoney(identifier), keyboard: 'main' };
    }

    const newCar = {
      id: carTemplate.id,
      name: carTemplate.name,
      price: carTemplate.price,
      speed: carTemplate.speed,
      acceleration: carTemplate.acceleration,
      handling: carTemplate.handling,
      tuning: 0,
      fuel: 100,
      condition: 100
    };

    const updates = {
      cars: [...userCars, newCar],
      [carTemplate.currency === 'money' ? 'money' : 'rubles']: currency - carTemplate.price
    };

    // Если это первая машина - делаем активной
    if (userCars.length === 0) {
      updates.activeCar = carId;
    }

    db.updateUser(context.platform, context.userId, updates);

    return {
      text: `${identifier} ${EMOJI.success} Машина куплена!
${SEPARATOR}
${EMOJI.car} ${carTemplate.name}
💰 Потрачено: ${formatNumber(carTemplate.price)}${carTemplate.currency === 'money' ? '$' : '₽'}
🏎️ Скорость: ${carTemplate.speed}`,
      keyboard: 'main'
    };
  }

  // Информация о машине
  async carInfo(context, user, args) {
    return await this.car(context, user, args);
  }

  // Выбор машины
  async carSelect(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const cars = user.cars || [];
    
    if (args.length === 0 || cars.length === 0) {
      return { text: `${identifier} ${EMOJI.error} Укажите номер машины!`, keyboard: 'main' };
    }

    const carIndex = parseInt(args[0]) - 1;
    
    if (carIndex < 0 || carIndex >= cars.length) {
      return { text: `${identifier} ${EMOJI.error} Машина не найдена!`, keyboard: 'main' };
    }

    const car = cars[carIndex];

    db.updateUser(context.platform, context.userId, {
      activeCar: car.id
    });

    return {
      text: `${identifier} ${EMOJI.success} Машина выбрана!
${SEPARATOR}
${EMOJI.car} ${car.name}`,
      keyboard: 'main'
    };
  }

  // Продажа машины
  async carSell(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const cars = user.cars || [];
    
    if (args.length === 0 || cars.length === 0) {
      return { text: `${identifier} ${EMOJI.error} Укажите номер машины!`, keyboard: 'main' };
    }

    const carIndex = parseInt(args[0]) - 1;
    
    if (carIndex < 0 || carIndex >= cars.length) {
      return { text: `${identifier} ${EMOJI.error} Машина не найдена!`, keyboard: 'main' };
    }

    const car = cars[carIndex];
    const sellPrice = Math.floor((car.price || 0) * 0.5);

    cars.splice(carIndex, 1);

    const updates = {
      cars,
      money: user.money + sellPrice
    };

    // Если продали активную машину
    if (car.id === user.activeCar && cars.length > 0) {
      updates.activeCar = cars[0].id;
    }

    db.updateUser(context.platform, context.userId, updates);

    return {
      text: `${identifier} ${EMOJI.success} Машина продана!
${SEPARATOR}
${EMOJI.car} ${car.name}
💰 Получено: ${formatNumber(sellPrice)}$`,
      keyboard: 'main'
    };
  }

  // Ремонт машины
  async carRepair(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    return {
      text: `${identifier} 🔧 РЕМОНТ МАШИНЫ
${SEPARATOR}
🔧 Функция в разработке...`,
      keyboard: 'main'
    };
  }

  // Тюнинг
  async tuning(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const cars = user.cars || [];
    const activeCar = cars.find(c => c.id === user.activeCar);

    if (!activeCar) {
      return { text: `${identifier} ${EMOJI.error} У вас нет активной машины!`, keyboard: 'main' };
    }

    const currentTuning = activeCar.tuning || 0;
    const upgradeCost = 100000 * Math.pow(1.1, currentTuning);

    return {
      text: `${identifier} 🔧 ТЮНИНГ
${SEPARATOR}
${EMOJI.car} ${activeCar.name}
📊 Текущий уровень: ${currentTuning}/20
🏎️ Скорость: ${Math.round(activeCar.speed * (1 + currentTuning * 0.05))}
${SEPARATOR}
💰 Улучшение: ${formatNumber(Math.floor(upgradeCost))}$
📈 +5% к характеристикам

💡 Улучшить: тюнинг купить`,
      keyboard: 'main'
    };
  }

  // Покупка тюнинга
  async tuningBuy(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const cars = user.cars || [];
    const carIndex = cars.findIndex(c => c.id === user.activeCar);

    if (carIndex === -1) {
      return { text: `${identifier} ${EMOJI.error} У вас нет активной машины!`, keyboard: 'main' };
    }

    const activeCar = cars[carIndex];
    const currentTuning = activeCar.tuning || 0;

    if (currentTuning >= 20) {
      return { text: `${identifier} ${EMOJI.error} Максимальный уровень тюнинга!`, keyboard: 'main' };
    }

    const upgradeCost = Math.floor(100000 * Math.pow(1.1, currentTuning));

    if (!hasEnoughMoney(user, upgradeCost)) {
      return { text: messages.errors.notEnoughMoney(identifier), keyboard: 'main' };
    }

    cars[carIndex].tuning = currentTuning + 1;
    const newSpeed = Math.round(activeCar.speed * (1 + (currentTuning + 1) * 0.05));

    db.updateUser(context.platform, context.userId, {
      money: user.money - upgradeCost,
      cars
    });

    return {
      text: `${identifier} ${EMOJI.success} Тюнинг улучшен!
${SEPARATOR}
${EMOJI.car} ${activeCar.name}
📊 Новый уровень: ${currentTuning + 1}
🏎️ Новая скорость: ${newSpeed}
💰 Потрачено: ${formatNumber(upgradeCost)}$`,
      keyboard: 'main'
    };
  }

  // Гонка
  async race(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const cooldown = isOnCooldown(user, 'race');
    if (cooldown.onCooldown) {
      return { text: messages.errors.cooldown(identifier, cooldown.remaining), keyboard: 'main' };
    }

    if (!hasEnoughEnergy(user, config.energyCost.race)) {
      return { text: messages.errors.notEnoughEnergy(identifier), keyboard: 'main' };
    }

    const cars = user.cars || [];
    const activeCar = cars.find(c => c.id === user.activeCar);

    if (!activeCar) {
      return { text: messages.errors.noCar(identifier), keyboard: 'main' };
    }

    // Генерируем соперника
    const opponentCars = CARS.filter(c => c.speed <= activeCar.speed * 1.3);
    const opponentCar = randomChoice(opponentCars);

    // Рассчитываем скорости
    const mySpeed = activeCar.speed * (1 + (activeCar.tuning || 0) * 0.05);
    const oppSpeed = opponentCar.speed * (1 + randomInt(0, 3) * 0.05);

    // Определяем победителя (с элементом случайности)
    const myChance = Math.min(80, Math.max(20, 50 + (mySpeed - oppSpeed)));
    const isWin = checkChance(myChance);
    
    const stake = Math.min(user.money, 5000);
    const prize = isWin ? stake : -stake;

    const cooldowns = { ...(user.cooldowns || {}), race: Date.now() };

    db.updateUser(context.platform, context.userId, {
      money: user.money + prize,
      energy: user.energy - config.energyCost.race,
      cooldowns,
      racesWon: isWin ? (user.racesWon || 0) + 1 : user.racesWon || 0,
      cups: isWin ? user.cups + 1 : user.cups,
      totalEarned: isWin ? (user.totalEarned || 0) + prize : user.totalEarned || 0
    });

    const resultEmoji = isWin ? '🏆' : '💀';
    const resultText = isWin ? 'ПОБЕДА!' : 'ПОРАЖЕНИЕ!';

    return {
      text: `${identifier} ${EMOJI.race} ГОНКА
${SEPARATOR}
🚗 Вы: ${activeCar.name} (${Math.round(mySpeed)})
🚙 Соперник: ${opponentCar.name} (${Math.round(oppSpeed)})
${SEPARATOR}
${resultEmoji} ${resultText}
💰 ${isWin ? '+' : ''}${formatNumber(prize)}$
${isWin ? '🏆 +1 кубок' : ''}`,
      keyboard: 'main'
    };
  }

  // Статистика гонок
  async raceStats(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    return {
      text: `${identifier} 📊 СТАТИСТИКА ГОНОК
${SEPARATOR}
🏁 Всего гонок: ${user.racesPlayed || 0}
🏆 Побед: ${user.racesWon || 0}
🏆 Кубков: ${user.cups || 0}`,
      keyboard: 'main'
    };
  }

  // Топ гонок
  async raceTop(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    
    const users = Object.values(db.getUsers())
      .filter(u => u.racesWon > 0)
      .sort((a, b) => (b.racesWon || 0) - (a.racesWon || 0))
      .slice(0, 10);

    let text = `${identifier} 🏆 ТОП ГОНЩИКОВ
${SEPARATOR}`;

    if (users.length === 0) {
      text += '\n📭 Пока никто не гонялся!';
    } else {
      users.forEach((u, i) => {
        const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i + 1}.`;
        text += `\n${medal} ${u.nickname} — ${u.racesWon} побед`;
      });
    }

    return { text, keyboard: 'main' };
  }
}

module.exports = new GamesModule();
