/**
 * FLASH BOT - Profile Module
 * Команды: профиль, статистика, уровень, опыт, энергия, ник, тег, инвентарь, достижения, топ
 */

const db = require('../core/database/db.service');
const cache = require('../core/cache');
const { messages } = require('../config/messages');
const { formatNumber, formatDate, formatDuration, getPlayerIdentifier, progressBar, getTagByLevel, getExpForLevel } = require('../core/utils/formatter');
const { isValidNickname } = require('../core/utils/validator');
const playerFinder = require('../core/utils/player-finder');
const { profileButtons, paginationButtons } = require('../config/keyboards');
const { EMOJI, TAGS } = require('../config/constants');

const SEPARATOR = '━━━━━━━━━━━━━━━━━━━━';

class ProfileModule {
  constructor() {
    this.commands = {
      'profile': this.profile.bind(this),
      'stats': this.stats.bind(this),
      'level': this.level.bind(this),
      'experience': this.experience.bind(this),
      'energy': this.energy.bind(this),
      'nick': this.nick.bind(this),
      'tag': this.tag.bind(this),
      'inventory': this.inventory.bind(this),
      'achievements': this.achievements.bind(this),
      'top': this.top.bind(this),
      'topMoney': this.topMoney.bind(this),
      'topLevel': this.topLevel.bind(this),
      'topBusiness': this.topBusiness.bind(this)
    };
  }

  // Профиль
  async profile(context, user, args) {
    if (!user) {
      return { text: messages.errors.notRegistered(getPlayerIdentifier({ platformId: context.userId }, context.platform)) };
    }

    let targetUser = user;
    const identifier = getPlayerIdentifier(user, context.platform);

    // Если указан другой игрок
    if (args.length > 0) {
      const { player } = playerFinder.parseFromCommand(args, context);
      if (player) {
        targetUser = player;
      }
    }

    // Проверяем ответ на сообщение
    if (context.replyTo) {
      const replyUser = playerFinder.findFromReply(context.replyTo, context.platform);
      if (replyUser) {
        targetUser = replyUser;
      }
    }

    const targetIdentifier = getPlayerIdentifier(targetUser, targetUser.platform);
    const isOwnProfile = targetUser.uid === user.uid;
    const privilegeEmoji = targetUser.privilege !== 'none' ? EMOJI[targetUser.privilege] || '' : '';

    let text = `${targetIdentifier} ${EMOJI.profile} ПРОФИЛЬ ИГРОКА
${SEPARATOR}
🆔 UID: #${targetUser.uid} | 📱 ${targetUser.platform === 'vk' ? 'VK' : 'Telegram'}
👤 Ник: ${targetUser.nickname} | 🏷️ [${targetUser.tag}]
📅 Регистрация: ${formatDate(targetUser.registeredAt)}
⏳ В игре: ${formatDuration(targetUser.playTime || 0)}
${SEPARATOR}
📊 СТАТИСТИКА
${SEPARATOR}
📈 Уровень: ${targetUser.level} (${EMOJI.experience} ${formatNumber(targetUser.experience)}/${formatNumber(getExpForLevel(targetUser.level + 1))})
🏆 Рейтинг: #${targetUser.rating || '—'}
💪 Сила: ${targetUser.strength} | 🧠 Интеллект: ${targetUser.intellect}
🎭 Харизма: ${targetUser.charisma} | 🍀 Удача: ${targetUser.luck}
${EMOJI.energy} Энергия: ${targetUser.energy}/${targetUser.maxEnergy}
${SEPARATOR}
${EMOJI.money} БАЛАНС
${SEPARATOR}
💵 Доллар: ${formatNumber(targetUser.money)}$
${EMOJI.rubles} Рубли: ${formatNumber(targetUser.rubles)}₽
${EMOJI.bitcoin} Биткоин: ${targetUser.bitcoin.toFixed(4)}₿
${EMOJI.diamonds} Алмазы: ${targetUser.diamonds}💎
${EMOJI.cups} Кубки: ${targetUser.cups}🏆
${EMOJI.coins} Монеты: ${targetUser.coins}🪙`;

    // Семья
    if (targetUser.spouseUid) {
      const spouse = db.getUserByUid(targetUser.spouseUid);
      text += `
${SEPARATOR}
${EMOJI.family} СЕМЬЯ
${SEPARATOR}
💍 В браке с: ${spouse ? getPlayerIdentifier(spouse, spouse.platform) : 'Неизвестно'} (UID: #${targetUser.spouseUid})`;
    }

    // Машины
    if (targetUser.cars && targetUser.cars.length > 0) {
      text += `
${SEPARATOR}
${EMOJI.car} МАШИНЫ (${targetUser.cars.length})
${SEPARATOR}`;
      targetUser.cars.slice(0, 3).forEach(car => {
        const active = car.id === targetUser.activeCar ? '✅ ' : '• ';
        const totalSpeed = Math.round(car.speed * (1 + (car.tuning || 0) * 0.05));
        text += `\n${active}${car.name} - Ур.${car.tuning || 0} (скорость: ${totalSpeed})`;
      });
      if (targetUser.cars.length > 3) {
        text += `\n...и ещё ${targetUser.cars.length - 3}`;
      }
    }

    // Бизнесы
    if (targetUser.businesses && targetUser.businesses.length > 0) {
      text += `
${SEPARATOR}
${EMOJI.business} БИЗНЕСЫ (${targetUser.businesses.length})
${SEPARATOR}`;
      targetUser.businesses.forEach((biz, i) => {
        text += `\n• #${i + 1} ${biz.name} - Ур.${biz.level} (${formatNumber(biz.income)}$/час)`;
      });
    }

    // Клан
    if (targetUser.clanId) {
      const clan = db.getClan(targetUser.clanId);
      text += `
${SEPARATOR}
${EMOJI.clan} КЛАН: ${clan ? clan.name : 'Неизвестно'} (ID: #${targetUser.clanId}) | ${targetUser.clanRole || 'Член'}`;
    }

    // Привилегия
    if (targetUser.privilege !== 'none') {
      text += `
${SEPARATOR}
👑 ПРИВИЛЕГИИ: ${privilegeEmoji} ${targetUser.privilege.toUpperCase()} (до ${formatDate(targetUser.privilegeExpires)})`;
    }

    // Достижения и рефералы
    text += `
${SEPARATOR}
${EMOJI.achievement} ДОСТИЖЕНИЯ (${targetUser.achievementsCount || 0}/50)
${SEPARATOR}
${EMOJI.referral} РЕФЕРАЛЬНАЯ ССЫЛКА: ${targetUser.referralCode} | ${targetUser.referralsCount || 0} игроков | ${formatNumber(targetUser.referralEarnings || 0)}$
${SEPARATOR}
📅 Последняя активность: ${formatDate(targetUser.lastActivity)}`;

    return {
      text,
      buttons: isOwnProfile ? profileButtons : null,
      keyboard: 'main'
    };
  }

  // Статистика
  async stats(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    return {
      text: `${identifier} 📊 СТАТИСТИКА
${SEPARATOR}
💰 ФИНАНСЫ:
• Всего заработано: ${formatNumber(user.totalEarned || 0)}$
• Всего потрачено: ${formatNumber(user.totalSpent || 0)}$
• Текущий баланс: ${formatNumber(user.money + (user.bankBalance || 0))}$
${SEPARATOR}
🎮 ИГРЫ:
• Всего игр: ${user.gamesPlayed || 0}
• Побед: ${user.gamesWon || 0}
• Процент побед: ${user.gamesPlayed ? Math.round((user.gamesWon || 0) / user.gamesPlayed * 100) : 0}%
${SEPARATOR}
⚔️ БОИ:
• Убито боссов: ${user.bossKills || 0}
• Выиграно гонок: ${user.racesWon || 0}
• Выиграно дуэлей: ${user.duelsWon || 0}
${SEPARATOR}
⏱️ ВРЕМЯ:
• В игре: ${formatDuration(user.playTime || 0)}
• Регистрация: ${formatDate(user.registeredAt)}
• Дней в игре: ${Math.floor((Date.now() - user.registeredAt) / (24 * 60 * 60 * 1000))}`,
      keyboard: 'main'
    };
  }

  // Уровень
  async level(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const expNeeded = getExpForLevel(user.level + 1);
    const progress = Math.round((user.experience / expNeeded) * 100);

    return {
      text: `${identifier} 📈 УРОВЕНЬ
${SEPARATOR}
🎖️ Текущий уровень: ${user.level}
⭐ Опыт: ${formatNumber(user.experience)}/${formatNumber(expNeeded)}
${progressBar(user.experience, expNeeded, 15)} ${progress}%
${SEPARATOR}
🏷️ Текущий тег: [${user.tag}]
🔜 Следующий тег: [${getTagByLevel(user.level + 10)}] (Ур.${Math.ceil((user.level + 10) / 10) * 10})`,
      keyboard: 'main'
    };
  }

  // Опыт
  async experience(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const expNeeded = getExpForLevel(user.level + 1);

    return {
      text: `${identifier} ⭐ ОПЫТ
${SEPARATOR}
📊 Текущий опыт: ${formatNumber(user.experience)}
🎯 Для следующего уровня: ${formatNumber(expNeeded)}
📈 Осталось: ${formatNumber(expNeeded - user.experience)}
${SEPARATOR}
💡 КАК ПОЛУЧИТЬ ОПЫТ:
• Работа: +50-100 опыта
• Бонус: +10-50 опыта
• Квесты: +50-500 опыта
• Казино: +10 опыта
• Босс: +25-100 опыта`,
      keyboard: 'main'
    };
  }

  // Энергия
  async energy(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const timeToFull = Math.ceil((user.maxEnergy - user.energy) * 60 * 1000); // 1 мин за 1 энергию

    return {
      text: `${identifier} ${EMOJI.energy} ЭНЕРГИЯ
${SEPARATOR}
⚡ Текущая: ${user.energy}/${user.maxEnergy}
${progressBar(user.energy, user.maxEnergy, 15)}
${SEPARATOR}
⏱️ Восстановление: 1/мин
🕐 До полной: ${formatDuration(timeToFull)}
${SEPARATOR}
💡 РАСХОД ЭНЕРГИИ:
• Гонка: 5 | Босс: 3
• Работа: 10 | Майнинг: 5
• Рыбалка: 8 | Казино: 1
• Грабеж: 15 | Дуэль: 8`,
      keyboard: 'main'
    };
  }

  // Смена ника
  async nick(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (args.length === 0) {
      return {
        text: `${identifier} ${EMOJI.error} Укажите новый никнейм!\nПример: ник Игрок123`,
        keyboard: 'main'
      };
    }

    const newNick = args.join(' ').trim();

    if (!isValidNickname(newNick)) {
      return {
        text: `${identifier} ${EMOJI.error} Неверный формат никнейма!\n• 2-20 символов\n• Буквы, цифры, пробелы, _`,
        keyboard: 'main'
      };
    }

    db.updateUser(context.platform, context.userId, { nickname: newNick });

    return {
      text: `${identifier} ${EMOJI.success} Никнейм изменён!
${SEPARATOR}
👤 Новый ник: ${newNick}`,
      keyboard: 'main'
    };
  }

  // Установка тега (только если достигнут уровень)
  async tag(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    // Показываем доступные теги
    const availableTags = TAGS.filter(t => user.level >= t.minLevel);

    let text = `${identifier} 🏷️ ТЕГИ
${SEPARATOR}
📌 Текущий тег: [${user.tag}]
${SEPARATOR}
📋 ДОСТУПНЫЕ ТЕГИ:
`;

    TAGS.forEach(t => {
      const available = user.level >= t.minLevel;
      const current = user.tag === t.name;
      text += `${available ? '✅' : '❌'} [${t.name}] — Ур.${t.minLevel}${current ? ' 👈' : ''}\n`;
    });

    if (args.length > 0) {
      const tagName = args.join(' ').trim();
      const tag = TAGS.find(t => t.name.toLowerCase() === tagName.toLowerCase());
      
      if (!tag) {
        text += `\n${EMOJI.error} Тег "${tagName}" не найден!`;
      } else if (user.level < tag.minLevel) {
        text += `\n${EMOJI.error} Для тега [${tag.name}] нужен Ур.${tag.minLevel}!`;
      } else {
        db.updateUser(context.platform, context.userId, { tag: tag.name });
        text = `${identifier} ${EMOJI.success} Тег изменён!
${SEPARATOR}
🏷️ Новый тег: [${tag.name}]`;
      }
    }

    return { text, keyboard: 'main' };
  }

  // Инвентарь
  async inventory(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const inventory = user.inventory || [];

    if (inventory.length === 0) {
      return {
        text: `${identifier} 🎒 ИНВЕНТАРЬ
${SEPARATOR}
📦 Ваш инвентарь пуст!

💡 Предметы можно получить:
• В магазине
• Из кейсов
• За достижения
• За квесты`,
        keyboard: 'main'
      };
    }

    let text = `${identifier} 🎒 ИНВЕНТАРЬ (${inventory.length})
${SEPARATOR}`;

    inventory.forEach((item, i) => {
      text += `\n${i + 1}. ${item.name} x${item.quantity || 1}`;
    });

    return { text, keyboard: 'main' };
  }

  // Достижения
  async achievements(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const allAchievements = db.loadFile('achievements.json') || [];
    const userAchievements = user.achievements || [];

    let text = `${identifier} ${EMOJI.achievement} ДОСТИЖЕНИЯ (${userAchievements.length}/${allAchievements.length})
${SEPARATOR}`;

    allAchievements.forEach(ach => {
      const completed = userAchievements.includes(ach.id);
      text += `\n${completed ? '✅' : '⬜'} ${ach.name}`;
      text += `\n   ${ach.description}`;
      if (ach.reward.money) text += ` | 💰 ${formatNumber(ach.reward.money)}$`;
      if (ach.reward.diamonds) text += ` | 💎 ${ach.reward.diamonds}`;
    });

    return { text, keyboard: 'main' };
  }

  // Топ
  async top(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);

    return {
      text: `${identifier} ${EMOJI.top} РЕЙТИНГИ
${SEPARATOR}
📋 Доступные топы:
• топ деньги — богатейшие игроки
• топ уровень — по уровню
• топ бизнес — по доходу с бизнесов
${SEPARATOR}
💡 Введите команду для просмотра`,
      keyboard: 'main'
    };
  }

  // Топ по деньгам
  async topMoney(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    
    let topData = cache.getTop('money');
    
    if (!topData) {
      const users = Object.values(db.getUsers());
      topData = users
        .sort((a, b) => (b.money + (b.bankBalance || 0)) - (a.money + (a.bankBalance || 0)))
        .slice(0, 20)
        .map((u, i) => ({ rank: i + 1, uid: u.uid, nickname: u.nickname, value: u.money + (u.bankBalance || 0) }));
      cache.setTop('money', topData);
    }

    let text = `${identifier} 💰 ТОП ПО ДЕНЬГАМ
${SEPARATOR}`;

    topData.slice(0, 10).forEach(entry => {
      const medal = entry.rank === 1 ? '🥇' : entry.rank === 2 ? '🥈' : entry.rank === 3 ? '🥉' : `${entry.rank}.`;
      const isMe = user && entry.uid === user.uid ? ' 👈' : '';
      text += `\n${medal} ${entry.nickname} — ${formatNumber(entry.value)}$${isMe}`;
    });

    if (user) {
      const myRank = topData.findIndex(e => e.uid === user.uid) + 1;
      if (myRank > 10) {
        text += `\n${SEPARATOR}\n📍 Ваше место: #${myRank}`;
      }
    }

    return { text, keyboard: 'main' };
  }

  // Топ по уровню
  async topLevel(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    
    let topData = cache.getTop('level');
    
    if (!topData) {
      const users = Object.values(db.getUsers());
      topData = users
        .sort((a, b) => b.level - a.level || b.experience - a.experience)
        .slice(0, 20)
        .map((u, i) => ({ rank: i + 1, uid: u.uid, nickname: u.nickname, value: u.level }));
      cache.setTop('level', topData);
    }

    let text = `${identifier} 📈 ТОП ПО УРОВНЮ
${SEPARATOR}`;

    topData.slice(0, 10).forEach(entry => {
      const medal = entry.rank === 1 ? '🥇' : entry.rank === 2 ? '🥈' : entry.rank === 3 ? '🥉' : `${entry.rank}.`;
      const isMe = user && entry.uid === user.uid ? ' 👈' : '';
      text += `\n${medal} ${entry.nickname} — Ур.${entry.value}${isMe}`;
    });

    if (user) {
      const myRank = topData.findIndex(e => e.uid === user.uid) + 1;
      if (myRank > 10) {
        text += `\n${SEPARATOR}\n📍 Ваше место: #${myRank}`;
      }
    }

    return { text, keyboard: 'main' };
  }

  // Топ по бизнесам
  async topBusiness(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    
    let topData = cache.getTop('business');
    
    if (!topData) {
      const users = Object.values(db.getUsers()).filter(u => u.businesses && u.businesses.length > 0);
      topData = users
        .sort((a, b) => {
          const incomeA = a.businesses.reduce((sum, biz) => sum + biz.income, 0);
          const incomeB = b.businesses.reduce((sum, biz) => sum + biz.income, 0);
          return incomeB - incomeA;
        })
        .slice(0, 20)
        .map((u, i) => ({
          rank: i + 1,
          uid: u.uid,
          nickname: u.nickname,
          value: u.businesses.reduce((sum, biz) => sum + biz.income, 0)
        }));
      cache.setTop('business', topData);
    }

    let text = `${identifier} 🏢 ТОП ПО БИЗНЕСАМ
${SEPARATOR}`;

    if (topData.length === 0) {
      text += '\n📭 Пока никто не владеет бизнесами!';
    } else {
      topData.slice(0, 10).forEach(entry => {
        const medal = entry.rank === 1 ? '🥇' : entry.rank === 2 ? '🥈' : entry.rank === 3 ? '🥉' : `${entry.rank}.`;
        const isMe = user && entry.uid === user.uid ? ' 👈' : '';
        text += `\n${medal} ${entry.nickname} — ${formatNumber(entry.value)}$/час${isMe}`;
      });
    }

    if (user) {
      const myRank = topData.findIndex(e => e.uid === user.uid) + 1;
      if (myRank > 10) {
        text += `\n${SEPARATOR}\n📍 Ваше место: #${myRank}`;
      }
    }

    return { text, keyboard: 'main' };
  }
}

module.exports = new ProfileModule();
