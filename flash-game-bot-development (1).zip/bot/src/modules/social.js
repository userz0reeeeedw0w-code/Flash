/**
 * FLASH BOT - Social Module
 * Команды: клан, босс, семья, корпорация, телефон, питомцы, дом, рефералы
 */

const db = require('../core/database/db.service');
const config = require('../config');
const { messages } = require('../config/messages');
const { formatNumber, formatDate, formatDuration, getPlayerIdentifier, parseAmount } = require('../core/utils/formatter');
const { hasEnoughMoney, hasEnoughEnergy, isOnCooldown, checkDailyLimit, isInClan, hasClanRole, isValidClanName } = require('../core/utils/validator');
const { randomInt } = require('../core/utils/crypto');
const playerFinder = require('../core/utils/player-finder');
const { clanButtons, bossButtons, bossAttackButtons } = require('../config/keyboards');
const { EMOJI, CLAN_ROLES, CLAN_ROLE_NAMES, PETS } = require('../config/constants');

const SEPARATOR = '━━━━━━━━━━━━━━━━━━━━';

class SocialModule {
  constructor() {
    this.commands = {
      'clan': this.clan.bind(this),
      'clanCreate': this.clanCreate.bind(this),
      'clanJoin': this.clanJoin.bind(this),
      'clanKick': this.clanKick.bind(this),
      'clanLeave': this.clanLeave.bind(this),
      'clanInfo': this.clanInfo.bind(this),
      'clanTop': this.clanTop.bind(this),
      'clanTreasury': this.clanTreasury.bind(this),
      'clanDeposit': this.clanDeposit.bind(this),
      'clanMembers': this.clanMembers.bind(this),
      'clanAttack': this.clanAttack.bind(this),
      'clanRepair': this.clanRepair.bind(this),
      'clans': this.clans.bind(this),
      'boss': this.boss.bind(this),
      'bossAttack': this.bossAttack.bind(this),
      'bossTop': this.bossTop.bind(this),
      'bossStats': this.bossStats.bind(this),
      'family': this.family.bind(this),
      'familyCreate': this.familyCreate.bind(this),
      'pet': this.pet.bind(this),
      'petList': this.petList.bind(this),
      'petBuy': this.petBuy.bind(this),
      'petFeed': this.petFeed.bind(this),
      'petInfo': this.petInfo.bind(this),
      'home': this.home.bind(this),
      'referral': this.referral.bind(this),
      'referralLink': this.referralLink.bind(this),
      'referralStats': this.referralStats.bind(this),
      'referralList': this.referralList.bind(this),
      'referralActivate': this.referralActivate.bind(this)
    };
  }

  // Клан
  async clan(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (!isInClan(user)) {
      return {
        text: `${identifier} ${EMOJI.clan} КЛАНЫ
${SEPARATOR}
📭 Вы не состоите в клане!

💡 Создать клан: клан создать [название]
💡 Вступить: клан вступить [UID клана]
📋 Список кланов: кланы`,
        keyboard: 'main'
      };
    }

    const clan = db.getClan(user.clanId);
    
    if (!clan) {
      db.updateUser(context.platform, context.userId, { clanId: null, clanRole: null });
      return { text: `${identifier} ${EMOJI.error} Клан не найден!`, keyboard: 'main' };
    }

    const leaderIdentifier = clan.leaderIdentifier || `UID #${clan.leaderUid}`;

    return {
      text: `${identifier} ${EMOJI.clan} КЛАН: ${clan.name}
${SEPARATOR}
🆔 ID: #${clan.uid}
👑 Лидер: ${leaderIdentifier}
👥 Участников: ${clan.members?.length || 0}/${config.limits.maxClanMembers}
${SEPARATOR}
💪 Сила: ${formatNumber(clan.power)}
❤️ Здоровье: ${formatNumber(clan.health)}/${formatNumber(clan.maxHealth)}
💰 Казна: ${formatNumber(clan.treasury)}$
⭐ Опыт: ${formatNumber(clan.experience)}
📈 Уровень: ${clan.level || 1}
${SEPARATOR}
🏆 Побед: ${clan.wins || 0} | 💀 Поражений: ${clan.losses || 0}
📅 Создан: ${formatDate(clan.createdAt)}
${SEPARATOR}
⚔️ Ваша роль: ${CLAN_ROLE_NAMES[user.clanRole] || 'Член'}`,
      buttons: clanButtons,
      keyboard: 'main'
    };
  }

  // Создание клана
  async clanCreate(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (isInClan(user)) {
      return { text: messages.errors.alreadyInClan(identifier), keyboard: 'main' };
    }

    if (args.length === 0) {
      return {
        text: `${identifier} ${EMOJI.error} Укажите название клана!
${SEPARATOR}
📝 Пример: клан создать Драконы
💰 Стоимость: ${formatNumber(config.clan.createCost)}$`,
        keyboard: 'main'
      };
    }

    const clanName = args.join(' ').trim();

    if (!isValidClanName(clanName)) {
      return {
        text: `${identifier} ${EMOJI.error} Неверное название клана!
• 3-20 символов
• Буквы, цифры, пробелы`,
        keyboard: 'main'
      };
    }

    // Проверяем уникальность
    const existingClan = db.getClanByName(clanName);
    if (existingClan) {
      return { text: `${identifier} ${EMOJI.error} Клан с таким названием уже существует!`, keyboard: 'main' };
    }

    if (!hasEnoughMoney(user, config.clan.createCost)) {
      return { text: messages.errors.notEnoughMoney(identifier), keyboard: 'main' };
    }

    const userIdentifier = getPlayerIdentifier(user, context.platform);
    const clan = db.createClan(user.uid, userIdentifier, clanName);

    db.updateUser(context.platform, context.userId, {
      money: user.money - config.clan.createCost,
      clanId: clan.uid,
      clanRole: CLAN_ROLES.LEADER,
      clanName: clan.name
    });

    return {
      text: `${identifier} ${EMOJI.success} Клан создан!
${SEPARATOR}
${EMOJI.clan} ${clanName}
🆔 ID клана: #${clan.uid}
👑 Вы — лидер клана!
💰 Потрачено: ${formatNumber(config.clan.createCost)}$`,
      keyboard: 'main'
    };
  }

  // Вступление в клан
  async clanJoin(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (isInClan(user)) {
      return { text: messages.errors.alreadyInClan(identifier), keyboard: 'main' };
    }

    if (args.length === 0) {
      return {
        text: `${identifier} ${EMOJI.error} Укажите ID клана!
${SEPARATOR}
📝 Пример: клан вступить 1
📋 Список кланов: кланы`,
        keyboard: 'main'
      };
    }

    const clanUid = parseInt(args[0]);
    const clan = db.getClan(clanUid);

    if (!clan) {
      return { text: `${identifier} ${EMOJI.error} Клан не найден!`, keyboard: 'main' };
    }

    if ((clan.members?.length || 0) >= config.limits.maxClanMembers) {
      return { text: `${identifier} ${EMOJI.error} Клан переполнен!`, keyboard: 'main' };
    }

    const userIdentifier = getPlayerIdentifier(user, context.platform);
    const members = [...(clan.members || []), {
      uid: user.uid,
      identifier: userIdentifier,
      role: CLAN_ROLES.NEWBIE,
      joinedAt: Date.now()
    }];

    db.updateClan(clanUid, {
      members,
      power: (clan.power || 100) + user.strength
    });

    db.updateUser(context.platform, context.userId, {
      clanId: clan.uid,
      clanRole: CLAN_ROLES.NEWBIE,
      clanName: clan.name
    });

    return {
      text: `${identifier} ${EMOJI.success} Вы вступили в клан!
${SEPARATOR}
${EMOJI.clan} ${clan.name}
⚔️ Ваша роль: ${CLAN_ROLE_NAMES[CLAN_ROLES.NEWBIE]}`,
      keyboard: 'main'
    };
  }

  // Исключение из клана
  async clanKick(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (!isInClan(user)) {
      return { text: messages.errors.clanRequired(identifier), keyboard: 'main' };
    }

    if (!hasClanRole(user, [CLAN_ROLES.LEADER, CLAN_ROLES.VICE_LEADER])) {
      return { text: `${identifier} ${EMOJI.error} Недостаточно прав!`, keyboard: 'main' };
    }

    if (args.length === 0) {
      return { text: `${identifier} ${EMOJI.error} Укажите UID игрока!`, keyboard: 'main' };
    }

    const targetUid = parseInt(args[0]);
    const clan = db.getClan(user.clanId);

    if (!clan) {
      return { text: `${identifier} ${EMOJI.error} Клан не найден!`, keyboard: 'main' };
    }

    if (targetUid === clan.leaderUid) {
      return { text: `${identifier} ${EMOJI.error} Нельзя исключить лидера!`, keyboard: 'main' };
    }

    const memberIndex = clan.members?.findIndex(m => m.uid === targetUid);
    
    if (memberIndex === -1 || memberIndex === undefined) {
      return { text: `${identifier} ${EMOJI.error} Участник не найден!`, keyboard: 'main' };
    }

    const kickedMember = clan.members[memberIndex];
    clan.members.splice(memberIndex, 1);

    db.updateClan(user.clanId, { members: clan.members });

    const targetUser = db.getUserByUid(targetUid);
    if (targetUser) {
      db.updateUserByUid(targetUid, {
        clanId: null,
        clanRole: null,
        clanName: null
      });
    }

    return {
      text: `${identifier} ${EMOJI.success} Участник исключён!
${SEPARATOR}
👤 ${kickedMember.identifier} (UID: #${targetUid})`,
      keyboard: 'main'
    };
  }

  // Покинуть клан
  async clanLeave(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (!isInClan(user)) {
      return { text: messages.errors.clanRequired(identifier), keyboard: 'main' };
    }

    const clan = db.getClan(user.clanId);

    if (user.clanRole === CLAN_ROLES.LEADER) {
      // Если лидер покидает - нужно передать лидерство или удалить клан
      if (clan.members?.length <= 1) {
        db.deleteClan(user.clanId);
        db.updateUser(context.platform, context.userId, {
          clanId: null,
          clanRole: null,
          clanName: null
        });
        return {
          text: `${identifier} ${EMOJI.success} Вы покинули и расформировали клан!`,
          keyboard: 'main'
        };
      }
      return {
        text: `${identifier} ${EMOJI.error} Передайте лидерство перед выходом или расформируйте клан!`,
        keyboard: 'main'
      };
    }

    // Удаляем из списка участников
    const members = clan.members?.filter(m => m.uid !== user.uid) || [];
    db.updateClan(user.clanId, { members });

    db.updateUser(context.platform, context.userId, {
      clanId: null,
      clanRole: null,
      clanName: null
    });

    return {
      text: `${identifier} ${EMOJI.success} Вы покинули клан ${clan.name}!`,
      keyboard: 'main'
    };
  }

  // Информация о клане
  async clanInfo(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    
    if (args.length === 0 && user && user.clanId) {
      return await this.clan(context, user, args);
    }

    if (args.length === 0) {
      return { text: `${identifier} ${EMOJI.error} Укажите ID клана!`, keyboard: 'main' };
    }

    const clanUid = parseInt(args[0]);
    const clan = db.getClan(clanUid);

    if (!clan) {
      return { text: `${identifier} ${EMOJI.error} Клан не найден!`, keyboard: 'main' };
    }

    return {
      text: `${identifier} ${EMOJI.clan} КЛАН: ${clan.name}
${SEPARATOR}
🆔 ID: #${clan.uid}
👑 Лидер: ${clan.leaderIdentifier}
👥 Участников: ${clan.members?.length || 0}/${config.limits.maxClanMembers}
${SEPARATOR}
💪 Сила: ${formatNumber(clan.power)}
❤️ Здоровье: ${formatNumber(clan.health)}/${formatNumber(clan.maxHealth)}
📈 Уровень: ${clan.level || 1}
${SEPARATOR}
🏆 Побед: ${clan.wins || 0} | 💀 Поражений: ${clan.losses || 0}`,
      keyboard: 'main'
    };
  }

  // Топ кланов
  async clanTop(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    
    const clans = Object.values(db.getClans())
      .sort((a, b) => (b.power || 0) - (a.power || 0))
      .slice(0, 10);

    let text = `${identifier} 🏆 ТОП КЛАНОВ
${SEPARATOR}`;

    if (clans.length === 0) {
      text += '\n📭 Кланов пока нет!';
    } else {
      clans.forEach((clan, i) => {
        const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i + 1}.`;
        const isMyСlan = user && user.clanId === clan.uid ? ' 👈' : '';
        text += `\n${medal} ${clan.name} — 💪 ${formatNumber(clan.power)}${isMyСlan}`;
      });
    }

    return { text, keyboard: 'main' };
  }

  // Казна клана
  async clanTreasury(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !isInClan(user)) {
      return { text: messages.errors.clanRequired(identifier), keyboard: 'main' };
    }

    const clan = db.getClan(user.clanId);

    return {
      text: `${identifier} 💰 КАЗНА КЛАНА
${SEPARATOR}
${EMOJI.clan} ${clan.name}
💰 В казне: ${formatNumber(clan.treasury)}$
${SEPARATOR}
💡 Пополнить: клан пополнить [сумма]`,
      keyboard: 'main'
    };
  }

  // Пополнение казны
  async clanDeposit(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !isInClan(user)) {
      return { text: messages.errors.clanRequired(identifier), keyboard: 'main' };
    }

    if (args.length === 0) {
      return { text: `${identifier} ${EMOJI.error} Укажите сумму!`, keyboard: 'main' };
    }

    const amount = parseAmount(args[0]);

    if (!amount || amount < 100) {
      return { text: `${identifier} ${EMOJI.error} Минимум 100$!`, keyboard: 'main' };
    }

    if (!hasEnoughMoney(user, amount)) {
      return { text: messages.errors.notEnoughMoney(identifier), keyboard: 'main' };
    }

    const clan = db.getClan(user.clanId);

    db.updateClan(user.clanId, {
      treasury: (clan.treasury || 0) + amount
    });

    db.updateUser(context.platform, context.userId, {
      money: user.money - amount
    });

    return {
      text: `${identifier} ${EMOJI.success} Казна пополнена!
${SEPARATOR}
💰 Внесено: ${formatNumber(amount)}$
${EMOJI.clan} В казне: ${formatNumber((clan.treasury || 0) + amount)}$`,
      keyboard: 'main'
    };
  }

  // Состав клана
  async clanMembers(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !isInClan(user)) {
      return { text: messages.errors.clanRequired(identifier), keyboard: 'main' };
    }

    const clan = db.getClan(user.clanId);
    const members = clan.members || [];

    let text = `${identifier} 👥 СОСТАВ КЛАНА: ${clan.name}
${SEPARATOR}`;

    members.forEach((m, i) => {
      const role = CLAN_ROLE_NAMES[m.role] || '🛡️ Член';
      text += `\n${i + 1}. ${m.identifier} — ${role}`;
    });

    text += `\n${SEPARATOR}\n👥 Всего: ${members.length}/${config.limits.maxClanMembers}`;

    return { text, keyboard: 'main' };
  }

  // Атака клана
  async clanAttack(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !isInClan(user)) {
      return { text: messages.errors.clanRequired(identifier), keyboard: 'main' };
    }

    const cooldown = isOnCooldown(user, 'clanAttack');
    if (cooldown.onCooldown) {
      return { text: messages.errors.cooldown(identifier, cooldown.remaining), keyboard: 'main' };
    }

    if (!hasEnoughEnergy(user, config.energyCost.clanAttack)) {
      return { text: messages.errors.notEnoughEnergy(identifier), keyboard: 'main' };
    }

    if (args.length === 0) {
      return { text: `${identifier} ${EMOJI.error} Укажите ID клана для атаки!`, keyboard: 'main' };
    }

    const targetClanUid = parseInt(args[0]);
    
    if (targetClanUid === user.clanId) {
      return { text: `${identifier} ${EMOJI.error} Нельзя атаковать свой клан!`, keyboard: 'main' };
    }

    const myClan = db.getClan(user.clanId);
    const targetClan = db.getClan(targetClanUid);

    if (!targetClan) {
      return { text: `${identifier} ${EMOJI.error} Клан не найден!`, keyboard: 'main' };
    }

    // Рассчитываем урон
    const damage = Math.floor(user.strength * randomInt(5, 15));
    const newHealth = Math.max(0, targetClan.health - damage);

    // Обновляем клан противника
    db.updateClan(targetClanUid, { health: newHealth });

    const cooldowns = { ...(user.cooldowns || {}), clanAttack: Date.now() };

    db.updateUser(context.platform, context.userId, {
      energy: user.energy - config.energyCost.clanAttack,
      cooldowns
    });

    // Проверяем победу
    if (newHealth <= 0) {
      db.updateClan(user.clanId, { wins: (myClan.wins || 0) + 1 });
      db.updateClan(targetClanUid, { 
        losses: (targetClan.losses || 0) + 1,
        health: 100 // Восстанавливаем минимум
      });

      return {
        text: `${identifier} 🎉 КЛАН ПОБЕЖДЁН!
${SEPARATOR}
${EMOJI.clan} ${targetClan.name} разгромлен!
💥 Урон: ${formatNumber(damage)}
🏆 +1 победа для вашего клана!`,
        keyboard: 'main'
      };
    }

    return {
      text: `${identifier} ⚔️ АТАКА КЛАНА
${SEPARATOR}
${EMOJI.clan} Цель: ${targetClan.name}
💥 Урон: ${formatNumber(damage)}
❤️ Здоровье врага: ${formatNumber(newHealth)}/${formatNumber(targetClan.maxHealth)}`,
      keyboard: 'main'
    };
  }

  // Починка клана
  async clanRepair(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user || !isInClan(user)) {
      return { text: messages.errors.clanRequired(identifier), keyboard: 'main' };
    }

    const clan = db.getClan(user.clanId);

    if (clan.health >= clan.maxHealth) {
      return { text: `${identifier} ${EMOJI.success} Клан в полном здоровье!`, keyboard: 'main' };
    }

    const repairCost = Math.floor((clan.maxHealth - clan.health) * 10);

    if (clan.treasury < repairCost) {
      return {
        text: `${identifier} ${EMOJI.error} Недостаточно в казне!
${SEPARATOR}
💰 Нужно: ${formatNumber(repairCost)}$
💰 В казне: ${formatNumber(clan.treasury)}$`,
        keyboard: 'main'
      };
    }

    db.updateClan(user.clanId, {
      health: clan.maxHealth,
      treasury: clan.treasury - repairCost
    });

    return {
      text: `${identifier} ${EMOJI.success} Клан восстановлен!
${SEPARATOR}
❤️ Здоровье: ${formatNumber(clan.maxHealth)}/${formatNumber(clan.maxHealth)}
💰 Потрачено: ${formatNumber(repairCost)}$`,
      keyboard: 'main'
    };
  }

  // Список кланов
  async clans(context, user, args) {
    return await this.clanTop(context, user, args);
  }

  // Босс
  async boss(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    
    const boss = db.getBoss();

    if (!boss || !boss.active) {
      return {
        text: `${identifier} ${EMOJI.boss} БОСС
${SEPARATOR}
😴 Босс сейчас не активен!
⏳ Ожидайте появления нового босса...`,
        keyboard: 'main'
      };
    }

    const healthPercent = Math.round((boss.currentHp / boss.maxHp) * 100);

    return {
      text: `${identifier} ${EMOJI.boss} БОСС: ${boss.name}
${SEPARATOR}
❤️ HP: ${formatNumber(boss.currentHp)}/${formatNumber(boss.maxHp)} (${healthPercent}%)
⚔️ Уровень: ${boss.level}
💰 Награда: ${formatNumber(boss.reward)}$
${SEPARATOR}
⏳ Появился: ${formatDuration(Date.now() - boss.spawnedAt)} назад
👥 Участников: ${boss.participants?.length || 0}`,
      buttons: bossButtons,
      keyboard: 'main'
    };
  }

  // Атака босса
  async bossAttack(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const boss = db.getBoss();

    if (!boss || !boss.active) {
      return { text: messages.errors.noBoss(identifier), keyboard: 'main' };
    }

    const cooldown = isOnCooldown(user, 'boss');
    if (cooldown.onCooldown) {
      return { text: messages.errors.cooldown(identifier, cooldown.remaining), keyboard: 'main' };
    }

    if (!hasEnoughEnergy(user, config.energyCost.boss)) {
      return { text: messages.errors.notEnoughEnergy(identifier), keyboard: 'main' };
    }

    const limit = checkDailyLimit(user, 'boss');
    if (!limit.canDo) {
      return { text: messages.errors.limitReached(identifier, 'босс'), keyboard: 'main' };
    }

    // Если есть аргумент - это выбор оружия
    let weapon = 'sword';
    let damageMultiplier = 1;
    
    if (args.length > 0 && ['sword', 'bow', 'shield'].includes(args[0])) {
      weapon = args[0];
      // Правильный выбор всегда меч
      damageMultiplier = weapon === 'sword' ? 2 : 0.5;
    }

    // Рассчитываем урон
    const baseDamage = user.strength * randomInt(10, 30);
    const damage = Math.floor(baseDamage * damageMultiplier);

    // Обновляем босса
    const newHp = Math.max(0, boss.currentHp - damage);
    const participants = [...(boss.participants || [])];
    
    const existingIndex = participants.findIndex(p => p.uid === user.uid);
    if (existingIndex >= 0) {
      participants[existingIndex].damage += damage;
    } else {
      participants.push({
        uid: user.uid,
        identifier: getPlayerIdentifier(user, context.platform),
        damage
      });
    }

    db.setBoss({
      ...boss,
      currentHp: newHp,
      participants
    });

    // Обновляем кулдауны пользователя
    const cooldowns = { ...(user.cooldowns || {}), boss: Date.now() };
    const dailyLimits = { ...(user.dailyLimits || {}), boss: (user.dailyLimits?.boss || 0) + 1 };
    const expGain = Math.floor(damage / 10);

    db.updateUser(context.platform, context.userId, {
      energy: user.energy - config.energyCost.boss,
      cooldowns,
      dailyLimits,
      experience: user.experience + expGain
    });

    const weaponEmoji = weapon === 'sword' ? '🗡️ МЕЧ' : weapon === 'bow' ? '🏹 ЛУК' : '🛡️ ЩИТ';
    const isCorrect = weapon === 'sword';

    let text = `${identifier} ${EMOJI.boss} АТАКА БОССА
${SEPARATOR}
${isCorrect ? '✅ Правильный выбор!' : '❌ Неправильный выбор!'}
⚔️ Оружие: ${weaponEmoji}
💥 Урон: ${formatNumber(damage)}
⭐ +${expGain} опыта
${SEPARATOR}
❤️ HP босса: ${formatNumber(newHp)}/${formatNumber(boss.maxHp)}`;

    if (newHp <= 0) {
      text += `\n${SEPARATOR}\n🎉 БОСС ПОВЕРЖЕН! Награды распределяются...`;
    }

    return { text, keyboard: 'main' };
  }

  // Топ по урону боссу
  async bossTop(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    
    const boss = db.getBoss();

    if (!boss || !boss.participants || boss.participants.length === 0) {
      return {
        text: `${identifier} 🏆 ТОП УРОНА БОССУ
${SEPARATOR}
📭 Нет данных о боссе или участниках`,
        keyboard: 'main'
      };
    }

    const sorted = boss.participants.sort((a, b) => b.damage - a.damage).slice(0, 10);

    let text = `${identifier} 🏆 ТОП УРОНА БОССУ: ${boss.name}
${SEPARATOR}`;

    sorted.forEach((p, i) => {
      const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i + 1}.`;
      const isMe = user && p.uid === user.uid ? ' 👈' : '';
      text += `\n${medal} ${p.identifier} — ${formatNumber(p.damage)} урона${isMe}`;
    });

    return { text, keyboard: 'main' };
  }

  // Статистика босса
  async bossStats(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    return {
      text: `${identifier} 📊 СТАТИСТИКА БОССОВ
${SEPARATOR}
🐉 Убито боссов: ${user.bossKills || 0}
💰 Заработано: ${formatNumber(user.bossEarnings || 0)}$`,
      keyboard: 'main'
    };
  }

  // Семья
  async family(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (!user.spouseUid) {
      return {
        text: `${identifier} ${EMOJI.family} СЕМЬЯ
${SEPARATOR}
💔 Вы не в браке!

💡 Создать семью: семья создать [игрок]`,
        keyboard: 'main'
      };
    }

    const spouse = db.getUserByUid(user.spouseUid);
    const spouseIdentifier = spouse ? getPlayerIdentifier(spouse, spouse.platform) : 'Неизвестно';

    return {
      text: `${identifier} ${EMOJI.family} СЕМЬЯ
${SEPARATOR}
💍 В браке с: ${spouseIdentifier}
📅 Дата брака: ${formatDate(user.marriedAt)}`,
      keyboard: 'main'
    };
  }

  // Создание семьи
  async familyCreate(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    return {
      text: `${identifier} ${EMOJI.family} СОЗДАНИЕ СЕМЬИ
${SEPARATOR}
🔧 Функция в разработке...`,
      keyboard: 'main'
    };
  }

  // Питомцы
  async pet(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (!user.pet) {
      return {
        text: `${identifier} ${EMOJI.pet} ПИТОМЦЫ
${SEPARATOR}
🐾 У вас нет питомца!

💡 Купить: питомец купить [номер]
📋 Список: питомец список`,
        keyboard: 'main'
      };
    }

    return {
      text: `${identifier} ${EMOJI.pet} ВАШ ПИТОМЕЦ
${SEPARATOR}
🐾 ${user.pet.name}
❤️ Здоровье: ${user.pet.health || 100}%
😊 Настроение: ${user.pet.mood || 100}%
📈 Уровень: ${user.pet.level || 1}
${SEPARATOR}
💡 Кормить: питомец кормить`,
      keyboard: 'main'
    };
  }

  // Список питомцев
  async petList(context, user, args) {
    const identifier = getPlayerIdentifier(user || { platformId: context.userId }, context.platform);
    
    let text = `${identifier} 🏪 МАГАЗИН ПИТОМЦЕВ
${SEPARATOR}`;

    PETS.forEach(pet => {
      text += `\n${pet.id}. ${pet.name} — ${formatNumber(pet.price)}$
   📈 +${pet.bonusValue} ${pet.bonusType}`;
    });

    text += `\n${SEPARATOR}\n💡 Купить: питомец купить [номер]`;

    return { text, keyboard: 'main' };
  }

  // Покупка питомца
  async petBuy(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (user.pet) {
      return { text: `${identifier} ${EMOJI.error} У вас уже есть питомец!`, keyboard: 'main' };
    }

    if (args.length === 0) {
      return await this.petList(context, user, args);
    }

    const petId = parseInt(args[0]);
    const petTemplate = PETS.find(p => p.id === petId);

    if (!petTemplate) {
      return { text: `${identifier} ${EMOJI.error} Питомец не найден!`, keyboard: 'main' };
    }

    if (!hasEnoughMoney(user, petTemplate.price)) {
      return { text: messages.errors.notEnoughMoney(identifier), keyboard: 'main' };
    }

    const newPet = {
      id: petTemplate.id,
      name: petTemplate.name,
      health: 100,
      mood: 100,
      level: 1,
      bonusType: petTemplate.bonusType,
      bonusValue: petTemplate.bonusValue
    };

    db.updateUser(context.platform, context.userId, {
      money: user.money - petTemplate.price,
      pet: newPet
    });

    return {
      text: `${identifier} ${EMOJI.success} Питомец куплен!
${SEPARATOR}
🐾 ${petTemplate.name}
💰 Потрачено: ${formatNumber(petTemplate.price)}$`,
      keyboard: 'main'
    };
  }

  // Кормление питомца
  async petFeed(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (!user.pet) {
      return { text: `${identifier} ${EMOJI.error} У вас нет питомца!`, keyboard: 'main' };
    }

    const feedCost = 500;

    if (!hasEnoughMoney(user, feedCost)) {
      return { text: messages.errors.notEnoughMoney(identifier), keyboard: 'main' };
    }

    const pet = { ...user.pet };
    pet.health = Math.min(100, pet.health + 20);
    pet.mood = Math.min(100, pet.mood + 20);

    db.updateUser(context.platform, context.userId, {
      money: user.money - feedCost,
      pet
    });

    return {
      text: `${identifier} ${EMOJI.success} Питомец накормлен!
${SEPARATOR}
🐾 ${pet.name}
❤️ Здоровье: ${pet.health}%
😊 Настроение: ${pet.mood}%
💰 Потрачено: ${formatNumber(feedCost)}$`,
      keyboard: 'main'
    };
  }

  // Информация о питомце
  async petInfo(context, user, args) {
    return await this.pet(context, user, args);
  }

  // Дом
  async home(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (!user.home) {
      return {
        text: `${identifier} ${EMOJI.home} ДОМ
${SEPARATOR}
🏠 У вас нет дома!

💡 Купить: дом купить [уровень]`,
        keyboard: 'main'
      };
    }

    return {
      text: `${identifier} ${EMOJI.home} ВАШ ДОМ
${SEPARATOR}
🏠 Уровень: ${user.home.level}
🛡️ Защита: ${user.home.protection || 0}%`,
      keyboard: 'main'
    };
  }

  // Рефералы
  async referral(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    return {
      text: `${identifier} ${EMOJI.referral} РЕФЕРАЛЫ
${SEPARATOR}
🔗 Ваш код: ${user.referralCode}
👥 Приглашено: ${user.referralsCount || 0}
💰 Заработано: ${formatNumber(user.referralEarnings || 0)}$
${SEPARATOR}
🎁 За каждого реферала: ${formatNumber(config.referral.bonus)}$
📈 +${config.referral.percent}% от дохода рефералов

💡 Команды:
• реферал ссылка — получить ссылку
• реферал активировать [код] — активировать код`,
      keyboard: 'main'
    };
  }

  // Реферальная ссылка
  async referralLink(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const link = context.platform === 'telegram' 
      ? `https://t.me/gamebotflash_bot?start=${user.referralCode}`
      : `https://vk.com/club237124814?ref=${user.referralCode}`;

    return {
      text: `${identifier} 🔗 ВАША ССЫЛКА
${SEPARATOR}
📝 Код: ${user.referralCode}
🔗 Ссылка: ${link}
${SEPARATOR}
💡 Поделитесь с друзьями и получайте бонусы!`,
      keyboard: 'main'
    };
  }

  // Статистика рефералов
  async referralStats(context, user, args) {
    return await this.referral(context, user, args);
  }

  // Список рефералов
  async referralList(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    const referrals = user.referrals || [];

    if (referrals.length === 0) {
      return {
        text: `${identifier} 👥 ВАШИ РЕФЕРАЛЫ
${SEPARATOR}
📭 У вас пока нет рефералов!`,
        keyboard: 'main'
      };
    }

    let text = `${identifier} 👥 ВАШИ РЕФЕРАЛЫ (${referrals.length})
${SEPARATOR}`;

    referrals.slice(0, 10).forEach((refUid, i) => {
      const refUser = db.getUserByUid(refUid);
      const refIdentifier = refUser ? getPlayerIdentifier(refUser, refUser.platform) : `UID #${refUid}`;
      text += `\n${i + 1}. ${refIdentifier}`;
    });

    if (referrals.length > 10) {
      text += `\n...и ещё ${referrals.length - 10}`;
    }

    return { text, keyboard: 'main' };
  }

  // Активация реферального кода
  async referralActivate(context, user, args) {
    const identifier = getPlayerIdentifier(user, context.platform);
    
    if (!user) {
      return { text: messages.errors.notRegistered(identifier) };
    }

    if (user.referredBy) {
      return { text: `${identifier} ${EMOJI.error} Вы уже активировали реферальный код!`, keyboard: 'main' };
    }

    if (args.length === 0) {
      return { text: `${identifier} ${EMOJI.error} Укажите реферальный код!`, keyboard: 'main' };
    }

    const code = args[0].toUpperCase();
    const users = db.getUsers();
    const referrer = Object.values(users).find(u => u.referralCode === code);

    if (!referrer) {
      return { text: `${identifier} ${EMOJI.error} Неверный реферальный код!`, keyboard: 'main' };
    }

    if (referrer.uid === user.uid) {
      return { text: `${identifier} ${EMOJI.error} Нельзя использовать свой код!`, keyboard: 'main' };
    }

    // Активируем
    db.updateUser(context.platform, context.userId, {
      referredBy: referrer.uid
    });

    db.updateUserByUid(referrer.uid, {
      referrals: [...(referrer.referrals || []), user.uid],
      referralsCount: (referrer.referralsCount || 0) + 1,
      referralEarnings: (referrer.referralEarnings || 0) + config.referral.bonus,
      money: referrer.money + config.referral.bonus
    });

    const referrerIdentifier = getPlayerIdentifier(referrer, referrer.platform);

    return {
      text: `${identifier} ${EMOJI.success} Реферальный код активирован!
${SEPARATOR}
👤 Пригласивший: ${referrerIdentifier}
💰 Он получил: ${formatNumber(config.referral.bonus)}$`,
      keyboard: 'main'
    };
  }
}

module.exports = new SocialModule();
