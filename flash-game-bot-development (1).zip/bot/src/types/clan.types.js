/**
 * FLASH BOT - Clan Types (JSDoc)
 */

/**
 * @typedef {Object} Clan
 * @property {number} uid - Уникальный ID клана
 * @property {string} name - Название клана
 * @property {number} leaderUid - UID лидера
 * @property {string} leaderIdentifier - Идентификатор лидера
 * @property {Array<ClanMember>} members - Участники
 * @property {number} power - Сила клана
 * @property {number} health - Текущее здоровье
 * @property {number} maxHealth - Максимальное здоровье
 * @property {number} treasury - Казна
 * @property {number} experience - Опыт
 * @property {number} level - Уровень
 * @property {number} wins - Победы
 * @property {number} losses - Поражения
 * @property {Object} upgrades - Улучшения
 * @property {number} createdAt - Дата создания
 */

/**
 * @typedef {Object} ClanMember
 * @property {number} uid - UID участника
 * @property {string} identifier - Идентификатор
 * @property {string} role - Роль
 * @property {number} joinedAt - Дата вступления
 */

/**
 * @typedef {Object} Boss
 * @property {string} name - Имя босса
 * @property {number} level - Уровень
 * @property {number} maxHp - Максимальное HP
 * @property {number} currentHp - Текущее HP
 * @property {number} reward - Награда
 * @property {Array<BossParticipant>} participants - Участники
 * @property {number} spawnedAt - Время появления
 * @property {boolean} active - Активен ли
 */

/**
 * @typedef {Object} BossParticipant
 * @property {number} uid - UID участника
 * @property {string} identifier - Идентификатор
 * @property {number} damage - Нанесённый урон
 */

module.exports = {};
