/**
 * FLASH BOT - Types Index
 */

const userTypes = require('./user.types');
const clanTypes = require('./clan.types');

module.exports = {
  ...userTypes,
  ...clanTypes
};
