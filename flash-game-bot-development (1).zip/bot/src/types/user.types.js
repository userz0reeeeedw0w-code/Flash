/**
 * FLASH BOT - User Types (JSDoc)
 */

/**
 * @typedef {Object} User
 * @property {number} uid - Уникальный ID игрока
 * @property {string} platform - Платформа (telegram/vk)
 * @property {string} platformId - ID на платформе
 * @property {string|null} vkId - VK ID
 * @property {string|null} telegramId - Telegram ID
 * @property {string|null} telegramUsername - Telegram username
 * @property {string} nickname - Игровой ник
 * @property {string} tag - Тег/звание
 * @property {number} money - Доллары
 * @property {number} rubles - Рубли
 * @property {number} bitcoin - Биткоин
 * @property {number} diamonds - Алмазы
 * @property {number} cups - Кубки
 * @property {number} coins - Монеты
 * @property {number} bankBalance - Баланс в банке
 * @property {number} bankLimit - Лимит банка
 * @property {number} credit - Текущий кредит
 * @property {number|null} creditDate - Дата взятия кредита
 * @property {number} level - Уровень
 * @property {number} experience - Опыт
 * @property {number} energy - Текущая энергия
 * @property {number} maxEnergy - Максимальная энергия
 * @property {number} strength - Сила
 * @property {number} intellect - Интеллект
 * @property {number} charisma - Харизма
 * @property {number} luck - Удача
 * @property {string} privilege - Тип привилегии
 * @property {number|null} privilegeExpires - Дата истечения привилегии
 * @property {Array<Car>} cars - Машины
 * @property {number|null} activeCar - ID активной машины
 * @property {Array<Business>} businesses - Бизнесы
 * @property {Array<Farm>} farms - Фермы
 * @property {Array<Printer>} printers - Принтеры
 * @property {number|null} job - ID работы
 * @property {number} jobLevel - Уровень работы
 * @property {number} jobExperience - Опыт работы
 * @property {number|null} lastWorkTime - Время последней работы
 * @property {number} pickaxeLevel - Уровень кирки
 * @property {number} shaftLevel - Уровень шахты
 * @property {Object} ores - Руда
 * @property {number|null} lastMiningTime - Время последней копки
 * @property {number} rodLevel - Уровень удочки
 * @property {Object} fish - Рыба
 * @property {number|null} lastFishingTime - Время последней рыбалки
 * @property {number|null} clanId - ID клана
 * @property {string|null} clanRole - Роль в клане
 * @property {number|null} familyId - ID семьи
 * @property {number|null} spouseUid - UID супруга
 * @property {string|null} spouseIdentifier - Идентификатор супруга
 * @property {Array<number>} children - UID детей
 * @property {Pet|null} pet - Питомец
 * @property {Home|null} home - Дом
 * @property {Array<Item>} inventory - Инвентарь
 * @property {Array<number>} achievements - ID достижений
 * @property {number} achievementsCount - Количество достижений
 * @property {string} referralCode - Реферальный код
 * @property {number|null} referredBy - UID пригласившего
 * @property {Array<number>} referrals - UID рефералов
 * @property {number} referralsCount - Количество рефералов
 * @property {number} referralEarnings - Заработок с рефералов
 * @property {number|null} rating - Рейтинг
 * @property {number} playTime - Время в игре
 * @property {number} totalEarned - Всего заработано
 * @property {number} totalSpent - Всего потрачено
 * @property {number} gamesPlayed - Всего игр
 * @property {number} gamesWon - Побед
 * @property {number} bossKills - Убито боссов
 * @property {Object} cooldowns - Кулдауны
 * @property {Object} dailyLimits - Дневные лимиты
 * @property {number|null} dailyLimitsReset - Время сброса лимитов
 * @property {Array<Quest>} dailyQuests - Ежедневные квесты
 * @property {Array<Quest>} weeklyQuests - Недельные квесты
 * @property {Array<NewbieTask>} newbiePath - Путь новичка
 * @property {number|null} lastBonusTime - Время последнего бонуса
 * @property {number} bonusStreak - Стрик бонусов
 * @property {number|null} lastHourlyBonus - Время последнего часового бонуса
 * @property {Object|null} captchaPending - Ожидающая капча
 * @property {number} captchaAttempts - Попытки капчи
 * @property {number|null} captchaBlockedUntil - Блокировка капчи до
 * @property {boolean} keyboardEnabled - Включена ли клавиатура
 * @property {boolean} notifications - Включены ли уведомления
 * @property {Array<LinkedAccount>} linkedAccounts - Привязанные аккаунты
 * @property {number} registeredAt - Дата регистрации
 * @property {number} lastActivity - Последняя активность
 * @property {boolean} isBanned - Заблокирован ли
 * @property {string|null} banReason - Причина бана
 * @property {boolean} isMuted - Замьючен ли
 * @property {number|null} muteUntil - Мут до
 */

/**
 * @typedef {Object} Car
 * @property {number} id - ID машины
 * @property {string} name - Название
 * @property {number} price - Цена
 * @property {number} speed - Скорость
 * @property {number} acceleration - Ускорение
 * @property {number} handling - Управляемость
 * @property {number} tuning - Уровень тюнинга
 * @property {number} fuel - Топливо
 * @property {number} condition - Состояние
 */

/**
 * @typedef {Object} Business
 * @property {number} id - ID бизнеса
 * @property {string} name - Название
 * @property {number} price - Цена покупки
 * @property {number} income - Доход в час
 * @property {number} level - Уровень
 * @property {number|null} lastCollect - Время последнего сбора
 * @property {number} purchasedAt - Дата покупки
 */

/**
 * @typedef {Object} Farm
 * @property {number} id - ID фермы
 * @property {string} name - Название
 * @property {number} price - Цена
 * @property {number} btcPerHour - BTC в час
 * @property {number} level - Уровень
 * @property {number|null} lastCollect - Время последнего сбора
 */

/**
 * @typedef {Object} Printer
 * @property {number} id - ID принтера
 * @property {string} name - Название
 * @property {number} price - Цена
 * @property {number} incomePerHour - Доход в час
 * @property {number} fuel - Топливо
 * @property {number|null} lastCollect - Время последнего сбора
 */

/**
 * @typedef {Object} Pet
 * @property {number} id - ID питомца
 * @property {string} name - Имя
 * @property {number} health - Здоровье
 * @property {number} mood - Настроение
 * @property {number} level - Уровень
 * @property {string} bonusType - Тип бонуса
 * @property {number} bonusValue - Значение бонуса
 */

/**
 * @typedef {Object} Home
 * @property {number} level - Уровень дома
 * @property {number} protection - Защита
 */

/**
 * @typedef {Object} Item
 * @property {string} name - Название
 * @property {number} quantity - Количество
 */

/**
 * @typedef {Object} Quest
 * @property {number} id - ID квеста
 * @property {string} name - Название
 * @property {string} type - Тип
 * @property {number} target - Цель
 * @property {number} progress - Прогресс
 * @property {boolean} completed - Завершён ли
 * @property {boolean} claimed - Награда получена
 * @property {Object} reward - Награда
 */

/**
 * @typedef {Object} NewbieTask
 * @property {number} id - ID задания
 * @property {string} name - Название
 * @property {string} command - Команда
 * @property {boolean} completed - Выполнено ли
 */

/**
 * @typedef {Object} LinkedAccount
 * @property {string} platform - Платформа
 * @property {string} platformId - ID
 * @property {number} linkedAt - Дата привязки
 */

module.exports = {};
