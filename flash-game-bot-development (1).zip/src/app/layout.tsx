import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "⚡ FLASH BOT — Игровой бот для Telegram и VK",
  description: "FLASH — полноценный игровой бот с 380+ командами для Telegram и VK. Экономика, кланы, боссы, гонки, казино и многое другое!",
  keywords: ["telegram bot", "vk bot", "game bot", "flash bot", "игровой бот"],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru">
      <body className="antialiased">
        {children}
      </body>
    </html>
  );
}
