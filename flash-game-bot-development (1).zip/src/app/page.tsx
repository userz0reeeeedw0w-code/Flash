import Link from 'next/link';

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 text-white">
      {/* Hero Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="text-center">
          <h1 className="text-6xl font-bold mb-4 bg-gradient-to-r from-yellow-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
            ⚡ FLASH BOT
          </h1>
          <p className="text-2xl text-gray-300 mb-8">
            Игровой бот для Telegram и VK
          </p>
          <p className="text-lg text-gray-400 mb-12">
            Франшиза 2026 года
          </p>
          
          <div className="flex justify-center gap-4 mb-16">
            <a 
              href="https://t.me/gamebotflash_bot" 
              target="_blank" 
              rel="noopener noreferrer"
              className="px-8 py-4 bg-blue-500 hover:bg-blue-600 rounded-lg font-bold text-lg transition-all transform hover:scale-105"
            >
              📱 Telegram
            </a>
            <a 
              href="https://vk.com/club237124814" 
              target="_blank" 
              rel="noopener noreferrer"
              className="px-8 py-4 bg-blue-700 hover:bg-blue-800 rounded-lg font-bold text-lg transition-all transform hover:scale-105"
            >
              📱 VKontakte
            </a>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          <FeatureCard 
            icon="🎮" 
            title="380+ Команд" 
            description="Огромный выбор действий и возможностей"
          />
          <FeatureCard 
            icon="💰" 
            title="Экономика" 
            description="Бизнесы, работа, казино, инвестиции"
          />
          <FeatureCard 
            icon="🏛️" 
            title="Кланы" 
            description="Создавайте кланы и сражайтесь"
          />
          <FeatureCard 
            icon="🐉" 
            title="Боссы" 
            description="Совместные битвы с боссами"
          />
          <FeatureCard 
            icon="🚗" 
            title="Гонки" 
            description="20 машин, тюнинг, соревнования"
          />
          <FeatureCard 
            icon="🎁" 
            title="Бонусы" 
            description="Ежедневные награды и стрики"
          />
          <FeatureCard 
            icon="📜" 
            title="Квесты" 
            description="Ежедневные и недельные задания"
          />
          <FeatureCard 
            icon="🔗" 
            title="Привязка" 
            description="Один аккаунт на обе платформы"
          />
        </div>

        {/* Stats Section */}
        <div className="bg-gray-800/50 rounded-2xl p-8 mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">📊 Статистика</h2>
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <StatCard value="380+" label="Команд" />
            <StatCard value="8" label="Модулей" />
            <StatCard value="2" label="Платформы" />
            <StatCard value="24/7" label="Онлайн" />
          </div>
        </div>

        {/* Currencies Section */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">💎 Валюты</h2>
          <div className="grid md:grid-cols-3 lg:grid-cols-5 gap-4">
            <CurrencyCard emoji="💵" name="Доллар" description="Основная валюта" />
            <CurrencyCard emoji="₽" name="Рубли" description="Донат-валюта" />
            <CurrencyCard emoji="₿" name="Биткоин" description="Инвестиции" />
            <CurrencyCard emoji="💎" name="Алмазы" description="За достижения" />
            <CurrencyCard emoji="🏆" name="Кубки" description="За победы" />
          </div>
        </div>

        {/* Commands Preview */}
        <div className="bg-gray-800/50 rounded-2xl p-8 mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">📝 Примеры команд</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            <CommandCard cmd="профиль" desc="Ваш профиль" />
            <CommandCard cmd="баланс" desc="Ваш баланс" />
            <CommandCard cmd="работать" desc="Заработать деньги" />
            <CommandCard cmd="казино 1000" desc="Игра в казино" />
            <CommandCard cmd="гонка" desc="Гоночные соревнования" />
            <CommandCard cmd="босс" desc="Атака на босса" />
            <CommandCard cmd="клан" desc="Информация о клане" />
            <CommandCard cmd="бонус" desc="Ежедневный бонус" />
            <CommandCard cmd="перевод @id 1000" desc="Перевод денег" />
          </div>
        </div>

        {/* Footer */}
        <footer className="text-center text-gray-500">
          <p className="mb-2">⚡ FLASH BOT — Франшиза 2026</p>
          <p>Node.js + JSON + Polling</p>
        </footer>
      </div>
    </main>
  );
}

function FeatureCard({ icon, title, description }: { icon: string; title: string; description: string }) {
  return (
    <div className="bg-gray-800/50 rounded-xl p-6 hover:bg-gray-800/70 transition-all transform hover:scale-105">
      <div className="text-4xl mb-4">{icon}</div>
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-gray-400">{description}</p>
    </div>
  );
}

function StatCard({ value, label }: { value: string; label: string }) {
  return (
    <div>
      <div className="text-4xl font-bold text-yellow-400">{value}</div>
      <div className="text-gray-400">{label}</div>
    </div>
  );
}

function CurrencyCard({ emoji, name, description }: { emoji: string; name: string; description: string }) {
  return (
    <div className="bg-gray-800/30 rounded-lg p-4 text-center">
      <div className="text-3xl mb-2">{emoji}</div>
      <div className="font-bold">{name}</div>
      <div className="text-sm text-gray-400">{description}</div>
    </div>
  );
}

function CommandCard({ cmd, desc }: { cmd: string; desc: string }) {
  return (
    <div className="bg-gray-700/30 rounded-lg p-3 font-mono">
      <div className="text-yellow-400">{cmd}</div>
      <div className="text-sm text-gray-400">{desc}</div>
    </div>
  );
}
