# Lucky Vault — виртуальное казино (демо)

Оригинальная социальная казино-платформа на Node.js и JSON-БД. Это **не** копия защищённых материалов и **не** азартная система на реальные деньги: все расчёты ведутся только в виртуальных монетах `VGC`.

## Возможности

- Регистрация/вход, пароли хешируются через Node `scrypt`.
- 20 авторских слотов с механиками в популярных жанрах:
  - Olympus-style: pay-anywhere, tumble и орбы-множители (`Stormpeak Gates`, `Candy Rain`);
  - Big Bass-style: рыболов-collect и free spins (`Bass Bounty`);
  - Book-style: расширяющийся бонусный символ (`Book of Nile Secrets`);
  - ways, cluster/cascade, Hold & Win, expanding wild respins.
- Быстрые игры: Dice, Neon Coin, Lucky Wheel, Rocket и Mines.
- Кошелёк, история операций, уровни/XP, ежедневный бонус и виртуальный кран.
- Лидерборд, лента выигрышей, адаптивный неоновый интерфейс.
- Синтезированная музыка и эффекты через Web Audio API; отдельные профили для Olympus-style, fishing, candy и classic.
- Оригинальные процедурные SVG-эмблемы и символы; мобильная/ПК адаптация и reduced-motion.
- Атомарное сохранение JSON-БД; результаты игр считает сервер.

## Запуск

```bash
npm install
npm start
```

Откройте <http://localhost:3000>. Первый аккаунт получает 5000 VGC.

Переменные окружения:

```bash
PORT=3000 HOST=0.0.0.0 DATA_DIR=./data npm start
```

## Ubuntu без домена

```bash
sudo apt update
sudo apt install -y nodejs npm
cd /path/to/lucky-virtual-casino
npm install --omit=dev
PORT=3000 HOST=0.0.0.0 npm start
```

Без домена приложение доступно по IP: `http://SERVER_IP:3000`. Откройте порт при необходимости:

```bash
sudo ufw allow 3000/tcp
```

Для постоянной работы можно использовать `systemd`:

```bash
sudo tee /etc/systemd/system/lucky-vault.service >/dev/null <<'UNIT'
[Unit]
Description=Lucky Vault Virtual Casino Demo
After=network.target

[Service]
WorkingDirectory=/path/to/lucky-virtual-casino
ExecStart=/usr/bin/npm start
Restart=always
Environment=NODE_ENV=production
Environment=PORT=3000
Environment=HOST=0.0.0.0

[Install]
WantedBy=multi-user.target
UNIT

sudo systemctl daemon-reload
sudo systemctl enable --now lucky-vault
```

## Тесты

```bash
npm test
```

Тесты проверяют все 20 движков, структуру результатов, каждую SVG-эмблему/символ и выборочный диапазон RTP.

## Данные и сброс

JSON-БД создаётся автоматически:

- путь по умолчанию: `data/db.json`;
- резервная копия: `cp data/db.json backup-db.json`;
- полный демо-сброс: остановите сервер, удалите `data/db.json` и запустите его снова.

## API

```text
POST /api/auth/register       { username, password }
POST /api/auth/login          { username, password }
GET  /api/slots
POST /api/play/slots/:id      { bet }                Authorization: Bearer TOKEN
POST /api/play/dice           { bet, target }
POST /api/play/mines/start    { bet, mines }
GET  /api/wallet
GET  /api/leaderboard
```

Все ставки ограничены диапазоном 10–5000 VGC. Проект предназначен только для локальной демонстрации и развлечения; не подключайте платёжные системы.
