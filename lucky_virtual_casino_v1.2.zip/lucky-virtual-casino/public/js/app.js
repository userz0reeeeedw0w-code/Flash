'use strict';

const state={user:null,slots:[],slot:null,reels:[],spinning:false,autoplay:0,mines:null,sound:false};
const app=document.getElementById('app');
const token=()=>localStorage.getItem('lv-token')||'';
const format=value=>Number(value||0).toLocaleString('ru-RU',{maximumFractionDigits:2});

async function api(path,body){
 const response=await fetch('/api'+path,{
  method:body?'POST':'GET',
  headers:{'Content-Type':'application/json',...(token()?{Authorization:`Bearer ${token()}`}:{})},
  body:body?JSON.stringify(body):undefined
 });
 const data=await response.json().catch(()=>({error:'Сервер недоступен'}));
 if(!response.ok)throw new Error(data.error||'Ошибка сети');
 return data;
}
function syncUser(){
 document.getElementById('auth-button').textContent=state.user?'Выйти':'Войти';
 document.getElementById('balance-pill').classList.toggle('hidden',!state.user);
 if(state.user)document.getElementById('balance').textContent=format(state.user.balance);
}
function toast(message,error=false){
 const item=document.createElement('div');item.textContent=message;if(error)item.className='error';
 document.getElementById('toast').append(item);setTimeout(()=>item.remove(),3600);
}
function openModal(html){const modal=document.getElementById('modal');modal.querySelector('.modal-card').innerHTML=`<button class="modal-close" aria-label="Закрыть">×</button>${html}`;modal.classList.remove('hidden');modal.querySelector('.modal-card').focus({preventScroll:true});}
function closeModal(){document.getElementById('modal').classList.add('hidden')}
function guard(){if(state.user)return true;openModal(authHTML());return false;}
function logout(callServer=true){localStorage.removeItem('lv-token');state.user=null;if(callServer)api('/auth/logout').catch(()=>{});syncUser();location.hash='#/lobby';}

function authHTML(active='login'){
 return `<h2>${active==='login'?'Вход в демо':'Новый аккаунт'}</h2><p class="muted">Только виртуальные монеты VGC. Реальные платежи отключены.</p>
 <div class="tabs"><button type="button" data-tab="login" class="${active==='login'?'active':''}">Вход</button><button type="button" data-tab="register" class="${active==='register'?'active':''}">Регистрация</button></div>
 <form id="auth-form" data-mode="${active}"><label>Логин</label><input name="username" required minlength="3" maxlength="20" autocomplete="username"><label>Пароль</label><input name="password" type="password" required minlength="6" autocomplete="current-password"><div class="form-error"></div><button class="btn primary">${active==='login'?'Войти':'Создать и получить 5000 VGC'}</button></form>`;
}

document.addEventListener('click',event=>{
 const authButton=event.target.closest('#auth-button');
 if(authButton&&state.user)return logout();
 const tab=event.target.closest('[data-tab]');
 if(tab){openModal(authHTML(tab.dataset.tab));return;}
 if(event.target.id==='modal'||event.target.closest('.modal-close'))closeModal();
});
document.addEventListener('keydown',event=>{if(event.key==='Escape')closeModal()});
document.addEventListener('submit',async event=>{
 if(event.target.id!=='auth-form')return;event.preventDefault();
 const form=new FormData(event.target),button=event.target.querySelector('button');
 button.disabled=true;
 try{const data=await api('/auth/'+event.target.dataset.mode,Object.fromEntries(form));localStorage.setItem('lv-token',data.token);state.user=data.user;syncUser();closeModal();route();}
 catch(error){event.target.querySelector('.form-error').textContent=error.message}
 finally{button.disabled=false}
});
document.getElementById('sound-toggle').addEventListener('click',event=>{
 state.sound=CasinoAudio.toggleMusic();event.currentTarget.textContent=state.sound?'🔊':'🔇';event.currentTarget.classList.toggle('on',state.sound);
 if(state.sound&&state.slot)CasinoAudio.setTheme(state.slot.presentation?.soundProfile);
});

async function route(){
 try{
  if(!state.slots.length)state.slots=await api('/slots');
  highlightNav();
  const page=((location.hash||'#/lobby').slice(2)||'lobby').split('/')[0];
  const routes={lobby:renderLobby,slots:renderSlots,slot:renderSlotGame,fast:renderFast,bonus:renderBonus,wallet:renderWallet,top:renderTop};
  await (routes[page]||renderLobby)();
 }catch(error){app.innerHTML='<article class="panel error-panel">Не удалось загрузить раздел</article>';toast(error.message,true);}
}
function highlightNav(){document.querySelectorAll('#main-nav a').forEach(link=>link.classList.toggle('active',link.getAttribute('href')==='#/'+((location.hash||'#/lobby').split('/')[1]||'lobby')))}

function volatilityLabel(value){return({low:'Низкая',medium:'Средняя',high:'Высокая','very-high':'Экстрим'})[value]||value}
function gameCard(slot){
 return `<article class="game-card" data-id="${slot.id}" style="--accent:${slot.presentation?.accent};--accent2:${slot.presentation?.accent2}">
  <div class="card-art">${GameArt.emblem(slot)}</div>
  <div class="card-body"><h3>${slot.title}</h3>
   <div class="meta"><span>RTP ${(slot.rtp*100).toFixed(1)}%</span><span>${volatilityLabel(slot.volatility)}</span></div>
   <div class="badges">${slot.features.slice(0,2).map(item=>`<span class="badge">${item}</span>`).join('')}</div></div></article>`;
}
function bindCards(){app.querySelectorAll('.game-card[data-id]').forEach(card=>card.addEventListener('click',()=>location.hash='#/slot/'+card.dataset.id))}

function renderLobby(){
 const featured=['stormpeak-gates','bass-bounty','candy-rain','harvest-bonanza'].map(id=>state.slots.find(slot=>slot.id===id)).filter(Boolean);
 app.innerHTML=`<section class="hero">
  <div><span class="badge">Virtual Casino • Только VGC • 18+</span><h1>Оригинальные слоты с <em>кинематографичными</em> механиками</h1>
  <p>${state.slots.length} авторских игр, быстрые режимы, бонусы и уровни. Полностью адаптивный интерфейс для телефона, планшета и ПК.</p>
  <div class="hero-actions"><a class="btn primary" href="#/slots" data-link>Открыть зал</a><a class="btn ghost" href="#/fast" data-link>Быстрые игры</a></div></div>
  <div class="hero-orbit">${['star','dragon','diamond','coin','crown','crystal'].map((name,index)=>`<div class="orbit-item" style="--delay:${index*.42}s">${GameArt.symbol(name,{size:44})}</div>`).join('')}</div></section>
  <div class="section-title"><h2>Избранные механики</h2><a href="#/slots" data-link>Все игры →</a></div><div id="popular" class="grid"></div>
  <div class="split-grid"><article class="panel"><h3>Лидеры</h3><ol id="home-top" class="list ranked"></ol></article><article class="panel"><h3>Последние выплаты</h3><ul id="home-feed" class="list"></ul></article></div>`;
 document.getElementById('popular').innerHTML=[...featured,...state.slots.filter(slot=>!featured.includes(slot))].slice(0,8).map(gameCard).join('');
 bindCards();refreshSocial(['home-top','home-feed']);
}

function renderSlots(){
 const filters=[['all','Все'],['payAnywhere','Olympus-style'],['collect','Fishing'],['book','Book'],['ways','Ways'],['cluster','Cluster'],['coins','Hold & Win'],['respin','Respin']];
 app.innerHTML=`<div class="section-title"><h2>Слот-зал</h2><span>${state.slots.length} игр</span></div>
 <div class="panel filters">${filters.map(([key,label],index)=>`<button class="btn small ${index?'ghost':'primary'}" data-filter="${key}">${label}</button>`).join('')}</div><div id="slot-grid" class="grid"></div>`;
 const applyFilter=filter=>{
  const items=filter==='all'?state.slots:state.slots.filter(slot=>filter==='book'?slot.expandingWild:slot.type===filter);
  document.getElementById('slot-grid').innerHTML=items.map(gameCard).join('');
  document.querySelectorAll('[data-filter]').forEach(button=>{button.className=`btn small ${button.dataset.filter===filter?'primary':'ghost'}`;button.onclick=()=>applyFilter(button.dataset.filter)});
  bindCards();
 };
 applyFilter('all');
}

function randomSymbol(slot){
 const entries=Object.entries(slot.symbols),total=entries.reduce((sum,[,item])=>sum+item.weight,0);
 let roll=Math.random()*total;
 for(const [key,item] of entries){roll-=item.weight;if(roll<=0)return key;}
 return entries[0][0];
}
function initialReels(slot){state.reels=Array.from({length:slot.reels},()=>Array.from({length:slot.rows},()=>randomSymbol(slot)))}
function cellHTML(symbol){return `<div class="cell">${GameArt.symbol(symbol,{size:58})}</div>`}
function buildGrid(slot,grid=state.reels){
 const reels=document.getElementById('reels');reels.style.setProperty('--cols',slot.reels);
 reels.innerHTML=grid.map(column=>`<div class="reel">${column.map(cellHTML).join('')}</div>`).join('');
}
function revealGrid(grid){
 return new Promise(resolve=>{
  const columns=[...document.querySelectorAll('#reels .reel')];columns.forEach(column=>column.classList.add('spinning'));
  columns.forEach((column,index)=>setTimeout(()=>{
   column.innerHTML=grid[index].map(cellHTML).join('');column.classList.remove('spinning');column.classList.add('landing');
   setTimeout(()=>column.classList.remove('landing'),420);CasinoAudio.sfx('stop');if(index===columns.length-1)setTimeout(resolve,180);
  },140*index));
 });
}
function showFx(result){
 const layer=document.getElementById('fx-layer');if(!layer)return;layer.innerHTML='';
 const add=(content,className,delay=0)=>{const element=document.createElement('div');element.className=className;element.innerHTML=content;element.style.animationDelay=`${delay}ms`;layer.append(element)};
 if(result.multipliers?.length)result.multipliers.slice(0,10).forEach((multiplier,index)=>{
  add(`<span>×${multiplier}</span>`,'fx-orb',index*130);CasinoAudio.sfx('multiplier');
 });
 if(result.coinCells?.length)result.coinCells.slice(0,8).forEach((cell,index)=>add(`<small>+${format(cell.value)}</small>`,'fx-fish',index*110));
 if(result.holdWin?.collected)add(`<b>COLLECT +${format(result.holdWin.collected)}</b>`,'fx-collect',180);
 if(result.respins?.length)add('<b>STICKY RESPIN</b>','fx-banner',120);
 if(result.freeSpins?.total)add(`<b>BONUS +${format(result.freeSpins.total)}</b>`,'fx-bonus',300);
 setTimeout(()=>layer.querySelectorAll('.fx-orb,.fx-fish,.fx-collect,.fx-bonus,.fx-banner').forEach(item=>item.remove()),2600);
}
function markWins(result){
 const cells=document.querySelectorAll('#reels .cell');
 const highlight=positions=>positions?.forEach(position=>cells[position.reel*state.slot.rows+position.row]?.classList.add('win'));
 result.wins?.slice(0,30).forEach(win=>highlight(win.positions));
 result.expansionEvents?.forEach(event=>Array.from({length:state.slot.rows},(__,row)=>cells[event.reel*state.slot.rows+row]?.classList.add('expanded')));
}

async function renderSlotGame(){
 if(!await guard())return;
 const id=(location.hash.split('/')[2]||''),slot=state.slots.find(item=>item.id===id)||state.slots[0];
 location.hash='#/slot/'+slot.id;state.slot=slot;state.autoplay=0;initialReels(slot);
 CasinoAudio.setTheme(slot.presentation?.soundProfile);
 app.className='page-slot';document.body.dataset.engine=slot.type;document.body.dataset.theme=slot.theme;
 app.innerHTML=`<div class="slot-shell theme-${slot.theme}">
  <header class="slot-head"><a class="btn ghost icon-only" href="#/slots" data-link aria-label="Назад">←</a>
   <div class="emblem-title"><div class="mini-emblem">${GameArt.emblem(slot)}</div><div><h1>${slot.title}</h1><p>${slot.features.join(' • ')}</p></div></div>
   <div class="badges desktop-only"><span class="badge">RTP ${(slot.rtp*100).toFixed(1)}%</span><span class="badge">${volatilityLabel(slot.volatility)}</span><span class="badge">${slot.reels}×${slot.rows}</span></div></header>
  <div class="slot-layout">
   <section class="stage" aria-label="${slot.title}">
    <div class="reel-frame"><div class="reels" id="reels"></div><div class="fx-layer" id="fx-layer" aria-live="polite"></div></div>
    <div class="result-bar" id="result">Выберите ставку и запустите барабаны</div>
    <div class="spin-controls">
     <div class="field bet-field"><button class="bet-chip" data-step="-">−</button><input id="bet" value="50" inputmode="numeric" aria-label="Ставка"><button class="bet-chip" data-step="+">+</button></div>
     ${[10,25,50,100].map(value=>`<button class="bet-chip" data-value="${value}">${value}</button>`).join('')}
     <button id="spin" class="btn primary spin-button">SPIN</button><button id="auto" class="btn ghost">AUTO</button>
    </div>
   </section>
   <aside class="game-info panel">
    <h2>Механика</h2><p class="muted">${slot.features.join('. ')}.</p>
    <h3>Символы</h3><div class="symbol-grid">${Object.entries(slot.symbols).slice(0,10).map(([key,value])=>`<div>${GameArt.symbol(key,{size:36})}<span>${value.name||key}</span></div>`).join('')}</div>
    <h3>Правила демо</h3><ul class="rules"><li>Результат рассчитывает сервер.</li><li>Ставка 10–5000 VGC.</li><li>VGC нельзя купить или вывести.</li></ul>
   </aside>
  </div></div>`;
 buildGrid(slot);bindSlotControls(slot);
}

async function performSpin(slot){
 const betInput=document.getElementById('bet'),spinButton=document.getElementById('spin'),resultBar=document.getElementById('result');
 const bet=Math.max(10,Math.min(5000,Number(betInput.value)||50));betInput.value=bet;
 if(bet>state.user.balance){toast('Недостаточно VGC',true);state.autoplay=0;updateAutoButton();return;}
 state.spinning=true;spinButton.disabled=true;document.body.classList.add('is-spinning');
 resultBar.className='result-bar';resultBar.textContent='Барабаны вращаются…';CasinoAudio.sfx('spin');
 document.querySelectorAll('.cell.win,.cell.expanded').forEach(cell=>cell.classList.remove('win','expanded'));
 try{
  const result=await api('/play/slots/'+slot.id,{bet});state.user=result.user;syncUser();
  await new Promise(resolve=>setTimeout(resolve,320));await revealGrid(result.grid);markWins(result);showFx(result);
  const win=result.totalWin||0,prefix=win>bet?`+${format(win-bet)} VGC`:`−${format(bet-win)} VGC`;
  resultBar.className='result-bar'+(win>bet*10?' jackpot':win>bet?' positive':win===bet?'':' negative');
  resultBar.textContent=win>bet*10?`MEGA WIN ${prefix}`:win>=bet?`${prefix}`:`Нет выигрыша · ${prefix}`;
  CasinoAudio.sfx(win>bet*10?'big':win>bet?'win':'click');
  if(result.multipliers?.length)resultBar.textContent+=` · Множители ×${result.multipliers.join(', ×')}`;
  if(result.freeSpins?.total)setTimeout(()=>toast(`Бонус завершён: +${format(result.freeSpins.total)} VGC`),700);
 }catch(error){toast(error.message,true);state.autoplay=0;}
 finally{state.spinning=false;spinButton.disabled=false;document.body.classList.remove('is-spinning');updateAutoButton();}
}
function updateAutoButton(){const button=document.getElementById('auto');if(button)button.textContent=state.autoplay?`STOP (${state.autoplay})`:'AUTO'}
function bindSlotControls(slot){
 const betInput=document.getElementById('bet');
 document.querySelectorAll('[data-step]').forEach(button=>button.addEventListener('click',()=>{
  const current=Number(betInput.value)||50;betInput.value=Math.max(10,Math.min(5000,button.dataset.step==='+'?current+10:current-10));
 }));
 document.querySelectorAll('[data-value]').forEach(button=>button.addEventListener('click',()=>betInput.value=button.dataset.value));
 document.getElementById('spin').addEventListener('click',()=>performSpin(slot));
 document.getElementById('auto').addEventListener('click',async()=>{
  if(state.autoplay){state.autoplay=0;updateAutoButton();return;}
  state.autoplay=25;updateAutoButton();
  while(state.autoplay&&!state.spinning){state.autoplay--;updateAutoButton();await performSpin(slot);if(state.autoplay)await new Promise(resolve=>setTimeout(resolve,450));}
 });
}

function renderFast(){
 if(!guard())return;app.className='';
 app.innerHTML=`<div class="section-title"><h2>Быстрые игры</h2><span>Мгновенный серверный расчёт</span></div><div class="fast-grid">${diceHTML()}${coinHTML()}${wheelHTML()}${rocketHTML()}${minesHTML()}</div>`;
 bindFast();
}
const field=(id,label='Ставка')=>`<label>${label}</label><div class="field"><input id="${id}" type="number" min="10" max="5000" value="50"></div>`;
function diceHTML(){return `<article class="panel game-panel"><h3>Dice</h3>${field('dice-bet')}<label>Цель: <b id="dice-value">50%</b>, выплата ×1.98</label><input id="dice-target" type="range" min="2" max="98" value="50"><div class="result-display" id="dice-result">—</div><button id="dice-play" class="btn primary">Бросить</button></article>`}
function coinHTML(){return `<article class="panel game-panel"><h3>Neon Coin</h3>${field('coin-bet')}<div class="result-display" id="coin-result">?</div><div class="row-buttons"><button class="btn" data-coin="heads">Орёл</button><button class="btn" data-coin="tails">Решка</button></div></article>`}
function wheelHTML(){return `<article class="panel game-panel"><h3>Lucky Wheel</h3>${field('wheel-bet')}<div class="result-display" id="wheel-result">—</div><button id="wheel-play" class="btn primary">Крутить</button></article>`}
function rocketHTML(){return `<article class="panel game-panel"><h3>Vault Rocket</h3>${field('rocket-bet')}<label>Автовывод, ×</label><input id="rocket-target" type="number" step=".01" min="1.01" value="2"><div class="result-display" id="rocket-result">—</div><button id="rocket-play" class="btn primary">Запуск</button></article>`}
function minesHTML(){return `<article class="panel game-panel mines-panel"><h3>Vault Mines</h3>${field('mines-bet')}<label>Мины</label><input id="mines-count" type="number" min="1" max="24" value="3"><div class="row-buttons"><button id="mines-start" class="btn">Старт</button><button id="mines-cash" class="btn primary" disabled>Забрать</button></div><div class="result-display" id="mines-result">Открыть игру</div><div class="tiles">${Array.from({length:25},(__,index)=>`<button class="tile" data-index="${index}" disabled>${index+1}</button>`).join('')}</div></article>`}
function readBet(id){return Math.max(10,Math.min(5000,Number(document.getElementById(id).value)||50))}
function setResult(id,content,positive=null){const node=document.getElementById(id);node.innerHTML=content;node.classList.toggle('positive',positive===true);node.classList.toggle('negative',positive===false)}
async function playFast(event,path,body,id,render){
 event.currentTarget.disabled=true;
 try{const result=await api(path,body);state.user=result.user;syncUser();setResult(id,render(result),result.payout>0);CasinoAudio.sfx(result.payout>0?'win':'click');}
 catch(error){toast(error.message,true)}finally{event.currentTarget.disabled=false}
}
function bindFast(){
 const range=document.getElementById('dice-target');
 range.addEventListener('input',()=>{document.getElementById('dice-value').textContent=`${range.value}%`;document.getElementById('dice-value').textContent=`${range.value}%`});
 document.getElementById('dice-play').addEventListener('click',event=>playFast(event,'/play/dice',{bet:readBet('dice-bet'),target:Number(range.value)},'dice-result',result=>`${result.roll.toFixed(2)} · ${result.won?'WIN':'LOSS'}`));
 document.querySelectorAll('[data-coin]').forEach(button=>button.addEventListener('click',event=>playFast(event,'/play/coin',{bet:readBet('coin-bet'),side:button.dataset.coin},'coin-result',result=>result.result==='heads'?'Орёл':'Решка')));
 document.getElementById('wheel-play').addEventListener('click',event=>playFast(event,'/play/wheel',{bet:readBet('wheel-bet')},'wheel-result',result=>`×${result.multiplier}`));
 document.getElementById('rocket-play').addEventListener('click',event=>playFast(event,'/play/rocket',{bet:readBet('rocket-bet'),target:Number(document.getElementById('rocket-target').value)},'rocket-result',result=>result.won?`CASHOUT ×${result.target}`:`CRASH ×${result.crash}`));
 bindMines();
}
function bindMines(){
 const start=document.getElementById('mines-start'),cash=document.getElementById('mines-cash'),tiles=[...document.querySelectorAll('.tile')];
 start.addEventListener('click',async()=>{
  start.disabled=true;
  try{
   const result=await api('/play/mines/start',{bet:readBet('mines-bet'),mines:Number(document.getElementById('mines-count').value)});
   state.user.balance=result.balance;syncUser();state.mines={count:result.mineCount};
   tiles.forEach(tile=>{tile.disabled=false;tile.className='tile'});
   cash.disabled=true;setResult('mines-result',`Открыто · ${result.mineCount} мин`,true);
  }catch(error){toast(error.message,true)}finally{start.disabled=false}
 });
 tiles.forEach(tile=>tile.addEventListener('click',async()=>{
  tile.disabled=true;
  try{
   const result=await api('/play/mines/reveal',{tile:Number(tile.dataset.index)});
   if(result.hit){tile.classList.add('mine');state.mines=null;tiles.forEach(item=>item.disabled=true);setResult('mines-result','Мина! Ставка потеряна',false);CasinoAudio.sfx('click')}
   else{tile.classList.add('safe');cash.disabled=false;cash.textContent=`Забрать ×${result.multiplier}`;setResult('mines-result',`Безопасно · ×${result.multiplier}`,true)}
  }catch(error){toast(error.message,true)}
 }));
 cash.addEventListener('click',async()=>{
  cash.disabled=true;
  try{const result=await api('/play/mines/cashout');state.user=result.user;syncUser();state.mines=null;tiles.forEach(tile=>tile.disabled=true);setResult('mines-result', `Выигрыш +${format(Math.max(0,result.payout-(result.bet||0)))} VGC`,true);CasinoAudio.sfx('win')}
  catch(error){toast(error.message,true)}
 });
}

async function claimBonus(path,message,event){
 event.currentTarget.disabled=true;
 try{const result=await api(path);state.user=result.user;syncUser();toast(`${message}: +${format(result.amount)} VGC`);CasinoAudio.sfx('win');renderBonus();}
 catch(error){toast(error.message,true);event.currentTarget.disabled=false;}
}
async function renderBonus(){
 if(!guard())return;const user=await api('/me');state.user=user;syncUser();
 app.innerHTML=`<div class="section-title"><h2>Бонусы и экономика</h2></div>
 <div class="stats"><div class="stat"><span>Баланс</span><b>${format(user.balance)}</b></div><div class="stat"><span>Уровень</span><b>${user.level}</b></div><div class="stat"><span>XP</span><b>${user.xp}/${user.nextLevelXp}</b></div><div class="stat"><span>Спины</span><b>${user.spinsCount}</b></div></div>
 <div class="split-grid"><article class="panel"><h3>Ежедневный бонус</h3><p>Раз в 20 часов: от 250 до 2500 VGC.</p><button id="daily" class="btn primary" ${user.canClaimDaily?'':'disabled'}>Получить</button></article>
 <article class="panel"><h3>Демо-кран</h3><p>Раз в час добавляет 250 тестовых VGC.</p><button id="faucet" class="btn" ${user.canClaimFaucet?'':'disabled'}>Пополнить</button></article></div>`;
 document.getElementById('daily').addEventListener('click',event=>claimBonus('/bonus/daily','Ежедневный бонус',event));
 document.getElementById('faucet').addEventListener('click',event=>claimBonus('/bonus/faucet','Демо-баланс',event));
}
async function renderWallet(){
 if(!guard())return;const wallet=await api('/wallet');
 app.innerHTML=`<div class="section-title"><h2>Кошелёк</h2><span>${format(wallet.balance)} VGC</span></div><article class="panel"><ul class="list">${wallet.transactions.map(item=>`<li><div><b>${item.description}</b><small>${item.type} · ${new Date(item.at).toLocaleString('ru-RU')}</small></div><b class="${item.amount>=0?'positive':'negative'}">${item.amount>=0?'+':''}${format(item.amount)}</b></li>`).join('')||'<li>Операций нет</li>'}</ul></article>`;
}
async function refreshSocial(topId,feedId){
 try{
  const [top,feed]=await Promise.all([api('/leaderboard'),api('/feed')]);
  const topNode=document.getElementById(topId),feedNode=document.getElementById(feedId);
  if(topNode)topNode.innerHTML=top.slice(0,5).map((user,index)=>`<li><span>${index+1}. ${user.username} · LVL ${user.level}</span><span class="positive">${format(user.won)}</span></li>`).join('');
  if(feedNode)feedNode.innerHTML=feed.slice(0,6).map(item=>`<li><span>${item.username} · ${item.game}</span><span class="positive">+${format(item.amount)}</span></li>`).join('');
 }catch(error){}
}
async function renderTop(){
 const [top,feed]=await Promise.all([api('/leaderboard'),api('/feed')]);
 app.innerHTML=`<div class="section-title"><h2>Топ игроков</h2></div><div class="split-grid"><article class="panel"><h3>Лидеры</h3><ol class="list ranked">${top.map((user,index)=>`<li><span>${index+1}. ${user.username} · LVL ${user.level}</span><span class="positive">${format(user.won)}</span></li>`).join('')}</ol></article><article class="panel"><h3>Крупные выплаты</h3><ul class="list">${feed.map(item=>`<li><span>${item.username} · ${item.game}</span><span class="positive">+${format(item.amount)} · ×${item.multiplier}</span></li>`).join('')}</ul></article></div>`;
}

window.addEventListener('hashchange',route);
(async function init(){
 if(token()){try{state.user=await api('/me')}catch(error){localStorage.removeItem('lv-token')}}
 syncUser();await route();
})();
