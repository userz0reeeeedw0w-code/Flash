'use strict';

const GameArt = (() => {
  const palettes={
    classic:['#fbbf24','#dc2626','#450a0a'],
    egypt:['#f59e0b','#7c2d12','#1c1917'],
    cyber:['#22d3ee','#2563eb','#020617'],
    nature:['#84cc16','#166534','#052e16'],
    fantasy:['#f87171','#7f1d1d','#1a0a0a'],
    water:['#38bdf8','#155e75','#041b24'],
    sweet:['#f472b6','#9333ea','#2a0a37'],
    winter:['#a5f3fc','#0891b2','#04212b'],
    magic:['#a78bfa','#5b21b6','#16082e'],
    myth:['#60a5fa','#1d4ed8','#071233'],
    halloween:['#fb923c','#4c1d95','#100422'],
    west:['#fbbf24','#92400e','#201203']
  };

  const symbolPaths={
    cherry:`<path d="M32 10c8 3 13 8 14 17" fill="none" stroke="#65a30d" stroke-width="4" stroke-linecap="round"/><circle cx="23" cy="39" r="12" fill="#ef4444"/><circle cx="41" cy="43" r="10" fill="#dc2626"/><circle cx="20" cy="35" r="3" fill="#fecaca" opacity=".8"/>`,
    lemon:`<ellipse cx="32" cy="34" rx="18" ry="14" transform="rotate(-18 32 34)" fill="#facc15"/><ellipse cx="27" cy="29" rx="6" ry="4" transform="rotate(-18 27 29)" fill="#fef9c3" opacity=".85"/>`,
    grape:`<g fill="#8b5cf6"><circle cx="26" cy="28" r="7"/><circle cx="38" cy="28" r="7"/><circle cx="32" cy="37" r="8"/><circle cx="25" cy="44" r="6"/><circle cx="39" cy="44" r="6"/></g><path d="M32 16v8" stroke="#65a30d" stroke-width="4" stroke-linecap="round"/>`,
    bell:`<path d="M32 12c10 0 15 8 15 20l5 9H12l5-9c0-12 5-20 15-20z" fill="#fbbf24"/><circle cx="32" cy="48" r="5" fill="#f59e0b"/><rect x="27" y="9" width="10" height="5" rx="2" fill="#f59e0b"/>`,
    star:`<path d="M32 8l7 16 17 2-13 11 4 17-15-9-15 9 4-17L8 26l17-2z" fill="#fde047" stroke="#f59e0b" stroke-width="2"/>`,
    diamond:`<path d="M18 14h28l10 13-24 25L8 27z" fill="#67e8f9"/><path d="M18 14h28l10 13H8z" fill="#a5f3fc"/><path d="M32 52L20 27h24z" fill="#cffafe" opacity=".7"/>`,
    seven:`<text x="32" y="47" text-anchor="middle" font-family="Arial Black,Arial" font-size="40" font-weight="900" fill="#ef4444" stroke="#fff1f2" stroke-width="1">7</text>`,
    scarab:`<ellipse cx="32" cy="35" rx="15" ry="19" fill="#22c55e"/><ellipse cx="32" cy="31" rx="8" ry="13" fill="#86efac"/><path d="M17 25 8 18m47 7 9-7M17 42l-9 7m47-7 9 7" stroke="#166534" stroke-width="4" stroke-linecap="round"/>`,
    eye:`<path d="M8 32q24-21 48 0-24 21-48 0z" fill="#fff7ed"/><circle cx="32" cy="32" r="9" fill="#0ea5e9"/><circle cx="32" cy="32" r="4" fill="#0c4a6e"/>`,
    phoenix:`<path d="M32 7c10 10 16 18 16 28 0 12-7 21-16 22-9-1-16-10-16-22 0-10 6-18 16-28z" fill="#fb923c"/><path d="M32 20c5 7 8 12 8 18 0 8-4 13-8 14-4-1-8-6-8-14 0-6 3-11 8-18z" fill="#fef08a"/>`,
    moon:`<path d="M45 8a25 25 0 1 0 11 39A21 21 0 0 1 45 8z" fill="#fde68a"/>`,
    wolf:`<path d="M12 14l10 8h20l10-8v18c0 14-9 24-20 28-11-4-20-14-20-28z" fill="#94a3b8"/><path d="M24 33h6m10 0h6" stroke="#0f172a" stroke-width="3" stroke-linecap="round"/><path d="M32 41l5 6H27z" fill="#0f172a"/>`,
    dragon:`<path d="M12 24q18-16 40-4-6 20-22 28-14-6-18-24z" fill="#dc2626"/><circle cx="38" cy="26" r="4" fill="#fde047"/><path d="M20 46l-6 10m18-6-2 10" stroke="#b91c1c" stroke-width="5" stroke-linecap="round"/>`,
    pearl:`<circle cx="32" cy="33" r="16" fill="#bae6fd" opacity=".55"/><circle cx="32" cy="33" r="10" fill="#f0f9ff"/><circle cx="28" cy="29" r="3" fill="#fff"/>`,
    candy:`<circle cx="32" cy="32" r="15" fill="#ec4899"/><path d="M32 17a15 15 0 0 1 0 30 9 9 0 0 0 0-30z" fill="#fdf2f8"/><path d="M17 32h30M32 17v30" stroke="#be185d" stroke-width="3"/>`,
    robot:`<rect x="15" y="20" width="34" height="27" rx="9" fill="#93c5fd"/><circle cx="26" cy="33" r="5" fill="#0f172a"/><circle cx="38" cy="33" r="5" fill="#0f172a"/><rect x="28" y="11" width="8" height="10" rx="3" fill="#60a5fa"/>`,
    tiger:`<path d="M12 18l9 7h22l9-7v17c0 13-9 22-20 26-11-4-20-13-20-26z" fill="#f97316"/><path d="M22 25h7m13 0h7" stroke="#7c2d12" stroke-width="4" stroke-linecap="round"/><path d="M32 39l5 7H27z" fill="#7c2d12"/>`,
    snowflake:`<path d="M32 8v48M11 20l42 24M53 20 11 44" stroke="#e0f2fe" stroke-width="6" stroke-linecap="round"/><path d="M32 8v48M11 20l42 24M53 20 11 44" stroke="#7dd3fc" stroke-width="2"/>`,
    crown:`<path d="M10 44V20l11 9 11-16 11 16 11-9v24z" fill="#fbbf24"/><rect x="10" y="44" width="44" height="9" rx="3" fill="#d97706"/>`,
    crystal:`<path d="M32 7l15 17-15 33-15-33z" fill="#c4b5fd"/><path d="M32 7l15 17H17z" fill="#ede9fe"/><path d="M32 57V24" stroke="#8b5cf6" stroke-width="2"/>`,
    coin:`<circle cx="32" cy="32" r="19" fill="#fbbf24"/><circle cx="32" cy="32" r="14" fill="#fde68a"/><text x="32" y="39" text-anchor="middle" font-size="18" font-weight="bold" fill="#b45309">V</text>`,
    ring:`<circle cx="32" cy="36" r="15" fill="none" stroke="#fcd34d" stroke-width="7"/><path d="M26 16l6-8 6 8-6 7z" fill="#a78bfa"/>`,
    goblet:`<path d="M18 12h28v9c0 10-6 16-14 17-8-1-14-7-14-17z" fill="#fbbf24"/><path d="M32 38v10m-10 4h20" stroke="#d97706" stroke-width="5" stroke-linecap="round"/>`,
    hourglass:`<path d="M18 10h28v7c0 7-8 11-14 15-6-4-14-8-14-15z" fill="#fde68a"/><path d="M18 54h28v-7c0-7-8-11-14-15-6 4-14 8-14 15z" fill="#fcd34d"/>`,
    laurel:`<path d="M32 52C18 48 11 36 13 20c14 1 23 11 24 26" fill="#4ade80"/><path d="M32 52c14-4 21-16 19-32-14 1-23 11-24 26" fill="#16a34a"/>`,
    orb:`<circle cx="32" cy="32" r="18" fill="#7c3aed"/><circle cx="32" cy="32" r="12" fill="#c4b5fd"/><text x="32" y="38" text-anchor="middle" font-size="15" font-weight="900" fill="#4c1d95">×</text>`,
    temple:`<path d="M10 50h44v6H10z" fill="#e2e8f0"/><path d="M16 26h32v24H16z" fill="#f8fafc"/><path d="M8 26 32 9l24 17z" fill="#cbd5e1"/><path d="M22 34h5v16h-5zm15 0h5v16h-5z" fill="#64748b"/>`,
    fish:`<path d="M10 32q14-15 31-8l12-9-4 17 4 17-12-9q-17 7-31-8z" fill="#38bdf8"/><circle cx="22" cy="30" r="3" fill="#082f49"/>`,
    bass:`<path d="M9 32q16-17 34-9l13-10-5 19 5 19-13-10q-18 8-34-9z" fill="#059669"/><path d="M20 24q12-5 24 0-12 16-24 0z" fill="#6ee7b7" opacity=".7"/><circle cx="21" cy="29" r="3" fill="#064e3b"/>`,
    rodman:`<circle cx="26" cy="20" r="9" fill="#fdba74"/><path d="M17 52c0-11 5-18 9-18s9 7 9 18z" fill="#0ea5e9"/><path d="M35 16c10 3 15 10 15 20" stroke="#e2e8f0" stroke-width="3" fill="none"/><path d="M50 36v8" stroke="#e2e8f0" stroke-width="3"/>`,
    buoy:`<circle cx="32" cy="32" r="18" fill="#f97316"/><circle cx="32" cy="32" r="8" fill="#fff7ed"/><path d="M32 14v36M14 32h36" stroke="#fff7ed" stroke-width="6"/>`,
    book:`<path d="M10 16q22-7 22 4v34q0-9-22-4z" fill="#b91c1c"/><path d="M54 16q-22-7-22 4v34q0-9 22-4z" fill="#ef4444"/><path d="M32 20v34" stroke="#fca5a5" stroke-width="3"/>`,
    moneybag:`<path d="M24 14h16l5 8c9 7 12 30-13 32C7 52 10 29 19 22z" fill="#a16207"/><path d="M24 14h16l3 6H21z" fill="#ca8a04"/><text x="32" y="41" text-anchor="middle" font-size="18" font-weight="bold" fill="#fef3c7">$</text>`,
    sheriff:`<path d="M32 7l7 16 17 2-13 11 4 17-15-9-15 9 4-17L8 25l17-2z" fill="#fbbf24"/><circle cx="32" cy="31" r="7" fill="#92400e"/>`,
    bull:`<path d="M10 20q22-12 44 0-4 24-22 32-18-8-22-32z" fill="#a16207"/><path d="M10 20 4 10m50 10 6-10" stroke="#78350f" stroke-width="6" stroke-linecap="round"/><circle cx="24" cy="31" r="3" fill="#451a03"/><circle cx="40" cy="31" r="3" fill="#451a03"/>`,
    eagle:`<path d="M32 9l8 15 18-6-13 17 13 17-18-6-8 15-8-15-18 6 13-17L6 18l18 6z" fill="#e2e8f0"/><circle cx="32" cy="31" r="6" fill="#fbbf24"/>`,
    cactus:`<path d="M28 52V18a4 4 0 0 1 8 0v34z" fill="#16a34a"/><path d="M28 32H18a5 5 0 0 1-5-5v-5m27 10h10a5 5 0 0 0 5-5v-5" stroke="#15803d" stroke-width="8" stroke-linecap="round" fill="none"/>`
  };

  function shade(hex, opacity=1){const value=hex.replace('#','');const rgb=[0,2,4].map(i=>parseInt(value.slice(i,i+2),16));return `rgba(${rgb.join(',')},${opacity})`;}
  function uid(prefix,text){let hash=0;for(const char of text)hash=(hash*31+char.charCodeAt(0))&0xffff;return `${prefix}-${hash.toString(36)}`;}

  function background(theme,id){
    const [accent,secondary,dark]=palettes[theme]||palettes.classic;
    const gradient=uid('bg',id+theme);
    let scene='';
    if(theme==='myth')scene=`<path d="M0 130 70 70l50 42 58-58 142 76v50H0z" fill="${shade(secondary,.65)}"/><path d="M150 18 128 72h20l-18 56 51-73h-22l18-37z" fill="${shade('#fff',.92)}"/>`;
    else if(theme==='halloween')scene=`<circle cx="255" cy="42" r="31" fill="#fdba74" opacity=".9"/><path d="M0 132q80-45 160-8t160-4v60H0z" fill="${shade(accent,.35)}"/><path d="M45 118q4-16-6-24m120 28q3-14-6-22" stroke="${shade('#fff',.35)}" stroke-width="5" fill="none" stroke-linecap="round"/>`;
    else if(theme==='sweet')scene=`<circle cx="45" cy="135" r="48" fill="${shade(secondary,.75)}"/><circle cx="270" cy="125" r="62" fill="${shade(accent,.35)}"/><path d="M0 126q80-38 160 0t160 0v54H0z" fill="${shade('#fff',.16)}"/>`;
    else if(theme==='egypt')scene=`<path d="M18 145 88 48l69 97z" fill="${shade('#fbd38d',.35)}"/><path d="M165 145l64-81 91 81z" fill="${shade(secondary,.75)}"/><circle cx="63" cy="42" r="21" fill="${shade(accent,.95)}"/>`;
    else if(theme==='cyber'||theme==='west')scene=`<path d="M0 145V83h35v62zM55 145V61h44v84zM124 145V96h39v49zM187 145V49h48v96zM260 145V77h60v68z" fill="${shade(secondary,.72)}"/><path d="M0 112h320" stroke="${shade(accent,.8)}" stroke-width="3"/>`;
    else if(theme==='water')scene=`<path d="M0 104q40-22 80 0t80 0 80 0 80 0v76H0z" fill="${shade(accent,.35)}"/><path d="M0 127q40-22 80 0t80 0 80 0 80 0v53H0z" fill="${shade(accent,.55)}"/>`;
    else scene=`<path d="M0 146 74 71l54 47 62-64 130 92v30H0z" fill="${shade(secondary,.65)}"/><circle cx="264" cy="45" r="27" fill="${shade(accent,.85)}"/>`;
    return `<defs><linearGradient id="${gradient}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${accent}"/><stop offset=".58" stop-color="${secondary}"/><stop offset="1" stop-color="${dark}"/></linearGradient><radialGradient id="${gradient}-glow" cx=".5" cy=".42"><stop offset="0" stop-color="#fff" stop-opacity=".55"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient></defs>
      <rect width="320" height="180" fill="url(#${gradient})"/>${scene}<rect width="320" height="180" fill="url(#${gradient}-glow)"/>`;
  }

  function motif(slot){
    const map={ 'stormpeak-gates':'temple','bass-bounty':'rodman','candy-rain':'candy','harvest-bonanza':'grape',
      'pharaohs-ember':'eye','book-of-nile-secrets':'book','dragon-vault':'dragon','ocean-pearls':'pearl',
      'wolf-moon-gold':'wolf','jungle-kings':'tiger','thunder-herd':'bull','western-money-rails':'moneybag',
      'ice-wilds':'snowflake','crystal-tumble':'crystal','neon-fortune':'robot','golden-scarab-ways':'scarab'};
    return GameArt.symbol(map[slot.id]||Object.keys(slot.symbols)[0],{size:104});
  }

  function emblem(slot){
    const [accent]=palettes[slot.theme]||palettes.classic;
    const frame=uid('frame',slot.id);
    return `<svg class="game-emblem" viewBox="0 0 320 180" role="img" aria-label="${slot.title}">
      ${background(slot.theme,slot.id)}
      <g transform="translate(108 38)">${motif(slot)}</g>
      <defs><linearGradient id="${frame}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".85"/><stop offset=".4" stop-color="${accent}" stop-opacity=".25"/><stop offset="1" stop-color="#fff" stop-opacity=".05"/></linearGradient></defs>
      <rect x="5" y="5" width="310" height="170" rx="24" fill="none" stroke="url(#${frame})" stroke-width="6"/>
      <path d="M20 158q140-28 280-6" stroke="#fff" stroke-opacity=".22" stroke-width="18" fill="none"/>
    </svg>`;
  }

  function symbol(name,{size=64}={}){
    const body=symbolPaths[name]||`<rect x="12" y="12" width="40" height="40" rx="10" fill="#94a3b8"/><text x="32" y="40" text-anchor="middle" font-size="22" fill="#0f172a">${name.slice(0,2)}</text>`;
    return `<svg class="symbol-svg" viewBox="0 0 64 64" width="${size}" height="${size}" aria-hidden="true">${body}</svg>`;
  }

  return {emblem,symbol,palettes};
})();

if(typeof module!=='undefined')module.exports=GameArt;
