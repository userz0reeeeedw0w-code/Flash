'use strict';

const CasinoAudio=(()=> {
 let context,master,musicGain,timer,playing=false,profile='classic';
 const profiles={
   classic:{tempo:2600,chords:[[220,277,330],[196,247,294],[175,220,262],[208,262,311]],wave:'triangle',gain:.045},
   olympus:{tempo:3100,chords:[[196,247,294],[220,262,330],[175,220,262],[147,185,220]],wave:'sine',gain:.055},
   fishing:{tempo:3400,chords:[[165,208,247],[147,185,233],[131,165,208],[175,220,262]],wave:'triangle',gain:.048},
   candy:{tempo:2300,chords:[[262,330,392],[233,294,349],[208,262,330],[247,312,370]],wave:'square',gain:.032},
   cluster:{tempo:2400,chords:[[262,330,392],[220,277,330],[196,247,294],[233,294,349]],wave:'triangle',gain:.04}
 };

 function ensure(){
  if(!context){
   context=new (window.AudioContext||window.webkitAudioContext)();
   master=context.createGain();master.gain.value=.82;master.connect(context.destination);
   musicGain=context.createGain();musicGain.gain.value=.04;musicGain.connect(master);
  }
  return context;
 }
 function tone(freq,start,duration,wave='sine',destination,gain=.16){
  const osc=context.createOscillator(),env=context.createGain();
  osc.type=wave;osc.frequency.setValueAtTime(freq,start);
  env.gain.setValueAtTime(.0001,start);env.gain.linearRampToValueAtTime(gain,start+.04);
  env.gain.exponentialRampToValueAtTime(.0001,start+duration);
  osc.connect(env);env.connect(destination||master);osc.start(start);osc.stop(start+duration+.05);
 }
 function noise(duration,frequency,gain=.14){
  const size=Math.floor(context.sampleRate*duration),buffer=context.createBuffer(1,size,context.sampleRate),data=buffer.getChannelData(0);
  for(let i=0;i<size;i++)data[i]=(Math.random()*2-1)*(1-i/size);
  const source=context.createBufferSource(),filter=context.createBiquadFilter(),env=context.createGain();
  source.buffer=buffer;filter.type='bandpass';filter.frequency.value=frequency;
  env.gain.value=gain;source.connect(filter);filter.connect(env);env.connect(master);source.start();
 }
 function schedule(){
  clearInterval(timer);const config=profiles[profile]||profiles.classic;let index=0;
  timer=setInterval(()=>{
   const chord=config.chords[index++%config.chords.length],time=context.currentTime;
   chord.forEach((freq,i)=>tone(freq,time+i*.06,config.tempo/1000+.7,config.wave,musicGain,config.gain/(i+1)));
   tone(chord[0]/2,time,config.tempo/1000+1,'sine',musicGain,config.gain*.8);
  },config.tempo);
 }
 function setTheme(next){profile=profiles[next]?next:'classic';if(playing)schedule();}
 function toggleMusic(){
  if(playing){clearInterval(timer);playing=false;if(musicGain)musicGain.gain.value=0;return false;}
  ensure();context.resume();playing=true;musicGain.gain.value=.04;schedule();return true;
 }
 function sfx(name){
  try{
   ensure();context.resume();const time=context.currentTime;
   if(name==='spin'){noise(.28,900,.07);for(let i=0;i<8;i++)tone(280+i*45,time+i*.03,.08,'square',master,.035);}
   else if(name==='stop')tone(180+Math.random()*50,time,.11,'square',master,.09);
   else if(name==='tumble'){noise(.13,1600,.06);tone(520,time,.1,'triangle',master,.08);}
   else if(name==='multiplier'){[784,988,1175,1568].forEach((freq,i)=>tone(freq,time+i*.06,.18,'triangle',master,.11));}
   else if(name==='collect'){noise(.35,700,.12);[392,523,659].forEach((freq,i)=>tone(freq,time+i*.07,.22,'sine',master,.1));}
   else if(name==='scatter'){[1047,1319,1568].forEach((freq,i)=>tone(freq,time+i*.09,.34,'sine',master,.1));}
   else if(name==='expand'){tone(180,time,.4,'sawtooth',master,.07);tone(90,time+.05,.45,'sine',master,.09);}
   else if(name==='win')[523,659,784,1047].forEach((freq,i)=>tone(freq,time+i*.08,.31,'triangle',master,.13));
   else if(name==='big')for(let i=0;i<15;i++)tone(i%2?784:1047,time+i*.07,.16,'square',master,.07);
   else tone(190,time,.13,'square',master,.07);
  }catch(error){}
 }
 return {toggleMusic,sfx,setTheme};
})();
