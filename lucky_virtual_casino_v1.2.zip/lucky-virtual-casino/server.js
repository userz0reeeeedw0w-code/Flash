const path=require('path');
const express=require('express');
const routes=require('./src/routes');
const db=require('./src/db');

const app=express();
app.disable('x-powered-by');
app.use(express.json({limit:'100kb'}));
app.use((_req,res,next)=>{
 res.setHeader('X-Content-Type-Options','nosniff');
 res.setHeader('Referrer-Policy','no-referrer');
 res.setHeader('X-Frame-Options','SAMEORIGIN');
 res.setHeader('Content-Security-Policy',"default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; connect-src 'self'; media-src 'self'");
 next();
});

const buckets=new Map();
function rateLimit(key,limit,windowMs){
 const now=Date.now(),bucket=buckets.get(key);
 if(!bucket||now>bucket.reset)return {allowed:true,reset:now+windowMs,count:1};
 bucket.count+=1;return {allowed:bucket.count<=limit,reset:bucket.reset,count:bucket.count};
}
setInterval(()=>{const now=Date.now();for(const [key,bucket] of buckets)if(now>bucket.reset)buckets.delete(key)},60000).unref();

app.use('/api',(req,res,next)=>{
 const minute=Math.floor(Date.now()/60000);
 const key=`${req.ip}:${minute}`;
 const check=rateLimit(key,req.path.startsWith('/auth/')?12:240,60000);
 if(!check.allowed)return res.status(429).json({error:'Слишком много запросов. Попробуйте позже.'});
 next();
});

app.use(express.static(path.join(__dirname,'public'),{maxAge:'1h',setHeaders:(res,path)=>{if(path.endsWith('.html'))res.setHeader('Cache-Control','no-cache')}}));
app.use('/api',routes);
app.get(/^\/(?!api\/).*/,(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.use((error,_req,res,_next)=>{console.error(error);res.status(500).json({error:'Внутренняя ошибка сервера'})});

const port=Number(process.env.PORT||3000),host=process.env.HOST||'0.0.0.0';
app.listen(port,host,()=>console.log(`Lucky Virtual Casino demo: http://localhost:${port}\nJSON DB: ${db.DB_FILE}`));
