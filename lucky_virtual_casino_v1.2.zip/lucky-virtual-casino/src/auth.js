const crypto = require('crypto');
const db = require('./db');

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  return `${salt}:${crypto.scryptSync(password, salt, 64).toString('hex')}`;
}

function verifyPassword(password, stored) {
  const [salt, expected] = stored.split(':');
  const actual = crypto.scryptSync(password, salt, 64);
  const target = Buffer.from(expected, 'hex');
  return actual.length === target.length && crypto.timingSafeEqual(actual, target);
}

function createUser(username, password) {
  const cleanName = String(username || '').trim();
  if (!/^[A-Za-z0-9_]{3,20}$/.test(cleanName)) throw new Error('Логин: 3–20 символов, буквы, цифры и _');
  if (String(password || '').length < 6) throw new Error('Пароль должен быть не короче 6 символов');
  if (db.data.users.some((user) => user.username.toLowerCase() === cleanName.toLowerCase())) {
    throw new Error('Такой логин уже занят');
  }
  const user = {
    id: crypto.randomUUID(), username: cleanName, password: hashPassword(password),
    balance: 5000, xp: 0, level: 1, wagered: 0, won: 0, spinsCount: 0,
    lastDailyAt: 0, lastFaucetAt: 0, createdAt: Date.now()
  };
  db.data.users.push(user);
  addTransaction(user.id, 5000, 'welcome', 'Стартовый виртуальный бонус');
  db.save();
  return user;
}

function createSession(userId) {
  const token = crypto.randomBytes(32).toString('hex');
  db.data.sessions[token] = { userId, createdAt: Date.now(), lastSeen: Date.now() };
  db.save();
  return token;
}

function getUserByToken(token) {
  const session = db.data.sessions[token];
  if (!session) return null;
  session.lastSeen = Date.now();
  return db.data.users.find((user) => user.id === session.userId) || null;
}

function publicUser(user) {
  if (!user) return null;
  return {
    id: user.id, username: user.username, balance: round(user.balance), xp: Math.floor(user.xp),
    level: user.level, nextLevelXp: user.level * 1000, wagered: round(user.wagered),
    won: round(user.won), spinsCount: user.spinsCount,
    canClaimDaily: Date.now() - user.lastDailyAt > 72000000,
    canClaimFaucet: Date.now() - user.lastFaucetAt > 3600000
  };
}

function addTransaction(userId, amount, type, description) {
  db.data.transactions.unshift({ id: crypto.randomUUID(), userId, amount: round(amount), type, description, at: Date.now() });
  if (db.data.transactions.length > 20000) db.data.transactions.length = 20000;
}

function authenticate(required = true) {
  return (req, res, next) => {
    const header = req.get('Authorization') || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : req.query.token;
    req.user = getUserByToken(token);
    req.token = token;
    if (!req.user && required) return res.status(401).json({ error: 'Требуется вход' });
    next();
  };
}

function round(value) { return Math.round(Number(value || 0) * 100) / 100; }

module.exports = {
  createUser, createSession, getUserByToken, verifyPassword,
  publicUser, addTransaction, authenticate
};
