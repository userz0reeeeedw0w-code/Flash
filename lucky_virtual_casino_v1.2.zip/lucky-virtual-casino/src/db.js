const fs = require('fs');
const path = require('path');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

const defaultData = () => ({
  meta: { createdAt: new Date().toISOString(), version: 1 },
  users: [],
  sessions: {},
  transactions: [],
  spins: [],
  bonuses: [],
  winners: [],
  activeGames: {}
});

let data;
try {
  data = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
} catch {
  data = defaultData();
}

for (const [key, value] of Object.entries(defaultData())) {
  if (data[key] === undefined) data[key] = value;
}

function persist() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const temporary = `${DB_FILE}.${process.pid}.tmp`;
  fs.writeFileSync(temporary, JSON.stringify(data, null, 2));
  fs.renameSync(temporary, DB_FILE);
}

function save() {
  if (save.timer) return;
  save.timer = setTimeout(() => {
    save.timer = null;
    try { persist(); } catch (error) { console.error('Database persistence failed:', error); }
  }, 25);
}

function saveNow() {
  clearTimeout(save.timer);
  save.timer = null;
  persist();
}

process.on('exit', saveNow);
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => { saveNow(); process.exit(0); });

module.exports = {
  get data() { return data; },
  save,
  saveNow,
  DB_FILE
};
