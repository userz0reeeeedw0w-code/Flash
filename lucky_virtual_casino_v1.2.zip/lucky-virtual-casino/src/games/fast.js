const crypto = require('crypto');

function validateBet(bet) {
  const value = Math.round(Number(bet) * 100) / 100;
  if (!Number.isFinite(value) || value < 10 || value > 5000) throw new Error('Ставка должна быть от 10 до 5000 VGC');
  return value;
}

function dice(bet, target) {
  const cleanBet = validateBet(bet);
  const cleanTarget = Math.min(98, Math.max(2, Math.floor(Number(target) || 50)));
  const chance = cleanTarget;
  const roll = crypto.randomInt(0, 10001) / 100;
  const win = roll < chance / 100;
  const payout = round(win ? cleanBet * 99 / chance : 0);
  return { game:'dice', roll, target:cleanTarget, chance, multiplier:round(99/chance), payout:round(payout - cleanBet), totalReturn:payout };
}

function coinflip(bet, side) {
  const cleanBet = validateBet(bet);
  const chosen = side === 'tails' ? 'tails' : 'heads';
  const result = crypto.randomInt(2) ? 'heads' : 'tails';
  const won = result === chosen;
  return { game:'coinflip', chosen, result, won, payout:won ? cleanBet * .97 : -cleanBet, totalReturn:won ? cleanBet*1.97 : 0 };
}

function wheel(bet) {
  const cleanBet=validateBet(bet);
  const table=[{x:0,w:28},{x:.5,w:22},{x:1.2,w:18},{x:0,w:10},{x:1.8,w:9},{x:0,w:4},{x:3,w:5},{x:0,w:2},{x:5,w:2}];
  let ticket=crypto.randomInt(10000), index=0;
  for(let i=0;i<table.length;i++){ticket-=table[i].w;if(ticket<0){index=i;break;}}
  const multiplier=table[index].x;
  return {game:'wheel',index,multiplier,payout:round(cleanBet*(multiplier-1)),totalReturn:round(cleanBet*multiplier)};
}

function rocket(bet,cashoutTarget){
  const cleanBet=validateBet(bet);
  const target=Math.max(1.01,Math.min(1000,Number(cashoutTarget)||2));
  const crash=Math.max(1,Math.floor((99/(100-crypto.randomInt(10000)))*100)/100);
  const won=crash>=target;
  return {game:'rocket',crash,target,won,payout:won?round(cleanBet*(target-1)):-cleanBet,totalReturn:won?round(cleanBet*target):0};
}

function startMines(userId,bet,mines){
  const cleanBet=validateBet(bet);
  const count=Math.min(24,Math.max(1,Math.floor(mines||3)));
  const positions=Array.from({length:25},(__,i)=>i);
  for(let i=positions.length-1;i>0;i--){const j=crypto.randomInt(i+1);[positions[i],positions[j]]=[positions[j],positions[i]];}
  return {game:'mines',userId,bet:cleanBet,mines:count,minePositions:positions.slice(0,count),revealed:[],finished:false};
}

function cashoutMultiplier(mines,revealed){return Math.round((product(25,revealed.length,mines)*.98)*10000)/10000;}
function round(value){return Math.round(Number(value||0)*100)/100;}
function product(total,taken,mines){let value=1;for(let index=0;index<taken;index++)value*=(total-index)/(total-mines-index);return value;}

module.exports={dice,coinflip,wheel,rocket,startMines,cashoutMultiplier,validateBet};
