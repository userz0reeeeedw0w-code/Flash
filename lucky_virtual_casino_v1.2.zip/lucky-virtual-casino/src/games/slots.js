const crypto = require('crypto');

const S = {
  cherry: { icon:'🍒', name:'Черешня' },
  lemon: { icon:'🍋', name:'Лимон' },
  grape: { icon:'🍇', name:'Виноград' },
  bell: { icon:'🔔', name:'Колокол' },
  star: { icon:'⭐', name:'Звезда', wild:true },
  diamond: { icon:'💎', name:'Алмаз' },
  seven: { icon:'7️⃣', name:'Семёрка' },
  scarab: { icon:'🪲', name:'Скарабей' },
  eye: { icon:'👁️', name:'Око Ра', scatter:true },
  phoenix: { icon:'🔥', name:'Феникс', wild:true },
  moon: { icon:'🌙', name:'Луна', scatter:true },
  wolf: { icon:'🐺', name:'Волк' },
  dragon: { icon:'🐉', name:'Дракон', wild:true },
  pearl: { icon:'🫧', name:'Жемчуг' },
  candy: { icon:'🍭', name:'Карамель' },
  robot: { icon:'🤖', name:'Робот' },
  tiger: { icon:'🐯', name:'Тигр' },
  snowflake: { icon:'❄️', name:'Лёд' },
  crown: { icon:'👑', name:'Корона', wild:true },
  crystal: { icon:'🔮', name:'Кристалл' },
  coin: { icon:'🪙', name:'Монета' },
  ring: { icon:'💍', name:'Кольцо' },
  goblet: { icon:'🏆', name:'Кубок' },
  hourglass: { icon:'⏳', name:'Песочные часы' },
  laurel: { icon:'🌿', name:'Лавр' },
  orb: { icon:'🟣', name:'Орб множителя' },
  temple: { icon:'🏛️', name:'Храм', scatter:true },
  fish: { icon:'🐟', name:'Рыба' },
  bass: { icon:'🐠', name:'Большая рыба' },
  rodman: { icon:'🎣', name:'Рыболов', wild:true },
  buoy: { icon:'🛟', name:'Спасательный круг', scatter:true },
  book: { icon:'📕', name:'Книга тайн', wild:true, scatter:true },
  moneybag: { icon:'💰', name:'Мешок денег' },
  sheriff: { icon:'⭐', name:'Шериф', wild:true },
  bull: { icon:'🐂', name:'Бык' },
  eagle: { icon:'🦅', name:'Орёл' },
  cactus: { icon:'🌵', name:'Кактус' }
};

function rand(maxExclusive) {
  return crypto.randomInt(0, maxExclusive);
}

function random() {
  return crypto.randomInt(0, 1000000) / 1000000;
}

function buildStrip(weights) {
  const strip = [];
  for (const [symbol, weight] of Object.entries(weights)) {
    for (let i = 0; i < weight; i++) strip.push(symbol);
  }
  for (let i = strip.length - 1; i > 0; i--) {
    const j = rand(i + 1);
    [strip[i], strip[j]] = [strip[j], strip[i]];
  }
  return strip;
}

function gridFromStrips(config) {
  return Array.from({ length: config.reels }, () => {
    const start = rand(config.stripLength);
    return Array.from({ length: config.rows }, (__, row) => config.strips[start + row].id);
  });
}

const slots = [
  slot('aurora-fruits', 'Aurora Fruits', 'classic', { type:'lines', reels:5, rows:3, rtp:.962, volatility:'low',
    symbols:{cherry:[8,[1,3,10]],lemon:[8,[1,3,10]],grape:[6,[2,5,18]],bell:[5,[3,8,25]],star:[4,[0,10,50]],seven:[2,[5,20,100]]},
    features:['Wild Star','Стабильные частые выплаты'], payoutScale:1.9 }),
  slot('pharaohs-ember', "Pharaoh's Ember", 'egypt', { type:'lines', reels:5, rows:3, rtp:.967, volatility:'high',
    symbols:{scarab:[8,[1,4,12]],eye:[1,[3,10,30]],diamond:[5,[4,12,40]],seven:[3,[6,25,80]],phoenix:[3,[0,15,75]],star:[2,[2,5,15]]},
    features:['Расширяющийся Phoenix Wild','Free Spins'], expandingWild:true, expandingSymbols:['phoenix'], freeSpinsOnly:true, payoutScale:.13 }),
  slot('neon-fortune', 'Neon Fortune', 'cyber', { type:'ways', reels:5, rows:3, rtp:.965, volatility:'medium',
    symbols:{robot:[8,[1,4,14]],diamond:[6,[3,9,28]],bell:[5,[4,11,35]],seven:[3,[8,22,70]],star:[4,[0,8,45]],candy:[4,[2,6,18]]}, features:['Any Ways','Neon Multipliers'], payoutScale:1.75, wayDivisor:160 }),
  slot('wolf-moon-gold', 'Wolf Moon Gold', 'nature', { type:'lines', reels:5, rows:3, rtp:.963, volatility:'high',
    symbols:{wolf:[8,[2,6,20]],moon:[1,[4,12,35]],tiger:[5,[5,15,50]],seven:[3,[8,25,90]],star:[4,[0,10,60]],grape:[4,[1,4,12]]}, features:['Full Moon Free Spins','x3 Wild'], payoutScale:.44 }),
  slot('dragon-vault', 'Dragon Vault', 'fantasy', { type:'coins', reels:5, rows:3, rtp:.968, volatility:'very-high',
    symbols:{coin:[10],dragon:[5],diamond:[4],seven:[3],crown:[3],crystal:[3]}, features:['Hold & Win','Grand Jackpot Chance'], payoutScale:2.6 }),
  slot('ocean-pearls', 'Ocean Pearls', 'water', { type:'lines', reels:5, rows:3, rtp:.959, volatility:'medium',
    symbols:{pearl:[8,[1,4,12]],snowflake:[7,[2,6,16]],star:[5,[3,9,30]],seven:[3,[6,18,65]],phoenix:[4,[0,12,55]],bell:[4,[2,7,22]]}, features:['Tidal Respins','Scatter Pearls'], payoutScale:.38 }),
  slot('sugar-burst', 'Sugar Burst', 'sweet', { type:'cluster', reels:6, rows:5, rtp:.966, volatility:'medium',
    symbols:{candy:[9],cherry:[8],lemon:[8],grape:[7],bell:[5],star:[3]}, features:['Cluster Pays','Cascade Wins','до x10'], clusterDivisor:6 }),
  slot('cyber-coins', 'Cyber Coins', 'cyber', { type:'lines', reels:5, rows:3, rtp:.961, volatility:'low',
    symbols:{coin:[9,[1,3,8]],robot:[7,[2,5,15]],diamond:[5,[4,10,28]],seven:[3,[6,18,60]],star:[5,[0,8,40]],bell:[4,[2,6,18]]}, features:['Frequent Wilds','Low Volatility'], payoutScale:1.25 }),
  slot('jungle-kings', 'Jungle Kings', 'nature', { type:'ways', reels:6, rows:4, rtp:.964, volatility:'high',
    symbols:{tiger:[9,[1,3,10]],wolf:[8,[2,5,14]],grape:[7,[3,7,20]],seven:[4,[6,15,48]],crown:[4,[0,12,65]],star:[4,[1,4,12]]}, features:['4096 Ways','King Crown Wild'], payoutScale:4.5, wayDivisor:240 }),
  slot('ice-wilds', 'Ice Wilds', 'winter', { type:'lines', reels:5, rows:3, rtp:.958, volatility:'medium',
    symbols:{snowflake:[9,[1,3,9]],pearl:[7,[2,5,14]],star:[5,[4,10,30]],seven:[3,[6,20,68]],phoenix:[4,[0,10,52]],diamond:[4,[3,8,24]]}, features:['Frozen Wild','Free Spins'], payoutScale:.42 }),
  slot('golden-scarab-ways', 'Golden Scarab Ways', 'egypt', { type:'ways', reels:5, rows:4, rtp:.967, volatility:'high',
    symbols:{scarab:[9,[1,4,12]],eye:[1,[0,0,20]],diamond:[5,[4,10,32]],seven:[3,[8,22,72]],phoenix:[4,[0,12,58]],crown:[4,[2,8,25]]}, features:['1024 Ways','Sticky Bonus Symbols'], wayDivisor:7800, payoutScale:2.1 }),
  slot('crystal-tumble','Crystal Tumble','magic',{type:'cluster',reels:7,rows:5,rtp:.969,volatility:'very-high',symbols:{crystal:[10],star:[8],diamond:[8],bell:[7],seven:[4],dragon:[3]},features:[],clusterDivisor:560}),
  slot('stormpeak-gates','Stormgate Super Scatter','myth',{type:'payAnywhere',reels:6,rows:5,rtp:.965,volatility:'very-high',
    symbols:{ring:[14],goblet:[11],hourglass:[10],laurel:[9],bolt:[8],crown:[4],orb:[3],temple:[2]},
    values:{ring:.55,goblet:.85,hourglass:1.3,laurel:2,bolt:4,crown:12},multiplierSymbol:'orb',
    features:['Pay Anywhere','Tumble','Множители до x50'],payDivisor:24000}),
  slot('bass-bounty','Halloween Bass II','halloween',{type:'collect',reels:5,rows:3,rtp:.966,volatility:'high',
    symbols:{fish:[10,[1,3,10]],bass:[7,[2,6,18]],crown:[4,[4,12,40]],rodman:[4,[0,10,50]],buoy:[2,[4,20,100]],ring:[5,[2,6,20]]},
    features:['Fisherman Collect','Free Spins','Золотые рыбы'],payoutScale:.31}),
  slot('book-of-nile-secrets','Book of Nile Secrets','egypt',{type:'lines',reels:5,rows:3,rtp:.966,volatility:'high',
    symbols:{book:[2,[4,40,200]],eye:[6,[2,8,30]],scarab:[6,[2,7,24]],phoenix:[3,[4,18,80]],crown:[3,[5,22,100]],seven:[3,[6,25,90]]},
    features:['Expanding Book','Free Spins'],expandingWild:true,expandingSymbols:['book'],freeSpinsOnly:true,payoutScale:.016}),
  slot('western-money-rails','Western Money Rails','west',{type:'coins',reels:5,rows:3,rtp:.967,volatility:'high',
    symbols:{moneybag:[10],sheriff:[5],safe:[4],seven:[3],crown:[3],cactus:[3]},features:['Money Collect','Hold & Win'],payoutScale:3.7}),
  slot('thunder-herd','Thunder Herd','nature',{type:'ways',reels:6,rows:4,rtp:.964,volatility:'high',
    symbols:{bull:[9,[1,4,14]],eagle:[8,[2,5,16]],wolf:[7,[3,8,22]],tiger:[5,[5,15,45]],crown:[4,[0,14,70]],star:[4,[1,5,15]]},
    features:['4096 Ways','Thunder Wild'],payoutScale:4.2,wayDivisor:420}),
  slot('star-reels-respin','Star Reels Respin','classic',{type:'respin',reels:5,rows:3,rtp:.962,volatility:'medium',
    symbols:{seven:[4,[5,20,80]],diamond:[5,[4,14,50]],bell:[6,[3,10,32]],grape:[7,[2,7,22]],cherry:[8,[1,4,12]],star:[4,[0,0,0]]},
    features:['Expanding Wilds','Sticky Respin'],payoutScale:.10}),
  slot('candy-rain','Sugar Vault 1000','sweet',{type:'payAnywhere',reels:6,rows:5,rtp:.966,volatility:'high',
    symbols:{cherry:[13],lemon:[12],grape:[10],bell:[9],crown:[5],orb:[3],temple:[2]},
    values:{cherry:.5,lemon:.75,grape:1.1,bell:1.7,crown:8},multiplierSymbol:'orb',
    features:['Pay Anywhere','Cascade','Сахарные множители'],payDivisor:24000}),
  slot('harvest-bonanza','Harvest Bonanza','classic',{type:'payAnywhere',reels:6,rows:5,rtp:.965,volatility:'high',
    symbols:{cherry:[13],lemon:[12],grape:[11],bell:[8],seven:[5],orb:[3],temple:[2]},
    values:{cherry:.45,lemon:.7,grape:1,bell:1.6,seven:6},multiplierSymbol:'orb',
    features:['Pay Anywhere','Tumble','Урожайные множители'],payDivisor:3600,minCount:7})
];


function slotThemeKey(theme){return({myth:'myth',fishing:'halloween',halloween:'halloween',sweet:'sweet',classic:'classic'})[theme]||theme;}
function slot(id, title, theme, config) {
  config.stripLength = Object.values(config.symbols).reduce((sum, item) => sum + item[0], 0);
  config.strips = Array.from({ length: config.reels }, () => buildStrip(Object.fromEntries(
    Object.entries(config.symbols).map(([symbol, item]) => [symbol, item[0]])
  )).map((symbol, index) => ({ id:index % config.stripLength, symbol })));
  config.wildSymbols = Object.keys(config.symbols).filter(key => S[key]?.wild);
  config.scatterSymbol = Object.keys(config.symbols).find(key => S[key]?.scatter) || null;
  const palettes={myth:['#38bdf8','#1d4ed8'],halloween:['#fb923c','#4c1d95'],sweet:['#f472b6','#9333ea'],classic:['#f59e0b','#b91c1c']};
  const [from,to]=palettes[slotThemeKey(config.theme)]||['#60a5fa','#7c3aed'];
  config.presentation={
    art:id,
    animation:config.type==='payAnywhere'?'tumble':config.type==='collect'?'collect':config.type==='respin'?'sticky-respin':'reels',
    backdrop:config.theme,
    accent:from,
    accent2:to,
    soundProfile:config.type==='payAnywhere'?'olympus':config.type==='collect'?'fishing':config.type==='cluster'?'candy':'classic'
  };
  return { id, title, theme, ...config };
}

function symbolAt(slotConfig, reel, row) {
  const strip = slotConfig.strips[reel];
  const position = (rand(slotConfig.stripLength) + row) % strip.length;
  return strip[position].symbol;
}

function makeGrid(slotConfig) {
  return Array.from({ length: slotConfig.reels }, (__, reel) => {
    const strip = slotConfig.strips[reel];
    const offset = rand(strip.length);
    return Array.from({ length: slotConfig.rows }, (__, row) => strip[(offset + row) % strip.length].symbol);
  });
}

const LINES_5X3 = [
  [1,1,1,1,1],[0,0,0,0,0],[2,2,2,2,2],[0,1,2,1,0],[2,1,0,1,2],
  [0,0,1,2,2],[2,2,1,0,0],[1,0,0,0,1],[1,2,2,2,1],[0,1,1,1,0],
  [2,1,1,1,2],[1,1,0,1,1],[1,1,2,1,1],[0,1,0,1,0],[2,1,2,1,2]
];

function expandSpecials(grid, slotConfig, freeSpin = false) {
  const events = [];
  if (!slotConfig.expandingWild || !slotConfig.expandingSymbols?.length || (slotConfig.freeSpinsOnly && !freeSpin)) return events;
  for (let reel = 0; reel < grid.length; reel++) {
    if (grid[reel].some((symbol) => slotConfig.wildSymbols.includes(symbol))) {
      const wild = grid[reel].find((symbol) => slotConfig.wildSymbols.includes(symbol));
      grid[reel] = grid[reel].map(() => wild);
      events.push({ kind:'expand', reel, symbol:wild });
    }
  }
  if (freeSpin && slotConfig.id === 'ice-wilds') {
    grid.forEach((column, reel) => column.forEach((symbol, row) => {
      if (symbol === 'star') events.push({ kind:'sticky', reel, row });
    }));
  }
  return events;
}

function evaluateLines(grid, config, bet, multiplier = 1) {
  const lines = config.reels === 5 && config.rows === 3 ? LINES_5X3 : [];
  const wins = [];
  for (let index = 0; index < lines.length; index++) {
    const path = lines[index];
    const symbolsOnLine = path.map((row, reel) => grid[reel][row]);
    let first;
    let count = 0;
    for (const symbol of symbolsOnLine) {
      if (symbol === config.scatterSymbol) break;
      if (!first && !config.wildSymbols.includes(symbol)) first = symbol;
      if (symbol === first || config.wildSymbols.includes(symbol)) count++;
      else break;
    }
    const definition = config.symbols[first];
    if (first && count >= 3 && definition?.[1]?.[count - 3]) {
      const amount = round(definition[1][count - 3] * bet * multiplier * (config.payoutScale || 1) / Math.max(lines.length, 1));
      if (amount > 0) wins.push({ line:index, symbol:first, count, amount, positions:path.slice(0,count).map((row,reel)=>({reel,row})) });
    }
  }
  return wins;
}

function evaluateWays(grid, config, bet, multiplier = 1) {
  const wins = [];
  for (const [symbol, definition] of Object.entries(config.symbols)) {
    if (config.wildSymbols.includes(symbol) || symbol === config.scatterSymbol) continue;
    let ways = 1;
    let reels = 0;
    for (const column of grid) {
      const matches = column.filter((cell) => cell === symbol || config.wildSymbols.includes(cell)).length;
      const natural = column.filter((cell) => cell === symbol).length;
      if ((!natural && reels === 0) || !matches) break;
      ways *= matches;
      reels++;
    }
    if (reels >= 3 && definition[1]?.[reels - 3]) {
      const amount = round(definition[1][reels - 3] * bet * multiplier * (config.payoutScale || 1) * ways / (config.wayDivisor || config.reels * config.rows * 8));
      if (amount > 0) wins.push({ symbol, count:reels, ways, amount });
    }
  }
  return wins;
}

function evaluateClusters(grid, config, bet, multiplier = 1) {
  const visited = new Set();
  const wins = [];
  for (let reel = 0; reel < grid.length; reel++) {
    for (let row = 0; row < grid[reel].length; row++) {
      const key = `${reel}:${row}`;
      if (visited.has(key) || config.wildSymbols.includes(grid[reel][row])) continue;
      const symbol = grid[reel][row];
      const cells = [];
      const queue = [[reel,row]];
      visited.add(key);
      while (queue.length) {
        const [x,y] = queue.pop();
        cells.push({ reel:x,row:y });
        for (const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
          const nx=x+dx, ny=y+dy, nextKey=`${nx}:${ny}`;
          if (nx>=0&&ny>=0&&nx<grid.length&&ny<config.rows&&!visited.has(nextKey)&&
            (grid[nx][ny]===symbol||config.wildSymbols.includes(grid[nx][ny]))) {
            visited.add(nextKey); queue.push([nx,ny]);
          }
        }
      }
      if (cells.length >= 5) {
        const premium = ['seven','dragon','star'].includes(symbol);
        const value = Math.pow(cells.length - 4, 1.55) * (premium ? 1.8 : 1) * bet * multiplier / (config.clusterDivisor || (config.reels > 6 ? 150 : 65));
        wins.push({ symbol, count:cells.length, amount:round(value), positions:cells });
      }
    }
  }
  return wins;
}

function tumbleClusters(grid, config, bet) {
  let current = grid.map(column => [...column]);
  const events = [];
  let total = 0;
  for (let cascade = 0; cascade < 20; cascade += 1) {
    const wins = evaluateClusters(current, config, bet, 1 + cascade * .5);
    if (!wins.length) break;
    total += wins.reduce((sum, win) => sum + win.amount, 0);
    const removed = new Set(wins.flatMap(win => win.positions.map(pos => `${pos.reel}:${pos.row}`)));
    current = current.map((column, reel) => {
      const remaining = column.filter((__, row) => !removed.has(`${reel}:${row}`));
      while (remaining.length < config.rows) remaining.unshift(Object.keys(config.symbols)[rand(Object.keys(config.symbols).length)]);
      return remaining;
    });
    events.push({ cascade: cascade + 1, wins });
  }
  return { grid: current, total: round(total), events };
}

function playFreeSpins(config, bet, count, multiplier) {
  const rounds = [];
  let total = 0;
  let remaining = count;
  let guard = 0;
  while (remaining-- > 0 && guard++ < 50) {
    const grid = makeGrid(config);
    expandSpecials(grid, config, true);
    const wins = config.type==='ways'?evaluateWays(grid,config,bet,multiplier):evaluateLines(grid,config,bet,multiplier);
    const amount = wins.reduce((sum,win)=>sum+win.amount,0);
    total += amount;
    rounds.push({ grid, wins, amount:round(amount) });
    const scatters = grid.flat().filter(s=>s===config.scatterSymbol).length;
    if (scatters>=4 && rounds.length<25) remaining += 5;
  }
  return { rounds, total:round(total) };
}

function playLinesOrWays(slotConfig, bet) {
  const grid = makeGrid(slotConfig);
  const expansionEvents = expandSpecials(grid, slotConfig);
  const scatters = grid.flat().filter(s=>s===slotConfig.scatterSymbol);
  let wins = slotConfig.type==='ways'
    ? evaluateWays(grid,slotConfig,bet)
    : evaluateLines(grid,slotConfig,bet);
  let baseWin = wins.reduce((sum,win)=>sum+win.amount,0);
  let freeSpins = null;
  let totalWin = baseWin;

  if (scatters.length >= 3) {
    const count = scatters.length >= 5 ? 15 : scatters.length === 4 ? 10 : 8;
    const bonusMultiplier = slotConfig.id==='wolf-moon-gold'?3:2;
    freeSpins = playFreeSpins(slotConfig,bet,count,bonusMultiplier);
    totalWin += freeSpins.total;
  }
  return { grid, wins, expansionEvents, freeSpins, baseWin:round(baseWin), totalWin:round(totalWin) };
}


function evaluatePayAnywhere(grid, config, bet) {
  const flat = grid.flat();
  const wins=[];
  for(const [symbol,value] of Object.entries(config.values||{})) {
    const count=flat.filter(item=>item===symbol||config.wildSymbols.includes(item)).length;
    if(count>=(config.minCount||8)) {
      const amount=value*Math.pow(count-(config.minCount||8)+1,1.22)*bet/(config.payDivisor||9500);
      if(amount>0) wins.push({symbol,count,amount,positions:grid.flatMap((column,reel)=>column.map((cell,row)=>cell===symbol?{reel,row}:null).filter(Boolean))});
    }
  }
  return wins;
}

function randomPaySymbol(config){const keys=Object.keys(config.values);return keys[rand(keys.length)];}
function randomMultiplier(free){const options=[2,2,3,3,4,5,8,10,15,25,50];return options[rand(options.length)];}
function refillPayGrid(grid,config){return grid.map(column=>{const remaining=column.filter(symbol=>![...Object.keys(config.values),config.multiplierSymbol].includes(symbol));while(remaining.length<config.rows)remaining.unshift(rand(100)<3?config.scatterSymbol:randomPaySymbol(config));return remaining.slice(0,config.rows)});}

function tumblePayAnywhere(config,bet,free=false){
  let current=makeGrid(config),total=0,allMultipliers=[],events=[];
  for(let cascade=0;cascade<18;cascade++){
    const wins=evaluatePayAnywhere(current,config,bet);
    if(!wins.length)break;
    let cascadeAmount=wins.reduce((sum,win)=>sum+win.amount,0);
    let multiplier=1;
    if(cascade>0&&(free||rand(100)<Math.min(72,cascade*14))){
      const orbs=Array.from({length:free&&rand(3)<1?1+rand(2):1},()=>randomMultiplier(free));
      multiplier=orbs.reduce((sum,value)=>sum+value,0);allMultipliers.push(...orbs);
    }
    cascadeAmount=round(cascadeAmount*multiplier);total+=cascadeAmount;
    const removed=new Set(wins.flatMap(win=>win.positions.map(pos=>`${pos.reel}:${pos.row}`)));
    current=current.map((column,reel)=>column.filter((__,row)=>!removed.has(`${reel}:${row}`)));
    while(current.some(column=>column.length<config.rows))current=refillPayGrid(current,config);
    events.push({cascade:cascade+1,multiplier,wins,amount:cascadeAmount});
  }
  return {grid:current,total:round(total),events,multipliers:allMultipliers};
}

function playPayAnywhere(slotConfig,bet){
  const base=tumblePayAnywhere(slotConfig,bet);
  const scatters=base.grid.flat().filter(symbol=>symbol===slotConfig.scatterSymbol).length;
  let bonus=null;
  if(scatters>=4){
    const rounds=[];let remaining=6+(scatters>=6?2:0),guard=0,bonusTotal=0;
    while(remaining-->0&&guard++<30){const round=tumblePayAnywhere(slotConfig,bet,true);bonusTotal+=round.total;rounds.push(round)}
    bonus={rounds,total:round(bonusTotal)};
  }
  return {grid:base.grid,wins:base.events.flatMap(event=>event.wins),tumbleEvents:base.events,
    baseWin:base.total,multipliers:base.multipliers,freeSpins:bonus,totalWin:round(base.total+(bonus?.total||0))};
}

function playCollect(slotConfig,bet){
  const grid=makeGrid(slotConfig);
  expandSpecials(grid,slotConfig);
  const wins=evaluateLines(grid,slotConfig,bet);
  let baseWin=wins.reduce((sum,win)=>sum+win.amount,0),collectWin=0;
  const fishPositions=[];
  grid.forEach((column,reel)=>column.forEach((symbol,row)=>{
    if(['fish','bass'].includes(symbol))fishPositions.push({reel,row,value:round(bet*(symbol==='bass'?1+random()*19:.4+random()*7)/2700)});
  }));
  const fishermen=grid.flat().filter(symbol=>symbol==='rodman').length;
  if(fishermen&&fishPositions.length>=4){
    collectWin=round(fishPositions.reduce((sum,pos)=>sum+pos.value,0)*(1+(fishermen-1)*.5));
  }
  const scatters=grid.flat().filter(symbol=>symbol===slotConfig.scatterSymbol).length;
  let freeSpins=null;
  if(scatters>=3){
    const rounds=[];let total=0,count=scatters>=5?15:scatters===4?12:10;
    for(let index=0;index<count;index++){
      const roundGrid=makeGrid(slotConfig);const lineWins=evaluateLines(roundGrid,slotConfig,bet,1);
      const fishes=[];roundGrid.forEach((column,reel)=>column.forEach((symbol,row)=>{if(['fish','bass'].includes(symbol))fishes.push({reel,row,value:round(bet*(symbol==='bass'?1.5+random()*23:.5+random()*9)/3600)})}));
      const rods=roundGrid.flat().filter(symbol=>symbol==='rodman').length;
      const collected=rods?round(fishes.reduce((sum,pos)=>sum+pos.value,0)):0;
      const amount=round(lineWins.reduce((sum,win)=>sum+win.amount,0)+collected);total+=amount;
      rounds.push({grid:roundGrid,wins:lineWins,fish:fishes,collected,amount});
    }
    freeSpins={rounds,total:round(total)};
  }
  return {grid,wins,coinCells:fishPositions,collectEvent:collectWin?{collected:collectWin}:null,
    holdWin:collectWin?{collected:collectWin,total:round(collectWin)}:null,freeSpins,
    baseWin:round(baseWin+collectWin),totalWin:round(baseWin+collectWin+(freeSpins?.total||0))};
}

function playRespin(slotConfig,bet){
  const firstGrid=makeGrid(slotConfig);const expanded=[];
  firstGrid.forEach((column,index)=>{if(column.includes('star')){expanded.push(index);firstGrid[index]=column.map(()=>'star')}});
  const firstWins=evaluateLines(firstGrid,slotConfig,bet);
  const firstTotal=firstWins.reduce((sum,win)=>sum+win.amount,0);
  let secondGrid=firstGrid.map((column,index)=>expanded.includes(index)?column.map(()=>'star'):makeGrid({reels:1,rows:slotConfig.rows,stripLength:slotConfig.stripLength,strips:[slotConfig.strips[index]]})[0]);
  const secondWins=evaluateLines(secondGrid,slotConfig,bet);
  const secondTotal=secondWins.reduce((sum,win)=>sum+win.amount,0);
  return {grid:secondGrid,wins:[...firstWins,...secondWins],respins:[{grid:firstGrid,wins:firstWins,amount:round(firstTotal)},{grid:secondGrid,wins:secondWins,amount:round(secondTotal)}],
    expansionEvents:expanded.map(reel=>({kind:'expand',reel,symbol:'star'})),baseWin:round(firstTotal+secondTotal),totalWin:round(firstTotal+secondTotal)};
}

function playCoins(slotConfig,bet) {
  const grid = makeGrid(slotConfig);
  const coinCells=[];
  grid.forEach((column,reel)=>column.forEach((symbol,row)=>{
    if(slotConfig.symbols.moneybag?symbol==='moneybag':symbol==='coin'||crypto.randomInt(100)<3) coinCells.push({reel,row,value:round(bet*(slotConfig.payoutScale||1)*(0.3+random()*6)/30)});
  }));
  let bonus=0, jackpot=null;
  if(coinCells.length>=7){
    bonus=round(coinCells.reduce((sum,cell)=>sum+cell.value,0));
    if(crypto.randomInt(500)<2){jackpot='GRAND';bonus+=bet*100;}
    else if(crypto.randomInt(100)<8) bonus*=2;
  }
  return { grid, coinCells, holdWin:bonus>0?{collected:bonus,jackpot,total:round(bonus)}:null, totalWin:round(bonus) };
}

function round(value) { return Math.round(Number(value || 0) * 100) / 100; }

function spin(slotId, bet) {
  const slotConfig = slots.find(item=>item.id===slotId);
  if(!slotConfig) throw new Error('Слот не найден');
  bet=round(bet);
  if(!(bet>=10&&bet<=5000)) throw new Error('Ставка должна быть от 10 до 5000 VGC');
  let result;
  if(slotConfig.type==='cluster'){
    const grid=makeGrid(slotConfig);
    result=tumbleClusters(grid,slotConfig,bet);
    result.wins=result.events.flatMap(event=>event.wins);
    result.baseWin=result.total;result.totalWin=result.total;
  } else if(slotConfig.type==='coins') result=playCoins(slotConfig,bet);
  else if(slotConfig.type==='payAnywhere') result=playPayAnywhere(slotConfig,bet);
  else if(slotConfig.type==='collect') result=playCollect(slotConfig,bet);
  else if(slotConfig.type==='respin') result=playRespin(slotConfig,bet);
  else result=playLinesOrWays(slotConfig,bet);
  result.slotId=slotId; result.bet=bet; result.engine=slotConfig.type;
  return result;
}

function publicSlots() {
  return slots.map(({strips,...rest})=>{
    void strips;
    return { ...rest, symbols:Object.fromEntries(Object.entries(rest.symbols).map(([key,val])=>[key,{...S[key],weight:val[0]}])) };
  });
}

module.exports={slots,publicSlots,spin};
