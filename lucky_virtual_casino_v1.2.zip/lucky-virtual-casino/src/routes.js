const express=require('express');
const crypto=require('crypto');
const db=require('./db');
const authLib=require('./auth');
const slots=require('./games/slots');
const fast=require('./games/fast');
const router=express.Router();

router.post('/auth/register',(req,res)=>{
 try{
   const user=authLib.createUser(req.body.username,req.body.password);
   const token=authLib.createSession(user.id);
   res.json({token,user:authLib.publicUser(user)});
 }catch(error){res.status(400).json({error:error.message});}
});

router.post('/auth/login',(req,res)=>{
 const user=db.data.users.find(item=>item.username.toLowerCase()===String(req.body.username||'').trim().toLowerCase());
 if(!user||!authLib.verifyPassword(req.body.password,user.password)) return res.status(401).json({error:'Неверный логин или пароль'});
 const token=authLib.createSession(user.id);
 res.json({token,user:authLib.publicUser(user)});
});

router.post('/auth/logout',authLib.authenticate(false),(req,res)=>{if(req.token){delete db.data.sessions[req.token];db.save();}res.json({ok:true});});
router.get('/me',authLib.authenticate(),(req,res)=>res.json(authLib.publicUser(req.user)));
router.get('/slots',(_req,res)=>res.json(slots.publicSlots()));

function finishRound(req,res,result){
 const user=req.user,bet=result.bet;
 if(user.balance<bet)return res.status(400).json({error:'Недостаточно VGC'});
 const payout=Math.max(0,Number(result.totalReturn||result.totalWin||0));
 user.balance=round(user.balance-bet+payout);user.wagered+=bet;user.won+=payout;user.spinsCount++;
 user.xp+=bet*.1;while(user.xp>=user.level*1000){user.xp-=user.level*1000;user.level++;}
 authLib.addTransaction(user.id,payout-bet,'game',result.game||result.slotId);
 if(payout>bet&&bet>=50){db.data.winners.unshift({id:crypto.randomUUID(),username:user.username,game:result.game||result.slotId,amount:round(payout-bet),multiplier:round(payout/bet),at:Date.now()});db.data.winners.length=Math.min(db.data.winners.length,200);}
 db.save();
 res.json({...result,balance:user.balance,user:authLib.publicUser(user)});
}

router.post('/play/slots/:id',authLib.authenticate(),(req,res)=>{
 try{const result=slots.spin(req.params.id,req.body.bet);result.game=req.params.id;finishRound(req,res,result);}
 catch(error){res.status(400).json({error:error.message});}
});

router.post('/play/dice',authLib.authenticate(),(req,res)=>finishRound(req,res,{...fast.dice(req.body.bet,req.body.target),bet:fast.validateBet(req.body.bet)}));
router.post('/play/coin',authLib.authenticate(),(req,res)=>finishRound(req,res,{...fast.coinflip(req.body.bet,req.body.side),bet:fast.validateBet(req.body.bet)}));
router.post('/play/wheel',authLib.authenticate(),(req,res)=>finishRound(req,res,{...fast.wheel(req.body.bet),bet:fast.validateBet(req.body.bet)}));
router.post('/play/rocket',authLib.authenticate(),(req,res)=>finishRound(req,res,{...fast.rocket(req.body.bet,req.body.target),bet:fast.validateBet(req.body.bet)}));

router.post('/play/mines/start',authLib.authenticate(),(req,res)=>{
 try{
  const bet=fast.validateBet(req.body.bet);
  if(req.user.balance<bet)return res.status(400).json({error:'Недостаточно VGC'});
  const game=fast.startMines(req.user.id,bet,req.body.mines);
  db.data.activeGames[req.user.id]=game;
  req.user.balance=round(req.user.balance-bet);req.user.wagered+=bet;userXP(req.user,bet*.05);
  authLib.addTransaction(req.user.id,-bet,'mines-start','Открыта игра Mines');db.save();
  res.json({started:true,bet,mineCount:game.mines,revealed:game.revealed,balance:req.user.balance,currentMultiplier:1,nextMultiplier:fast.cashoutMultiplier(game.minePositions,1)});
 }catch(error){res.status(400).json({error:error.message})}
});

router.post('/play/mines/reveal',authLib.authenticate(),(req,res)=>{
 const game=db.data.activeGames[req.user.id];
 const tile=Number(req.body.tile);
 if(!game||game.finished||tile<0||tile>24||game.revealed.includes(tile))return res.status(400).json({error:'Активная игра не найдена или плитка недоступна'});
 game.revealed.push(tile);
 if(game.minePositions.includes(tile)){game.finished=true;delete db.data.activeGames[req.user.id];db.save();return res.json({hit:true,tile,balance:req.user.balance,lost:game.bet});}
 const next=fast.cashoutMultiplier(game.minePositions,game.revealed.length+1);
 if(next>=5000){return cashoutMines(req,res,true);}
 res.json({hit:false,tile,multiplier:fast.cashoutMultiplier(game.minePositions,game.revealed.length),nextMultiplier:next,safeLeft:25-game.mines-game.revealed.length});
});

router.post('/play/mines/cashout',authLib.authenticate(),(req,res)=>{
 const game=db.data.activeGames[req.user.id];
 if(!game||game.finished)return res.status(400).json({error:'Нет активной игры'});
 cashoutMines(req,res,false,game);
});

function cashoutMines(req,res,maxWin,providedGame){
 const game=providedGame||db.data.activeGames[req.user.id];
 const multiplier=maxWin?fast.cashoutMultiplier(game.minePositions,25-game.mines):fast.cashoutMultiplier(game.minePositions,game.revealed.length);
 const payout=round(game.bet*multiplier);req.user.balance=round(req.user.balance+payout);req.user.won+=payout;userXP(req.user,payout*.02);
 authLib.addTransaction(req.user.id,payout-game.bet,'mines-win',`Mines x${multiplier}`);
 if(payout>game.bet&&game.bet>=50)db.data.winners.unshift({id:crypto.randomUUID(),username:req.user.username,game:'mines',amount:round(payout-game.bet),multiplier,at:Date.now()});
 game.finished=true;delete db.data.activeGames[req.user.id];db.save();
 res.json({cashed:true,multiplier,bet:game.bet,payout,balance:req.user.balance,user:authLib.publicUser(req.user)});
}

router.post('/bonus/daily',authLib.authenticate(),(req,res)=>{
 if(Date.now()-req.user.lastDailyAt<72000000)return res.status(429).json({error:'Ежедневный бонус уже получен'});
 const options=[250,350,500,750,1000,1500,2500],amount=options[crypto.randomInt(options.length)];
 req.user.lastDailyAt=Date.now();req.user.balance=round(req.user.balance+amount);authLib.addTransaction(req.user.id,amount,'bonus','Ежедневный колесо-бонус');db.save();
 res.json({amount,message:`Вы получили ${amount} VGC`,user:authLib.publicUser(req.user)});
});

router.post('/bonus/faucet',authLib.authenticate(),(req,res)=>{
 if(Date.now()-req.user.lastFaucetAt<3600000)return res.status(429).json({error:'Виртуальный кран доступен раз в час'});
 req.user.lastFaucetAt=Date.now();req.user.balance=round(req.user.balance+250);authLib.addTransaction(req.user.id,250,'faucet','Виртуальные средства для теста');db.save();
 res.json({amount:250,user:authLib.publicUser(req.user)});
});

router.get('/wallet',authLib.authenticate(),(req,res)=>({
 balance:authLib.publicUser(req.user).balance,
 transactions:db.data.transactions.filter(item=>item.userId===req.user.id).slice(0,80)
}));

router.get('/feed',(_req,res)=>res.json(db.data.winners.slice(0,40)));
router.get('/leaderboard',(_req,res)=>res.json([...db.data.users].sort((a,b)=>b.won-a.won).slice(0,20).map(u=>({username:u.username,level:u.level,won:authLib.publicUser(u).won,wagered:authLib.publicUser(u).wagered}))));

function userXP(user,xp){user.xp+=xp;while(user.xp>=user.level*1000){user.xp-=user.level*1000;user.level++;}}
function round(value){return Math.round(Number(value||0)*100)/100;}

module.exports=router;
