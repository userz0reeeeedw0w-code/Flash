const assert=require('assert');
const slots=require('../src/games/slots');
const fast=require('../src/games/fast');
const art=require('../public/js/artwork');

assert.strictEqual(slots.slots.length>=20,true,'At least 20 slot engines expected');
for(const slot of slots.slots){
 assert.ok(slot.title&&slot.presentation?.animation&&slot.presentation?.soundProfile,`${slot.id} presentation metadata`);
 assert.ok(art.emblem(slot).includes('<svg'),`${slot.id} original emblem`);
 for(const symbol of Object.keys(slot.symbols))assert.ok(art.symbol(symbol).includes('<svg'),`${slot.id}/${symbol} vector symbol`);
 for(let index=0;index<30;index++){
  const result=slots.spin(slot.id,10);
  assert.strictEqual(Array.isArray(result.grid),true,`${slot.id} grid`);
  assert.strictEqual(result.grid.length,slot.reels,`${slot.id} reel count`);
  assert.ok(result.grid.every(column=>column.length===slot.rows),`${slot.id} row shape`);
  assert.ok(Number.isFinite(result.totalWin)&&result.totalWin>=0,`${slot.id} payout`);
 }
}

let returned=0;
for(let index=0;index<1500;index++)returned+=slots.spin('aurora-fruits',10).totalWin;
const rtp=returned/(1500*10);
assert.ok(rtp>.35&&rtp<1.75,`Unexpected sampled RTP: ${rtp}`);
assert.strictEqual(typeof fast.dice(10,50).totalReturn,'number');
assert.strictEqual(typeof fast.rocket(10,2).won,'boolean');
console.log(`QA OK: ${slots.slots.length} games, all emblems/symbols valid, sampled RTP ${(rtp*100).toFixed(1)}%`);
